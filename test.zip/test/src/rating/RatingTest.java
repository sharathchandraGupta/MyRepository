package rating;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.google.common.base.VerifyException;
import com.steadystate.css.parser.selectors.PseudoElementSelectorImpl;

import Reporting.Reports;
import modules.CustomerSearch;
import utils.DataManager;
import utils.RateWorkBook;
import utils.Reusable_Methods;
import utils.Parameters;

public class RatingTest {

	ExtentReports extent;
	ExtentTest test;
	public static WebDriver driver;

	String projPath = System.getProperty("user.dir");

	@BeforeTest
	public void initData() {
		extent = Reports.GetExtent();
		new DataManager("\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\TestData\\InputDataSheet.xlsx",
				"poc");
	}

	@BeforeClass
	// Launch the application thru IE browser
	public void launchApplication() throws InvalidFormatException, IOException, AWTException, InterruptedException {

		try {

			System.setProperty("webdriver.edge.driver",
					"\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\Browsers\\MicrosoftWebDriver.exe");
			driver = new EdgeDriver();
			driver.get("http://toaqpasdck02:8080/Express/default.aspx");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(5000);
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println("Failed to login");
			e.printStackTrace();
		}
	}

	// Call Login
	@Test 
	public void test() throws InterruptedException {

		// DataManager DM = new DataManager();
		Reusable_Methods RM = new Reusable_Methods(driver);
		Thread.sleep(2000);
		int rnunmber = DataManager.rowNumber;

		for (int row = 1; row < rnunmber; row++) {
			DataManager.readData(row);
			System.out.println("Execution Row:" + row);

			if (Parameters.flag.equalsIgnoreCase("Y")) {
				test = extent.createTest(Parameters.TCID, "");
				try {
					// Call Login
					System.out.println("Starated Login");
					DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
					Date date = new Date();
					DataManager.writeData(
							"\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\TestData\\InputDataSheet.xlsx",
							row, 35, dateFormat.format(date));
					System.out.println("Execution Start Time: " + dateFormat.format(date));
					
					test.pass("Enter the Login Details");
					modules.Login login = new modules.Login(driver);
					login.populateLogin();
					test.pass("Login Successfully");
					
					// Verfiy Page Dashboard
					boolean flag = RM.verify_PageTitle(driver, "Dashboard");
					try {
						Assert.assertEquals(flag, true);
						test.pass("Verify the dashboard page");
					} catch (AssertionError e) {
						// e.printStackTrace();
						test.fail("Failed to Login");
						System.out.println("Failed to Navigate to Dashboard page");
					}

					// Call Customer Search
					System.out.println("Starated CustomerSearch");
					test.pass("Enter the Customer details to search");
					modules.CustomerSearch customerSearch = new modules.CustomerSearch(driver);
					customerSearch.customerSearch();
					test.pass("Click on OK and Verfiy the Customer Page");

					// VerfiyCustomerPage
					flag = false;
					flag = RM.verify_PageTitle(driver, "Customer");
					try {
						Assert.assertEquals(flag, true);
						test.pass("Sucessfully Navigated to Customer Page");
					} catch (AssertionError e) {
						e.printStackTrace();
						test.fail("Failed to Navigate Customer Page");
						System.out.println("Failed to Navigate to Customer page");
					}

					// Call Customer Information
					System.out.println("Starated CustomerInformation");
					test.pass("Enter the customer details");
					modules.CustomerInformation customerInformation = new modules.CustomerInformation(driver);
					customerInformation.customerInformation();
					test.pass("Click on Next and Verfiy the Submission Page");
					
					// VerfiySubmissionPage
					flag = false;
					flag = RM.verify_PageTitle(driver, "Submission");
					try {
						Assert.assertEquals(flag, true);
						test.pass("Sucessfully Navigated to Submission Page");
					} catch (AssertionError e) {
						e.printStackTrace();
						test.fail("Failed to Navigate Submission Page");
						System.out.println("Failed to Navigate to Submission page");
					}

					// Call Submission
					test.pass("Enter the Submission details");
					modules.Submission submission = new modules.Submission(driver);
					submission.submission();
					test.pass("Click on Next and Verify the Business page");
					
					// VerfiyBusinessPage
					flag = false;
					flag = RM.verify_PageTitle(driver, "Business");
					try {
						Assert.assertEquals(flag, true);
						test.pass("Sucessfully Navigated to Business Page");
					} catch (AssertionError e) {
						e.printStackTrace();
						test.fail("Failed to Navigate Business Page");
						System.out.println("Failed to Navigate to Business page");
					}

					// Call Business Module
					test.pass("Enter the Business details");
					modules.Business Business = new modules.Business(driver);
					Business.business();
					test.pass("Click On Next and Verify the Location page");
					
					// Verfiy Location Page
					flag = false;
					flag = RM.verify_PageTitle(driver, "Location");
					try {

						Assert.assertEquals(flag, true);
						test.pass("Sucessfully Navigated to Location Page");
					} catch (AssertionError e) {
						e.printStackTrace();
						test.fail("Failed to Navigate Location Page");
						System.out.println("Failed to Navigate to Location page");
					}

					// Call Location
					test.pass("Enter the Location details");
					modules.Location Location = new modules.Location(driver);
					Location.location();
					test.pass("Click on Next and Verfiy the Premium Page");
					
					// VerfiyPremiumPage
					flag = false;
					flag = RM.verify_PageTitle(driver, "Premium");
					try {
						Assert.assertEquals(flag, true);
						test.pass("Sucessfully Navigated to Premium Page");
					} catch (AssertionError e) {
						e.printStackTrace();
						test.fail("Failed to Navigate Premium Page");
						System.out.println("Failed to Navigate to First Premium page");
					}

					// Call Coverage
					test.pass("Select the coverage limit");
					modules.Coverage Coverage = new modules.Coverage(driver);
					Coverage.Coverage();
					test.pass("Click on Next and Verify the Premium page");
					
					// VerfiyPremiumPage
					flag = false;
					try {
						flag = RM.verify_PageTitle(driver, "Premium");
						Assert.assertEquals(flag, true);
						test.pass("Sucessfully Navigated to Premium Page");
					} catch (AssertionError e) {
						e.printStackTrace();
						test.fail("Failed to Navigate Premium Page");
						System.out.println("Failed to Navigate to Premium page");
					}

					// Call Premium
					modules.Premium Premium = new modules.Premium(driver);
					Premium.Premium();

					// Capture Building Premium
					test.log(Status.PASS, "Capturing Building Premium");
					String BuildingPremium =null;
					try{
						BuildingPremium = driver
								.findElement(By.xpath("//*[@fieldref='CovBuildingOutput.CalculatedPremium']")).getText();
						test.pass("Premium Captured from the application: " +BuildingPremium);
					}catch(Exception e){
						test.fail("Failed to Capture the BuildingPremium");
					}

					//Entering the captured Premium to excel
					DataManager.writeData(
							"\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\TestData\\InputDataSheet.xlsx",
							row, 9, BuildingPremium);

					// Capture Content Premium
					String ContentPremium = null;
					try{
						ContentPremium = driver
								.findElement(
										By.xpath("//*[@fieldref='CovBusinessPersonalPropertyOutput.CalculatedPremium']"))
								.getText();
						test.pass("ContentPremium Captured from the application: " +ContentPremium);
					}catch(Exception e){
						test.fail("Failed to capture ContentPremium from the application");
					}
					
					//Entering the captured ContentPremium to excel inputsheet
					DataManager.writeData(
							"\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\TestData\\InputDataSheet.xlsx",
							row, 10, ContentPremium);

					// Capture Coverage Premium
					String CoveragePremium  = null;
					try{
						CoveragePremium	= driver
								.findElement(By
										.xpath("//*[@fieldref='CovAutomaticBlanketCoverageExtensionOutput.CalculatedPremium']"))
								.getText();
						test.pass("Coverage Premium Captured from the application: " +CoveragePremium);
					}catch(Exception e){
						test.fail("Failed to capture CoveragePremium from the application");
					}
					
					//Entering the captured CoveragePremium to excel input sheet					
					DataManager.writeData(
							"\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\TestData\\InputDataSheet.xlsx",
							row, 2, CoveragePremium);

					// Capture the Quote No/PolicyNumber
					String PolicyNumber = null;
					try{
						PolicyNumber = driver
								.findElement(By.xpath("//*[@fieldref='ConstantsPolicy.CurrentPolicyNumberIdentifier']"))
								.getText();
						test.pass("PolicyNumber Captured from the application:" +PolicyNumber);
					}catch(Exception e){
						test.fail("Failed to capture PolicyNumber from the application");
					}
					
					//Entering the captured PolicyNumber to excel input sheet 
					DataManager.writeData(
							"\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\TestData\\InputDataSheet.xlsx",
							row, 5, PolicyNumber);

					// Call RaterWorkbook - Automatic Blanket Coverage Extension
					RateWorkBook obj = new RateWorkBook();

					double RateBookPremium = -1;
					if (Parameters.coverage.equalsIgnoreCase("Automatic Blanket Coverage Extension")) {
						try{
							test.pass("Entering the input parameters:BuildingPremium,ContentPremium,CoverageLimit,IBC Code");							
							RateBookPremium = obj.automatic_Coverage(BuildingPremium, ContentPremium,
									Parameters.CoverageLimit, Parameters.IndustryCode, RateBookPremium);
							System.out.println(RateBookPremium);
							DataManager.writeData(
									"\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\TestData\\InputDataSheet.xlsx",
									row, 3, Integer.toString((int) RateBookPremium));
							test.pass("Capturing the RateBook premium from Rate Book: "+RateBookPremium);
						}catch(Exception e){
							test.pass("Failed to Capture the RateBook premium from Rate Book");
						}						
					}

					// Premium Validation
					test.pass("Application Premium validation with Ratebook Premium");
					boolean flag_Verfi = false;
					try {
						flag_Verfi = (int) RateBookPremium == Integer.parseInt(CoveragePremium);
					} catch (Exception e) {

					}
					try {						
						if (Integer.toString((int) RateBookPremium).trim().equals(CoveragePremium.trim())
								|| flag_Verfi) {
							
							DataManager.writeData(
									"\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\TestData\\InputDataSheet.xlsx",
									row, 4, "Pass");
							test.log(Status.PASS, "RateBookPremium: " +RateBookPremium+"and CoveragePremium: "+CoveragePremium+"are as expected" );
							System.out.println(CoveragePremium);
							System.out.println((int) RateBookPremium);
							RateBookPremium = 0;
							CoveragePremium = "";
						} else {
							DataManager.writeData(
									"\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\TestData\\InputDataSheet.xlsx",
									row, 4, "Fail");
							System.out.println(CoveragePremium);
							test.log(Status.FAIL, "RateBookPremium: " +RateBookPremium+"and CoveragePremium: "+CoveragePremium+"are NOT as expected" );
							System.out.println((int) RateBookPremium);
							RateBookPremium = 0;
							CoveragePremium = "";
						}
					} catch (Exception e) {
						DataManager.writeData(
								"\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\TestData\\InputDataSheet.xlsx",
								row, 4, "Fail");
						System.out.println("Issues with premium validation");
					}
				} catch (Exception e) {
					DataManager.writeData(
							"\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\TestData\\InputDataSheet.xlsx",
							row, 4, "Skip");
					e.printStackTrace();
				} finally {

					// LogOut
					try {
						DateFormat dateFormater = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
						Date date1 = new Date();
						DataManager.writeData(
								"\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\InputDataSheet.xlsx", row,
								36, dateFormater.format(date1));
						System.out.println("Execution End Time: " + dateFormater.format(date1));
						JavascriptExecutor js = (JavascriptExecutor) driver;
						WebElement ele_LogOut = driver.findElement(By.id("id_LogOut"));
						js.executeScript("arguments[0].scrollIntoView(true);", ele_LogOut);
						Thread.sleep(2000);
						ele_LogOut.click();
						Thread.sleep(5000);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			} else {
				continue;
			}
		}
	}

	@AfterTest
	public void tearDown() {
		extent.flush();
		// driver.quit();

	}
}

package modules;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Premium {
	WebDriver driver;
	pages.Premium p;
	
	public Premium(WebDriver webdriver) {
		driver=webdriver;
		p=new pages.Premium(driver);
				
	}
	String BuildingPremium=null;
	public void Premium() throws InterruptedException
	{
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1500)");
	
		
		
		
		try{
			if(driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Approve')]")).isDisplayed()){
				driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Approve')]")).click();
				Thread.sleep(2000);
				driver.findElement(By.xpath("//button[text()='Yes']")).click(); 
//				driver.switchTo().frame(arg0)
				Thread.sleep(6000);
			}
		}catch(Exception e){
			System.out.println("Approve button not displayed");
		}
		
		
		//Quote Click
		try{
			js.executeScript("window.scrollBy(0,1500)");
			if(driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Quote')]")).isDisplayed()){
				driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Quote')]")).click();
				
				 
			}
		}catch(Exception e){
			System.out.println("Quote button not displayed");
		}
		
		
			
	/*	
	
	// Capture the CoveragePremium from application 
	String Premium = driver.findElement(By.xpath("//*[@fieldref='CovAutomaticBlanketCoverageExtensionOutput.CalculatedPremium']")).getText();
	int CoverageLimit = Integer.parseInt(Limit.replace(",", ""));
	int CoveragePremium= Integer.parseInt(Premium);
*/
	 
	}
	

	
	

}

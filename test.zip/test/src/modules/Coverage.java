package modules;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utils.Parameters;
import utils.Reusable_Methods;

public class Coverage {
	WebDriver driver;
	pages.Coverage cov;
	Reusable_Methods RM = new Reusable_Methods(driver);
	
	public Coverage(WebDriver webdriver) {
		driver=webdriver;
		cov=new pages.Coverage(driver);
				
	}
	
public void Coverage() throws InterruptedException
	{
	cov.CoverageTab.click();
	Thread.sleep(3000);
	boolean flag = RM.verify_PageTitle(driver, "Coverage");		  
	  Assert.assertEquals(flag, true);			
	  
	  JavascriptExecutor js = (JavascriptExecutor) driver;
	  cov.PROPERTYHeader.click();
//	  driver.findElement(By.xpath("//*[@class='toggleHeaderInner'][contains(text(),'PROPERTY')]")).click();
	  Thread.sleep(1000);
	  cov.CommercialPropertyHeader.click();
	  Thread.sleep(1000);
	  
	  cov.ExtensionsHeader.click();
	  Thread.sleep(1000);
	  
	  js.executeScript("window.scrollBy(0,800)");
	  js.executeScript("arguments[0].scrollIntoView(true);", cov.CoverageExtensionInput);
	  cov.CoverageExtensionInput.clear();
	  cov.CoverageExtensionInput.sendKeys(Parameters.CoverageLimit.toString());
	  Thread.sleep(1000);
	  cov.CoverageExtensionInput.sendKeys(Keys.TAB);  
	  Thread.sleep(2000);
	  js.executeScript("window.scrollBy(0,1500)");
	  Thread.sleep(2000);
	  if(!cov.LiabilityIndicator.isSelected())
		  cov.LiabilityIndicator.click();
	  	  
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
		Thread.sleep(6000);
	
	}
	

	
	
	
	

}


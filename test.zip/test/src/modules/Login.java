package modules;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import utils.Parameters;

public class Login {
	
	Parameters parameter = new Parameters();
	WebDriver driver;
	pages.Login l;
	ExtentReports extent;
	ExtentTest test;
	
	public Login(WebDriver webdriver) {
		driver=webdriver;
		l=new pages.Login(driver);
	}
	
	
	public void populateLogin() throws InterruptedException
	{
		//l.username.sendKeys("Wes_UW_3");
//		try {
//			l.username.sendKeys(parameter.userName);
//			l.passWord.sendKeys(parameter.password);
//			l.login.click();			
//			Thread.sleep(5000);
//			test.pass("login Sucessfull");
//		} catch (Exception e) {
//			test.fail("Failed to login");
//		}
//		
//	}
	
	l.username.sendKeys(parameter.userName);
	l.passWord.sendKeys(parameter.password);
	l.login.click();
	Thread.sleep(5000);
}
}



package modules;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.Parameters;

public class Submission {
	WebDriver driver;
	pages.Submission s;

	public Submission(WebDriver webdriver) {
		driver=webdriver;
		s=new pages.Submission(driver);
				
	}

	public void submission() throws InterruptedException
	{
	if(!Parameters.brokerName.equals("")){
		s.brokerName.sendKeys(Parameters.brokerName);	
		Thread.sleep(2000);
		s.brokerName.sendKeys(Keys.TAB);
		Thread.sleep(3000);
	}
	
	
	s.brokerLocation.click();
	Thread.sleep(3000);
	s.brokerLocation.sendKeys(Keys.ARROW_DOWN);
	Thread.sleep(2000);
	s.brokerLocation.sendKeys(Keys.ARROW_DOWN);
	Thread.sleep(2000);
	s.brokerLocation.sendKeys(Keys.TAB);
	Thread.sleep(2000);	
	s.currentInsurer.sendKeys(Parameters.currentInsurer);
	Thread.sleep(1000);
	s.currentInsurer.sendKeys(Keys.TAB);
	Thread.sleep(1000);	
	s.yearBusinessEstablished.sendKeys(Integer.toString(Parameters.yearBusinessEstablished));
	s.fullTimeEmploys.sendKeys(Integer.toString(Parameters.fullTimeEmploys));
	
	if(Parameters.commercialProperty.equalsIgnoreCase("YES")){
		
		if(!s.commercialProperty.isSelected()){
			s.commercialProperty.click();
		}
	}else{
		if(s.commercialProperty.isSelected()){
			s.commercialProperty.click();
	}
		}
		
		if(Parameters.businessInterruptionInput.equalsIgnoreCase("YES")){
			if(!s.bineBusinessInterruptionInput.isSelected()){
				s.bineBusinessInterruptionInput.click();
				}
		}else{
			if(s.bineBusinessInterruptionInput.isSelected()){
				s.bineBusinessInterruptionInput.click();
			}	
		}
		
		if(Parameters.inlandMarineInput.equalsIgnoreCase("YES")){
			if(!s.inlandMarineInput.isSelected()){
				s.inlandMarineInput.click();}
		}else{
			if(s.inlandMarineInput.isSelected()){
				s.inlandMarineInput.click();
			}	
		}
				
		if(Parameters.liability.equalsIgnoreCase("YES")){
			
		
			if(!s.liabilityIndicator.isSelected()){
				s.liabilityIndicator.click();
			}
		}else{
			if(s.liabilityIndicator.isSelected()){
				s.liabilityIndicator.click();
			}
		}				
				

		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
		Thread.sleep(5000);

	
	}

		
	

}

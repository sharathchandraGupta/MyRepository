package modules;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import utils.Parameters;

public class CustomerInformation {
	WebDriver driver;
	pages.CustomerInformation c;

	public CustomerInformation(WebDriver webdriver) {
		driver = webdriver;
		c = new pages.CustomerInformation(driver);

	}

	public void customerInformation() throws InterruptedException {
		// c.leagalName.sendKeys("RatingTest4321");
		// c.isdcode.sendKeys("652");
		// c.phonenumber.sendKeys("4569874");

		c.leagalName.sendKeys(Parameters.leagalName);
		
		c.isdcode.sendKeys(Parameters.isdCode.toString());
		c.phonenumber.sendKeys(Parameters.phoneNumber.toString());

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1500)");

		// c.postalcode.sendKeys("M4C1B7");
		c.postalcode.sendKeys(Parameters.postalCode);

		// WebElement
		// e=driver.findElement(By.id("a360EC66582164B979EF1D3E179283E763B_4_1_anchorId"));
		// js.executeScript("arguments[0].click();", e);

		try {
			driver.findElement(By.xpath(("(//img[@class='g-btn-img-loneIcon'])[3]"))).click();
			Thread.sleep(8000);
		} catch (Exception e) {
		}

		/*
		 * WebElement SelectLink =
		 * uiDriver.webDr.findElement(By.xpath("(//span[text()='Select'])[1]"));
		 * ((JavascriptExecutor)
		 * uiDriver.webDr).executeScript("arguments[0].click();", SelectLink);
		 */

		try {
			driver.switchTo().frame(0);
			driver.findElements(By.className("g-btn-text")).get(0).click();
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			Thread.sleep(3000);
			js.executeScript("window.scrollBy(0,1500)");
		} catch (Exception e) {

		}
		Thread.sleep(1000);
		c.ibccode.sendKeys(Parameters.ibcCode.toString().substring(0, Parameters.ibcCode.toString().length()-2));
		Thread.sleep(2000);
		c.ibccode.sendKeys(Keys.TAB);
		Thread.sleep(1000);		
		c.revenue.sendKeys(Integer.toString(Parameters.revenue));
		
		c.revenue.sendKeys(Keys.TAB);
		Thread.sleep(2000);
		js.executeScript("window.scrollBy(0,1500)");
//		c.next.click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
		Thread.sleep(5000);

	}

}

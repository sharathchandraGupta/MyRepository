package modules;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.Parameters;

public class Business {
	WebDriver driver;
	pages.Business b;
	
	public Business(WebDriver webdriver) {
		driver=webdriver;
		b=new pages.Business(driver);
				
	}
	
	public void business() throws InterruptedException
	{
	b.propertyLiabilityClaims.sendKeys(Parameters.propertyLiabilityClaims);	
	Thread.sleep(2000);
	b.propertyLiabilityClaims.sendKeys(Keys.TAB);
	Thread.sleep(2000);
	
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,1500)");
	driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
	Thread.sleep(5000);
		
	
	}
	
	


}

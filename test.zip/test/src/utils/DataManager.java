package utils;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;

import net.sourceforge.htmlunit.corejs.javascript.ast.SwitchCase;

public class DataManager {
	static XSSFWorkbook wb = null;
	static XSSFWorkbook rb = null;
	static Sheet sh = null;
	static Sheet rs = null;
	static FileOutputStream out = null;
	public static int rowNumber;

	public DataManager(String fileName, String sheet) {

		try {
			wb = (XSSFWorkbook) WorkbookFactory.create(new FileInputStream(fileName));
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
		}
		sh = wb.getSheet(sheet);
		rowNumber = sh.getPhysicalNumberOfRows();

	}
	
	public static void RaterWorkBook(String fileName, String sheet) {

		try {
//			rb = (XSSFWorkbook) WorkbookFactory.create(new FileInputStream(fileName));
//			Workbook rb = WorkbookFactory.create(new FileInputStream(fileName));
			Workbook rb = WorkbookFactory.create(new FileInputStream(fileName));
//			Sheet sh = wb.getSheet("Rater");
			rs = rb.getSheet(sheet);
//			rb = new XSSFWorkbook(OPCPackage.open(fileName));
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
		}
	  
		//rowNumber = sh.getPhysicalNumberOfRows();

	}

	public static void writeData(int i, double RaterWorkbookPremium) {
		sh.getRow(i).getCell(3).setCellValue(RaterWorkbookPremium);
		try {
//			out = new FileOutputStream(path);
		} catch (Exception e) {

			e.printStackTrace();
		}
		try {
			wb.write(out);
		} catch (IOException e) {

			e.printStackTrace();
		}
		
	}
	public static void readData(int i) {

		Parameters.TestCaseName = sh.getRow(i).getCell(0).getStringCellValue();
		try{
			Parameters.flag = sh.getRow(i).getCell(1).getStringCellValue();	
		}catch(Exception e){
			Parameters.flag = "N";
			System.out.println("Caught null while retriving the flag value");
		}
		
		
//		Parameters.AppPremium = sh.getRow(i).getCell(2).getStringCellValue();
		//Parameters.RaterWorkbookPremium = sh.getRow(i).getCell(3).getStringCellValue();
		//Parameters.Status = sh.getRow(i).getCell(4).getStringCellValue();
//		Parameters.PolicyNumber = sh.getRow(i).getCell(5).getStringCellValue();
		Parameters.TCID = sh.getRow(i).getCell(0).getStringCellValue();
		Parameters.coverage = sh.getRow(i).getCell(6).getStringCellValue();
		Parameters.userName = sh.getRow(i).getCell(7).getStringCellValue();
		Parameters.password = sh.getRow(i).getCell(8).getStringCellValue();
//		Parameters.BuildingPremium = sh.getRow(i).getCell(9).getNumericCellValue();
//		Parameters.ContentsPremium = sh.getRow(i).getCell(10).getNumericCellValue();
		Parameters.CoverageLimit = sh.getRow(i).getCell(11).getStringCellValue();
		Parameters.IndustryCode = sh.getRow(i).getCell(12).getNumericCellValue();
		Parameters.customerName = sh.getRow(i).getCell(13).getStringCellValue();
		Parameters.leagalName = sh.getRow(i).getCell(14).getStringCellValue();
		Parameters.isdCode = sh.getRow(i).getCell(15).getNumericCellValue();
		Parameters.phoneNumber = sh.getRow(i).getCell(16).getNumericCellValue();
		Parameters.postalCode = sh.getRow(i).getCell(17).getStringCellValue();
		Parameters.ibcCode = sh.getRow(i).getCell(18).getNumericCellValue();
		Parameters.revenue = (int) sh.getRow(i).getCell(19).getNumericCellValue();
		try{
			Parameters.brokerName = sh.getRow(i).getCell(20).getStringCellValue();	
		}catch(Exception e){
			Parameters.brokerName = "";			
			
		}
		
		
		Parameters.currentInsurer = sh.getRow(i).getCell(21).getStringCellValue();
		Parameters.yearBusinessEstablished = (int) sh.getRow(i).getCell(22).getNumericCellValue();
		Parameters.fullTimeEmploys = (int) sh.getRow(i).getCell(23).getNumericCellValue();
		Parameters.commercialProperty = sh.getRow(i).getCell(24).getStringCellValue();
		Parameters.inlandMarineInput = sh.getRow(i).getCell(25).getStringCellValue();
		Parameters.businessInterruptionInput = sh.getRow(i).getCell(26).getStringCellValue();
		Parameters.liability = sh.getRow(i).getCell(27).getStringCellValue();		
		Parameters.propertyLiabilityClaims = sh.getRow(i).getCell(28).getStringCellValue();
		Parameters.typeOfConstruction = sh.getRow(i).getCell(29).getStringCellValue();
		Parameters.noOfStoreys = (int) sh.getRow(i).getCell(30).getNumericCellValue();
		Parameters.yearBuilt = (int) sh.getRow(i).getCell(31).getNumericCellValue();
		Parameters.area = (int) sh.getRow(i).getCell(32).getNumericCellValue();
		Parameters.BuildingLimit = (int) sh.getRow(i).getCell(33).getNumericCellValue();
		try{
			Parameters.BusinessPersonalProperty = (int) sh.getRow(i).getCell(34).getNumericCellValue();	
		}catch(Exception e){
			Parameters.BusinessPersonalProperty = 0;
		}
		 
		
		
		
		
		
		
		

	}

	public static String readData(int rowNumber, int cellNumber) {
		String cellValue = null;
		try {
			cellValue = sh.getRow(rowNumber).getCell(cellNumber).getStringCellValue();

		} catch (Exception e) {
		}

		return cellValue;
	}
	
public static void writeRateBook(String path, int row, int cell, String value) {
		
	rs.getRow(row).createCell(cell).setCellValue(value);
		try {
			out = new FileOutputStream(path);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		try {
			rb.write(out);
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	public static void writeData(String path, int row, int cell, String value) {
		
		sh.getRow(row).createCell(cell).setCellValue(value);		

		try {
			out = new FileOutputStream(path);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		try {
			wb.write(out);
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	public static void closeWorkBook() {
		try {
			wb.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void openFile(String path) {
		File file = new File(path);

		if (!Desktop.isDesktopSupported()) {
			System.out.println("Desktop is not supported");
			return;
		}

		Desktop desktop = Desktop.getDesktop();
		if (file.exists())
			try {
				desktop.open(file);
			} catch (IOException e) {

				e.printStackTrace();
			}

	}

}

package utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;


public class Reusable_Methods {

	
	WebDriver driver ;

	public Reusable_Methods(WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(webdriver, this);
		}
	
	
	public static boolean verify_PageTitle(WebDriver driver, String Title){
		try {
			WebElement element = driver.findElement(By.xpath("//*[@id='pageTitle']"));		
			if(element.getText().equalsIgnoreCase(Title)){
				return true;	
			}else{
				return false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}		
		
	}
	
	public static String getRandomString() {
		
        try {
			String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
			StringBuilder salt = new StringBuilder();
			Random rnd = new Random();
			while (salt.length() < 10) { // length of the random string.
			    int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			    salt.append(SALTCHARS.charAt(index));
			}
			String saltStr = salt.toString();
			return saltStr;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;		
		}
		

    }
	
	public static String getDate(){
		try {
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			Date date = new Date();
			return dateFormat.format(date);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	
	public static String generateRepeatingString(char c, Integer n) {
	    try {
			StringBuilder b = new StringBuilder();
			for (Integer x = 0; x < n; x++)
			    b.append(c);
			return b.toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

}

package utils;

public class Parameters {
	
	public static String TestCaseName;
	public static String flag;
	public static String userName;
	public static String password;	
	public static String coverage;
	public static String AppPremium;
	public static String RaterWorkbookPremium;
	public static String PolicyNumber;
	public static Double BuildingPremium;
	public static Double ContentsPremium;
	public static String CoverageLimit;
	public static Double IndustryCode;
	public static String customerName;
	public static String leagalName;
	public static Double isdCode;
	public static Double phoneNumber;
	public static String postalCode;
	public static Double ibcCode;
	public static int revenue;
	public static String brokerName;
	public static String currentInsurer;
	public static int yearBusinessEstablished;
	public static int fullTimeEmploys;
	public static String commercialProperty;
	public static String inlandMarineInput;
	public static String businessInterruptionInput;
	public static String propertyLiabilityClaims;
	public static String typeOfConstruction;
	public static int noOfStoreys;
	public static int yearBuilt;
	public static int area;
	public static String liability;
	public static int BuildingLimit;
	public static int BusinessPersonalProperty;
	public static String TCID;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

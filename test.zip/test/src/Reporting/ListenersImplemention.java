package Reporting;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class ListenersImplemention {
	ExtentReports extent;
	ExtentTest test;
	
	public void pass(String str){
		test.pass(str);
	}
	public void fail(String str){
		test.pass(str);
	}

}

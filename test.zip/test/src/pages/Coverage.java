package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Coverage {
	WebDriver driver;
	public Coverage( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);		
	}

	@FindBy(how=How.XPATH,using="//a[contains(text(),'Coverage')]")
	public WebElement CoverageTab;
	
	@FindBy(how=How.XPATH,using="//*[@class='toggleHeaderInner'][contains(text(),'PROPERTY')]")
	public WebElement PROPERTYHeader;
	
	@FindBy(how=How.XPATH,using="//*[@class='toggleHeaderInner'][contains(text(),'Commercial Property')]")
	public WebElement CommercialPropertyHeader;
	
	@FindBy(how=How.XPATH,using="//*[@class='toggleHeaderInner'][contains(text(),'Extensions')]")
	public WebElement ExtensionsHeader;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAutomaticBlanketCoverageExtensionInput.Limit']")
	public WebElement  CoverageExtensionInput;	

	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.LiabilityIndicator']")
	public WebElement  LiabilityIndicator;
	
	
	
	
	
	
	
	

}

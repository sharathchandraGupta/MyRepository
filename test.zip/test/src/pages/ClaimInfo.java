package pages;

public class ClaimInfo {

}

package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Premium {
	
	WebDriver driver;
	public Premium( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}

	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.QuotePremium']")
	public WebElement quotePremium;
	
	@FindBy(how=How.XPATH,using="//*[contains(text(),'Approve')]")
	public WebElement getTownGrade;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAutomaticBlanketCoverageExtensionInput.Limit']")
	public WebElement CoverageLimit;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAutomaticBlanketCoverageExtensionOutput.CalculatedPremium']")
	public WebElement CoveragePremium;
	
	
	
	
};

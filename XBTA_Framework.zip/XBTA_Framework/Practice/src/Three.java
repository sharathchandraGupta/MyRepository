import org.testng.annotations.Test;

@Test
public class Three {
	public void FirstMethod_Three() {
		System.out.println("Am in class three and in method one");
		
	}
	
	public void SecondMethod_Three() {
		System.out.println("Am in class three and in method two");
		
	}
}

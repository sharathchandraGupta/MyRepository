import org.testng.annotations.Factory;
import org.testng.annotations.Test;

@Test
public class Two {
	public void FirstMethod_Two() {
		long id = Thread.currentThread().getId();
		System.out.println("Am in class two and in method one:"+id);
		
	}

	public void SecondMethod_Two() {
		long id = Thread.currentThread().getId();
		System.out.println("Am in class two and in method two: "+id);
		
	}
	
	/*@Factory
	public Object[] factoryMethod(){
		return new Object[] {new One(),new One(),new One()};
	}*/
}

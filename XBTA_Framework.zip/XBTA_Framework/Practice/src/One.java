
import org.testng.annotations.*;
import org.testng.annotations.Test;


public class One {
		@Test
		public void FirstMethod_One() {
			long id = Thread.currentThread().getId();
			System.out.println("Before Method: "+id);
			
		}
		
		@Test
		public void SecondMethod_One() {
			
			long id = Thread.currentThread().getId();
			System.out.println("First Test Method: "+id);
			
		}
		
		@Test
		public void ThirdMethod_One() {
			
			long id = Thread.currentThread().getId();
			System.out.println("Second Test Method: "+id);
			
		}
		@Test
	public void FourthMethod_One() {
			
			long id = Thread.currentThread().getId();
			System.out.println("AfterMethod: "+id);
			
		}

}


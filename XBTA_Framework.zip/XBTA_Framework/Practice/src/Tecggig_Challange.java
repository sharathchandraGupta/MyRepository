import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class Tecggig_Challange {

	public static void main(String[] args) throws IOException{
        Scanner in = new Scanner(System.in);
        int output = 0;
        int ip1_size = 0;
        ip1_size = Integer.parseInt(in.nextLine().trim());
//        String[] ip1 = {"1#2","2#5","1#5","2#3","3#4","4#5","4#6","5#6"};
        String[] ip1 = new String[ip1_size];
        for(int a=0;a<ip1_size;a++){
        	ip1[a]=in.nextLine();
        }
       
       
        
        ArrayList<String> arr = new ArrayList<String>();
        
        for(int j=0;j<ip1.length;j++){
        	int	len=0;
        	 len = ip1[j].split("#").length;
        	int i=0;
        
        	while(len>0){
        		
//        		Integer.parseInt(ip1[j].split("#")[i]);
        		arr.add(ip1[j].split("#")[i]);
        		i=i+1;
        		len=len-1;
        	}
        	
        	
//        	System.out.println(ip1[j]);
        }
        Collections.sort(arr);
        System.out.println(arr.get(0));
        System.out.println(arr.get(arr.size()-1));
        
        int armyBasecamp2 = Integer.parseInt(arr.get(arr.size()-1));
        String cit="city";
        int[] arrF = new int[armyBasecamp2];
        int conns = 0;
        
        for(int a=0;a<armyBasecamp2;a++){
        	arrF[a]=0;
        	cit="city";
        	cit=cit+Integer.toString(a+1); 
        	
        	
        	System.out.println(cit);
        	for(int b=0;b<ip1.length;b++){
        		if(ip1[b].contains(Integer.toString(a+1))){  
        			arrF[a]=arrF[a]+1;
        		}
        	}
        	
        	System.out.println(arrF[a]);
        }
        
        ArrayList<Integer> finalMap = new ArrayList<Integer>();
        
        for(int a=0;a<arrF.length;a++){
        	finalMap.add(arrF[a]);
//        	System.out.println(finalMap.get(a));
        }
        
        Collections.sort(finalMap);
        
        System.out.println(finalMap.get(0));
  
        
        
        
        
        
        
        
        
        
        /* for(int c=0;c<arrF.length;c++){
    		System.out.println(arrF[c]);
    		}*/
   
       /* 
        System.out.println("Array values");
        
//        HashMap mObj = new HashMap();
        	ArrayList<String> arr = new ArrayList<String>();
        	
        for(int j=0;j<ip1.length;j++){
        	int	len=0;
        	 len = ip1[j].split("#").length;
        	int i=0;
        
        	while(len>0){
        		
//        		Integer.parseInt(ip1[j].split("#")[i]);
        		arr.add(ip1[j].split("#")[i]);
        		i=i+1;
        		len=len-1;
        	}
        	
        	
//        	System.out.println(ip1[j]);
        }
        Collections.sort(arr);
        HashMap ma = new HashMap<>();
        int no=0;
        for(int k=0;k<arr.size();k++){
      	
        	System.out.println(arr.get(k));
    	
        	if(ma.containsKey(arr.get(k))){
        		ma.put(arr.get(k), ma.get(arr.get(k)+1));
        	}else{
        		ma.put(arr.get(k), 1);
        	}
        	
        	
        }
        
        
       */
       
        
        
   /*     System.out.println(arr.get(0));
        System.out.println(arr.get(arr.size()-1));*/
        
//        output = minRoads(ip1);
//        System.out.println(String.valueOf(output));
    }
	
	
}

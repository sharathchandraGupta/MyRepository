
public class Five {
	public static void main(String[] args){
		System.out.println("Am in class five");
	}

}

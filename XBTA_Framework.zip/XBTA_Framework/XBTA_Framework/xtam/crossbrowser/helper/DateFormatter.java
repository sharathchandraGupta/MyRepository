// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DateFormatter.java

package crossbrowser.helper;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormatter
{

    public DateFormatter()
    {
    }

    public static String formatDate(Date date, String timestampFormat)
    {
        SimpleDateFormat sdf = new SimpleDateFormat(timestampFormat);
        String dateStr = sdf.format(date);
        return dateStr;
    }
}

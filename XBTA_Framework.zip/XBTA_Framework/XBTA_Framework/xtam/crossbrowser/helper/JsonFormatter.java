// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JsonFormatter.java

package crossbrowser.helper;

import crossbrowser.logger.FrameworkLogger;
import java.util.Date;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// Referenced classes of package crossbrowser.helper:
//            DateFormatter

public class JsonFormatter
{

    public JsonFormatter()
    {
    }

    public static String format(Date date, String step, String expected, String actual, String status, String screenshotPath)
    {
        String json = "";
        String dateStr = DateFormatter.formatDate(date, "dd MMM, yyyy HH:mm:ss z");
        JSONObject object = new JSONObject();
        if(dateStr != null)
            object.put("date", dateStr);
        else
            object.put("date", "");
        if(step != null)
            object.put("step", step);
        else
            object.put("step", "");
        if(expected != null)
            object.put("expected", expected);
        else
            object.put("expected", "");
        if(actual != null)
            object.put("actual", actual);
        else
            object.put("actual", "");
        if(status != null)
            object.put("status", status);
        else
            object.put("status", "");
        if(screenshotPath != null)
            object.put("screenshotPath", screenshotPath);
        else
            object.put("screenshotPath", "");
        json = object.toJSONString();
        return json;
    }

    public static String format(String os, String browser, String version)
    {
        String json = "";
        JSONObject object = new JSONObject();
        if(os != null)
            object.put("os", os);
        else
            object.put("os", "");
        if(browser != null)
            object.put("browser", browser);
        else
            object.put("browser", "");
        if(version != null)
            object.put("version", version);
        else
            object.put("version", "");
        json = object.toJSONString();
        return json;
    }

    public static String format(String key, String value)
    {
        String json = "";
        JSONObject object = new JSONObject();
        object.put(key, value);
        json = object.toJSONString();
        return json;
    }

    public static JSONObject string2Json(String jsonString)
    {
        JSONObject jsonObject = new JSONObject();
        try
        {
            jsonObject = (JSONObject)(new JSONParser()).parse(jsonString);
        }
        catch(ParseException e)
        {
            FrameworkLogger.log((new StringBuilder("Error while parsing the JSON string. Exception: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/helper/JsonFormatter);
            FrameworkLogger.log("Error while creating Report.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/helper/JsonFormatter);
        }
        return jsonObject;
    }
}

// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TimeUtils.java

package crossbrowser.helper;

import java.util.concurrent.TimeUnit;

public class TimeUtils
{

    public TimeUtils()
    {
    }

    public static String convertSecToHHMMSS(long seconds)
    {
        String time = "Failed to calculate duration";
        long hours = TimeUnit.SECONDS.toHours(seconds);
        long minute = TimeUnit.SECONDS.toMinutes(seconds) - TimeUnit.SECONDS.toHours(seconds) * 60L;
        long second = TimeUnit.SECONDS.toSeconds(seconds) - TimeUnit.SECONDS.toMinutes(seconds) * 60L;
        time = (new StringBuilder(String.valueOf(hours))).append("h ").append(minute).append("m ").append(second).append("s").toString();
        return time;
    }
}

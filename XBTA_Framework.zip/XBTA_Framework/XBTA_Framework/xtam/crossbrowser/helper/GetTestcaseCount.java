// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   GetTestcaseCount.java

package crossbrowser.helper;

import crossbrowser.bean.ReportBean;
import crossbrowser.bean.TestCaseReportBean;
import java.util.Iterator;
import java.util.List;
import org.json.simple.JSONObject;

public class GetTestcaseCount
{

    public GetTestcaseCount()
    {
    }

    public JSONObject getTestcaseInfo(String testcaseName)
    {
        int pass = 0;
        int fail = 0;
        int skip = 0;
        int total = 0;
        for(Iterator iterator = ReportBean.report.iterator(); iterator.hasNext();)
        {
            TestCaseReportBean testCaseReportBean = (TestCaseReportBean)iterator.next();
            if(testCaseReportBean.getTestCaseName().equals(testcaseName))
            {
                if(testCaseReportBean.getStatus().equalsIgnoreCase("pass"))
                    pass++;
                else
                if(testCaseReportBean.getStatus().equalsIgnoreCase("fail"))
                    fail++;
                else
                if(testCaseReportBean.getStatus().equalsIgnoreCase("skip"))
                    skip++;
                total++;
            }
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("pass", Integer.valueOf(pass));
        jsonObject.put("fail", Integer.valueOf(fail));
        jsonObject.put("skip", Integer.valueOf(skip));
        jsonObject.put("total", Integer.valueOf(total));
        return jsonObject;
    }

    public String getTestcaseDescription(String testcaseName)
    {
        String description = "";
        for(Iterator iterator = ReportBean.report.iterator(); iterator.hasNext();)
        {
            TestCaseReportBean testCaseReportBean = (TestCaseReportBean)iterator.next();
            if(testCaseReportBean.getTestCaseName().equals(testcaseName))
            {
                description = testCaseReportBean.getDescription();
                break;
            }
        }

        return description;
    }

    public JSONObject getTotalCount()
    {
        int pass = 0;
        int fail = 0;
        int skip = 0;
        int total = 0;
        for(Iterator iterator = ReportBean.report.iterator(); iterator.hasNext();)
        {
            TestCaseReportBean testCaseReportBean = (TestCaseReportBean)iterator.next();
            if(testCaseReportBean.getStatus().equalsIgnoreCase("pass"))
                pass++;
            else
            if(testCaseReportBean.getStatus().equalsIgnoreCase("fail"))
                fail++;
            else
            if(testCaseReportBean.getStatus().equalsIgnoreCase("skip"))
                skip++;
            total++;
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("pass", Integer.valueOf(pass));
        jsonObject.put("fail", Integer.valueOf(fail));
        jsonObject.put("skip", Integer.valueOf(skip));
        jsonObject.put("total", Integer.valueOf(total));
        return jsonObject;
    }

    public JSONObject getBrowserInfo(String browserName)
    {
        int pass = 0;
        int fail = 0;
        int skip = 0;
        int total = 0;
        for(Iterator iterator = ReportBean.report.iterator(); iterator.hasNext();)
        {
            TestCaseReportBean testCaseReportBean = (TestCaseReportBean)iterator.next();
            if(testCaseReportBean.getOsBrowser().equals(browserName))
            {
                if(testCaseReportBean.getStatus().equalsIgnoreCase("pass"))
                    pass++;
                else
                if(testCaseReportBean.getStatus().equalsIgnoreCase("fail"))
                    fail++;
                else
                if(testCaseReportBean.getStatus().equalsIgnoreCase("skip"))
                    skip++;
                total++;
            }
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("pass", Integer.valueOf(pass));
        jsonObject.put("fail", Integer.valueOf(fail));
        jsonObject.put("skip", Integer.valueOf(skip));
        jsonObject.put("total", Integer.valueOf(total));
        return jsonObject;
    }
}

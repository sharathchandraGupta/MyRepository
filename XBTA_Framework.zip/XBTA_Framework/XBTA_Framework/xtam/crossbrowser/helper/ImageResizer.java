// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ImageResizer.java

package crossbrowser.helper;

import crossbrowser.logger.FrameworkLogger;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ImageResizer
{

    public ImageResizer()
    {
    }

    public static void resize(File inputImageFile, File outputImageFile, double percent)
        throws IOException
    {
        FrameworkLogger.log((new StringBuilder("Input file: ")).append(inputImageFile.getAbsolutePath()).append(" Output file: ").append(outputImageFile.getAbsolutePath()).append(" Percent: ").append(percent).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/helper/ImageResizer);
        BufferedImage inputImage = ImageIO.read(inputImageFile);
        FrameworkLogger.log((new StringBuilder("Reading bufferImage: ")).append(inputImageFile.getAbsolutePath()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/helper/ImageResizer);
        int scaledWidth = (int)((double)inputImage.getWidth() * percent);
        int scaledHeight = (int)((double)inputImage.getHeight() * percent);
        FrameworkLogger.log((new StringBuilder("Reading Height & Width: ")).append(inputImageFile.getAbsolutePath()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/helper/ImageResizer);
        resize(inputImageFile, outputImageFile, scaledWidth, scaledHeight);
    }

    private static void resize(File inputImageFile, File outputImageFile, int scaledWidth, int scaledHeight)
        throws IOException
    {
        BufferedImage inputImage = ImageIO.read(inputImageFile);
        FrameworkLogger.log((new StringBuilder("Reading bufferImage: ")).append(inputImageFile.getAbsolutePath()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/helper/ImageResizer);
        BufferedImage outputImage = new BufferedImage(scaledWidth, scaledHeight, inputImage.getType());
        Graphics2D g2d = outputImage.createGraphics();
        g2d.drawImage(inputImage, 0, 0, scaledWidth, scaledHeight, null);
        g2d.dispose();
        String arr[] = outputImageFile.getAbsolutePath().split("\\.");
        String formatName = arr[arr.length - 1];
        ImageIO.write(outputImage, formatName, outputImageFile);
        FrameworkLogger.log((new StringBuilder("Writing Image: ")).append(outputImageFile.getAbsolutePath()).append(" Format: ").append(formatName).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/helper/ImageResizer);
    }
}

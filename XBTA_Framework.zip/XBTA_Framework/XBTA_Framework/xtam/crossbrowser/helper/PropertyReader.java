// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PropertyReader.java

package crossbrowser.helper;

import java.io.*;
import java.util.*;

public class PropertyReader
{

    public PropertyReader()
    {
    }

    public static String getProperty(String key, String defaultValue)
    {
        String value;
        Properties prop;
        InputStream input;
        value = "";
        prop = new Properties();
        input = null;
        try
        {
            input = new FileInputStream("./crossbrowser.properties");
            prop.load(input);
            value = prop.getProperty(key, defaultValue);
            break MISSING_BLOCK_LABEL_105;
        }
        catch(IOException ex)
        {
            System.out.println("Error while reading Property file. Please check 'crossbrowser.properties' file.");
        }
        if(input != null)
            try
            {
                input.close();
            }
            catch(IOException e)
            {
                System.out.println("Error while reading Property file. Please check 'crossbrowser.properties' file.");
            }
        break MISSING_BLOCK_LABEL_128;
        Exception exception;
        exception;
        if(input != null)
            try
            {
                input.close();
            }
            catch(IOException e)
            {
                System.out.println("Error while reading Property file. Please check 'crossbrowser.properties' file.");
            }
        throw exception;
        if(input != null)
            try
            {
                input.close();
            }
            catch(IOException e)
            {
                System.out.println("Error while reading Property file. Please check 'crossbrowser.properties' file.");
            }
        return value;
    }

    public static HashMap getAllProperty()
    {
        HashMap keyValHashMap;
        Properties prop;
        InputStream input;
        String value = "";
        keyValHashMap = new HashMap();
        prop = new Properties();
        input = null;
        try
        {
            input = new FileInputStream("./crossbrowser.properties");
            prop.load(input);
            Set keys = prop.keySet();
            String key;
            String val;
            for(Iterator iterator = keys.iterator(); iterator.hasNext(); keyValHashMap.put(key, val))
            {
                Object k = iterator.next();
                String value = getProperty(k.toString(), "");
                key = k.toString();
                val = value;
            }

            break MISSING_BLOCK_LABEL_166;
        }
        catch(IOException ex)
        {
            System.out.println("Error while reading Property file. Please check 'crossbrowser.properties' file.");
        }
        if(input != null)
            try
            {
                input.close();
            }
            catch(IOException e)
            {
                System.out.println("Error while reading Property file. Please check 'crossbrowser.properties' file.");
            }
        break MISSING_BLOCK_LABEL_187;
        Exception exception;
        exception;
        if(input != null)
            try
            {
                input.close();
            }
            catch(IOException e)
            {
                System.out.println("Error while reading Property file. Please check 'crossbrowser.properties' file.");
            }
        throw exception;
        if(input != null)
            try
            {
                input.close();
            }
            catch(IOException e)
            {
                System.out.println("Error while reading Property file. Please check 'crossbrowser.properties' file.");
            }
        return keyValHashMap;
    }
}

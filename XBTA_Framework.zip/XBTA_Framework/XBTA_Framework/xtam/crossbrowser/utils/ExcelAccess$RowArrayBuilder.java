// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExcelAccess.java

package crossbrowser.utils;

import java.util.List;

// Referenced classes of package crossbrowser.utils:
//            ExcelAccess, DataRow

public static class ExcelAccess$RowArrayBuilder extends ExcelAccess.MapReader
{

    public boolean handleRow(DataRow row, int rowIx)
    {
        rows.add(row);
        return true;
    }

    private List rows;

    public ExcelAccess$RowArrayBuilder(List rows)
    {
        this.rows = rows;
    }
}

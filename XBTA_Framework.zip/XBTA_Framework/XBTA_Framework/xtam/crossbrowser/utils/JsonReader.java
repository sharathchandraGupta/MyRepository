// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JsonReader.java

package crossbrowser.utils;

import crossbrowser.logger.FrameworkLogger;
import java.io.*;
import java.util.List;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

// Referenced classes of package crossbrowser.utils:
//            FileUtil

public class JsonReader
{

    public JsonReader()
    {
        fileUtils = new FileUtil();
        parser = new JSONParser();
    }

    public List parseJson(String fileName)
    {
        if(FileUtil.fileExists(fileName))
            try
            {
                JSONArray jsonFileContent = (JSONArray)parser.parse(fileUtils.readFile(fileName));
//                FrameworkLogger.log((new StringBuilder("Returning from parseJson(): '")).append(jsonFileContent).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                return jsonFileContent;
            }
            catch(IOException e)
            {
//                FrameworkLogger.log((new StringBuilder("Error while reading JSON File: '")).append(fileName).append("'. Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
//                FrameworkLogger.log((new StringBuilder("Error while reading JSON File: '")).append(fileName).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
            }
            catch(ParseException e)
            {
//                FrameworkLogger.log((new StringBuilder("Error while parsing JSON File: '")).append(fileName).append("'. Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
//                FrameworkLogger.log((new StringBuilder("Error while parsing JSON File: '")).append(fileName).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
            }
        return null;
    }

    public JSONObject jsonRead(String filepath)
    {
        JSONParser jsonParser = new JSONParser();
        try
        {
            JSONObject json = (JSONObject)jsonParser.parse(fileUtils.readFile(filepath));
//            FrameworkLogger.log((new StringBuilder("Returning from jsonRead(): '")).append(json).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
            return json;
        }
        catch(IOException e)
        {
//            FrameworkLogger.log((new StringBuilder("Error while reading JSON File: '")).append(filepath).append("'. Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
//            FrameworkLogger.log((new StringBuilder("Error while reading JSON File: '")).append(filepath).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
            return null;
        }
        catch(ParseException e)
        {
//            FrameworkLogger.log((new StringBuilder("Error while parsing JSON File: '")).append(filepath).append("'. Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        }
//        FrameworkLogger.log((new StringBuilder("Error while parsing JSON File: '")).append(filepath).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
        return null;
    }

    public boolean jsonWrite(String filepath, JSONObject object)
    {
        try
        {
            File file = new File(filepath);
            file.createNewFile();
            FileWriter fileWriter = new FileWriter(file);
            fileWriter.write(object.toString());
            fileWriter.flush();
            fileWriter.close();
//            FrameworkLogger.log((new StringBuilder("Writing JSON Object : '")).append(object.toJSONString()).append("' to File '").append(filepath).append("' done.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        }
        catch(IOException e)
        {
//            FrameworkLogger.log((new StringBuilder("Error while writing JSON File: '")).append(filepath).append("'. Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
//            FrameworkLogger.log((new StringBuilder("Error while writing JSON File: '")).append(filepath).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
            return false;
        }
        return true;
    }

    private FileUtil fileUtils;
    JSONParser parser;
}

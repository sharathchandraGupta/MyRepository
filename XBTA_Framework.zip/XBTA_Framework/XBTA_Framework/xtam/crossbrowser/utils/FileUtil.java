// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FileUtil.java

package crossbrowser.utils;

import crossbrowser.logger.FrameworkLogger;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileUtil
{

    public FileUtil()
    {
    }

    public List fileList(String folder)
    {
        return null;
    }

    public static boolean makePath(String sPath)
    {
        File file = new File(sPath);
        if(file.exists())
        {
//            FrameworkLogger.log((new StringBuilder("File '")).append(sPath).append("' exists.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/FileUtil);
            return true;
        }
        if(!makePath(file.getParent()))
        {
//            FrameworkLogger.log((new StringBuilder("File '")).append(sPath).append("' makePath() failed.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/FileUtil);
            return false;
        }
        try
        {
            file.createNewFile();
//            FrameworkLogger.log((new StringBuilder("File '")).append(sPath).append("' created.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/FileUtil);
        }
        catch(IOException e)
        {
//            FrameworkLogger.log((new StringBuilder("Error while creating File: '")).append(sPath).append("'. Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/FileUtil);
//            FrameworkLogger.log((new StringBuilder("Error while creating File: '")).append(sPath).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/utils/FileUtil);
        }
        return file.exists();
    }

    public static boolean fileExists(String sFile)
    {
        return isExist(sFile);
    }

    public static boolean folderExists(String sFolder)
    {
        return isExist(sFolder);
    }

    private static boolean isExist(String sName)
    {
//        FrameworkLogger.log((new StringBuilder("File '")).append(sName).append("'").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/FileUtil);
        return (new File(sName)).exists();
    }

    public static void removeFolder(String sFolderPath)
    {
        File file = new File(sFolderPath);
        file.delete();
//        FrameworkLogger.log((new StringBuilder("File '")).append(sFolderPath).append("' Removed.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/FileUtil);
    }

    public static boolean makeFolder(String sFolderPath)
    {
        if(!(new File(sFolderPath)).isDirectory())
        {
//            FrameworkLogger.log((new StringBuilder("Folder '")).append(sFolderPath).append("' created.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/FileUtil);
            return (new File(sFolderPath)).mkdir();
        } else
        {
//            FrameworkLogger.log((new StringBuilder("Folder '")).append(sFolderPath).append("' already exists.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/FileUtil);
            return true;
        }
    }

    public static String getTempPath()
    {
        return "";
    }

    public static void createTextFile(String sFile)
    {
        File file = new File(sFile);
        try
        {
            file.createNewFile();
        }
        catch(IOException e)
        {
//            FrameworkLogger.log((new StringBuilder("Error while creating File: '")).append(sFile).append("'. Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/FileUtil);
//            FrameworkLogger.log((new StringBuilder("Error while creating File: '")).append(sFile).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/utils/FileUtil);
        }
    }

    public FileReader readFile(String filePath)
    {
        if(fileExists(filePath))
        {
            try
            {
                return new FileReader(filePath);
            }
            catch(FileNotFoundException e)
            {
//                FrameworkLogger.log((new StringBuilder("Error while reading File: '")).append(filePath).append("'. Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/FileUtil);
            }
//            FrameworkLogger.log((new StringBuilder("Error while reading File: '")).append(filePath).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/utils/FileUtil);
        }
        return null;
    }

    public String getFileData(String filePath)
    {
        if(fileExists(filePath))
        {
            try
            {
                BufferedReader br = new BufferedReader(new FileReader(new File(filePath)));
                StringBuilder sb = new StringBuilder();
                String line;
                while((line = br.readLine()) != null) 
                    sb.append(line.trim());
                return sb.toString();
            }
            catch(IOException e)
            {
//                FrameworkLogger.log((new StringBuilder("Error while reading File: '")).append(filePath).append("'. Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/FileUtil);
            }
//            FrameworkLogger.log((new StringBuilder("Error while reading File: '")).append(filePath).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/utils/FileUtil);
            return null;
        } else
        {
            return null;
        }
    }

    public static String getLatestFilefromDir(String dirPath, String extention)
    {
        File dir = new File(dirPath);
        File listOfFiles[] = dir.listFiles();
        List files = new ArrayList();
        for(int i = 0; i < listOfFiles.length; i++)
        {
            File file = listOfFiles[i];
            if(file.isFile() && "*".equals(extention))
                files.add(file);
            else
            if(file.getName().endsWith(extention))
                files.add(file);
        }

        if(files == null || files.size() == 0)
            return null;
        File lastModifiedFile = (File)files.get(0);
        for(int i = 1; i < files.size(); i++)
            if(lastModifiedFile.lastModified() < ((File)files.get(i)).lastModified())
                lastModifiedFile = (File)files.get(i);

        return lastModifiedFile.getName();
    }

    public static void recursiveDelete(String filePath)
    {
        File file = new File(filePath);
        if(!file.exists())
            return;
        if(file.isDirectory())
        {
            File afile[];
            int j = (afile = file.listFiles()).length;
            for(int i = 0; i < j; i++)
            {
                File f = afile[i];
                recursiveDelete(f.getAbsolutePath());
            }

        }
        file.delete();
    }
}

// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExcelAccess.java

package crossbrowser.utils;


// Referenced classes of package crossbrowser.utils:
//            ExcelAccess, DataRow

public static abstract class ExcelAccess$MapReader extends ndler
{

    public abstract boolean handleRow(DataRow datarow, int i);

    public final boolean handleRow(cess namedRowAccess, int rowIx)
    {
        return handleRow(namedRowAccess.get(), rowIx);
    }

    public ExcelAccess$MapReader()
    {
    }
}

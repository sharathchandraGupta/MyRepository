// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ZipUtils.java

package crossbrowser.utils;

import crossbrowser.helper.DateFormatter;
import crossbrowser.helper.PropertyReader;
import crossbrowser.logger.FrameworkLogger;
import java.io.*;
import java.util.Date;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

// Referenced classes of package crossbrowser.utils:
//            FileUtil

public class ZipUtils
{

    public ZipUtils()
    {
    }

    public static String unzipFile()
    {
        String folderRoot = PropertyReader.getProperty("DwnldFldr", "").trim();
        String filename = FileUtil.getLatestFilefromDir(folderRoot, ".zip");
        String filePath = (new StringBuilder(String.valueOf(folderRoot))).append("/").append(filename).toString();
        Date date = new Date();
        String timeStamp = DateFormatter.formatDate(date, "ddMMMyyyy-HHmmssS-z");
        String opFolder = (new StringBuilder(String.valueOf(folderRoot))).append("/").append(timeStamp).toString();
        try
        {
            ZipFile zipFile = new ZipFile(filePath);
            for(Enumeration enu = zipFile.entries(); enu.hasMoreElements();)
            {
                ZipEntry zipEntry = (ZipEntry)enu.nextElement();
                String name = zipEntry.getName();
                File file = new File((new StringBuilder(String.valueOf(opFolder))).append("/").append(name).toString());
                if(name.endsWith("/"))
                {
                    file.mkdirs();
                } else
                {
                    File parent = file.getParentFile();
                    if(parent != null)
                        parent.mkdirs();
                    InputStream is = zipFile.getInputStream(zipEntry);
                    FileOutputStream fos = new FileOutputStream(file);
                    byte bytes[] = new byte[1024];
                    int length;
                    while((length = is.read(bytes)) >= 0) 
                        fos.write(bytes, 0, length);
                    is.close();
                    fos.close();
                }
            }

            zipFile.close();
            return opFolder;
        }
        catch(IOException e)
        {
            FrameworkLogger.log("Error in unzipping.", crossbrowser.logger.FrameworkLogger.LEVEL.error, crossbrowser/utils/ZipUtils);
            FrameworkLogger.log((new StringBuilder("Error in unzipping. Error: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.trace, crossbrowser/utils/ZipUtils);
            return null;
        }
    }
}

// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExcelAccess.java

package crossbrowser.utils;

import crossbrowser.logger.FrameworkLogger;
import java.util.HashMap;

// Referenced classes of package crossbrowser.utils:
//            ExcelAccess, DataRow

private final class ExcelAccess$NamedRowHandler$Access
    implements ExcelAccess.NamedRowAccess
{

    public DataRow get()
    {
        String values[] = rowAccess.get();
        HashMap namedValues = new HashMap();
        for(int ix = 0; ix < values.length; ix++)
        {
            if(ix >= ExcelAccess.NamedRowHandler.access$0(ExcelAccess.NamedRowHandler.this).length)
                break;
            String colName = ExcelAccess.NamedRowHandler.access$0(ExcelAccess.NamedRowHandler.this)[ix];
            namedValues.put(colName, values[ix]);
        }

        FrameworkLogger.log((new StringBuilder("Returning from get(): DataRow(")).append(namedValues).append(")").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
        return new DataRow(namedValues);
    }

    public void set(DataRow datarow)
    {
    }

    public void set(String s, String s1)
    {
    }

    private ExcelAccess.RowAccess rowAccess;
    final ExcelAccess.NamedRowHandler this$1;

    private ExcelAccess$NamedRowHandler$Access(ExcelAccess.RowAccess rowAccess)
    {
        this$1 = ExcelAccess.NamedRowHandler.this;
        super();
        this.rowAccess = rowAccess;
    }

    ExcelAccess$NamedRowHandler$Access(ExcelAccess.RowAccess rowaccess, ExcelAccess$NamedRowHandler$Access excelaccess$namedrowhandler$access)
    {
        this(rowaccess);
    }
}

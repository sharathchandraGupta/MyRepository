// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   XMLUtils.java

package crossbrowser.utils;

import crossbrowser.logger.FrameworkLogger;
import java.io.IOException;
import javax.xml.parsers.*;
import javax.xml.xpath.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

public class XMLUtils
{

    public XMLUtils()
    {
    }

    public static Node getNode(Document doc, String xpathStr)
    {
        try
        {
            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            XPathExpression expr = xpath.compile(xpathStr);
            Node nl = (Node)expr.evaluate(doc, XPathConstants.NODE);
            return nl;
        }
        catch(Exception e)
        {
            FrameworkLogger.log((new StringBuilder("Error: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.trace, crossbrowser/utils/XMLUtils);
        }
        return null;
    }

    public static Document docBuilder(String filePath)
    {
        Document doc = null;
        try
        {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            doc = db.parse(filePath);
            doc.getDocumentElement().normalize();
        }
        catch(ParserConfigurationException e)
        {
            FrameworkLogger.log((new StringBuilder("Error in parsing. Error: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.trace, crossbrowser/utils/XMLUtils);
        }
        catch(SAXException e)
        {
            FrameworkLogger.log((new StringBuilder("Error in parsing. Error: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.trace, crossbrowser/utils/XMLUtils);
        }
        catch(IOException e)
        {
            FrameworkLogger.log((new StringBuilder("Error in parsing. Error: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.trace, crossbrowser/utils/XMLUtils);
        }
        return doc;
    }

    public static String tidyXpath(String xpathStr)
    {
        if(!xpathStr.startsWith("//"))
            if(xpathStr.startsWith("/"))
                xpathStr = (new StringBuilder("/")).append(xpathStr).toString();
            else
                xpathStr = (new StringBuilder("//")).append(xpathStr).toString();
        return xpathStr;
    }
}

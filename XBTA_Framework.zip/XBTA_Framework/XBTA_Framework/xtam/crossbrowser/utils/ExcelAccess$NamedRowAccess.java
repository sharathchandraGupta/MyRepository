// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExcelAccess.java

package crossbrowser.utils;


// Referenced classes of package crossbrowser.utils:
//            ExcelAccess, DataRow

public static interface ExcelAccess$NamedRowAccess
{

    public abstract DataRow get();

    public abstract void set(DataRow datarow);

    public abstract void set(String s, String s1);
}

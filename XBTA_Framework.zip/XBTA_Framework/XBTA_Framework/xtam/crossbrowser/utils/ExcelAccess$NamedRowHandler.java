// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExcelAccess.java

package crossbrowser.utils;

import crossbrowser.logger.FrameworkLogger;
import java.util.HashMap;
import java.util.Map;

// Referenced classes of package crossbrowser.utils:
//            ExcelAccess

public static abstract class ExcelAccess$NamedRowHandler
    implements ExcelAccess.RowHandler
{
    /* member class not found */
    class Access {}


    public abstract boolean handleRow(ExcelAccess.NamedRowAccess namedrowaccess, int i);

    public final boolean handleRow(ExcelAccess.RowAccess rowAccess, int rowIx)
    {
        String colValues[] = rowAccess.get();
        if(rowIx == 0)
        {
            setColNames(colValues);
            FrameworkLogger.log("Returning from handleRow(): true", crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
            return true;
        } else
        {
            FrameworkLogger.log((new StringBuilder("Returning from handleRow(): handleRow(new Access(")).append(rowAccess).append("),").append(rowIx - 1).append(")").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
            return handleRow(((ExcelAccess.NamedRowAccess) (new Access(rowAccess, null))), rowIx - 1);
        }
    }

    private void setColNames(String colNames[])
    {
        this.colNames = colNames;
        for(int ix = 0; ix < colNames.length; ix++)
            colName2IxMap.put(colNames[ix], Integer.valueOf(ix));

    }

    private String colNames[];
    private Map colName2IxMap;


    public ExcelAccess$NamedRowHandler()
    {
        colName2IxMap = new HashMap();
    }
}

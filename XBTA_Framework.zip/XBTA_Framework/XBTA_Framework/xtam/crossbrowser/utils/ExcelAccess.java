// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExcelAccess.java

package crossbrowser.utils;

import crossbrowser.logger.FrameworkLogger;
import java.io.*;
import java.util.*;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

// Referenced classes of package crossbrowser.utils:
//            DataRow

public class ExcelAccess
{
    /* member class not found */
    class MapReader {}

    /* member class not found */
    class NamedRowAccess {}

    public static abstract class NamedRowHandler
        implements RowHandler
    {
        /* member class not found */
        class Access {}


        public abstract boolean handleRow(NamedRowAccess namedrowaccess, int i);

        public final boolean handleRow(RowAccess rowAccess, int rowIx)
        {
            String colValues[] = rowAccess.get();
            if(rowIx == 0)
            {
                setColNames(colValues);
                FrameworkLogger.log("Returning from handleRow(): true", crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
                return true;
            } else
            {
                FrameworkLogger.log((new StringBuilder("Returning from handleRow(): handleRow(new Access(")).append(rowAccess).append("),").append(rowIx - 1).append(")").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
                return handleRow(((NamedRowAccess) (new Access(rowAccess, null))), rowIx - 1);
            }
        }

        private void setColNames(String colNames[])
        {
            this.colNames = colNames;
            for(int ix = 0; ix < colNames.length; ix++)
                colName2IxMap.put(colNames[ix], Integer.valueOf(ix));

        }

        private String colNames[];
        private Map colName2IxMap;


        public NamedRowHandler()
        {
            colName2IxMap = new HashMap();
        }
    }

    public static interface RowAccess
    {

        public abstract String[] get();

        public abstract void set(String as[]);

        public abstract void set(int i, String s);
    }

    public static class RowArrayBuilder extends MapReader
    {

        public boolean handleRow(DataRow row, int rowIx)
        {
            rows.add(row);
            return true;
        }

        private List rows;

        public RowArrayBuilder(List rows)
        {
            this.rows = rows;
        }
    }

    public static interface RowHandler
    {

        public abstract boolean handleRow(RowAccess rowaccess, int i);
    }

    private static class SimpleRowAccess
        implements RowAccess
    {

        public String[] get()
        {
            String colValues[] = new String[cells.size()];
            for(int j = 0; j < cells.size(); j++)
                switch(((Cell)cells.get(j)).getCellType())
                {
                case 1: // '\001'
                    colValues[j] = ((Cell)cells.get(j)).getStringCellValue();
                    break;

                case 0: // '\0'
                    ((Cell)cells.get(j)).setCellType(1);
                    colValues[j] = ((Cell)cells.get(j)).getStringCellValue();
                    break;

                case 4: // '\004'
                    colValues[j] = Boolean.toString(((Cell)cells.get(j)).getBooleanCellValue());
                    break;
                }

            FrameworkLogger.log((new StringBuilder("Returning from SimpleRowAccess: ")).append(colValues).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
            return colValues;
        }

        public void set(String values[])
        {
            for(int i = 0; i < cells.size(); i++)
                if(i >= values.length)
                    break;

        }

        public void set(int i, String s)
        {
        }

        final ArrayList cells;

        SimpleRowAccess(ArrayList cells)
        {
            this.cells = cells;
        }
    }


    private ExcelAccess()
    {
    }

    public static List sheetNames(String fileName)
    {
        String fileExtension;
        FrameworkLogger.log((new StringBuilder("sheetNames() - ")).append(fileName).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
        String fileNameArr[] = fileName.split("\\.");
        int size = fileNameArr.length;
        fileExtension = fileNameArr[size - 1];
        FileInputStream file;
        file = new FileInputStream(new File(fileName));
        if(fileExtension.equalsIgnoreCase("xlsx"))
        {
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            List sheetNames = new ArrayList();
            for(int i = 0; i < workbook.getNumberOfSheets(); i++)
            {
                FrameworkLogger.log((new StringBuilder("SheetName - ")).append(workbook.getSheetName(i)).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
                sheetNames.add(workbook.getSheetName(i));
            }

            workbook.close();
            FrameworkLogger.log((new StringBuilder("Returning sheetNames - ")).append(sheetNames).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
            return sheetNames;
        }
        try
        {
            if(fileExtension.equalsIgnoreCase("xls"))
            {
                HSSFWorkbook workbook = new HSSFWorkbook(file);
                List sheetNames = new ArrayList();
                for(int i = 0; i < workbook.getNumberOfSheets(); i++)
                {
                    FrameworkLogger.log((new StringBuilder("SheetName - ")).append(workbook.getSheetName(i)).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
                    sheetNames.add(workbook.getSheetName(i));
                }

                workbook.close();
                FrameworkLogger.log((new StringBuilder("Returning sheetNames - ")).append(sheetNames).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
                return sheetNames;
            }
        }
        catch(IOException e)
        {
            FrameworkLogger.log((new StringBuilder("Error while reading Excel: '")).append(fileName).append("'. Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
            FrameworkLogger.log((new StringBuilder("Error while reading Excel: '")).append(fileName).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/utils/ExcelAccess);
        }
        return null;
    }

    public static int accessSheet(String fileName, String sheetName, RowArrayBuilder rowArrayBuilder)
    {
        String fileNameArr[] = fileName.split("\\.");
        int size = fileNameArr.length;
        String fileExtension = fileNameArr[size - 1];
        FileInputStream fis;
        org.apache.poi.hssf.usermodel.HSSFSheet sheet;
        try
        {
            fis = new FileInputStream(new File(fileName));
            if(fileExtension.equalsIgnoreCase("xlsx"))
            {
                wbXLSX = new XSSFWorkbook(fis);
                sheet = wbXLSX.getSheet(sheetName);
                FrameworkLogger.log((new StringBuilder("Returning - access(")).append(sheet).append(",").append(rowArrayBuilder).append(")").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
                return access(sheet, rowArrayBuilder);
            }
        }
        catch(IOException e)
        {
            FrameworkLogger.log((new StringBuilder("Error while reading Excel: '")).append(fileName).append("', SheetName '").append(sheetName).append("'. Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
            FrameworkLogger.log((new StringBuilder("Error while reading Excel: '")).append(fileName).append("', SheetName '").append(sheetName).append("'.").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/utils/ExcelAccess);
            return null.intValue();
        }
        if(fileExtension.equalsIgnoreCase("xls"))
        {
            wbXLS = new HSSFWorkbook(fis);
            sheet = wbXLS.getSheet(sheetName);
            FrameworkLogger.log((new StringBuilder("Returning - access(")).append(sheet).append(",").append(rowArrayBuilder).append(")").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
            return access(sheet, rowArrayBuilder);
        }
        return 0;
    }

    public static int access(Sheet sheet, RowHandler rowHandler)
    {
        int count = 0;
        int rowCount = 0;
        Iterator ite = sheet.rowIterator();
        ArrayList cellArr = new ArrayList();
        while(ite.hasNext()) 
        {
            Row row = (Row)ite.next();
            Cell c;
            for(Iterator cite = row.cellIterator(); cite.hasNext(); cellArr.add(c))
                c = (Cell)cite.next();

            boolean rc = rowHandler.handleRow(new SimpleRowAccess(cellArr), rowCount);
            if(!rc)
                break;
            count++;
            cellArr.clear();
            rowCount++;
        }
        FrameworkLogger.log((new StringBuilder("Returning from access: ")).append(count).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
        return count;
    }

    private static XSSFWorkbook wbXLSX;
    private static HSSFWorkbook wbXLS;
}

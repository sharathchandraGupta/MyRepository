// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExcelAccess.java

package crossbrowser.utils;

import crossbrowser.logger.FrameworkLogger;
import java.util.ArrayList;
import org.apache.poi.ss.usermodel.Cell;

// Referenced classes of package crossbrowser.utils:
//            ExcelAccess

private static class ExcelAccess$SimpleRowAccess
    implements ExcelAccess.RowAccess
{

    public String[] get()
    {
        String colValues[] = new String[cells.size()];
        for(int j = 0; j < cells.size(); j++)
            switch(((Cell)cells.get(j)).getCellType())
            {
            case 1: // '\001'
                colValues[j] = ((Cell)cells.get(j)).getStringCellValue();
                break;

            case 0: // '\0'
                ((Cell)cells.get(j)).setCellType(1);
                colValues[j] = ((Cell)cells.get(j)).getStringCellValue();
                break;

            case 4: // '\004'
                colValues[j] = Boolean.toString(((Cell)cells.get(j)).getBooleanCellValue());
                break;
            }

        FrameworkLogger.log((new StringBuilder("Returning from SimpleRowAccess: ")).append(colValues).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/utils/ExcelAccess);
        return colValues;
    }

    public void set(String values[])
    {
        for(int i = 0; i < cells.size(); i++)
            if(i >= values.length)
                break;

    }

    public void set(int i, String s)
    {
    }

    final ArrayList cells;

    ExcelAccess$SimpleRowAccess(ArrayList cells)
    {
        this.cells = cells;
    }
}

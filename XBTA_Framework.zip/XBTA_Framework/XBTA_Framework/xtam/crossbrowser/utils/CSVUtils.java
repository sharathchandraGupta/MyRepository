// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CSVUtils.java

package crossbrowser.utils;

import crossbrowser.logger.FrameworkLogger;
import java.io.*;
import java.util.*;
import org.apache.commons.csv.*;
import org.apache.commons.io.input.BOMInputStream;

public class CSVUtils
{

    public CSVUtils()
    {
    }

    public static String getValue(String line)
    {
        if(line.startsWith("\""))
        {
            line = line.substring(1);
            if(line.endsWith("\""))
                line = line.substring(0, line.length() - 1);
        }
        return line.split("-")[1].trim();
    }

    public static CSVRecord getRow(CSVParser parser, String refKey, String refKeyVal)
    {
        List records;
        int i;
        Iterator iterator;
        records = parser.getRecords();
        i = 0;
        iterator = records.iterator();
          goto _L1
_L3:
        CSVRecord record = (CSVRecord)iterator.next();
        if(refKeyVal.equalsIgnoreCase(record.get(refKey)))
        {
            parser.close();
            return record;
        }
        if(i != records.size() - 1)
            continue; /* Loop/switch isn't completed */
        FrameworkLogger.log((new StringBuilder("No row found with key:")).append(refKey).append(" and value:").append(refKeyVal).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.info, crossbrowser/utils/CSVUtils);
        parser.close();
        return null;
        i++;
_L1:
        if(iterator.hasNext()) goto _L3; else goto _L2
_L2:
        break MISSING_BLOCK_LABEL_130;
        IOException e;
        e;
        FrameworkLogger.log("Error in parsing the Rows of csv file", crossbrowser.logger.FrameworkLogger.LEVEL.info, crossbrowser/utils/CSVUtils);
        return null;
    }

    public static Map getHeaderMap(CSVParser parser)
    {
        return parser.getHeaderMap();
    }

    public static CSVParser parseCSV(String csvfilePath)
    {
        try
        {
            CSVParser parser = new CSVParser(new InputStreamReader(new BOMInputStream(new FileInputStream(csvfilePath)), "UTF-8"), CSVFormat.DEFAULT.withHeader(new String[0]));
            return parser;
        }
        catch(IOException e)
        {
            FrameworkLogger.log("Error in parsing the csv file", crossbrowser.logger.FrameworkLogger.LEVEL.info, crossbrowser/utils/CSVUtils);
        }
        return null;
    }

    public static CSVParser parseCSV(String csvfilePath, int linesToSkip)
    {
        try
        {
            BufferedReader read = new BufferedReader(new InputStreamReader(new FileInputStream(csvfilePath), "UTF-8"));
            for(int i = 1; i <= linesToSkip; i++)
                read.readLine();

            CSVParser parser = new CSVParser(read, CSVFormat.DEFAULT.withHeader(new String[0]));
            return parser;
        }
        catch(IOException e)
        {
            FrameworkLogger.log("Error in parsing the csv file", crossbrowser.logger.FrameworkLogger.LEVEL.info, crossbrowser/utils/CSVUtils);
        }
        return null;
    }
}

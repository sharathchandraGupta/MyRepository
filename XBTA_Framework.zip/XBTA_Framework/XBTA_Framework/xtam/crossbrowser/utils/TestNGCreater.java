// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TestNGCreater.java

package crossbrowser.utils;

import crossbrowser.helper.PropertyReader;
import crossbrowser.logger.FrameworkLogger;
import java.util.ArrayList;
import java.util.List;
import org.testng.TestNG;
import org.testng.xml.*;

public class TestNGCreater
{

    public TestNGCreater()
    {
    }

    public void createTest(String testIx)
    {
        FrameworkLogger.log("Creating TestNG Suite", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        XmlSuite suite = new XmlSuite();
        suite.setName(testIx.replace(".java", ""));
        String minuts = PropertyReader.getProperty("TimeOut", "5");
        float minutsInt = Float.parseFloat(minuts);
        long miliSec = (long)(minutsInt * 60000F);
        suite.setTimeOut((new StringBuilder(String.valueOf(miliSec))).toString());
        suite.setThreadCount(100);
        FrameworkLogger.log((new StringBuilder("Suite Name: ")).append(testIx.replace(".java", "")).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        XmlTest test = new XmlTest(suite);
        test.setName((new StringBuilder(String.valueOf(testIx.replace(".java", "")))).append("-xBrowser Test").toString());
        test.setParallel("instances");
        test.addParameter("testCaseName", testIx);
        FrameworkLogger.log((new StringBuilder("Test Case Name: ")).append(testIx).append(".").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        List classes = new ArrayList();
        classes.add(new XmlClass("crossbrowser.harness.FactoryClass"));
        test.setXmlClasses(classes);
        List suites = new ArrayList();
        suites.add(suite);
        TestNG tng = new TestNG();
        tng.setUseDefaultListeners(false);
        tng.setVerbose(0);
        tng.setXmlSuites(suites);
        FrameworkLogger.log("Running TestNG Test.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        tng.run();
    }
}

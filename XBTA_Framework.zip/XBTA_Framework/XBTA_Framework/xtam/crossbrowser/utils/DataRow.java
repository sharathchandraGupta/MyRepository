// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DataRow.java

package crossbrowser.utils;

import crossbrowser.logger.FrameworkLogger;
import java.util.*;

public class DataRow extends HashMap
{

    public DataRow(Map data)
    {
        putAll(data);
        FrameworkLogger.log((new StringBuilder("DataRow - ")).append(data).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
    }

    public DataRow()
    {
    }

    public String toString()
    {
        String mapValues = "";
        Iterable keys = keySet();
        for(Iterator iterator = keys.iterator(); iterator.hasNext();)
        {
            String key = (String)iterator.next();
            FrameworkLogger.log((new StringBuilder("Key - ")).append(key).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
            mapValues = (new StringBuilder(String.valueOf(mapValues))).append(key).append(" = ").append((String)get(key)).append(";").toString();
        }

        FrameworkLogger.log((new StringBuilder("Returning from toString() - {")).append(mapValues).append("}").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        return (new StringBuilder("{")).append(mapValues).append("}").toString();
    }

    private static final long serialVersionUID = 0xd4d60d2d3a9be537L;
}

// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TestCaseSerializer.java

package crossbrowser.harness;

import crossbrowser.logger.FrameworkLogger;
import crossbrowser.utilss.JsonReader;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.*;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

// Referenced classes of package crossbrowser.harness:
//            Harness, Serializer

public class TestCaseSerializer
{

    public TestCaseSerializer()
    {
        harness = new Harness();
        serializer = new Serializer();
        ar = new ArrayList();
    }

    private static List findClasses(File directory, String packageName)
    {
        List classes = new ArrayList();
        if(!directory.exists())
        {
            FrameworkLogger.log((new StringBuilder("Directory does not exists. Directory : ")).append(directory).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
            return classes;
        }
        File files[] = directory.listFiles();
        File afile[];
        int j = (afile = files).length;
        for(int i = 0; i < j; i++)
        {
            File file = afile[i];
            if(file.isDirectory())
            {
                if(!$assertionsDisabled && file.getName().contains("."))
                    throw new AssertionError();
                classes.addAll(findClasses(file, (new StringBuilder(String.valueOf(packageName))).append(".").append(file.getName()).toString()));
            } else
            if(file.getName().endsWith(".class"))
                try
                {
                    classes.add(Class.forName((new StringBuilder(String.valueOf(packageName))).append('.').append(file.getName().substring(0, file.getName().length() - 6)).toString()));
                }
                catch(ClassNotFoundException e)
                {
                    FrameworkLogger.log((new StringBuilder("Error getting class : ")).append(file.getName()).append(". Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                    FrameworkLogger.log((new StringBuilder("Error reading testcase file : ")).append(file.getName()).append(".").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/harness/TestCaseSerializer);
                }
        }

        FrameworkLogger.log((new StringBuilder("Returning Classes : ")).append(((Object) (classes.toArray())).toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
        return classes;
    }

    public static ArrayList getClasses(String packageName)
    {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        if(!$assertionsDisabled && classLoader == null)
            throw new AssertionError();
        FrameworkLogger.log((new StringBuilder("Package Name : ")).append(packageName).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
        String path = packageName.replace('.', '/');
        FrameworkLogger.log((new StringBuilder("Path : ")).append(path).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
        List dirs = new ArrayList();
        try
        {
            Enumeration resources = classLoader.getResources(path);
            FrameworkLogger.log((new StringBuilder("Class Loader : ")).append(classLoader.getResources(path)).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
            FrameworkLogger.log((new StringBuilder("Resources : ")).append(resources.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
            URL resource;
            for(; resources.hasMoreElements(); dirs.add(new File(resource.getFile())))
            {
                resource = (URL)resources.nextElement();
                FrameworkLogger.log((new StringBuilder("Resource path: ")).append(resource.getFile().toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
            }

        }
        catch(IOException e)
        {
            FrameworkLogger.log((new StringBuilder("Error getting class. Error: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
            FrameworkLogger.log("Error reading testcase file.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/harness/TestCaseSerializer);
        }
        ArrayList classes = new ArrayList();
        File directory;
        for(Iterator iterator = dirs.iterator(); iterator.hasNext(); classes.addAll(findClasses(directory, packageName)))
        {
            directory = (File)iterator.next();
            FrameworkLogger.log((new StringBuilder("Directory : ")).append(directory).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
            FrameworkLogger.log((new StringBuilder("Package Name : ")).append(packageName).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
        }

        FrameworkLogger.log((new StringBuilder("Returning Classes : ")).append(((Object) (classes.toArray())).toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
        return classes;
    }

    protected ArrayList getTestCaseInstances(String uiMapFile, Class testClass, Map combinations, List testData, List rowRef, String hubIP, String hubPort, 
            String dir)
        throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException
    {
        try
        {
            FrameworkLogger.log((new StringBuilder("Combinations : ")).append(combinations.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
            List testRowData = testData;
            Iterator entryIx = combinations.entrySet().iterator();
            int counter = 0;
            while(entryIx.hasNext()) 
            {
                java.util.Map.Entry os = (java.util.Map.Entry)entryIx.next();
                Map browserVersions = (Map)os.getValue();
                JSONArray browsers = (JSONArray)browserVersions.get("browsers");
                List browserVersion = new ArrayList();
                for(int i = 0; i < browsers.size(); i++)
                    browserVersion.add(browsers.get(i).toString());

                for(Iterator iterator = browserVersion.iterator(); iterator.hasNext();)
                {
                    String browser = (String)iterator.next();
                    Map capability = new HashMap();
                    String browver[] = browser.toString().split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)");
                    FrameworkLogger.log((new StringBuilder("Browser : ")).append(browver).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                    capability.put("os", os.getKey().toString());
                    FrameworkLogger.log((new StringBuilder("OS : ")).append(os.getKey().toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                    capability.put("browser", browver[0]);
                    FrameworkLogger.log((new StringBuilder("Browser : ")).append(browver[0]).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                    if(dir.equals("/"))
                    {
                        if(browver.length == 1)
                        {
                            FrameworkLogger.log("Browser version was not provided", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/harness/TestCaseSerializer);
                        } else
                        {
                            capability.put("version", browser.toString().replace(browver[0], ""));
                            FrameworkLogger.log((new StringBuilder("Version: ")).append(browver[1]).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                        }
                    } else
                    if(dir.isEmpty())
                    {
                        capability.put("version", "");
                        FrameworkLogger.log("Version: ANY", crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                    }
                    capability.put("hubIP", hubIP);
                    capability.put("hubPort", hubPort);
                    capability.put("dir", dir);
                    FrameworkLogger.log((new StringBuilder("HUB IP: ")).append(hubIP).append(" - HUB Port: ").append(hubPort).append(" - Dir: ").append(dir).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                    RemoteWebDriver remoteWebDriver = harness.setUp(capability, testClass.toString());
                    if(remoteWebDriver != null)
                        if(testRowData != null && uiMapFile != null)
                        {
                            Map testDataRow = serializer.getRowDataMap(testData, (String)rowRef.get(counter % rowRef.size()));
                            Object testCaseObj = testClass.getDeclaredConstructor(new Class[] {
                                org/openqa/selenium/WebDriver, java/util/Map, java/lang/Object
                            }).newInstance(new Object[] {
                                remoteWebDriver, testDataRow, uiMapFile
                            });
                            ar.add(testCaseObj);
                        } else
                        if(testRowData != null && uiMapFile == null)
                        {
                            Map testDataRow = serializer.getRowDataMap(testData, (String)rowRef.get(counter % rowRef.size()));
                            Object testCaseObj = testClass.getDeclaredConstructor(new Class[] {
                                org/openqa/selenium/WebDriver, java/util/Map, java/lang/Object
                            }).newInstance(new Object[] {
                                remoteWebDriver, testDataRow, null
                            });
                            ar.add(testCaseObj);
                        } else
                        if(testRowData == null && uiMapFile != null)
                        {
                            Object testCaseObj = testClass.getDeclaredConstructor(new Class[] {
                                org/openqa/selenium/WebDriver, java/util/Map, java/lang/Object
                            }).newInstance(new Object[] {
                                remoteWebDriver, null, uiMapFile
                            });
                            ar.add(testCaseObj);
                        } else
                        {
                            Object testCaseObj = testClass.getDeclaredConstructor(new Class[] {
                                org/openqa/selenium/WebDriver, java/util/Map, java/lang/Object
                            }).newInstance(new Object[] {
                                remoteWebDriver, null, null
                            });
                            ar.add(testCaseObj);
                        }
                    counter++;
                }

            }
            FrameworkLogger.log((new StringBuilder("TestCaseObject: ")).append(((Object) (ar.toArray())).toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
            return ar;
        }
        catch(Exception e)
        {
            FrameworkLogger.log((new StringBuilder("Error while creating testcase object. Error: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
        }
        FrameworkLogger.log("Error while creating testcase object.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/harness/TestCaseSerializer);
        return null;
    }

    protected ArrayList getTestCases(String testCaseName)
    {
        String testPack = "xtam.test";
        FrameworkLogger.log((new StringBuilder("TestCaseSerializer getTestCases(): ")).append(testCaseName).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
        List testObjects = new ArrayList();
        try
        {
            List classInstances = getClasses(testPack);
            FrameworkLogger.log((new StringBuilder("Classes: ")).append(classInstances.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
            FrameworkLogger.log((new StringBuilder("Class Instances is Empty?: ")).append(classInstances.isEmpty()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
            JsonReader reader = new JsonReader();
            List testSuiteObject = reader.parseJson("browsers.json");
            for(Iterator iterator = testSuiteObject.iterator(); iterator.hasNext();)
            {
                Map test = (Map)iterator.next();
                Map executionSpace = (Map)test.get("executionspace");
                FrameworkLogger.log((new StringBuilder("executionSpace: ")).append(executionSpace.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                ArrayList testCases = (ArrayList)executionSpace.get("testCases");
                FrameworkLogger.log((new StringBuilder("testCases: ")).append(testCases.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                Map listCombinations = (Map)executionSpace.get("combinations");
                FrameworkLogger.log((new StringBuilder("listCombinations: ")).append(listCombinations.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                Map combinations = (Map)listCombinations.get(testCaseName.replace(".java", ""));
                FrameworkLogger.log((new StringBuilder("combinations: ")).append(combinations.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                String testDataFile = (String)executionSpace.get("testData");
                FrameworkLogger.log((new StringBuilder("testDataFile: ")).append(testDataFile.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                String uiMapFile = (String)executionSpace.get("repository");
                FrameworkLogger.log((new StringBuilder("uiMapFile: ")).append(uiMapFile.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                List testCaseDataRef = (List)executionSpace.get("testCaseData");
                FrameworkLogger.log((new StringBuilder("testCaseDataRef: ")).append(testCaseDataRef.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                String hubIP = (String)test.get("server");
                FrameworkLogger.log((new StringBuilder("hubIP: ")).append(hubIP.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                String hubPort = (String)test.get("port");
                FrameworkLogger.log((new StringBuilder("hubPort: ")).append(hubPort.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                String dir = (String)test.get("dir");
                FrameworkLogger.log((new StringBuilder("dir: ")).append(dir.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                for(Iterator iterator1 = testCases.iterator(); iterator1.hasNext();)
                {
                    String testIx = (String)iterator1.next();
                    for(Iterator iterator2 = classInstances.iterator(); iterator2.hasNext();)
                    {
                        Class classInstance = (Class)iterator2.next();
                        if(classInstance.toString().replace((new StringBuilder("class ")).append(testPack).append(".").toString(), "").equals(StringUtils.join(testIx.split(".java"))))
                        {
                            if(testCaseDataRef != null)
                            {
                                for(Iterator iterator3 = testCaseDataRef.iterator(); iterator3.hasNext();)
                                {
                                    Map testDataIx = (Map)iterator3.next();
                                    FrameworkLogger.log((new StringBuilder("testDataIx: ")).append(testDataIx.get("name").toString()).append(" ").append(testCaseName).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
                                    if(classInstance.toString().replace((new StringBuilder("class ")).append(testPack).append(".").toString(), "").equals(testDataIx.get("name").toString()) && testCaseName.replace(".java", "").equals(testDataIx.get("name").toString()))
                                        testObjects.add(getTestCaseInstances(uiMapFile, classInstance, combinations, serializer.readSheetData(StringUtils.join(testIx.split(".java")), testDataFile), (List)testDataIx.get("_rowIds"), hubIP, hubPort, dir));
                                }

                            } else
                            {
                                testObjects.add(getTestCaseInstances(uiMapFile, classInstance, combinations, serializer.readSheetData(StringUtils.join(testIx.split(".java")), testDataFile), null, hubIP, hubPort, dir));
                            }
                            break;
                        }
                    }

                }

            }

        }
        catch(Exception testCasts)
        {
            FrameworkLogger.log((new StringBuilder("Error while getting testcase object. Error: ")).append(testCasts.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
            FrameworkLogger.log("Error while getting testcase object.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/harness/TestCaseSerializer);
        }
        FrameworkLogger.log((new StringBuilder("Returning from getTestCases(): ")).append(testObjects.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/harness/TestCaseSerializer);
        return ar;
    }

    private Harness harness;
    private Serializer serializer;
    private ArrayList ar;
    static final boolean $assertionsDisabled = !crossbrowser/harness/TestCaseSerializer.desiredAssertionStatus();

}

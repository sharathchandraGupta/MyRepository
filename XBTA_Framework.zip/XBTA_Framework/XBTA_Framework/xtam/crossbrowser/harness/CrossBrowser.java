// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CrossBrowser.java

package crossbrowser.harness;

import crossbrowser.bean.ReportBean;
import crossbrowser.bean.TestCaseCreationBean;
import crossbrowser.logger.FrameworkLogger;
import crossbrowser.report.MasterReporter;
import crossbrowser.utils.JsonReader;
import crossbrowser.utils.TestNGCreater;

import java.util.*;

public class CrossBrowser
{

    public CrossBrowser()
    {
    }

    public void runCrossBrowser()
    {
        JsonReader reader = new JsonReader();
        TestNGCreater testNGCreater = new TestNGCreater();
        List testSuiteObject = reader.parseJson("browsers.json"); //it will return the array list with details in the json
//        FrameworkLogger.log("Reading 'browsers.json' file.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        if(testSuiteObject.isEmpty())
//            FrameworkLogger.log("'browsers.json' file is empty.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
        for(Iterator iterator = testSuiteObject.iterator(); iterator.hasNext();)
        {
            Map testMap = (Map)iterator.next();
//            FrameworkLogger.log((new StringBuilder("Iterating over testSuiteObject -> testMap:")).append(testMap).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
            Map executionSpace = (Map)testMap.get("executionspace");
            ArrayList testCases = (ArrayList)executionSpace.get("testCases");
            ArrayList testCasesResolved = new ArrayList();
            String testIx;
            for(Iterator iterator1 = testCases.iterator(); iterator1.hasNext(); testCasesResolved.add(testIx.replace(".java", "")))
                testIx = (String)iterator1.next();

            Date startDate = new Date();
            ReportBean.startDate = startDate;
            for(Iterator iterator2 = testCases.iterator(); iterator2.hasNext(); MasterReporter.callReporter(testCasesResolved))
            {
                String testIx1 = (String)iterator2.next();
                TestCaseCreationBean.testcasesInstanceCreated = new ArrayList();
//                FrameworkLogger.log((new StringBuilder("In runCrossBrowser() method. value testIx:")).append(testIx1).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
//                FrameworkLogger.log((new StringBuilder("Starting execution of Testcase: '")).append(testIx1).append("'").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.info, getClass());
                testNGCreater.createTest(testIx1);
                Date endDate = new Date();
                ReportBean.endDate = endDate;
            }

        }

    }
}

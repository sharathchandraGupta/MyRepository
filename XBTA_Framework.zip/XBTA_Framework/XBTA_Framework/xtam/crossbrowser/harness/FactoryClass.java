// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FactoryClass.java

package crossbrowser.harness;

import crossbrowser.logger.FrameworkLogger;
import java.util.ArrayList;

// Referenced classes of package crossbrowser.harness:
//            TestCaseSerializer

public class FactoryClass
{

    public FactoryClass()
    {
        tcSerializer = new TestCaseSerializer();
    }

    public Object[] runTestSuite(String testCaseName)
    {
        ArrayList ar;
//        FrameworkLogger.log((new StringBuilder("Entering Factory Class with TestCase:")).append(testCaseName).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
//        FrameworkLogger.log("Entering Factory Class - running 'runTestSuite()' method.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        ar = new ArrayList();
        ar = tcSerializer.getTestCases(testCaseName);
//        FrameworkLogger.log((new StringBuilder("Got Testcase Object[tcSerializer.getTestCases]:")).append(ar).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        if(ar.size() == 0)
        	System.out.println("Nothing");
//            break MISSING_BLOCK_LABEL_150;
        Object res[] = null;
        res = new Object[ar.size()];
        res = ar.toArray();
        if(res.length != 0)
        {
//            FrameworkLogger.log((new StringBuilder("Returning Testcase object:")).append(((Object) (res))).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
            return res;
        }
//        FrameworkLogger.log("Error in getting test case objects. Please check the availability of nodes and assets.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
        return null;
        try
        {
//            FrameworkLogger.log("Error in getting test case objects. Testcase Object returned from 'tcSerializer.getTestCases()' is Empty.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
//            FrameworkLogger.log("Error in getting test case objects. Please check the availability of nodes and assets.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
            return ar.toArray();
        }
        catch(Exception runTestCase)
        {
//            FrameworkLogger.log((new StringBuilder("Error in getting test case objects. Exception: ")).append(runTestCase.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        }
//        FrameworkLogger.log("Error in getting test case objects. Please check the availability of nodes and assets.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
        return null;
    }

    private TestCaseSerializer tcSerializer;
}

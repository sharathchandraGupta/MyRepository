// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Serializer.java

package crossbrowser.harness;

import crossbrowser.logger.FrameworkLogger;
import crossbrowser.utils.ExcelAccess;
import java.io.File;
import java.util.*;

public class Serializer
{

    public Serializer()
    {
        uiMap = new ArrayList();
    }

    public List readSheetData(String sheetName, String testDataFile)
    {
        List testDataMap = new ArrayList();
        if(testDataFile != null)
        {
            File f = new File((new StringBuilder("./assets/TestData/")).append(testDataFile).toString());
            if(f.exists() && !f.isDirectory())
            {
//                FrameworkLogger.log((new StringBuilder("Reading test Data file : ")).append(testDataFile).append(".").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                ExcelAccess.accessSheet((new StringBuilder("./assets/TestData/")).append(testDataFile).toString(), sheetName, new crossbrowser.utils.ExcelAccess.RowArrayBuilder(testDataMap));
                return testDataMap;
            } else
            {
//                FrameworkLogger.log((new StringBuilder("The selected test Data file : ")).append(testDataFile).append(" does not Exist").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
                return null;
            }
        } else
        {
//            FrameworkLogger.log("Test Data File is Empty in 'browser.json'.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
            return null;
        }
    }

    public List readObjectRepository(String uiMapFile)
    {
        if(uiMapFile != null)
        {
            File f = new File((new StringBuilder("./assets/ObjectRepository/")).append(uiMapFile).toString());
            if(f.exists() && !f.isDirectory())
            {
//                FrameworkLogger.log((new StringBuilder("Reading ObjectRepository file : ")).append(uiMapFile).append(".").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                ExcelAccess.accessSheet((new StringBuilder("./assets/ObjectRepository/")).append(uiMapFile).toString(), "locators", new crossbrowser.utils.ExcelAccess.RowArrayBuilder(uiMap));
                return uiMap;
            } else
            {
//                FrameworkLogger.log((new StringBuilder("The selected ObjectRepository file : ")).append(uiMapFile).append(" does not Exist").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
                return null;
            }
        } else
        {
//            FrameworkLogger.log("Object Repository File is Empty in 'browser.json'.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
            return null;
        }
    }

    public Map getRowDataMap(List testDataMap, String rowId)
    {
        List rowDataMap;
        rowDataMap = testDataMap;
        if(testDataMap.isEmpty())
//            FrameworkLogger.log("Test Data Map is Empty.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
        if(rowId.isEmpty())
        	System.out.println("Test Data Row ");
//            FrameworkLogger.log("Test Data Row id is Empty.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
        boolean notFound;
        Iterator iterator;
        notFound = true;
        iterator = rowDataMap.iterator();
        while(iterator.hasNext()) 
        {
            Map rowMap = (Map)iterator.next();
            String sTemp = (String)rowMap.get("_rowId");
            if(sTemp.contains(rowId))
            {
//                FrameworkLogger.log("Returning test data from Serializer.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                notFound = false;
                return rowMap;
            }
        }
        if(notFound)
        	System.out.println("Test Data Sheet not cont");
//            FrameworkLogger.log((new StringBuilder("Test Data Sheet not contains row id :")).append(rowId).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
//          goto _L1;
        Exception e;
//        e;
//        FrameworkLogger.log((new StringBuilder("Error while reading test data. Row ID : ")).append(rowId).append(". Error: ").append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
//        FrameworkLogger.log((new StringBuilder("Error while reading test data. Row ID : ")).append(rowId).append(".").toString(), crossbrowser.logger.FrameworkLogger..fatal, getClass());
//_L1:
//        FrameworkLogger.log((new StringBuilder("Returning NULL for row id :")).append(rowId).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
        return null;
    }

    List uiMap;
}

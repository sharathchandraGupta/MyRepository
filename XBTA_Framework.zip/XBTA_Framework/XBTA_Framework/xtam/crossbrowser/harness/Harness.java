// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Harness.java

package crossbrowser.harness;

import crossbrowser.bean.*;
import crossbrowser.helper.DateFormatter;
import crossbrowser.logger.FrameworkLogger;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Platform;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;

public class Harness
{

    public Harness()
    {
    }

    public RemoteWebDriver setUp(Map capability, String testcaseName)
    {
        DesiredCapabilities cap = new DesiredCapabilities();
        RemoteWebDriver hubDriver = null;
//        FrameworkLogger.log((new StringBuilder("Creating RemoteWebDriver/LocalWebDriver with capability: ")).append(capability.toString()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        if(capability.get("dir").toString().isEmpty())
        {
//            FrameworkLogger.log("Creating LocalWebDriver", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
            try
            {
                if(capability.get("browser").toString().equalsIgnoreCase("firefox"))
                {
                    hubDriver = new FirefoxDriver();
//                    FrameworkLogger.log("Created FirefoxDriver", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("browser").toString().equalsIgnoreCase("explorer") || capability.get("browser").toString().equalsIgnoreCase("ie") || capability.get("browser").toString().equalsIgnoreCase("Internetexplorer"))
                {
                    System.setProperty("webdriver.ie.driver", "./driver/IEDriverServer.exe");
                    hubDriver = new InternetExplorerDriver();
//                    FrameworkLogger.log("Created InternetExplorerDriver", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("browser").toString().equalsIgnoreCase("chrome"))
                {
                    System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");
                    hubDriver = new ChromeDriver();
//                    FrameworkLogger.log("Created ChromeDriver", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("browser").toString().equalsIgnoreCase("safari"))
                {
                    hubDriver = new SafariDriver();
//                    FrameworkLogger.log("Created SafariDriver", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("browser").toString().equalsIgnoreCase("android")){
                	
                }
//                    FrameworkLogger.log("Can not run testcase on 'Android' in LocalWebDriver Mode. Setup the Selenium Grid to use 'Android'.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
                else
                if(capability.get("browser").toString().equalsIgnoreCase("safari") && capability.get("os").toString().contains("iOS"))
                	System.out.println("Can not run testcase on 'Safari-iOS'");
//                    FrameworkLogger.log("Can not run testcase on 'Safari-iOS' in LocalWebDriver Mode. Setup the Selenium Grid to use 'Safari' on 'iOS'.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
                else
                	System.out.println("Please provide a proper bro");
                
//                    FrameworkLogger.log((new StringBuilder("Please provide a proper browser name.[Browser name: ")).append(capability.get("browser").toString()).append("]").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
            }
            catch(Exception e)
            {
//                FrameworkLogger.log((new StringBuilder("Error in creating LocalWebDriver. Exception: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
//                FrameworkLogger.log("Error in creating LocalWebDriver. Please check the capability, driver folder and Browser availability.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
            }
        } else
        if(capability.get("dir").toString().equals("/"))
        {
//            FrameworkLogger.log("Creating RemoteWebDriver", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
            try
            {
                if(capability.get("browser").toString().equalsIgnoreCase("firefox"))
                {
                    cap.setBrowserName("firefox");
                    if(Integer.parseInt(capability.get("version").toString().split("(?<=\\D)(?=\\d)|(?<=\\d)(?=\\D)")[0]) <= 47)
                        cap.setCapability("marionette", false);
                    else
                        cap.setCapability("marionette", true);
                    ProfilesIni profilesIni = new ProfilesIni();
                    org.openqa.selenium.firefox.FirefoxProfile fxProfile = profilesIni.getProfile("default");
                    cap.setCapability("firefox_profile", fxProfile);
//                    FrameworkLogger.log("Created RemoteWebDriver. setBrowserName=FireFox.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("browser").toString().equalsIgnoreCase("explorer") || capability.get("browser").toString().equalsIgnoreCase("ie") || capability.get("browser").toString().equalsIgnoreCase("Internetexplorer") || capability.get("browser").toString().equalsIgnoreCase("Internet explorer"))
                {
                    cap.setBrowserName("internet explorer");
                    cap.setCapability("acceptSslCerts", true);
                    cap.setCapability("acceptInsecureCerts", true);
//                    FrameworkLogger.log("Created RemoteWebDriver. setBrowserName=internet explorer.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("browser").toString().equalsIgnoreCase("chrome"))
                {
                    cap.setBrowserName("chrome");
//                    FrameworkLogger.log("Created RemoteWebDriver. setBrowserName=chrome.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("browser").toString().equalsIgnoreCase("safari"))
                {
                    cap.setBrowserName("safari");
//                    FrameworkLogger.log("Created RemoteWebDriver. setBrowserName=safari.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("browser").toString().equalsIgnoreCase("android"))
                {
                    cap.setBrowserName("android");
                    cap.setCapability("launchTimeout", Integer.valueOf(120));
                    cap.setCapability("newCommandTimeout", Integer.valueOf(120));
                    cap.setCapability("platformName", "ANDROID");
                    cap.setCapability("browserName", "chrome");
                    cap.setCapability("deviceName", "Android");
                    cap.setPlatform(Platform.ANDROID);
                    cap.setCapability("deviceName", "Android");
                    cap.setCapability("autoAcceptAlerts", true);
                    cap.setCapability("useLocationServices", true);
                    cap.setCapability("locationServicesEnabled", true);
                    cap.setCapability("locationServicesAuthorized", true);
//                    FrameworkLogger.log("Created RemoteWebDriver. setBrowserName=android.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("browser").toString().equalsIgnoreCase("safari") && capability.get("os").toString().contains("iOS"))
                {
                    cap.setCapability("browserName", "safari");
                    SafariOptions options = new SafariOptions();
                    options.setUseCleanSession(true);
                    cap.setCapability("safari.options", options);
//                    FrameworkLogger.log("Created RemoteWebDriver. setBrowserName=safari, OS=iOS.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("browser").toString().equalsIgnoreCase("edge") || capability.get("browser").toString().equalsIgnoreCase("Microsoft Edge") || capability.get("browser").toString().equalsIgnoreCase("MicrosoftEdge"))
                {
                    cap.setBrowserName("MicrosoftEdge");
//                    FrameworkLogger.log("Created RemoteWebDriver. setBrowserName=microsoft edge.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                {
//                    FrameworkLogger.log((new StringBuilder("Please provide a proper browser name.[Browser name: ")).append(capability.get("browser").toString()).append("]").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
                }
                if(capability.get("os").toString().contains("iOS"))
                {
                    cap.setCapability("browserName", "safari");
                    cap.setCapability("deviceName", "iOS");
                    cap.setCapability("autoAcceptAlerts", true);
                    cap.setCapability("useLocationServices", true);
                    cap.setCapability("locationServicesEnabled", true);
                    cap.setCapability("locationServicesAuthorized", true);
                    cap.setCapability("platformName", "iOS");
                    cap.setCapability("deviceName", "iOS");
                    cap.setCapability("platformName", "iOS");
                    cap.setCapability("platformVersion", capability.get("version").toString());
//                    FrameworkLogger.log((new StringBuilder("Created RemoteWebDriver. OS=iOS, version=")).append(capability.get("version").toString()).append(".").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                }
                cap.setCapability("browserVersion", capability.get("version").toString());
//                FrameworkLogger.log((new StringBuilder("Created RemoteWebDriver. version=")).append(capability.get("version").toString()).append(".").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                if(capability.get("os").toString().toLowerCase().contains("windows7") && !capability.get("browser").toString().equalsIgnoreCase("android"))
                {
                    cap.setPlatform(Platform.WINDOWS);
//                    FrameworkLogger.log("Created RemoteWebDriver. OS=WIN7.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("os").toString().toLowerCase().contains("windows8") && !capability.get("browser").toString().equalsIgnoreCase("android"))
                {
                    cap.setPlatform(Platform.WIN8);
//                    FrameworkLogger.log("Created RemoteWebDriver. OS=WIN8.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("os").toString().toLowerCase().contains("windows10") && !capability.get("browser").toString().equalsIgnoreCase("android"))
                {
                    cap.setPlatform(Platform.WIN8);
//                    FrameworkLogger.log("Created RemoteWebDriver. OS=WIN10.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("os").toString().toLowerCase().contains("mac") && !capability.get("browser").toString().equalsIgnoreCase("android"))
                {
                    cap.setPlatform(Platform.MAC);
//                    FrameworkLogger.log("Created RemoteWebDriver. OS=MAC.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("os").toString().toLowerCase().contains("vista") && !capability.get("browser").toString().equalsIgnoreCase("android"))
                {
                    cap.setPlatform(Platform.VISTA);
//                    FrameworkLogger.log("Created RemoteWebDriver. OS=VISTA.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("os").toString().toLowerCase().contains("xp") && !capability.get("browser").toString().equalsIgnoreCase("android"))
                {
                    cap.setPlatform(Platform.XP);
//                    FrameworkLogger.log("Created RemoteWebDriver. OS=XP.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("browser").toString().toLowerCase().equalsIgnoreCase("android"))
                {
                    cap.setPlatform(Platform.ANDROID);
                    cap.setCapability("launchTimeout", Integer.valueOf(120));
                    cap.setCapability("newCommandTimeout", Integer.valueOf(120));
                    cap.setCapability("platformName", "ANDROID");
                    cap.setCapability("browserName", "chrome");
                    cap.setCapability("deviceName", "Android");
                    cap.setCapability("deviceName", "Android");
                    cap.setPlatform(Platform.ANDROID);
                    cap.setCapability("autoAcceptAlerts", true);
                    cap.setCapability("useLocationServices", true);
                    cap.setCapability("locationServicesEnabled", true);
                    cap.setCapability("locationServicesAuthorized", true);
//                    FrameworkLogger.log("Created RemoteWebDriver. OS=ANDROID[Selendroid].", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("os").toString().equalsIgnoreCase("WindowsNT") && capability.get("browser").toString().equalsIgnoreCase("chrome"))
                {
                    cap.setPlatform(Platform.ANDROID);
                    cap.setCapability("launchTimeout", Integer.valueOf(120));
                    cap.setCapability("newCommandTimeout", Integer.valueOf(120));
                    cap.setCapability("platformName", "ANDROID");
                    cap.setCapability("browserName", "chrome");
                    cap.setCapability("deviceName", "Android");
                    cap.setPlatform(Platform.ANDROID);
                    cap.setCapability("deviceName", "Android");
                    cap.setCapability("autoAcceptAlerts", true);
                    cap.setCapability("useLocationServices", true);
                    cap.setCapability("locationServicesEnabled", true);
                    cap.setCapability("locationServicesAuthorized", true);
                    Map chromeOptions = new HashMap();
                    chromeOptions.put("androidPackage", "com.android.chrome");
                    cap.setCapability("chromeOptions", chromeOptions);
//                    FrameworkLogger.log("Created RemoteWebDriver. OS=ANDROID[Connected to WindowsNT].", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("os").toString().contains("Android"))
                {
                    cap.setPlatform(Platform.ANDROID);
                    cap.setCapability("launchTimeout", Integer.valueOf(120));
                    cap.setCapability("newCommandTimeout", Integer.valueOf(120));
                    cap.setCapability("platformName", "ANDROID");
                    cap.setCapability("browserName", "chrome");
                    cap.setCapability("deviceName", "Android");
                    cap.setPlatform(Platform.ANDROID);
                    cap.setCapability("deviceName", "Android");
                    cap.setCapability("autoAcceptAlerts", true);
                    cap.setCapability("useLocationServices", true);
                    cap.setCapability("locationServicesEnabled", true);
                    cap.setCapability("locationServicesAuthorized", true);
//                    FrameworkLogger.log("Created RemoteWebDriver. OS=ANDROID.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                if(capability.get("os").toString().contains("iOS"))
                {
                    cap.setCapability("platformName", "iOS");
                    cap.setCapability("browserName", "safari");
                    cap.setCapability("deviceName", "iOS");
                    cap.setCapability("autoAcceptAlerts", true);
                    cap.setCapability("useLocationServices", true);
                    cap.setCapability("locationServicesEnabled", true);
                    cap.setCapability("locationServicesAuthorized", true);
                    cap.setCapability("platformName", "iOS");
                    cap.setCapability("deviceName", "iOS");
                    cap.setCapability("platformName", "iOS");
//                    FrameworkLogger.log("Created RemoteWebDriver. OS=iOS.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
                } else
                {
//                    FrameworkLogger.log((new StringBuilder("Please provide a proper PLATFORM name.[PLATFORM name: ")).append(capability.get("os").toString()).append("]").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
                }
            }
            catch(Exception e)
            {
//                FrameworkLogger.log((new StringBuilder("Error in creating RemoteWebDriver. Exception: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
//                FrameworkLogger.log("Error in creating RemoteWebDriver. Please check the capability and Browser availability in Selenium Grid.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
            }
            String serverUrl = (new StringBuilder("http://")).append(capability.get("hubIP")).append(":").append(capability.get("hubPort")).append("/wd/hub").toString();
            try
            {
//                FrameworkLogger.log((new StringBuilder("Selenium Grid[Hub] URL: '")).append(serverUrl).append("'").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.info, getClass());
                for(int flag = 1; flag < 4; flag++)
                {
                    if(hubDriver != null)
                        break;
//                    FrameworkLogger.log((new StringBuilder("Attempt ")).append(flag).append(": Trying to create new browser instance - '").append(capability.get("browser")).append(capability.get("version")).append("' on '").append(capability.get("os")).append("'").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.info, getClass());
                    hubDriver = createDriver(hubDriver, cap, serverUrl);
                }

            }
            catch(Exception e)
            {
                try
                {
//                    FrameworkLogger.log((new StringBuilder("Retrying: Trying to create new browser instance - '")).append(capability.get("browser")).append(capability.get("version")).append("' on '").append(capability.get("os")).append("'").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.info, getClass());
                    hubDriver = createDriver(hubDriver, cap, serverUrl);
                }
                catch(Exception e1)
                {
                    try
                    {
//                        FrameworkLogger.log((new StringBuilder("Retrying again: Trying to create new browser instance - '")).append(capability.get("browser")).append(capability.get("version")).append("' on '").append(capability.get("os")).append("'").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.info, getClass());
                        hubDriver = createDriver(hubDriver, cap, serverUrl);
                    }
                    catch(Exception e2)
                    {
//                        FrameworkLogger.log((new StringBuilder("Error in creating RemoteWebDriver. Exception: ")).append(e2.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
//                        FrameworkLogger.log("Error in creating RemoteWebDriver. Please check the capability, Browser availability in Selenium Grid and Grid's status.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
                    }
                }
            }
        } else
        {
//            FrameworkLogger.log("Error: 'dir' path not found in 'browser.json'.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
        }
        TestCaseReportBean testCaseReportBean;
        if(hubDriver != null)
        {
            testCaseReportBean = new TestCaseReportBean();
            testCaseReportBean.setTestCaseName(testcaseName.replace("class xtam.test.", ""));
            Capabilities capCreated = hubDriver.getCapabilities();
            String version = capCreated.getVersion();
            if(version.isEmpty())
                version = capCreated.getCapability("browserVersion").toString();
            if(version.contains("."))
                version = version.split("\\.")[0];
            if(version.isEmpty() || version == null || version == "")
                version = "Unknown";
            String os = "";
            if(capCreated.getPlatform().toString().equalsIgnoreCase("XP"))
                os = "WINDOWS";
            else
            if(capCreated.getPlatform().toString().equalsIgnoreCase("ANY") && capCreated.getBrowserName().toString().equalsIgnoreCase("firefox"))
                os = "WINDOWS";
            else
                os = capCreated.getPlatform().toString();
            if(capCreated.getBrowserName().toString().equalsIgnoreCase("MicrosoftEdge"))
            {
                os = "WIN10";
                if(version.equalsIgnoreCase("Unknown"))
                    version = "00";
            }
            testCaseReportBean.setOsBrowser((new StringBuilder(String.valueOf(os))).append("-").append(capCreated.getBrowserName()).append("-").append(version).toString());
            testCaseReportBean.setStatus("FAIL");
            List liTestStepReportBeans = new ArrayList();
            TestStepReportBean testStepReportBean = new TestStepReportBean();
            testStepReportBean.setDate("Not found");
            testStepReportBean.setStepName("Not found");
            testStepReportBean.setExpected("Not found");
            testStepReportBean.setActual("Browser crashed. No information found.");
            testStepReportBean.setScreenShotPath("");
            testStepReportBean.setResult("Fail");
            liTestStepReportBeans.add(testStepReportBean);
            testCaseReportBean.setSteps(liTestStepReportBeans);
            TestCaseCreationBean.testcasesInstanceCreated.add(testCaseReportBean);
//            FrameworkLogger.log("Returning RemoteWebDriver from Harness.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
//            FrameworkLogger.log((new StringBuilder("Opening browser: '")).append(capability.get("browser")).append(capability.get("version")).append("' on '").append(capability.get("os")).append("'").toString(), crossbrowser.logger.FrameworkLogger.LEVEL.info, getClass());
            return hubDriver;
        }
        testCaseReportBean = new TestCaseReportBean();
        testCaseReportBean.setTestCaseName(testcaseName.replace("class xtam.test.", ""));
        String version = cap.getVersion();
        if(version.contains("."))
            version = version.split("\\.")[0];
        testCaseReportBean.setOsBrowser((new StringBuilder()).append(cap.getPlatform()).append("-").append(cap.getBrowserName()).append("-").append(version).toString());
        testCaseReportBean.setStatus("FAIL");
        List liTestStepReportBeans = new ArrayList();
        TestStepReportBean testStepReportBean = new TestStepReportBean();
        testStepReportBean.setDate(DateFormatter.formatDate(new Date(), "dd MMM, yyyy HH:mm:ss z"));
        testStepReportBean.setStepName("Opening new browser");
        testStepReportBean.setExpected("Should have oppened a new Browser");
        testStepReportBean.setActual("Browser not found");
        testStepReportBean.setScreenShotPath("");
        testStepReportBean.setResult("Fail");
        liTestStepReportBeans.add(testStepReportBean);
        testCaseReportBean.setSteps(liTestStepReportBeans);
        TestCaseCreationBean.testcasesInstanceCreated.add(testCaseReportBean);
//        FrameworkLogger.log("Not able to create RemoteWebDriver with required Capability.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, getClass());
        return null;
    }

    private RemoteWebDriver createDriver(RemoteWebDriver driver, DesiredCapabilities capabilities, String url)
    {
        try
        {
            driver = new RemoteWebDriver(new URL(url), capabilities);
        }
        catch(MalformedURLException e)
        {
//            FrameworkLogger.log((new StringBuilder("Error: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        }
        return driver;
    }
}

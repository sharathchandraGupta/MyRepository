// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FrameworkLogger.java

package crossbrowser.logger;


// Referenced classes of package crossbrowser.logger:
//            FrameworkLogger

public static final class FrameworkLogger$LEVEL extends Enum
{

    public boolean equalsName(String otherName)
    {
        return otherName != null ? name.equals(otherName) : false;
    }

    public String toString()
    {
        return name;
    }

    public static FrameworkLogger$LEVEL[] values()
    {
        FrameworkLogger$LEVEL aframeworklogger$level[];
        int i;
        FrameworkLogger$LEVEL aframeworklogger$level1[];
        System.arraycopy(aframeworklogger$level = ENUM$VALUES, 0, aframeworklogger$level1 = new FrameworkLogger$LEVEL[i = aframeworklogger$level.length], 0, i);
        return aframeworklogger$level1;
    }

    public static FrameworkLogger$LEVEL valueOf(String s)
    {
        return (FrameworkLogger$LEVEL)Enum.valueOf(crossbrowser/logger/FrameworkLogger$LEVEL, s);
    }

    public static final FrameworkLogger$LEVEL trace;
    public static final FrameworkLogger$LEVEL debug;
    public static final FrameworkLogger$LEVEL info;
    public static final FrameworkLogger$LEVEL warn;
    public static final FrameworkLogger$LEVEL error;
    public static final FrameworkLogger$LEVEL fatal;
    private final String name;
    private static final FrameworkLogger$LEVEL ENUM$VALUES[];

    static 
    {
        trace = new FrameworkLogger$LEVEL("trace", 0, "trace");
        debug = new FrameworkLogger$LEVEL("debug", 1, "debug");
        info = new FrameworkLogger$LEVEL("info", 2, "info");
        warn = new FrameworkLogger$LEVEL("warn", 3, "warn");
        error = new FrameworkLogger$LEVEL("error", 4, "error");
        fatal = new FrameworkLogger$LEVEL("fatal", 5, "fatal");
        ENUM$VALUES = (new FrameworkLogger$LEVEL[] {
            trace, debug, info, warn, error, fatal
        });
    }

    private FrameworkLogger$LEVEL(String s, int i, String str)
    {
        super(s, i);
        name = str;
    }
}

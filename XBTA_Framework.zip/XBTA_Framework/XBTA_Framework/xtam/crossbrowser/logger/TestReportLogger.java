// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TestReportLogger.java

package crossbrowser.logger;

import org.testng.Reporter;

public class TestReportLogger
{

    public TestReportLogger()
    {
    }

    public static void log(String log)
    {
        Reporter.log(log);
    }
}

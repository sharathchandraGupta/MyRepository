// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FrameworkLogger.java

package crossbrowser.logger;

import crossbrowser.logger.format.Log4JProperties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class FrameworkLogger
{
    /* member class not found */
    class LEVEL {}


    public FrameworkLogger()
    {
    }

    public static void log(Object message, LEVEL level, Class cls)
    {
        Logger logger = Logger.getLogger(cls.getName());
        System.setProperty("logfilename", "Sprintest(R)-CrossBrowser-Logs.log");
        PropertyConfigurator.configure(Log4JProperties.getProperties());
        if(level.toString().equals("trace"))
            logger.trace(message);
        else
        if(level.toString().equals("debug"))
            logger.debug(message);
        else
        if(level.toString().equals("info"))
            logger.info(message);
        else
        if(level.toString().equals("warn"))
            logger.warn(message);
        else
        if(level.toString().equals("error"))
            logger.error(message);
        else
        if(level.toString().equals("fatal"))
            logger.fatal(message);
    }
}

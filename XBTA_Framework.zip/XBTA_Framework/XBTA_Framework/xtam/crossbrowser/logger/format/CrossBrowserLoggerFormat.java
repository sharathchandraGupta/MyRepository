// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   CrossBrowserLoggerFormat.java

package crossbrowser.logger.format;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.HTMLLayout;
import org.apache.log4j.spi.LoggingEvent;

public class CrossBrowserLoggerFormat extends HTMLLayout
{

    public CrossBrowserLoggerFormat()
    {
        timestampFormat = "dd MMM, yyyy HH:mm:ss z";
        sdf = new SimpleDateFormat(timestampFormat);
    }

    public String format(LoggingEvent event)
    {
        String record = super.format(event);
        Pattern pattern = Pattern.compile("\\s*<\\s*tr\\s*>\\s*<\\s*td\\s*>\\s*(\\d*)\\s*<\\s*/td\\s*>");
        Matcher matcher = pattern.matcher(record);
        if(!matcher.find())
        {
            return record;
        } else
        {
            StringBuffer buffer = new StringBuffer(record);
            buffer.replace(matcher.start(1), matcher.end(1), sdf.format(new Date(event.timeStamp)));
            return buffer.toString();
        }
    }

    public void setTimestampFormat(String format)
    {
        timestampFormat = format;
        sdf = new SimpleDateFormat(format);
    }

    public String getTimestampFormat()
    {
        return timestampFormat;
    }

    private static final String rxTimestamp = "\\s*<\\s*tr\\s*>\\s*<\\s*td\\s*>\\s*(\\d*)\\s*<\\s*/td\\s*>";
    private String timestampFormat;
    private SimpleDateFormat sdf;
}

// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExcelReport.java

package crossbrowser.report.reporter;

import crossbrowser.bean.ReportBean;
import crossbrowser.logger.FrameworkLogger;
import crossbrowser.report.reporter.helper.ExcelReportHelper;
import java.io.File;
import java.util.ArrayList;
import org.apache.commons.io.FileUtils;

// Referenced classes of package crossbrowser.report.reporter:
//            HTMLReport

public class ExcelReport
{

    public ExcelReport()
    {
    }

    public static void generateReport(ArrayList testCases)
    {
        File tempfile;
        FrameworkLogger.log("Creating Excel Report...!!!", crossbrowser.logger.FrameworkLogger.LEVEL.info, crossbrowser/report/reporter/ExcelReport);
        tempfile = new File("./test-output/temp.xlsx");
        try
        {
            ExcelReportHelper reportHelper = new ExcelReportHelper();
            reportHelper.createTestcaseInstanceReport(ReportBean.report, testCases);
            if(tempfile.isFile())
                FileUtils.copyFile(tempfile, new File("./test-output/Sprintest_CrossBrowser_Report.xlsx"));
            break MISSING_BLOCK_LABEL_133;
        }
        catch(Exception exception)
        {
            FrameworkLogger.log((new StringBuilder("Error while creating Excel Report. Error: ")).append(exception.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/report/reporter/HTMLReport);
            FrameworkLogger.log("Error while creating Excel Report.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/report/reporter/HTMLReport);
        }
        tempfile.delete();
        FrameworkLogger.log("Deleted temp excel report.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/report/reporter/HTMLReport);
        break MISSING_BLOCK_LABEL_148;
        Exception exception1;
        exception1;
        tempfile.delete();
        FrameworkLogger.log("Deleted temp excel report.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/report/reporter/HTMLReport);
        throw exception1;
        tempfile.delete();
        FrameworkLogger.log("Deleted temp excel report.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/report/reporter/HTMLReport);
    }
}

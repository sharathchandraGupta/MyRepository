// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ConsoleReporter.java

package crossbrowser.report.reporter;

import crossbrowser.helper.GetTestcaseCount;
import java.io.PrintStream;
import java.util.ArrayList;
import org.json.simple.JSONObject;

public class ConsoleReporter
{

    public ConsoleReporter()
    {
    }

    public static void print(ArrayList testCases)
    {
        GetTestcaseCount testcaseCount = new GetTestcaseCount();
        JSONObject totalCountJson = testcaseCount.getTotalCount();
        String totalPass = totalCountJson.get("pass").toString();
        String totalFail = totalCountJson.get("fail").toString();
        String totalSkip = totalCountJson.get("skip").toString();
        String total = totalCountJson.get("total").toString();
        System.out.println("==============================Execution Summary==============================");
        System.out.println((new StringBuilder("Passed: ")).append(totalPass).append(", Failed: ").append(totalFail).append(", Skipped: ").append(totalSkip).append(", Total Executed: ").append(total).toString());
        System.out.println("=============================================================================");
    }
}

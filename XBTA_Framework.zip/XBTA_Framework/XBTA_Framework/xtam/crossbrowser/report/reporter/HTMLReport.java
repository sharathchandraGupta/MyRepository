// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   HTMLReport.java

package crossbrowser.report.reporter;

import crossbrowser.bean.ReportBean;
import crossbrowser.logger.FrameworkLogger;
import crossbrowser.report.reporter.helper.HTMLReportHelper;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import org.apache.commons.io.FileUtils;

public class HTMLReport
{

    public HTMLReport()
    {
    }

    public static void generateReport(ArrayList testCases)
    {
        File tempfile;
        FrameworkLogger.log("Creating HTML Report...!!!", crossbrowser.logger.FrameworkLogger.LEVEL.info, crossbrowser/report/reporter/HTMLReport);
        File file = new File("./test-output/Sprintest_CrossBrowser_Report.html");
        if(file.isFile())
            try
            {
                Date date = new Date();
                FileUtils.copyFile(file, new File((new StringBuilder("./test-output/ArchiveReports/Archive_Sprintest_CrossBrowser_Report")).append(date.getYear()).append(date.getMonth()).append(date.getDate()).append(date.getHours()).append(date.getMinutes()).append(date.getSeconds()).append(".html").toString()));
            }
            catch(IOException e)
            {
                FrameworkLogger.log((new StringBuilder("Error while coping Report to ArchiveReports. Error: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/report/reporter/HTMLReport);
                FrameworkLogger.log("Error while coping Report to ArchiveReports.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/report/reporter/HTMLReport);
            }
        tempfile = new File("./test-output/temp.html");
        try
        {
            HTMLReportHelper reportHelper = new HTMLReportHelper();
            reportHelper.createTestcaseInstanceReport(ReportBean.report, testCases);
            if(tempfile.isFile())
                FileUtils.copyFile(tempfile, new File("./test-output/Sprintest_CrossBrowser_Report.html"));
            break MISSING_BLOCK_LABEL_271;
        }
        catch(Exception exception)
        {
            FrameworkLogger.log((new StringBuilder("Error while creating Report. Error: ")).append(exception.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/report/reporter/HTMLReport);
            FrameworkLogger.log("Error while creating Report.", crossbrowser.logger.FrameworkLogger.LEVEL.fatal, crossbrowser/report/reporter/HTMLReport);
        }
        tempfile.delete();
        FrameworkLogger.log("Deleted temp report.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/report/reporter/HTMLReport);
        break MISSING_BLOCK_LABEL_286;
        Exception exception1;
        exception1;
        tempfile.delete();
        FrameworkLogger.log("Deleted temp report.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/report/reporter/HTMLReport);
        throw exception1;
        tempfile.delete();
        FrameworkLogger.log("Deleted temp report.", crossbrowser.logger.FrameworkLogger.LEVEL.debug, crossbrowser/report/reporter/HTMLReport);
    }
}

// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   HTMLReportHelper2.java

package crossbrowser.report.reporter.helper;

import crossbrowser.bean.*;
import crossbrowser.helper.*;
import crossbrowser.logger.FrameworkLogger;
import java.io.*;
import java.util.*;
import org.apache.commons.collections.list.SetUniqueList;
import org.json.simple.JSONObject;

public class HTMLReportHelper2
{

    public HTMLReportHelper2()
    {
        testcaseCount = new GetTestcaseCount();
        totalCountJson = testcaseCount.getTotalCount();
        totalPass = totalCountJson.get("pass").toString();
        totalFail = totalCountJson.get("fail").toString();
        totalSkip = totalCountJson.get("skip").toString();
        total = totalCountJson.get("total").toString();
    }

    public void createTestcaseInstanceReport(List testCaseReportBeanlist, ArrayList testCases)
    {
        String filename = "temp.html";
        PrintWriter m_out = createWriter("./test-output/", filename);
        createHeader(m_out);
        createSummary(m_out, testCaseReportBeanlist, testCases);
        int tcInstanceCount = 1;
        for(Iterator iterator = testCaseReportBeanlist.iterator(); iterator.hasNext();)
        {
            TestCaseReportBean testCaseReportBean = (TestCaseReportBean)iterator.next();
            String testcaseName = testCaseReportBean.getTestCaseName();
            String description = testCaseReportBean.getDescription();
            String duration = testCaseReportBean.getDuration();
            String osBrowser = testCaseReportBean.getOsBrowser();
            String status = testCaseReportBean.getStatus();
            if(description == null)
                description = "Not provided.";
            createTeatcaseDetail(m_out, testcaseName, description, duration, osBrowser, status, tcInstanceCount, testCaseReportBean.getSteps());
            tcInstanceCount++;
        }

        createFooter(m_out);
        closeWriter(m_out);
    }

    private PrintWriter createWriter(String outdir, String fileName)
    {
        (new File(outdir)).mkdirs();
        try
        {
            return new PrintWriter(new BufferedWriter(new FileWriter(new File(outdir, fileName))));
        }
        catch(IOException e)
        {
            FrameworkLogger.log((new StringBuilder("Error while creating HTML Report. Exception: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        }
        return null;
    }

    private void createTeatcaseDetail(PrintWriter out, String testcaseName, String description, String duration, String osBrowser, String status, int tcInstanceNumber, 
            List testStepReportBeanList)
    {
        out.println((new StringBuilder("<table class='overviewTable' id='instance")).append(tcInstanceNumber).append("'><thead><tr><th colspan='4' class='header suite'><p>").append(testcaseName).append(":</p></th><th class='header suite status'><p title='Back to Summary'><a href='#summary'>&#x25B2;</a></p></th></tr></thead>").toString());
        out.println("<tbody id='tests-1' class='tests'>");
        out.println("<tr>");
        out.println("<td class='test' colspan='5'>");
        out.println((new StringBuilder("<p><b>Description:</b> ")).append(description).append("<p>").toString());
        out.println("</td>");
        out.println("</tr>");
        out.println("<tr>");
        out.println("<td class='test' colspan='3'>");
        out.println((new StringBuilder("<p><b>OS-Browser:</b> ")).append(osBrowser).append("<p>").toString());
        out.println("</td>");
        if(status.equalsIgnoreCase("PASS"))
        {
            out.println("<td class='test' colspan='2'>");
            out.println((new StringBuilder("<p><b>Status:</b> <span class='successIndicator'>")).append(status).append("&nbsp;&#x2714;</span><p>").toString());
            out.println("</td>");
        } else
        if(status.equalsIgnoreCase("FAIL"))
        {
            out.println("<td class='test' colspan='2'>");
            out.println((new StringBuilder("<p><b>Status:</b> <span class='failureIndicator'>")).append(status).append("&nbsp;&#x2718;</span><p>").toString());
            out.println("</td>");
        } else
        if(status.equalsIgnoreCase("SKIP"))
        {
            out.println("<td class='test' colspan='2'>");
            out.println((new StringBuilder("<p><b>Status:</b><span class='skipIndicator'>")).append(status).append("&nbsp;&#x2718;</span><p>").toString());
            out.println("</td>");
        }
        out.println("</tr>");
        out.println("<tr>");
        out.println("<td class='test' colspan='5'>");
        out.println((new StringBuilder("<p><b>Duration:</b> ")).append(duration).append("<p>").toString());
        out.println("</td>");
        out.println("</tr>");
        createDetailReport(out, testStepReportBeanList);
        out.println("</tbody>");
        out.println("</table>");
        out.println("<br><hr class='style-transparen'>");
    }

    private void createHeader(PrintWriter out)
    {
        out.println("<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN' 'http://www.w3.org/TR/html4/loose.dtd'>");
        out.println("<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='' lang=''>");
        out.println("<head>");
        out.println("<title>Sprintest&reg;/CrossBrowser Detail Report</title>");
        out.println("<meta http-equiv='Content-Type' content='text/html;charset=utf-8' />");
        out.println("<meta name='description' content='TestNG unit test results.' />");
        out.println("<style TYPE='text/css'>");
        out.println("*                        {padding: 0; margin: 0;}");
        out.println("a                        {color: #006699;}");
        out.println("a:visited                {color: #003366;}");
        out.println("body                     {font-family: Lucida Sans Unicode, Lucida Grande, sans-serif; line-height: 1.8em; font-size: 62.5%; margin: 1.8em 1em;}");
        out.println("h1                       {font-family: Arial, Helvetica, sans-serif; font-weight: bold; font-size: 2.7em; margin-bottom: 0.6667em;}");
        out.println("h2                       {font-family: Arial, Helvetica, sans-serif; font-weight: bold; font-size: 2.0em; margin-bottom: 0;}");
        out.println("p                        {font-size: 1.5em;}");
        out.println("p2                        {font-size: 1.3em;}");
        out.println(".header                  {font-weight: bold; text-align: left;}");
        out.println(".passed                  {background-color: #44aa44;}");
        out.println(".skipped                 {background-color: #ffaa00;}");
        out.println(".failed                  {background-color: #ff4444;}");
        out.println(".failedConfig            {background-color: #800000; color: #ffffff}");
        out.println(".skippedConfig           {background-color: #cc6600; color: #ffffff}");
        out.println(".total              \t\t{font-weight: bold; background-color: #808080;}");
        out.println(".passedText              {color: #44aa44;}");
        out.println(".skippedText             {color: #ffaa00;}");
        out.println(".failedText              {color: #ff4444;}");
        out.println(".totalText          \t\t{color: #004994;}");
        out.println(".summary                 {background-color: #004994; font-weight: bold; color: #FFFFFF;}");
        out.println(".suite                   {background-color: #19B9E5; font-weight: bold;}");
        out.println(".details                 {background-color: #999999; font-weight: bold;}");
        out.println(".test                    {background-color: #eeeeee; padding-left: 2em;}");
        out.println(".test .passed            {background-color: #88ee88;}");
        out.println(".test .skipped           {background-color: #ffff77;}");
        out.println(".test .failed            {background-color: #ff8888;}");
        out.println(".test .total\t            {background-color: #bfbfbf;}");
        out.println(".test .passed a          {color: #1A411A;}");
        out.println(".test .skipped a         {color: #D99102;}");
        out.println(".test .failed a          {color: #E30202;}");
        out.println(".test .passed a:visited  {color: #1A411A;}");
        out.println(".test .skipped a:visited {color: #D99102;}");
        out.println(".test .failed a:visited  {color: #E30202;}");
        out.println(".group                   {background-color: #cccccc; color: #000000; font-weight: bold;}");
        out.println(".suiteLinks              {float: right; font-weight: normal; vertical-align: middle;}");
        out.println(".suiteLinks a            {color: #ffffff; margin-left: .5em;}");
        out.println(".passRate                {font-weight: bold; text-align: right;}");
        out.println(".duration                {text-align: right;}");
        out.println(".thread                  {white-space: nowrap;}");
        out.println(".resultsTable            {border: 0; width: 100%; margin-top: 1.8em; line-height: 1.7em; border-spacing: 0.1em;}");
        out.println(".resultsTable .method    {width: 18em;}");
        out.println(".resultsTable .duration  {width: 6em;}");
        out.println(".resultsTable td         {vertical-align: top; padding: 0 1em;}");
        out.println(".resultsTable th         {padding: 0 .5em;}");
        out.println(".number                  {text-align: right;}");
        out.println(".status                  {text-align: center;}");
        out.println(".zero                    {font-weight: normal;}");
        out.println(".columnHeadings          {font-size: 1em;}");
        out.println(".columnHeadings th       {font-weight: normal;}");
        out.println(".configTable             {border: 1px solid #800000; color: #800000; margin-bottom: 1.5em;}");
        out.println("#sidebarHeader           {padding: 1.8em 1em; margin: 0 -1em 1.8em -1em;}");
        out.println("#suites                  {line-height: 1.7em; border-spacing: 0.1em; width: 100%;}");
        out.println(".tests                   {display: table-row-group;}");
        out.println(".header.suite            {cursor: pointer; clear: right; height: 1.214em; margin-top: 1px;}");
        out.println("div.test                 {margin-top: 0.1em; clear: right; font-size: 1.3em;}");
        out.println(".toggle                  {font-family: monospace; font-weight: bold; padding-left: 2px; padding-right: 5px; color: #777777;}");
        out.println(".successIndicator        {font-family: monospace; font-weight: bold; padding-left: 2px; color: #44aa44;}");
        out.println(".skipIndicator           {font-family: monospace; font-weight: bold; padding-left: 2px; color: #ffaa00;}");
        out.println(".failureIndicator        {font-family: monospace; font-weight: bold; padding-left: 2px; color: #ff4444;}");
        out.println(".result                  {font-size: 1.1em; vertical-align: middle;}");
        out.println(".dependency              {font-family: Lucida Console, Monaco, Courier New, monospace; font-weight: bold;}");
        out.println(".arguments               {font-family: Lucida Console, Monaco, Courier New, monospace; font-weight: bold;}");
        out.println(".testOutput              {font-family: Lucida Console, Monaco, Courier New, monospace; color: #666666;}");
        out.println(".stackTrace              {font-size: 0.9em; line-height: 1.2em; margin-left: 2em; display: none;}");
        out.println(".stackTrace .stackTrace  {font-size: inherit;}");
        out.println(".description             {border-bottom: 1px dotted #006699;}");
        out.println("#meta                    {font-size: 1em; text-align: right; float: right;}");
        out.println("#systemInfo              {color: #666666;}");
        out.println("#log                     {font-family: Lucida Console, Monaco, Courier New, monospace; font-size: 1.3em; margin-top: 1.8em;}");
        out.println(".heading\t\t\t        {color: #004994;}");
        out.println(".style-drop-shadow \t\t{height: 12px;border: 0; box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);}");
        out.println(".style-transparen\t\t{border: 0; height: 1px; background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));}");
        out.println(".overviewTable           {width: 100%; margin-top: 1.8em; line-height: 1.7em; border-spacing: 0.1em; }");
        out.println(".overviewTable td        {padding: 3px 3px 3px 3px;}");
        out.println(".overviewTable th        {padding: 3px 3px 3px 3px;}");
        out.println(".overviewTable .duration {width: 6em;}");
        out.println(".overviewTable .passRate {width: 6em;}");
        out.println(".overviewTable .number   {width: 5em;}");
        out.println(".overviewTable tr        {height: 1.6em;}");
        out.println(".summaryTable           {width: 30%; margin-top: 1.8em; line-height: 1.7em; border-spacing: 0.1em; }");
        out.println(".summaryTable td        {padding: 3px 3px 3px 3px;}");
        out.println(".summaryTable th        {padding: 3px 3px 3px 3px;}");
        out.println(".summaryTable .duration {width: 6em;}");
        out.println(".summaryTable .passRate {width: 6em;}");
        out.println(".summaryTable .number   {width: 5em;}");
        out.println(".summaryTable tr        {height: 1.6em;}");
        out.println(".traceinfo{position: fixed;top: 0; bottom: 0;left: 0;right:0;background: rgba(0, 161, 228, 0.2);z-index: 99999;opacity:0;-webkit-transition: opacity 400ms ease-in;transition: opacity 400ms ease-in;pointer-events: none;}");
        out.println(".traceinfo.visible{opacity:1;pointer-events: auto;}");
        out.println(".traceinfo > div{width: 80%; height : 90%; position: relative;margin: 2% auto;padding: 5px 20px 13px 20px;background: #fff; align:'center';}");
        out.println(".traceinfo .close{background: #606061;color: #FFFFFF;line-height: 25px;position: absolute;right: -12px;text-align: center;top: -10px;width: 24px;text-decoration: none;font-weight: bold;}");
        out.println(".traceinfo .close:hover{background: #00d9ff;}");
        out.println(".traceinfo img {display: block;margin-left: auto;margin-right: auto;}");
        out.println("</style>");
        out.println("<script type='text/javascript'>");
        out.println("function showTrace(e){");
        out.println("window.event.srcElement.parentElement.getElementsByClassName('traceinfo')[0].className = 'traceinfo visible';");
        out.println("}");
        out.println("function closeTraceModal(e){");
        out.println("window.event.srcElement.parentElement.parentElement.className = 'traceinfo';");
        out.println("}");
        out.println("function init(){");
        long totalAng = 360L;
        long passAng = 0L;
        long failAng = 0L;
        long skipAng = 0L;
        long eachAng = 0L;
        long passInt = Integer.parseInt(totalPass);
        long failInt = Integer.parseInt(totalFail);
        long skipInt = Integer.parseInt(totalSkip);
        long totalInt = Integer.parseInt(total);
        eachAng = totalAng / totalInt;
        passAng = eachAng * passInt;
        failAng = eachAng * failInt;
        skipAng = eachAng * skipInt;
        out.println((new StringBuilder("var data = [")).append(passAng).append(", ").append(failAng).append(", ").append(skipAng).append("];").toString());
        out.println("var labels = ['Pass', 'Fail', 'Skip'];");
        out.println("var colors = ['#44aa44', '#ff4444', '#ffaa00'];");
        out.println("function drawSegment(canvas, context, i) {");
        out.println("context.save();");
        out.println("var centerX = Math.floor(canvas.width / 2);");
        out.println("var centerY = Math.floor(canvas.height / 2);");
        out.println("radius = Math.floor(canvas.width / 2);");
        out.println("var startingAngle = degreesToRadians(sumTo(data, i));");
        out.println("var arcSize = degreesToRadians(data[i]);");
        out.println("var endingAngle = startingAngle + arcSize;");
        out.println("context.beginPath();");
        out.println("context.moveTo(centerX, centerY);");
        out.println("context.arc(centerX, centerY, radius,startingAngle, endingAngle, false);");
        out.println("context.closePath();");
        out.println("context.fillStyle = colors[i];");
        out.println("context.fill();");
        out.println("context.restore();");
        out.println("drawSegmentLabel(canvas, context, i);");
        out.println("}");
        out.println("function degreesToRadians(degrees) {");
        out.println("return (degrees * Math.PI)/180;");
        out.println("}");
        out.println("function sumTo(a, i) {");
        out.println("var sum = 0;");
        out.println("for (var j = 0; j < i; j++) {");
        out.println("sum += a[j];");
        out.println("}");
        out.println("return sum;");
        out.println("}");
        out.println("function drawSegmentLabel(canvas, context, i) {");
        out.println("if(data[i]>0){");
        out.println("context.save();");
        out.println("var x = Math.floor(canvas.width / 2);");
        out.println("var y = Math.floor(canvas.height / 2);");
        out.println("var angle = degreesToRadians(sumTo(data, i));");
        out.println("context.translate(x, y);");
        out.println("context.rotate(angle);");
        out.println("var dx = Math.floor(canvas.width * 0.5) - 10;");
        out.println("var dy = Math.floor(canvas.height * 0.12);");
        out.println("context.textAlign = 'right';");
        out.println("var fontSize = 10;");
        out.println("context.font = fontSize + 'pt Helvetica';");
        out.println("context.fillText(labels[i], dx, dy);");
        out.println("context.restore();");
        out.println("}");
        out.println("}");
        out.println("canvas = document.getElementById('piechart');");
        out.println("var context = canvas.getContext('2d');");
        out.println("for (var i = 0; i < data.length; i++) {");
        out.println("drawSegment(canvas, context, i);");
        out.println("}");
        out.println("}");
        out.println("</script>");
        out.println("</head>");
        out.println("<body onload='init()'>");
        out.println("<div id='header'>");
        out.println("<table width='100%'><tr><td>");
        out.println((new StringBuilder("<img alt='Sprintest LOGO' width='193px' height='75px' src='data:image/jpg;base64,")).append(ImageLibrary.sprintestLogo).append("' />").toString());
        out.println("</td>");
        out.println("<td class='number'>");
        out.println((new StringBuilder("<img alt='IGATE LOGO' width='267x' height='75px' src='data:image/jpg;base64,")).append(ImageLibrary.capgeminiLogo).append("' />").toString());
        out.println("</td></tr></table><br><br>");
        out.println("<h1 class='heading'>Sprintest<sup>&reg;</sup>/CrossBrowser Execution Report</h1>");
        out.println("</div>");
        out.println("<hr class='style-drop-shadow'><br>");
        out.println("<h2 id='summary'>Execution Summary:</h2><br>");
        out.println("<p class='totalText'><b>Test Suite Execution Details</b></p>");
        out.println((new StringBuilder("<table><tbody><tr><td class='totalText number'><p>Start Time: </p></td><td><p>")).append(DateFormatter.formatDate(ReportBean.startDate, "dd MMM, yyyy HH:mm:ss z")).append("</p></td><tr>").toString());
        out.println((new StringBuilder("<tr><td class='totalText number'><p>End Time: </p></td><td><p>")).append(DateFormatter.formatDate(ReportBean.endDate, "dd MMM, yyyy HH:mm:ss z")).append("</p></td><tr>").toString());
        out.println((new StringBuilder("<tr><td class='totalText number'><p>Total Time: </p></td><td><p>")).append(TimeUtils.convertSecToHHMMSS((ReportBean.endDate.getTime() - ReportBean.startDate.getTime()) / 1000L)).append("</p></td><tr><tbody></table>").toString());
    }

    private void createFooter(PrintWriter out)
    {
        out.println("</body>");
        out.println("</html>");
    }

    private void createDetailReport(PrintWriter out, List testStepReportBeanList)
    {
        out.println("<tr>");
        out.println("<td class='header details'><p>Date</p></th>");
        out.println("<td class='header details'><p>Step</p></th>");
        out.println("<td class='header details'><p>Expected</p></th>");
        out.println("<td class='header details'><p>Actual</p></th>");
        out.println("<td class='header details'><p>Result</p></th>");
        out.println("</tr></thead><tbody>");
        if(testStepReportBeanList != null)
        {
            for(Iterator iterator = testStepReportBeanList.iterator(); iterator.hasNext(); out.println("</tr>"))
            {
                TestStepReportBean testStepReportBean = (TestStepReportBean)iterator.next();
                out.println("<tr class='test'>");
                out.println((new StringBuilder("<td class='test'><p2>")).append(testStepReportBean.getDate()).append("</p2></td>").toString());
                out.println((new StringBuilder("<td class='test'><p2>")).append(testStepReportBean.getStepName()).append("</p2></td>").toString());
                out.println((new StringBuilder("<td class='test'><p2>")).append(testStepReportBean.getExpected()).append("</p2></td>").toString());
                String imgLinkId = testStepReportBean.getScreenShotPath().replace("./test-output/stepScreenShots/", "").replace(".png", "");
                String imgPath = testStepReportBean.getScreenShotPath().replace("test-output/", "");
                if(imgPath.endsWith(".png"))
                    out.println((new StringBuilder("<td class='test'><p2><a onclick='showTrace()' href='#")).append(imgLinkId).append("'>").append(testStepReportBean.getActual()).append("</a><div id='").append(imgLinkId).append("' class='traceinfo'><div><a href='#close' onclick='closeTraceModal()' title='Close' class='close'>X</a><a href='").append(imgPath).append("' target='_blank'><img src='").append(imgPath).append("' height='100%' width='auto' ></a></div></div></p2></td>").toString());
                else
                if(imgPath.endsWith(".html"))
                    out.println((new StringBuilder("<td class='test'><p2><a onclick='showTrace()' href='#")).append(imgLinkId).append("'>").append(testStepReportBean.getActual()).append("</a><div id='").append(imgLinkId).append("' class='traceinfo'><div><a href='#close' onclick='closeTraceModal()' title='Close' class='close'>X</a><a href='").append(imgPath).append("' target='_blank'><iframe src='").append(imgPath).append("' height='100%' width='100%' ></iframe></a></div></div></p2></td>").toString());
                else
                    out.println((new StringBuilder("<td class='test'><p2>")).append(testStepReportBean.getActual()).append("</p2></td>").toString());
                String status = testStepReportBean.getResult();
                if(status.equalsIgnoreCase("pass"))
                    out.println((new StringBuilder("<td class='passed'><p>")).append(status).append("</p></td>").toString());
                else
                if(status.equalsIgnoreCase("fail"))
                    out.println((new StringBuilder("<td class='failed'><p>")).append(status).append("</p></td>").toString());
                else
                if(status.equalsIgnoreCase("skip"))
                    out.println((new StringBuilder("<td class='skipped'><p>")).append(status).append("</p></td>").toString());
            }

        } else
        {
            out.println("<tr class='test'>");
            out.println("<td class='test'><p2>Not Found</p2></td>");
            out.println("<td class='test'><p2>Test Step</p2></td>");
            out.println("<td class='test'><p2>Should Execute</p2></td>");
            String imgLinkId = "";
            String imgPath = "";
            out.println((new StringBuilder("<td class='test'><p2><a onclick='showTrace()' href='#")).append(imgLinkId).append("'>Something went wrong</a><div id='").append(imgLinkId).append("' class='traceinfo'><div><a href='#close' onclick='closeTraceModal()' title='Close' class='close'>X</a><a href='").append(imgPath).append("' target='_blank'><img src='").append(imgPath).append("' height='100%' width='auto' ></a></div></div></p2></td>").toString());
            out.println("<td class='failed'><p>Fail</p></td>");
            out.println("</tr>");
        }
    }

    private void closeWriter(PrintWriter out)
    {
        out.flush();
        out.close();
    }

    public void createSummary(PrintWriter out, List testCaseReportBeansList, ArrayList testCases)
    {
        List osBwList = new ArrayList();
        List testCaseList = new ArrayList();
        for(Iterator iterator = ReportBean.report.iterator(); iterator.hasNext();)
        {
            TestCaseReportBean testCaseReportBean = (TestCaseReportBean)iterator.next();
            if(testCaseReportBean != null)
            {
                osBwList.add(testCaseReportBean.getOsBrowser());
                testCaseList.add(testCaseReportBean.getTestCaseName());
            }
        }

        List uniqueOsBrowserList = SetUniqueList.decorate(osBwList);
        List uniqueTestCaseList = SetUniqueList.decorate(testCaseList);
        List uniqueTestCaseListJson = SetUniqueList.decorate(testCases);
        uniqueTestCaseListJson.removeAll(uniqueTestCaseList);
        String tcName;
        for(Iterator iterator1 = uniqueTestCaseListJson.iterator(); iterator1.hasNext(); uniqueTestCaseList.add(tcName))
            tcName = (String)iterator1.next();

        List doneIndex = new ArrayList();
        out.println("<br>");
        out.println("<table width='100%'><tr><td width='30%'>");
        out.println("<table width='100%'>");
        out.println((new StringBuilder("<tr><td class='passedText number' width='30%'><p><b>Passed:</b> </td><td class='' width='70%'><p>")).append(totalPass).append("</p></td></tr>").toString());
        out.println((new StringBuilder("<tr><td class='failedText number' width='30%'><p><b>Failed:</b> </td><td class='' width='70%'><p>")).append(totalFail).append("</p></td></tr>").toString());
        out.println((new StringBuilder("<tr><td class='skippedText number' width='30%'><p><b>Skipped:</b> </td><td class='' width='70%'><p>")).append(totalSkip).append("</p></td></tr>").toString());
        out.println((new StringBuilder("<tr><td class='totalText number' width='30%'><p><b>Total: </b></td><td class='' width='70%'><p>")).append(this.total).append("</p></td></tr>").toString());
        out.println("</table></td>");
        out.println("<td width='35%' class='status'><canvas id='piechart' width='100%' height='100%'>Your browser does not support HTML5 Canvas.</canvas></td>");
        out.println("<td width='35%' class='status'><canvas id='barchart' width='100%' height='100%'>Your browser does not support HTML5 Canvas.</canvas></td>");
        out.println("</tr></table>");
        out.println("<table class='overviewTable'>");
        out.println("<tr><th class='header summary'><p>TestCase</p></th>");
        out.println("<th class='header summary'><p>Pass</p></th>");
        out.println("<th class='header summary'><p>Fail</p></th>");
        out.println("<th class='header summary'><p>Skip</p></th>");
        out.println("<th class='header summary'><p>Total</p></th>");
        for(Iterator iterator2 = uniqueOsBrowserList.iterator(); iterator2.hasNext(); out.println("</p></th>"))
        {
            String unqOsBw = (String)iterator2.next();
            out.println("<th class='header summary status'><p>");
            String osBw[] = unqOsBw.split("-");
            String os = osBw[0];
            String browser = osBw[1];
            String version = osBw[2];
            if(version.contains("."))
                version = version.split("\\.")[0];
            out.println((new StringBuilder("<img alt='")).append(os).append("' title='").append(os).append("' width='25px' height='25px' src='data:image/jpg;base64,").append(ImageLibrary.get(os)).append("' /><img alt='").append(browser).append("' title='").append(browser).append("' width='25px' height='25px' src='data:image/jpg;base64,").append(ImageLibrary.get(browser)).append("' />&nbsp;v").append(version).toString());
        }

        out.println("</tr>");
        out.println("<tr><td colspan='5'></td>");
        JSONObject brwsrJson;
        for(Iterator iterator3 = uniqueOsBrowserList.iterator(); iterator3.hasNext(); out.println((new StringBuilder("<td class='test'><table width='100%'><tr><td class='test passed status'><p>")).append(brwsrJson.get("pass").toString()).append("</p></td><td class='test failed status'><p>").append(brwsrJson.get("fail").toString()).append("</p></td><td class='test skipped status'><p>").append(brwsrJson.get("skip").toString()).append("</p></td><td class='test total status'><p>").append(brwsrJson.get("total").toString()).append("</p></td></tr></table></td>").toString()))
        {
            String unqOsBw = (String)iterator3.next();
            brwsrJson = testcaseCount.getBrowserInfo(unqOsBw);
        }

        out.println("</tr>");
        for(Iterator iterator4 = uniqueTestCaseList.iterator(); iterator4.hasNext(); out.println("</tr>"))
        {
            String tcName = (String)iterator4.next();
            JSONObject testCaseInfoJson = testcaseCount.getTestcaseInfo(tcName);
            out.println("<tr class='test'>");
            int total = Integer.parseInt(testCaseInfoJson.get("total").toString());
            if(total > 0)
                out.println((new StringBuilder("<td class='test'><p>")).append(tcName).append("</p></td>").toString());
            else
                out.println((new StringBuilder("<td class='test'><p>")).append(tcName).append("<small>[Not Executed]</small></p></td>").toString());
            out.println((new StringBuilder("<td class='test passed'><p>")).append(testCaseInfoJson.get("pass").toString()).append("</p></th>").toString());
            out.println((new StringBuilder("<td class='test failed'><p>")).append(testCaseInfoJson.get("fail").toString()).append("</p></th>").toString());
            out.println((new StringBuilder("<td class='test skipped'><p>")).append(testCaseInfoJson.get("skip").toString()).append("</p></th>").toString());
            out.println((new StringBuilder("<td class='test total'><p>")).append(testCaseInfoJson.get("total").toString()).append("</p></th>").toString());
            for(Iterator iterator5 = uniqueOsBrowserList.iterator(); iterator5.hasNext(); out.println("</tr></table></td>"))
            {
                String osBw = (String)iterator5.next();
                int index = 1;
                out.println("<td class='test'><table width='100%'><tr>");
                for(Iterator iterator6 = ReportBean.report.iterator(); iterator6.hasNext();)
                {
                    TestCaseReportBean testCaseReportBean = (TestCaseReportBean)iterator6.next();
                    if(tcName.equals(testCaseReportBean.getTestCaseName()) && !doneIndex.contains(Integer.valueOf(index)) && osBw.equals(testCaseReportBean.getOsBrowser()))
                    {
                        String status = testCaseReportBean.getStatus();
                        if(status.equalsIgnoreCase("pass"))
                            out.println((new StringBuilder("<td class='passed status'><p><a href='#instance")).append(index).append("'>").append(status).append("</a></p></td>").toString());
                        else
                        if(status.equalsIgnoreCase("fail"))
                            out.println((new StringBuilder("<td class='failed status'><p><a href='#instance")).append(index).append("'>").append(status).append("</a></p></td>").toString());
                        else
                        if(status.equalsIgnoreCase("skip"))
                            out.println((new StringBuilder("<td class='skipped status'><p><a href='#instance")).append(index).append("'>").append(status).append("</a></p></td>").toString());
                        doneIndex.add(Integer.valueOf(index));
                    }
                    index++;
                }

            }

        }

        out.println("<table>");
        out.println("<br><p align='right'><small>*See logs for more details.</small></p>");
        out.println("<br><hr class='style-drop-shadow'><br><br>");
        out.println("<h2>Detail Report:</h2>");
    }

    GetTestcaseCount testcaseCount;
    JSONObject totalCountJson;
    String totalPass;
    String totalFail;
    String totalSkip;
    String total;
}

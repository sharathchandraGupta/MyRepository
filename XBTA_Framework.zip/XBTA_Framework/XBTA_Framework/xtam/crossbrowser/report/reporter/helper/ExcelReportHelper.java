// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExcelReportHelper.java

package crossbrowser.report.reporter.helper;

import crossbrowser.bean.ReportBean;
import crossbrowser.bean.TestCaseReportBean;
import crossbrowser.helper.GetTestcaseCount;
import crossbrowser.helper.ImageLibrary;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections.list.SetUniqueList;
import org.apache.commons.lang3.text.WordUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;

public class ExcelReportHelper
{

    public ExcelReportHelper()
    {
        testcaseCount = new GetTestcaseCount();
        totalCountJson = testcaseCount.getTotalCount();
        totalPass = totalCountJson.get("pass").toString();
        totalFail = totalCountJson.get("fail").toString();
        totalSkip = totalCountJson.get("skip").toString();
        total = totalCountJson.get("total").toString();
    }

    public void createTestcaseInstanceReport(List report, ArrayList testCases)
    {
        try
        {
            String filename = "./test-output/temp.xlsx";
            XSSFWorkbook xlsxReportWorkbook = new XSSFWorkbook();
            XSSFSheet homesheet = xlsxReportWorkbook.createSheet("Sprintest(R)-CrossBrowser");
            XSSFSheet summarysheet = xlsxReportWorkbook.createSheet("Summary");
            ArrayList headerData = new ArrayList();
            ArrayList headerRow = new ArrayList();
            headerRow.add("Sprintest\256/CrossBrowser Execution Report");
            headerData.add(headerRow);
            ArrayList summaryTableData = new ArrayList();
            List osBwList = new ArrayList();
            List testCaseList = new ArrayList();
            for(Iterator iterator = ReportBean.report.iterator(); iterator.hasNext();)
            {
                TestCaseReportBean testCaseReportBean = (TestCaseReportBean)iterator.next();
                if(testCaseReportBean != null)
                {
                    osBwList.add(testCaseReportBean.getOsBrowser());
                    testCaseList.add(testCaseReportBean.getTestCaseName());
                }
            }

            List uniqueOsBrowserList = SetUniqueList.decorate(osBwList);
            List uniqueTestCaseList = SetUniqueList.decorate(testCaseList);
            List uniqueTestCaseListJson = SetUniqueList.decorate(testCases);
            uniqueTestCaseListJson.removeAll(uniqueTestCaseList);
            String tcName;
            for(Iterator iterator1 = uniqueTestCaseListJson.iterator(); iterator1.hasNext(); uniqueTestCaseList.add(tcName))
                tcName = (String)iterator1.next();

            ArrayList header = new ArrayList();
            header.add("TestCase");
            header.add("Description");
            header.add("Total");
            header.add("Pass");
            header.add("Fail");
            header.add("Skip");
            String os;
            String browser;
            String version;
            for(Iterator iterator2 = uniqueOsBrowserList.iterator(); iterator2.hasNext(); header.add((new StringBuilder(String.valueOf(os.toUpperCase()))).append(" - ").append(WordUtils.capitalize(browser.toLowerCase())).append(" v").append(version).toString()))
            {
                String unqOsBw = (String)iterator2.next();
                String osBw[] = unqOsBw.split("-");
                os = osBw[0];
                browser = osBw[1];
                if(os.equals("XP"))
                    os = "WINDOWS";
                version = osBw[2];
                if(version.contains("."))
                    version = version.split("\\.")[0];
            }

            ArrayList passheader = new ArrayList();
            ArrayList failheader = new ArrayList();
            ArrayList skipheader = new ArrayList();
            ArrayList totalheader = new ArrayList();
            passheader.add("Pass#");
            passheader.add(totalPass);
            passheader.add("");
            passheader.add("");
            passheader.add("");
            passheader.add("");
            failheader.add("Fail#");
            failheader.add(totalFail);
            failheader.add("");
            failheader.add("");
            failheader.add("");
            failheader.add("");
            skipheader.add("Skip#");
            skipheader.add(totalSkip);
            skipheader.add("");
            skipheader.add("");
            skipheader.add("");
            skipheader.add("");
            totalheader.add("Total#");
            totalheader.add(this.total);
            totalheader.add(this.total);
            totalheader.add(totalPass);
            totalheader.add(totalFail);
            totalheader.add(totalSkip);
            JSONObject brwsrJson;
            for(Iterator iterator3 = uniqueOsBrowserList.iterator(); iterator3.hasNext(); totalheader.add(brwsrJson.get("total").toString()))
            {
                String unqOsBw = (String)iterator3.next();
                brwsrJson = testcaseCount.getBrowserInfo(unqOsBw);
                passheader.add(brwsrJson.get("pass").toString());
                failheader.add(brwsrJson.get("fail").toString());
                skipheader.add(brwsrJson.get("skip").toString());
            }

            summaryTableData.add(passheader);
            summaryTableData.add(failheader);
            summaryTableData.add(skipheader);
            summaryTableData.add(totalheader);
            summaryTableData.add(header);
            ArrayList testcaseRow;
            for(Iterator iterator4 = uniqueTestCaseList.iterator(); iterator4.hasNext(); summaryTableData.add(testcaseRow))
            {
                String tcName = (String)iterator4.next();
                testcaseRow = new ArrayList();
                JSONObject testCaseInfoJson = testcaseCount.getTestcaseInfo(tcName);
                int total = Integer.parseInt(testCaseInfoJson.get("total").toString());
                if(total > 0)
                    testcaseRow.add(tcName);
                else
                    testcaseRow.add((new StringBuilder(String.valueOf(tcName))).append(" [Not Executed]").toString());
                String description = "";
                description = testcaseCount.getTestcaseDescription(tcName);
                if(description == null || description.isEmpty() || description.equals(""))
                    description = "Not provided.";
                testcaseRow.add(description);
                testcaseRow.add(testCaseInfoJson.get("total").toString());
                testcaseRow.add(testCaseInfoJson.get("pass").toString());
                testcaseRow.add(testCaseInfoJson.get("fail").toString());
                testcaseRow.add(testCaseInfoJson.get("skip").toString());
                for(Iterator iterator5 = uniqueOsBrowserList.iterator(); iterator5.hasNext();)
                {
                    String osBw = (String)iterator5.next();
                    for(Iterator iterator6 = ReportBean.report.iterator(); iterator6.hasNext();)
                    {
                        TestCaseReportBean testCaseReportBean = (TestCaseReportBean)iterator6.next();
                        if(tcName.equals(testCaseReportBean.getTestCaseName()) && osBw.equals(testCaseReportBean.getOsBrowser()))
                        {
                            String status = testCaseReportBean.getStatus();
                            if(status.equalsIgnoreCase("pass"))
                                testcaseRow.add(status);
                            else
                            if(status.equalsIgnoreCase("fail"))
                                testcaseRow.add(status);
                            else
                            if(status.equalsIgnoreCase("skip"))
                                testcaseRow.add(status);
                        }
                    }

                }

            }

            createHomeSheet(xlsxReportWorkbook, homesheet);
            createHeader(headerData, xlsxReportWorkbook, summarysheet);
            createSummaryTable(summaryTableData, xlsxReportWorkbook, summarysheet);
            FileOutputStream fileOut = new FileOutputStream(new File(filename));
            xlsxReportWorkbook.write(fileOut);
            fileOut.flush();
            fileOut.close();
        }
        catch(FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    public void createHeader(ArrayList bookData, XSSFWorkbook xlsxReportWorkbook, XSSFSheet sheet)
    {
        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 6));
        int rowCount = -1;
        XSSFFont font = xlsxReportWorkbook.createFont();
        XSSFCellStyle style = xlsxReportWorkbook.createCellStyle();
        font.setBoldweight((short)700);
        font.setColor(new XSSFColor(new java.awt.Color(0, 176, 240)));
        font.setFontHeightInPoints((short)18);
        font.setFontName("Candara");
        style.setFont(font);
        for(Iterator iterator = bookData.iterator(); iterator.hasNext();)
        {
            ArrayList aBook = (ArrayList)iterator.next();
            Row row = sheet.createRow(++rowCount);
            int columnCount = -1;
            for(Iterator iterator1 = aBook.iterator(); iterator1.hasNext();)
            {
                Object field = iterator1.next();
                Cell cell = row.createCell(++columnCount);
                cell.setCellStyle(style);
                if(field instanceof String)
                    cell.setCellValue((String)field);
                else
                if(field instanceof Integer)
                    cell.setCellValue(((Integer)field).intValue());
            }

        }

    }

    public void createSummaryTable(ArrayList bookData, XSSFWorkbook xlsxReportWorkbook, XSSFSheet sheet)
    {
        int rowCount = 1;
        int ix = 0;
        for(Iterator iterator = bookData.iterator(); iterator.hasNext();)
        {
            ArrayList aBook = (ArrayList)iterator.next();
            Row row = sheet.createRow(++rowCount);
            int columnCount = -1;
            for(Iterator iterator1 = aBook.iterator(); iterator1.hasNext();)
            {
                Object field = iterator1.next();
                XSSFFont font = xlsxReportWorkbook.createFont();
                XSSFCellStyle style = xlsxReportWorkbook.createCellStyle();
                if(ix < 4)
                    font.setFontHeightInPoints((short)16);
                if(ix == 0)
                {
                    font.setBoldweight((short)700);
                    style.setFillForegroundColor(new XSSFColor(new java.awt.Color(68, 170, 68)));
                    style.setFillPattern((short)1);
                    style.setFont(font);
                }
                if(ix == 1)
                {
                    font.setBoldweight((short)700);
                    style.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 68, 68)));
                    style.setFillPattern((short)1);
                    style.setFont(font);
                }
                if(ix == 2)
                {
                    font.setBoldweight((short)700);
                    style.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 170, 0)));
                    style.setFillPattern((short)1);
                    style.setFont(font);
                }
                if(ix == 3)
                {
                    font.setBoldweight((short)700);
                    style.setFillForegroundColor(new XSSFColor(new java.awt.Color(173, 173, 173)));
                    style.setFillPattern((short)1);
                    style.setFont(font);
                }
                if(ix == 4)
                {
                    font.setBoldweight((short)700);
                    style.setFillForegroundColor(new XSSFColor(new java.awt.Color(0, 73, 148)));
                    style.setFillPattern((short)1);
                    font.setColor(new XSSFColor(new java.awt.Color(255, 255, 255)));
                    style.setFont(font);
                }
                if(ix > 4)
                    if(columnCount == 0)
                        style.setWrapText(true);
                    else
                    if(columnCount == 2)
                    {
                        style.setFillForegroundColor(new XSSFColor(new java.awt.Color(136, 238, 136)));
                        style.setFillPattern((short)1);
                        style.setFont(font);
                    } else
                    if(columnCount == 3)
                    {
                        style.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 136, 136)));
                        style.setFillPattern((short)1);
                        style.setFont(font);
                    } else
                    if(columnCount == 4)
                    {
                        style.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 255, 119)));
                        style.setFillPattern((short)1);
                        style.setFont(font);
                    } else
                    if(columnCount == 1)
                    {
                        style.setFillForegroundColor(new XSSFColor(new java.awt.Color(191, 191, 191)));
                        style.setFillPattern((short)1);
                        style.setFont(font);
                    }
                Cell cell = row.createCell(++columnCount);
                if(field instanceof String)
                {
                    if(field.toString().equals("PASS"))
                    {
                        style.setFillForegroundColor(new XSSFColor(new java.awt.Color(189, 252, 189)));
                        style.setFillPattern((short)1);
                        font.setColor(new XSSFColor(new java.awt.Color(68, 170, 68)));
                        font.setBoldweight((short)700);
                        style.setAlignment(HorizontalAlignment.CENTER);
                        style.setFont(font);
                    } else
                    if(field.toString().equals("FAIL"))
                    {
                        style.setFillForegroundColor(new XSSFColor(new java.awt.Color(252, 192, 192)));
                        style.setFillPattern((short)1);
                        font.setColor(new XSSFColor(new java.awt.Color(255, 68, 68)));
                        font.setBoldweight((short)700);
                        style.setAlignment(HorizontalAlignment.CENTER);
                        style.setFont(font);
                    } else
                    if(field.toString().equals("SKIP"))
                    {
                        style.setFillForegroundColor(new XSSFColor(new java.awt.Color(250, 250, 195)));
                        style.setFillPattern((short)1);
                        font.setColor(new XSSFColor(new java.awt.Color(255, 170, 0)));
                        font.setBoldweight((short)700);
                        style.setAlignment(HorizontalAlignment.CENTER);
                        style.setFont(font);
                    }
                    cell.setCellValue((String)field);
                    cell.setCellStyle(style);
                } else
                if(field instanceof Integer)
                {
                    cell.setCellValue(((Integer)field).intValue());
                    cell.setCellStyle(style);
                }
            }

            ix++;
        }

    }

    public void createHomeSheet(XSSFWorkbook xlsxReportWorkbook, XSSFSheet sheet)
    {
        byte capGLogo[] = Base64.decodeBase64(ImageLibrary.capgeminiLogo);
        ByteArrayInputStream capGLogoInputStrm = new ByteArrayInputStream(capGLogo);
        CreationHelper capGHelper = xlsxReportWorkbook.getCreationHelper();
        Drawing capGDrawing = sheet.createDrawingPatriarch();
        ClientAnchor capGAnchor = capGHelper.createClientAnchor();
        capGAnchor.setAnchorType(0);
        byte sprintLogo[] = Base64.decodeBase64(ImageLibrary.sprintestLogo);
        ByteArrayInputStream sprintLogoInputStrm = new ByteArrayInputStream(sprintLogo);
        CreationHelper sprintHelper = xlsxReportWorkbook.getCreationHelper();
        Drawing sprintDrawing = sheet.createDrawingPatriarch();
        ClientAnchor sprintAnchor = sprintHelper.createClientAnchor();
        sprintAnchor.setAnchorType(0);
        try
        {
            int capGpictureIndex = xlsxReportWorkbook.addPicture(capGLogoInputStrm, 6);
            capGAnchor.setCol1(10);
            capGAnchor.setRow1(0);
            Picture capGPict = capGDrawing.createPicture(capGAnchor, capGpictureIndex);
            capGPict.resize(4D, 3D);
            int sprinpictureIndex = xlsxReportWorkbook.addPicture(sprintLogoInputStrm, 6);
            sprintAnchor.setCol1(0);
            sprintAnchor.setRow1(0);
            Picture sprintPict = sprintDrawing.createPicture(sprintAnchor, sprinpictureIndex);
            sprintPict.resize(3D, 3D);
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        sheet.addMergedRegion(new CellRangeAddress(7, 11, 3, 9));
        XSSFFont font = xlsxReportWorkbook.createFont();
        XSSFCellStyle style = xlsxReportWorkbook.createCellStyle();
        font.setBoldweight((short)700);
        font.setColor(new XSSFColor(new java.awt.Color(0, 176, 240)));
        font.setFontHeightInPoints((short)28);
        font.setFontName("Candara");
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setWrapText(true);
        Row row = sheet.createRow(7);
        Cell cell = row.createCell(3);
        cell.setCellStyle(style);
        cell.setCellValue("Sprintest\256/CrossBrowser Execution Report");
    }

    GetTestcaseCount testcaseCount;
    JSONObject totalCountJson;
    String totalPass;
    String totalFail;
    String totalSkip;
    String total;
}

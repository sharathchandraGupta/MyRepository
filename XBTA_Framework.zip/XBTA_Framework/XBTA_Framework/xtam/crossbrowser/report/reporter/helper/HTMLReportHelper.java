// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   HTMLReportHelper.java

package crossbrowser.report.reporter.helper;

import crossbrowser.bean.*;
import crossbrowser.helper.*;
import crossbrowser.logger.FrameworkLogger;
import java.io.*;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.*;
import org.apache.commons.collections.list.SetUniqueList;
import org.json.simple.JSONObject;

public class HTMLReportHelper
{

    public HTMLReportHelper()
    {
        testcaseCount = new GetTestcaseCount();
        totalCountJson = testcaseCount.getTotalCount();
        totalPass = totalCountJson.get("pass").toString();
        totalFail = totalCountJson.get("fail").toString();
        totalSkip = totalCountJson.get("skip").toString();
        total = totalCountJson.get("total").toString();
        passInt = Integer.parseInt(totalPass);
        failInt = Integer.parseInt(totalFail);
        skipInt = Integer.parseInt(totalSkip);
        totalInt = Integer.parseInt(total);
    }

    public void createTestcaseInstanceReport(List testCaseReportBeanlist, ArrayList testCases)
    {
        String filename = "temp.html";
        PrintWriter m_out = createWriter("./test-output/", filename);
        createHeader(m_out);
        createSummary(m_out, testCaseReportBeanlist, testCases);
        int tcInstanceCount = 1;
        for(Iterator iterator = testCaseReportBeanlist.iterator(); iterator.hasNext();)
        {
            TestCaseReportBean testCaseReportBean = (TestCaseReportBean)iterator.next();
            String testcaseName = testCaseReportBean.getTestCaseName();
            String description = testCaseReportBean.getDescription();
            String duration = testCaseReportBean.getDuration();
            String osBrowser = testCaseReportBean.getOsBrowser();
            String status = testCaseReportBean.getStatus();
            if(description == null)
                description = "Not provided.";
            createTeatcaseDetail(m_out, testcaseName, description, duration, osBrowser, status, tcInstanceCount, testCaseReportBean.getSteps());
            tcInstanceCount++;
        }

        createFooter(m_out);
        closeWriter(m_out);
    }

    private PrintWriter createWriter(String outdir, String fileName)
    {
        (new File(outdir)).mkdirs();
        try
        {
            return new PrintWriter(new BufferedWriter(new FileWriter(new File(outdir, fileName))));
        }
        catch(IOException e)
        {
            FrameworkLogger.log((new StringBuilder("Error while creating HTML Report. Exception: ")).append(e.getMessage()).toString(), crossbrowser.logger.FrameworkLogger.LEVEL.debug, getClass());
        }
        return null;
    }

    private void createTeatcaseDetail(PrintWriter out, String testcaseName, String description, String duration, String osBrowser, String status, int tcInstanceNumber, 
            List testStepReportBeanList)
    {
        out.println((new StringBuilder("<table class='overviewTable' id='instance")).append(tcInstanceNumber).append("'><thead><tr><th colspan='4' class='header suite'><p>").append(testcaseName).append(":</p></th><th class='header suite status'><p title='Back to Summary'><a href='#summary'>&#x25B2;</a></p></th></tr></thead>").toString());
        out.println("<tbody id='tests-1' class='tests'>");
        out.println("<tr>");
        out.println("<td class='test' colspan='5'>");
        out.println((new StringBuilder("<p><b>Description:</b> ")).append(description).append("<p>").toString());
        out.println("</td>");
        out.println("</tr>");
        out.println("<tr>");
        out.println("<td class='test' colspan='3'>");
        out.println((new StringBuilder("<p><b>OS-Browser:</b> ")).append(osBrowser).append("<p>").toString());
        out.println("</td>");
        if(status.equalsIgnoreCase("PASS"))
        {
            out.println("<td class='test' colspan='2'>");
            out.println((new StringBuilder("<p><b>Status:</b> <span class='successIndicator'>")).append(status).append("&nbsp;&#x2714;</span><p>").toString());
            out.println("</td>");
        } else
        if(status.equalsIgnoreCase("FAIL"))
        {
            out.println("<td class='test' colspan='2'>");
            out.println((new StringBuilder("<p><b>Status:</b> <span class='failureIndicator'>")).append(status).append("&nbsp;&#x2718;</span><p>").toString());
            out.println("</td>");
        } else
        if(status.equalsIgnoreCase("SKIP"))
        {
            out.println("<td class='test' colspan='2'>");
            out.println((new StringBuilder("<p><b>Status:</b><span class='skipIndicator'>")).append(status).append("&nbsp;&#x2718;</span><p>").toString());
            out.println("</td>");
        }
        out.println("</tr>");
        out.println("<tr>");
        out.println("<td class='test' colspan='5'>");
        out.println((new StringBuilder("<p><b>Duration:</b> ")).append(duration).append("<p>").toString());
        out.println("</td>");
        out.println("</tr>");
        createDetailReport(out, testStepReportBeanList);
        out.println("</tbody>");
        out.println("</table>");
        out.println("<br><hr class='style-transparen'>");
    }

    private void createHeader(PrintWriter out)
    {
        out.println("<!DOCTYPE HTML PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN' 'http://www.w3.org/TR/html4/loose.dtd'>");
        out.println("<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='' lang=''>");
        out.println("<head>");
        out.println("<title>Sprintest&reg;/CrossBrowser Detail Report</title>");
        out.println("<meta http-equiv='Content-Type' content='text/html;charset=utf-8' />");
        out.println("<meta name='description' content='TestNG unit test results.' />");
        out.println("<style TYPE='text/css'>");
        out.println("*                        {padding: 0; margin: 0;}");
        out.println("a                        {color: #006699;}");
        out.println("a:visited                {color: #003366;}");
        out.println("body                     {font-family: Lucida Sans Unicode, Lucida Grande, sans-serif; line-height: 1.8em; font-size: 62.5%; margin: 1.8em 1em;}");
        out.println("h1                       {font-family: Arial, Helvetica, sans-serif; font-weight: bold; font-size: 2.7em; margin-bottom: 0.6667em;}");
        out.println("h2                       {font-family: Arial, Helvetica, sans-serif; font-weight: bold; font-size: 2.0em; margin-bottom: 0;}");
        out.println("p                        {font-size: 1.5em;}");
        out.println("p2                        {font-size: 1.3em;}");
        out.println(".header                  {font-weight: bold; text-align: left;}");
        out.println(".passed                  {background-color: #44aa44;}");
        out.println(".skipped                 {background-color: #ffaa00;}");
        out.println(".failed                  {background-color: #ff4444;}");
        out.println(".failedConfig            {background-color: #800000; color: #ffffff}");
        out.println(".skippedConfig           {background-color: #cc6600; color: #ffffff}");
        out.println(".total              \t\t{font-weight: bold; background-color: #808080;}");
        out.println(".passedText              {color: #44aa44;}");
        out.println(".skippedText             {color: #ffaa00;}");
        out.println(".failedText              {color: #ff4444;}");
        out.println(".totalText          \t\t{color: #004994;}");
        out.println(".actText          \t\t{color: #A8A8A8;}");
        out.println(".summary                 {background-color: #004994; font-weight: bold; color: #FFFFFF;}");
        out.println(".suite                   {background-color: #19B9E5; font-weight: bold;}");
        out.println(".details                 {background-color: #999999; font-weight: bold;}");
        out.println(".test                    {background-color: #eeeeee; padding-left: 2em;}");
        out.println(".test .passed            {background-color: #88ee88;}");
        out.println(".test .skipped           {background-color: #ffff77;}");
        out.println(".test .failed            {background-color: #ff8888;}");
        out.println(".test .total\t            {background-color: #bfbfbf;}");
        out.println(".test .passed a          {color: #1A411A;}");
        out.println(".test .skipped a         {color: #D99102;}");
        out.println(".test .failed a          {color: #E30202;}");
        out.println(".test .passed a:visited  {color: #1A411A;}");
        out.println(".test .skipped a:visited {color: #D99102;}");
        out.println(".test .failed a:visited  {color: #E30202;}");
        out.println(".group                   {background-color: #cccccc; color: #000000; font-weight: bold;}");
        out.println(".suiteLinks              {float: right; font-weight: normal; vertical-align: middle;}");
        out.println(".suiteLinks a            {color: #ffffff; margin-left: .5em;}");
        out.println(".passRate                {font-weight: bold; text-align: right;}");
        out.println(".duration                {text-align: right;}");
        out.println(".thread                  {white-space: nowrap;}");
        out.println(".resultsTable            {border: 0; width: 100%; margin-top: 1.8em; line-height: 1.7em; border-spacing: 0.1em;}");
        out.println(".resultsTable .method    {width: 18em;}");
        out.println(".resultsTable .duration  {width: 6em;}");
        out.println(".resultsTable td         {vertical-align: top; padding: 0 1em;}");
        out.println(".resultsTable th         {padding: 0 .5em;}");
        out.println(".number                  {text-align: right;}");
        out.println(".status                  {text-align: center;}");
        out.println(".zero                    {font-weight: normal;}");
        out.println(".columnHeadings          {font-size: 1em;}");
        out.println(".columnHeadings th       {font-weight: normal;}");
        out.println(".configTable             {border: 1px solid #800000; color: #800000; margin-bottom: 1.5em;}");
        out.println("#sidebarHeader           {padding: 1.8em 1em; margin: 0 -1em 1.8em -1em;}");
        out.println("#suites                  {line-height: 1.7em; border-spacing: 0.1em; width: 100%;}");
        out.println(".tests                   {display: table-row-group;}");
        out.println(".header.suite            {cursor: pointer; clear: right; height: 1.214em; margin-top: 1px;}");
        out.println("div.test                 {margin-top: 0.1em; clear: right; font-size: 1.3em;}");
        out.println(".toggle                  {font-family: monospace; font-weight: bold; padding-left: 2px; padding-right: 5px; color: #777777;}");
        out.println(".successIndicator        {font-family: monospace; font-weight: bold; padding-left: 2px; color: #44aa44;}");
        out.println(".skipIndicator           {font-family: monospace; font-weight: bold; padding-left: 2px; color: #ffaa00;}");
        out.println(".failureIndicator        {font-family: monospace; font-weight: bold; padding-left: 2px; color: #ff4444;}");
        out.println(".result                  {font-size: 1.1em; vertical-align: middle;}");
        out.println(".dependency              {font-family: Lucida Console, Monaco, Courier New, monospace; font-weight: bold;}");
        out.println(".arguments               {font-family: Lucida Console, Monaco, Courier New, monospace; font-weight: bold;}");
        out.println(".testOutput              {font-family: Lucida Console, Monaco, Courier New, monospace; color: #666666;}");
        out.println(".stackTrace              {font-size: 0.9em; line-height: 1.2em; margin-left: 2em; display: none;}");
        out.println(".stackTrace .stackTrace  {font-size: inherit;}");
        out.println(".description             {border-bottom: 1px dotted #006699;}");
        out.println("#meta                    {font-size: 1em; text-align: right; float: right;}");
        out.println("#systemInfo              {color: #666666;}");
        out.println("#log                     {font-family: Lucida Console, Monaco, Courier New, monospace; font-size: 1.3em; margin-top: 1.8em;}");
        out.println(".heading\t\t\t        {color: #004994;}");
        out.println(".style-drop-shadow \t\t{height: 12px;border: 0; box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);}");
        out.println(".style-transparen\t\t{border: 0; height: 1px; background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));}");
        out.println(".overviewTable           {width: 100%; margin-top: 1.8em; line-height: 1.7em; border-spacing: 0.1em; }");
        out.println(".overviewTable td        {padding: 3px 3px 3px 3px;}");
        out.println(".overviewTable th        {padding: 3px 3px 3px 3px;}");
        out.println(".overviewTable .duration {width: 6em;}");
        out.println(".overviewTable .passRate {width: 6em;}");
        out.println(".overviewTable .number   {width: 5em;}");
        out.println(".overviewTable tr        {height: 1.6em;}");
        out.println(".summaryTable           {width: 30%; margin-top: 1.8em; line-height: 1.7em; border-spacing: 0.1em; }");
        out.println(".summaryTable td        {padding: 3px 3px 3px 3px;}");
        out.println(".summaryTable th        {padding: 3px 3px 3px 3px;}");
        out.println(".summaryTable .duration {width: 6em;}");
        out.println(".summaryTable .passRate {width: 6em;}");
        out.println(".summaryTable .number   {width: 5em;}");
        out.println(".summaryTable tr        {height: 1.6em;}");
        out.println(".traceinfo{position: fixed;top: 0; bottom: 0;left: 0;right:0;background: rgba(0, 161, 228, 0.2);z-index: 99999;opacity:0;-webkit-transition: opacity 400ms ease-in;transition: opacity 400ms ease-in;pointer-events: none;}");
        out.println(".traceinfo.visible{opacity:1;pointer-events: auto;}");
        out.println(".traceinfo > div{width: 80%; height : 90%; position: relative;margin: 2% auto;padding: 5px 20px 13px 20px;background: #fff; align:'center';}");
        out.println(".traceinfo .close{background: #606061;color: #FFFFFF;line-height: 25px;position: absolute;right: -12px;text-align: center;top: -10px;width: 24px;text-decoration: none;font-weight: bold;}");
        out.println(".traceinfo .close:hover{background: #00d9ff;}");
        out.println(".traceinfo img {display: block;margin-left: auto;margin-right: auto;}");
        out.println("</style>");
        out.println("<script type='text/javascript'>");
        out.println("function showTrace(e){");
        out.println("window.event.srcElement.parentElement.getElementsByClassName('traceinfo')[0].className = 'traceinfo visible';");
        out.println("}");
        out.println("function closeTraceModal(e){");
        out.println("window.event.srcElement.parentElement.parentElement.className = 'traceinfo';");
        out.println("}");
        out.println("var Piechart = function(options){");
        out.println("this.options = options;");
        out.println("this.canvas = options.canvas;");
        out.println("this.ctx = this.canvas.getContext('2d');");
        out.println("this.colors = options.colors;");
        out.println("function drawPieSlice(ctx,centerX, centerY, radius, startAngle, endAngle, color ){");
        out.println("ctx.fillStyle = color;");
        out.println("ctx.beginPath();");
        out.println("ctx.moveTo(centerX,centerY);");
        out.println("ctx.arc(centerX, centerY, radius, startAngle, endAngle);");
        out.println("ctx.closePath();");
        out.println("ctx.fill();");
        out.println("}");
        out.println("this.draw = function(){");
        out.println("var total_value = 0;");
        out.println("var color_index = 0;");
        out.println("for (var categ in this.options.data){");
        out.println("var val = this.options.data[categ];");
        out.println(" total_value += val;");
        out.println("}");
        out.println("var start_angle = 0;");
        out.println("for (categ in this.options.data){");
        out.println("val = this.options.data[categ];");
        out.println("var slice_angle = 2 * Math.PI * val / total_value;");
        out.println("drawPieSlice(");
        out.println("this.ctx,");
        out.println("this.canvas.width/2,");
        out.println("this.canvas.height/2,");
        out.println(" Math.min(this.canvas.width/2,this.canvas.height/2),");
        out.println("start_angle,");
        out.println("start_angle+slice_angle,");
        out.println("this.colors[color_index%this.colors.length]");
        out.println(");");
        out.println("start_angle += slice_angle;");
        out.println("color_index++;");
        out.println("}");
        out.println("if (this.options.doughnutHoleSize){");
        out.println("drawPieSlice(");
        out.println("this.ctx,");
        out.println("this.canvas.width/2,");
        out.println("this.canvas.height/2,");
        out.println("this.options.doughnutHoleSize * Math.min(this.canvas.width/2,this.canvas.height/2),");
        out.println("0,");
        out.println("2 * Math.PI,");
        out.println("'#ffffff'");
        out.println(");");
        out.println("}");
        out.println("}");
        out.println("this.drawLegend = function() {");
        out.println("var posX=40;");
        out.println("var posY=20;");
        out.println("var labels=(Object.keys(this.options.data));");
        out.println("for(var i = 0; i < this.colors.length; i++){");
        out.println("this.ctx.fillStyle = this.colors[i];");
        out.println("this.ctx.fillRect(posX, posY, 10, -10);");
        out.println("this.ctx.fillStyle = 'black';");
        out.println("this.ctx.font = 'bold 10px Arial';");
        out.println("this.ctx.fillText(labels[i], posX+15, posY-2);");
        out.println("posY=posY+15;");
        out.println("}");
        out.println("}");
        out.println("}");
        out.println("function init(){");
        out.println("var myVinyls = {");
        out.println((new StringBuilder("'Pass': ")).append(passInt).append(",").toString());
        out.println((new StringBuilder("'Fail': ")).append(failInt).append(",").toString());
        out.println((new StringBuilder("'Skip': ")).append(skipInt).toString());
        out.println("};");
        out.println("var myDougnutChart = new Piechart(");
        out.println("{");
        out.println("canvas:piechart,");
        out.println("data:myVinyls,");
        out.println("colors:['#44aa44','#ff4444', '#ffaa00'],");
        out.println("doughnutHoleSize:0.5");
        out.println("}");
        out.println(");");
        out.println("myDougnutChart.draw();");
        out.println("myDougnutChart.drawLegend();");
        out.println("}");
        out.println("var BarChart = (function() {");
        out.println("console.log('loaded');");
        out.println("var canvas, ctx, data, options, canvasHeight, canvasWidth, barGap, barWidth, barPosX, scale;");
        out.println("function init(canvasId, userData, userOptions) {");
        out.println("canvas = document.getElementById(canvasId);");
        out.println("ctx = canvas.getContext('2d');");
        out.println("data = userData || [];");
        out.println(" options = userOptions || {};");
        out.println("canvasHeight = canvas.height;");
        out.println("canvasWidth = canvas.width;");
        out.println("barGap = options.barGap || 25;");
        out.println(" barWidth = options.barWidth || 25;");
        out.println("barPosX = options.barPosX || 50;");
        out.println("scale=((canvasHeight-35)/100)");
        out.println("drawGrid();");
        out.println("drawGraph();");
        out.println("}");
        out.println("function drawGrid() {");
        out.println("var gridGap = (canvasHeight-20) / 5,");
        out.println("currentGridY = 15;");
        out.println("ctx.lineWidth = 2;");
        out.println("ctx.strokeStyle = options.gridColor || 'rgba(50,50,50,.3)';");
        out.println("for (var i = 0; i <= 4; i++) {");
        out.println("if(i%2==0){");
        out.println("ctx.fillText((100-(i*25))+'%', 10, currentGridY);");
        out.println("}");
        out.println("ctx.beginPath();");
        out.println("ctx.moveTo(40, currentGridY);");
        out.println("ctx.lineTo(canvasWidth-110, currentGridY);");
        out.println("ctx.closePath();");
        out.println("ctx.stroke();");
        out.println("currentGridY += gridGap;");
        out.println("}");
        out.println("}");
        out.println("function drawGraph() {");
        out.println("for (var i = 0; i < data.length; i++) {");
        out.println("ctx.fillStyle = colors[i];");
        out.println("ctx.fillRect(barPosX, canvasHeight-20, barWidth, -(dataPercentage[i]*scale));");
        out.println("ctx.font = options.fontSettings || 'bold 13px Arial';");
        out.println("ctx.fillStyle = options.fontColor || colors[i];");
        out.println("ctx.fillText(dataPercentage[i]+'%', barPosX, canvasHeight - (dataPercentage[i]*scale) - 25);");
        out.println("ctx.fillStyle = options.fontColor || 'black';");
        out.println("ctx.fillText(labels[i], barPosX, canvasHeight-5);");
        out.println(" barPosX += barWidth + barGap;");
        out.println("}");
        out.println("}");
        out.println("return {");
        out.println("render: init");
        out.println("};");
        out.println("})();");
        out.println((new StringBuilder("var data = [")).append(passInt).append(", ").append(failInt).append(", ").append(skipInt).append("],").toString());
        out.println((new StringBuilder("dataPercentage = [")).append(getPercentage(passInt, totalInt)).append(", ").append(getPercentage(failInt, totalInt)).append(", ").append(getPercentage(skipInt, totalInt)).append("],").toString());
        out.println("colors = ['rgba(68,170,68,1)','rgba(255,68,68,1)','rgba(255,170,0,1)'],");
        out.println("labels = ['Pass', 'Fail', 'Skip'],");
        out.println("options = {};");
        out.println("function initBarChart(){");
        out.println("BarChart.render('barchart', data, options, colors, labels, dataPercentage);");
        out.println("}");
        out.println("</script>");
        out.println("</head>");
        out.println("<body onload='init(), initBarChart()'>");
        out.println("<div id='header'>");
        out.println("<table width='100%'><tr><td>");
        out.println((new StringBuilder("<img alt='Sprintest LOGO' width='193px' height='75px' src='data:image/jpg;base64,")).append(ImageLibrary.sprintestLogo).append("' />").toString());
        out.println("</td>");
        out.println("<td class='number'>");
        out.println((new StringBuilder("<img alt='IGATE LOGO' width='267x' height='75px' src='data:image/jpg;base64,")).append(ImageLibrary.capgeminiLogo).append("' />").toString());
        out.println("</td></tr></table><br><br>");
        out.println("<h1 class='heading'>Sprintest<sup>&reg;</sup>/CrossBrowser Execution Report</h1>");
        out.println("</div>");
        out.println("<hr class='style-drop-shadow'><br>");
        out.println("<h2 id='summary'>Execution Summary:</h2><br>");
        out.println("<p class='totalText'><b>Test Suite Execution Details</b></p>");
        out.println((new StringBuilder("<table><tbody><tr><td class='totalText number'><p>Start Time: </p></td><td><p>")).append(DateFormatter.formatDate(ReportBean.startDate, "dd MMM, yyyy HH:mm:ss z")).append("</p></td><tr>").toString());
        out.println((new StringBuilder("<tr><td class='totalText number'><p>End Time: </p></td><td><p>")).append(DateFormatter.formatDate(ReportBean.endDate, "dd MMM, yyyy HH:mm:ss z")).append("</p></td><tr>").toString());
        out.println((new StringBuilder("<tr><td class='totalText number'><p>Total Time: </p></td><td><p>")).append(TimeUtils.convertSecToHHMMSS((ReportBean.endDate.getTime() - ReportBean.startDate.getTime()) / 1000L)).append("</p></td><tr><tbody></table>").toString());
    }

    private void createFooter(PrintWriter out)
    {
        out.println("</body>");
        out.println("</html>");
    }

    private void createDetailReport(PrintWriter out, List testStepReportBeanList)
    {
        out.println("<tr>");
        out.println("<td class='header details'><p>Date</p></th>");
        out.println("<td class='header details'><p>Step</p></th>");
        out.println("<td class='header details'><p>Expected</p></th>");
        out.println("<td class='header details'><p>Actual</p></th>");
        out.println("<td class='header details'><p>Result</p></th>");
        out.println("</tr></thead><tbody>");
        if(testStepReportBeanList != null)
        {
            for(Iterator iterator = testStepReportBeanList.iterator(); iterator.hasNext(); out.println("</tr>"))
            {
                TestStepReportBean testStepReportBean = (TestStepReportBean)iterator.next();
                out.println("<tr class='test'>");
                out.println((new StringBuilder("<td class='test'><p2>")).append(testStepReportBean.getDate()).append("</p2></td>").toString());
                out.println((new StringBuilder("<td class='test'><p2>")).append(testStepReportBean.getStepName()).append("</p2></td>").toString());
                out.println((new StringBuilder("<td class='test'><p2>")).append(testStepReportBean.getExpected()).append("</p2></td>").toString());
                String imgLinkId = testStepReportBean.getScreenShotPath().replace("./test-output/stepScreenShots/", "").replace(".png", "");
                String imgPath = testStepReportBean.getScreenShotPath().replace("test-output/", "");
                if(imgPath.endsWith(".png"))
                    out.println((new StringBuilder("<td class='test'><p2><a onclick='showTrace()' href='#")).append(imgLinkId).append("'>").append(testStepReportBean.getActual()).append("</a><div id='").append(imgLinkId).append("' class='traceinfo'><div><a href='#close' onclick='closeTraceModal()' title='Close' class='close'>X</a><a href='").append(imgPath).append("' target='_blank'><img src='").append(imgPath).append("' height='100%' width='auto' ></a></div></div></p2></td>").toString());
                else
                if(imgPath.endsWith(".html"))
                    out.println((new StringBuilder("<td class='test'><p2><a onclick='showTrace()' href='#")).append(imgLinkId).append("'>").append(testStepReportBean.getActual()).append("</a><div id='").append(imgLinkId).append("' class='traceinfo'><div><a href='#close' onclick='closeTraceModal()' title='Close' class='close'>X</a><a href='").append(imgPath).append("' target='_blank'><iframe src='").append(imgPath).append("' height='100%' width='100%' ></iframe></a></div></div></p2></td>").toString());
                else
                    out.println((new StringBuilder("<td class='test'><p2>")).append(testStepReportBean.getActual()).append("</p2></td>").toString());
                String status = testStepReportBean.getResult();
                if(status.equalsIgnoreCase("pass"))
                    out.println((new StringBuilder("<td class='passed'><p>")).append(status).append("</p></td>").toString());
                else
                if(status.equalsIgnoreCase("fail"))
                    out.println((new StringBuilder("<td class='failed'><p>")).append(status).append("</p></td>").toString());
                else
                if(status.equalsIgnoreCase("skip"))
                    out.println((new StringBuilder("<td class='skipped'><p>")).append(status).append("</p></td>").toString());
            }

        } else
        {
            out.println("<tr class='test'>");
            out.println("<td class='test'><p2>Not Found</p2></td>");
            out.println("<td class='test'><p2>Test Step</p2></td>");
            out.println("<td class='test'><p2>Should Execute</p2></td>");
            String imgLinkId = "";
            String imgPath = "";
            out.println((new StringBuilder("<td class='test'><p2><a onclick='showTrace()' href='#")).append(imgLinkId).append("'>Something went wrong</a><div id='").append(imgLinkId).append("' class='traceinfo'><div><a href='#close' onclick='closeTraceModal()' title='Close' class='close'>X</a><a href='").append(imgPath).append("' target='_blank'><img src='").append(imgPath).append("' height='100%' width='auto' ></a></div></div></p2></td>").toString());
            out.println("<td class='failed'><p>Fail</p></td>");
            out.println("</tr>");
        }
    }

    private void closeWriter(PrintWriter out)
    {
        out.flush();
        out.close();
    }

    public void createSummary(PrintWriter out, List testCaseReportBeansList, ArrayList testCases)
    {
        List osBwList = new ArrayList();
        List testCaseList = new ArrayList();
        for(Iterator iterator = ReportBean.report.iterator(); iterator.hasNext();)
        {
            TestCaseReportBean testCaseReportBean = (TestCaseReportBean)iterator.next();
            if(testCaseReportBean != null)
            {
                osBwList.add(testCaseReportBean.getOsBrowser());
                testCaseList.add(testCaseReportBean.getTestCaseName());
            }
        }

        List uniqueOsBrowserList = SetUniqueList.decorate(osBwList);
        List uniqueTestCaseList = SetUniqueList.decorate(testCaseList);
        List uniqueTestCaseListJson = SetUniqueList.decorate(testCases);
        uniqueTestCaseListJson.removeAll(uniqueTestCaseList);
        String tcName;
        for(Iterator iterator1 = uniqueTestCaseListJson.iterator(); iterator1.hasNext(); uniqueTestCaseList.add(tcName))
            tcName = (String)iterator1.next();

        List doneIndex = new ArrayList();
        out.println("<br>");
        out.println("<table width='100%'><tr><td width='10%'></td><td width='20%'>");
        out.println("<table width='100%'>");
        out.println((new StringBuilder("<tr><td class='passedText number' width='30%'><p><b>Passed:</b> </td><td class='' width='40%'><p>")).append(getPercentage(passInt, totalInt)).append("%</p></td><td class='actText' width='30%'><p>[").append(totalPass).append("]</p></td></tr>").toString());
        out.println((new StringBuilder("<tr><td class='failedText number' width='30%'><p><b>Failed:</b> </td><td class='' width='40%'><p>")).append(getPercentage(failInt, totalInt)).append("%</p></td><td class='actText' width='30%'><p>[").append(totalFail).append("]</p></td></tr>").toString());
        out.println((new StringBuilder("<tr><td class='skippedText number' width='30%'><p><b>Skipped:</b> </td><td class='' width='40%'><p>")).append(getPercentage(skipInt, totalInt)).append("%</p></td><td class='actText' width='30%'><p>[").append(totalSkip).append("]</p></td></tr>").toString());
        out.println((new StringBuilder("<tr><td class='totalText number' width='30%'><p><b>Total: </b></td><td class='' width='40%'><p>")).append(getPercentage(totalInt, totalInt)).append("%</p></td><td class='actText' width='30%'><p>[").append(this.total).append("]</p></td></tr>").toString());
        out.println("</table></td>");
        out.println("<td width='10%'></td><td width='25%' class='status'><canvas id='piechart' height='100%'>Your browser does not support HTML5 Canvas.</canvas></td>");
        out.println("<td width='35%' class='status'><canvas id='barchart' height='100%'>Your browser does not support HTML5 Canvas.</canvas></td>");
        out.println("</tr></table>");
        out.println("<table class='overviewTable'>");
        out.println("<tr><th class='header summary'><p>TestCase</p></th>");
        out.println("<th class='header summary'><p>Pass</p></th>");
        out.println("<th class='header summary'><p>Fail</p></th>");
        out.println("<th class='header summary'><p>Skip</p></th>");
        out.println("<th class='header summary'><p>Total</p></th>");
        for(Iterator iterator2 = uniqueOsBrowserList.iterator(); iterator2.hasNext(); out.println("</p></th>"))
        {
            String unqOsBw = (String)iterator2.next();
            out.println("<th class='header summary status'><p>");
            String osBw[] = unqOsBw.split("-");
            String os = osBw[0];
            String browser = osBw[1];
            String version = osBw[2];
            if(version.contains("."))
                version = version.split("\\.")[0];
            out.println((new StringBuilder("<img alt='")).append(os).append("' title='").append(os).append("' width='25px' height='25px' src='data:image/jpg;base64,").append(ImageLibrary.get(os)).append("' /><img alt='").append(browser).append("' title='").append(browser).append("' width='25px' height='25px' src='data:image/jpg;base64,").append(ImageLibrary.get(browser)).append("' />&nbsp;v").append(version).toString());
        }

        out.println("</tr>");
        out.println("<tr><td colspan='5'></td>");
        JSONObject brwsrJson;
        for(Iterator iterator3 = uniqueOsBrowserList.iterator(); iterator3.hasNext(); out.println((new StringBuilder("<td class='test'><table width='100%'><tr><td class='test passed status'><p>")).append(brwsrJson.get("pass").toString()).append("</p></td><td class='test failed status'><p>").append(brwsrJson.get("fail").toString()).append("</p></td><td class='test skipped status'><p>").append(brwsrJson.get("skip").toString()).append("</p></td><td class='test total status'><p>").append(brwsrJson.get("total").toString()).append("</p></td></tr></table></td>").toString()))
        {
            String unqOsBw = (String)iterator3.next();
            brwsrJson = testcaseCount.getBrowserInfo(unqOsBw);
        }

        out.println("</tr>");
        for(Iterator iterator4 = uniqueTestCaseList.iterator(); iterator4.hasNext(); out.println("</tr>"))
        {
            String tcName = (String)iterator4.next();
            JSONObject testCaseInfoJson = testcaseCount.getTestcaseInfo(tcName);
            out.println("<tr class='test'>");
            int total = Integer.parseInt(testCaseInfoJson.get("total").toString());
            if(total > 0)
                out.println((new StringBuilder("<td class='test'><p>")).append(tcName).append("</p></td>").toString());
            else
                out.println((new StringBuilder("<td class='test'><p>")).append(tcName).append("<small>[Not Executed]</small></p></td>").toString());
            out.println((new StringBuilder("<td class='test passed'><p>")).append(testCaseInfoJson.get("pass").toString()).append("</p></th>").toString());
            out.println((new StringBuilder("<td class='test failed'><p>")).append(testCaseInfoJson.get("fail").toString()).append("</p></th>").toString());
            out.println((new StringBuilder("<td class='test skipped'><p>")).append(testCaseInfoJson.get("skip").toString()).append("</p></th>").toString());
            out.println((new StringBuilder("<td class='test total'><p>")).append(testCaseInfoJson.get("total").toString()).append("</p></th>").toString());
            for(Iterator iterator5 = uniqueOsBrowserList.iterator(); iterator5.hasNext(); out.println("</tr></table></td>"))
            {
                String osBw = (String)iterator5.next();
                int index = 1;
                out.println("<td class='test'><table width='100%'><tr>");
                for(Iterator iterator6 = ReportBean.report.iterator(); iterator6.hasNext();)
                {
                    TestCaseReportBean testCaseReportBean = (TestCaseReportBean)iterator6.next();
                    if(tcName.equals(testCaseReportBean.getTestCaseName()) && !doneIndex.contains(Integer.valueOf(index)) && osBw.equals(testCaseReportBean.getOsBrowser()))
                    {
                        String status = testCaseReportBean.getStatus();
                        if(status.equalsIgnoreCase("pass"))
                            out.println((new StringBuilder("<td class='passed status'><p><a href='#instance")).append(index).append("'>").append(status).append("</a></p></td>").toString());
                        else
                        if(status.equalsIgnoreCase("fail"))
                            out.println((new StringBuilder("<td class='failed status'><p><a href='#instance")).append(index).append("'>").append(status).append("</a></p></td>").toString());
                        else
                        if(status.equalsIgnoreCase("skip"))
                            out.println((new StringBuilder("<td class='skipped status'><p><a href='#instance")).append(index).append("'>").append(status).append("</a></p></td>").toString());
                        doneIndex.add(Integer.valueOf(index));
                    }
                    index++;
                }

            }

        }

        out.println("<table>");
        out.println("<br><p align='right'><small>*See logs for more details.</small></p>");
        out.println("<br><hr class='style-drop-shadow'><br><br>");
        out.println("<h2>Detail Report:</h2>");
    }

    public static double getPercentage(long n, long total)
    {
        if(n != 0L)
        {
            float proportion = (float)n / (float)total;
            DecimalFormat df = new DecimalFormat("0.00");
            String formate = df.format(proportion * 100F);
            if((double)proportion != 1.0D)
                try
                {
                    double finalValue = df.parse(formate).doubleValue();
                    return finalValue;
                }
                catch(ParseException e)
                {
                    return 0.0D;
                }
            else
                return 100D;
        } else
        {
            return 0.0D;
        }
    }

    GetTestcaseCount testcaseCount;
    JSONObject totalCountJson;
    String totalPass;
    String totalFail;
    String totalSkip;
    String total;
    long passInt;
    long failInt;
    long skipInt;
    long totalInt;
}

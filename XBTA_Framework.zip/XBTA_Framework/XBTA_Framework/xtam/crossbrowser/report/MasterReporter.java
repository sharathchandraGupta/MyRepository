// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MasterReporter.java

package crossbrowser.report;

import crossbrowser.helper.GetTestcaseCount;
import crossbrowser.helper.PropertyReader;
import crossbrowser.logger.FrameworkLogger;
import crossbrowser.report.reporter.ConsoleReporter;
import crossbrowser.report.reporter.ExcelReport;
import crossbrowser.report.reporter.HTMLReport;
import java.util.ArrayList;
import org.json.simple.JSONObject;

public class MasterReporter
{

    public MasterReporter()
    {
    }

    public static void callReporter(ArrayList testCases)
    {
        GetTestcaseCount testcaseCount = new GetTestcaseCount();
        JSONObject totalCountJson = testcaseCount.getTotalCount();
        String totalStr = totalCountJson.get("total").toString();
        int total = Integer.parseInt(totalStr);
        if(total > 0)
        {
//            FrameworkLogger.log("Creating Execution Report...!!!", crossbrowser.logger.FrameworkLogger.LEVEL.info, crossbrowser/report/MasterReporter);
            if(PropertyReader.getProperty("HTMLReport", "Y").equalsIgnoreCase("yes") || PropertyReader.getProperty("HTMLReport", "Y").equalsIgnoreCase("y"))
                HTMLReport.generateReport(testCases);
            if(PropertyReader.getProperty("ExcelReport", "Y").equalsIgnoreCase("yes") || PropertyReader.getProperty("ExcelReport", "Y").equalsIgnoreCase("y"))
                ExcelReport.generateReport(testCases);
//            FrameworkLogger.log("Execution Report creation finished.", crossbrowser.logger.FrameworkLogger.LEVEL.info, crossbrowser/report/MasterReporter);
            ConsoleReporter.print(testCases);
        }
    }
}

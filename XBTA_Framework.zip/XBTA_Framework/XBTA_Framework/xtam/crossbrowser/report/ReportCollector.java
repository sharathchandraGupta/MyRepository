// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ReportCollector.java

package crossbrowser.report;

import crossbrowser.bean.*;
import crossbrowser.helper.*;
import java.io.PrintStream;
import java.util.*;
import org.json.simple.JSONObject;
import org.testng.*;

public class ReportCollector
    implements IReporter
{

    public ReportCollector()
    {
    }

    public void generateReport(List xml, List suites, String outdir)
    {
        try
        {
            Thread.sleep(15000L);
        }
        catch(InterruptedException interruptedexception) { }
        for(Iterator iterator = suites.iterator(); iterator.hasNext();)
        {
            ISuite suite = (ISuite)iterator.next();
            for(Iterator iterator2 = suite.getResults().values().iterator(); iterator2.hasNext();)
            {
                ISuiteResult sr = (ISuiteResult)iterator2.next();
                ITestContext context = sr.getTestContext();
                IResultMap testResultMaps[] = {
                    context.getPassedTests(), context.getFailedTests(), context.getSkippedTests()
                };
                IResultMap airesultmap[];
                int j = (airesultmap = testResultMaps).length;
                for(int i = 0; i < j; i++)
                {
                    IResultMap resultMap = airesultmap[i];
                    TestCaseReportBean testCaseReportBean;
                    for(Iterator iterator4 = resultMap.getAllResults().iterator(); iterator4.hasNext(); ReportBean.report.add(testCaseReportBean))
                    {
                        ITestResult testResult = (ITestResult)iterator4.next();
                        ArrayList testLogs = (ArrayList)Reporter.getOutput(testResult);
                        testCaseReportBean = new TestCaseReportBean();
                        List listTestStepReportBeans = new ArrayList();
                        for(Iterator iterator5 = testLogs.iterator(); iterator5.hasNext();)
                        {
                            String log = (String)iterator5.next();
                            TestStepReportBean testStepReportBean = new TestStepReportBean();
                            JSONObject reportJson = JsonFormatter.string2Json(log);
                            if(reportJson.containsKey("step"))
                            {
                                testStepReportBean.setDate(reportJson.get("date").toString());
                                testStepReportBean.setStepName(reportJson.get("step").toString());
                                testStepReportBean.setExpected(reportJson.get("expected").toString());
                                testStepReportBean.setActual(reportJson.get("actual").toString());
                                testStepReportBean.setResult(reportJson.get("status").toString());
                                testStepReportBean.setScreenShotPath(reportJson.get("screenshotPath").toString());
                                listTestStepReportBeans.add(testStepReportBean);
                            } else
                            if(reportJson.containsKey("os"))
                            {
                                String os = "";
                                if(reportJson.get("os").toString().equalsIgnoreCase("XP"))
                                    os = "WINDOWS";
                                else
                                if(reportJson.get("os").toString().equalsIgnoreCase("ANY") && reportJson.get("browser").toString().equalsIgnoreCase("firefox"))
                                    os = "WINDOWS";
                                else
                                    os = reportJson.get("os").toString();
                                String version = reportJson.get("version").toString();
                                if(reportJson.get("browser").toString().equalsIgnoreCase("MicrosoftEdge"))
                                {
                                    os = "WIN10";
                                    if(version.equalsIgnoreCase("Unknown"))
                                        version = "00";
                                }
                                if(version.contains("."))
                                    version = version.split("\\.")[0];
                                testCaseReportBean.setOsBrowser((new StringBuilder(String.valueOf(os))).append("-").append(reportJson.get("browser")).append("-").append(version).toString());
                            } else
                            if(reportJson.containsKey("description"))
                                testCaseReportBean.setDescription(reportJson.get("description").toString());
                        }

                        long secInt = (testResult.getEndMillis() - testResult.getStartMillis()) / 1000L;
                        String minuts = PropertyReader.getProperty("TimeOut", "5");
                        float minutsInt = Float.parseFloat(minuts);
                        long timeoutLim = (long)(minutsInt * 60F);
                        if(secInt >= timeoutLim - 1L)
                        {
                            TestStepReportBean testStepReportBean = new TestStepReportBean();
                            if(listTestStepReportBeans.size() > 0)
                                testStepReportBean.setDate(((TestStepReportBean)listTestStepReportBeans.get(listTestStepReportBeans.size() - 1)).getDate());
                            else
                                testStepReportBean.setDate("Not Found");
                            testStepReportBean.setStepName("Timeout");
                            testStepReportBean.setExpected("Reached timeout time");
                            testStepReportBean.setActual((new StringBuilder("Reached timeout time: ")).append(PropertyReader.getProperty("TimeOut", "5")).append(" minutes").toString());
                            testStepReportBean.setResult("Skip");
                            testStepReportBean.setScreenShotPath("");
                            listTestStepReportBeans.add(testStepReportBean);
                            testResult.setStatus(3);
                        }
                        testCaseReportBean.setDuration(TimeUtils.convertSecToHHMMSS((testResult.getEndMillis() - testResult.getStartMillis()) / 1000L));
                        testCaseReportBean.setStatus(getStatusString(testResult.getStatus()));
                        testCaseReportBean.setTestCaseName(testResult.getInstanceName().replace("xtam.test.", ""));
                        testCaseReportBean.setSteps(listTestStepReportBeans);
                        String osBwStr = testCaseReportBean.getOsBrowser();
                        if(osBwStr == null)
                        {
                            osBwStr = "UnknownOS-UnknownBrowser-00";
                            testCaseReportBean.setOsBrowser(osBwStr);
                            List list = testCaseReportBean.getSteps();
                            TestStepReportBean testStepReportBean = new TestStepReportBean();
                            testStepReportBean.setDate("Not Found");
                            testStepReportBean.setStepName("Connection");
                            testStepReportBean.setExpected("Sould connect to Node browser.");
                            testStepReportBean.setActual("Not able to connect to node browser. No information found.");
                            testStepReportBean.setResult("Fail");
                            testStepReportBean.setScreenShotPath("");
                            list.add(0, testStepReportBean);
                        } else
                        if(osBwStr.isEmpty() || osBwStr.equals(""))
                        {
                            osBwStr = "UnknownOS-UnknownBrowser-00";
                            testCaseReportBean.setOsBrowser(osBwStr);
                        }
                    }

                }

            }

        }

        for(Iterator iterator1 = TestCaseCreationBean.testcasesInstanceCreated.iterator(); iterator1.hasNext();)
        {
            TestCaseReportBean testCasesCreated = (TestCaseReportBean)iterator1.next();
            boolean found = false;
            for(Iterator iterator3 = ReportBean.report.iterator(); iterator3.hasNext();)
            {
                TestCaseReportBean testCaseReportFound = (TestCaseReportBean)iterator3.next();
                System.out.println(testCasesCreated.getTestCaseName());
                System.out.println(testCaseReportFound.getTestCaseName());
                System.out.println(testCasesCreated.getOsBrowser());
                System.out.println(testCaseReportFound.getOsBrowser());
                System.out.println("----------------------------------------------");
                if(testCasesCreated.getTestCaseName().equals(testCaseReportFound.getTestCaseName()) && testCasesCreated.getOsBrowser().equals(testCaseReportFound.getOsBrowser()))
                {
                    found = true;
                    System.out.println("Found");
                }
            }

            if(!found)
                ReportBean.report.add(testCasesCreated);
        }

    }

    private String getStatusString(int testResultStatus)
    {
        switch(testResultStatus)
        {
        case 1: // '\001'
            return "PASS";

        case 2: // '\002'
            return "FAIL";

        case 3: // '\003'
            return "SKIP";

        case 4: // '\004'
            return "SUCCESS_PERCENTAGE_FAILURE";
        }
        return null;
    }
}

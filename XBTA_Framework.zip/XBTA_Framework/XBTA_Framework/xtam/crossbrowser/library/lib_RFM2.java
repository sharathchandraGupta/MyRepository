package crossbrowser.library;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;

import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class lib_RFM2 {
	private WebDriver		driver;
	private Keywords		actions;
	private Map				input;
	private UIValidations	uiActions;
	private lib_MCD			mcd;

	public lib_RFM2(WebDriver driver, Keywords actions, UIValidations uiActions, Map inputData, lib_MCD mcd) {
		this.driver = driver;
		this.actions = actions;
		this.uiActions = uiActions;
		this.input = inputData;
		this.mcd = mcd;

		// mcd = new lib_MCD (driver, actions, uiActions, inputData);
	}

	String strStatus = "";

	/**
	 * Launch the URL and login the RFM application
	 * 
	 * @param strURL
	 * @param strUserName
	 * @param strPassword
	 */
	public void LaunchAndLogin(Object strURL, Object strUserName, Object strPassword) {
		String strStep = "Login application as '" + strUserName + "'";
		String strExpt = "User '" + strUserName + "' should be able to login";

		try {

			// Launch the application URL
			actions.launchApplication(strURL);
			actions.waitForPageToLoad(3000);

			if (strURL.toString().contains("rdi")) {
				System.out.println("RFM - RDI Login");

				String temp = strUserName + ":" + strPassword + "@";
				strURL = strURL.toString().replace(temp, "");
				driver.get(strURL.toString());

				Thread.sleep(2000);
				actions.smartWait(120);

				mcd.SwitchToWindow("");

				actions.reportCreatePASS(strStep, strExpt, "User logged-in successfully", "Pass");

			} else {
				System.out.println("RFM - QMS Login");
				actions.checkElement(actions.getLocator("RFMLoginPage.UserName"), 180);
				if (uiActions.elementPresent(actions.getwebDriverLocator(actions.getLocator("RFMLoginPage.Page")))) {

					actions.getwebDriverLocator(actions.getLocator("RFMLoginPage.UserName")).sendKeys(strUserName.toString().trim());
					actions.getwebDriverLocator(actions.getLocator("RFMLoginPage.Password")).sendKeys(strPassword.toString().trim());
					actions.getwebDriverLocator(actions.getLocator("RFMLoginPage.Login")).click();
					Thread.sleep(2000);

					if (!actions.isMicrosoftEdge() && !actions.isSafari()) {
						actions.smartWait(120);
						mcd.SwitchToWindow("");
					}

					actions.reportCreatePASS(strStep, strExpt, "User logged-in successfully", "Pass");

				} else {
					throw new Exception("RFM Login Page is not displated");
				}
			}
		} catch (Exception e) {
			actions.reportCreateFAIL(strStep, strExpt, e.getMessage(), "Fail");
			e.printStackTrace();
		}
	}

	/**
	 * Logout RFM application
	 */
	public void Logout() {
		try {

			actions.WaitForElementPresent("RFMHomePage.Logout");
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.javaScriptClick("RFMHomePage.Logout");
			Thread.sleep(3000);
			String strMessageType = "Confirmation-popup";
			String strExptMessage = "Do you want to close this";
			
			if(actions.isSafari()){
				driver.switchTo().alert().accept();			
			}
			mcd.VerifyAlertMessageDisplayed(strMessageType, strExptMessage, false, AlertPopupButton.OK_BUTTON);
			// actions.verifyTestStep(strMessageType, strExptMessage, false);
			Thread.sleep(2000);
			if (!actions.isSafari()) {
				driver.switchTo().alert().accept();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Select Market (Node) if the 'Select Node' pop-up window is displayed
	 * 
	 * @param strMarket
	 * @throws Exception
	 */
	public boolean SelectMarket(String strMarket) throws Exception {
		boolean WindowSelected = false;
		WebElement eleMarketSlct;
		List<WebElement> eleListStrong;
		boolean eleFound = false;
		String eleMarketName = "";
		String strXPath = "";
		String strWindow = "Select Node";
		try {
			// Switch to 'Select Node' window
			System.out.println("Switch to 'Select Node' window");
			try {
				if (actions.isMicrosoftEdge() || actions.isSafari()) {
					Thread.sleep(2000);
					actions.WaitForWindowToBe(2, 30);
				}
				WindowSelected = mcd.waitAndSwitch("Select Node");
			} catch (Exception er) {
				actions.reportCreateFAIL("Verify 'Select Market' window is displayed", "'Select Market' window should be displayed", "'Select Market' window is not displayed", "Fail");
				return false;
			}
			String winHandleCurrent = driver.getWindowHandle();

			if (WindowSelected) {
				System.out.println("Window '" + strWindow + "' selected successfully");
				// Click on market name
				System.out.println("Click on market name");

				WebElement eleMarketTree = actions.getwebDriverLocator(actions.getLocator("RFMSelectNodeDialog.MarketList"));
				if (strMarket.equalsIgnoreCase("GLOBAL")) {
					strXPath = "//span[contains(text(),'GLOBAL')]";
				} else {
					strXPath = "//label[contains(text(),'" + strMarket + "')]";
				}

				WebElement eleMarket = eleMarketTree.findElement(By.xpath(strXPath));
				if (eleMarket != null) {
					if (actions.isMicrosoftEdge() || actions.isSafari()) {
						actions.javaScriptClick(eleMarket);
					} else {
						actions.click(eleMarket);
					}
					Thread.sleep(1000);
					actions.waitForPageToLoad(3000);
					System.out.println("Market selected - " + strMarket);
				} else {
					System.out.println("Market not available - " + strMarket);
				}
				System.out.println("Switch back to Main window");
				mcd.SwitchToWindow("RFM - Home");
			} else {
				System.out.println("Failed to select Window '" + strWindow + "'");
			}

			// Verify Market selected
			System.out.println("Verify the Market selected");

			if (strMarket.trim().equalsIgnoreCase("GLOBAL")) {
				eleMarketSlct = actions.getwebDriverLocator(actions.getLocator("RFMHomePage.MarketGlobal"));
			} else {
				eleMarketSlct = actions.getwebDriverLocator(actions.getLocator("RFMHomePage.Market"));

			}

			eleListStrong = eleMarketSlct.findElements(By.tagName("strong"));
			for (int i = 0; i < eleListStrong.size(); i++) {
				if (eleListStrong.get(i).getText().contains("Market")) {
					eleFound = true;
					eleMarketName = eleListStrong.get(i).getText();
					break;
				}
			}
			if (eleMarketSlct.getText().contains("Market")) {
				eleFound = true;
				eleMarketName = eleMarketSlct.getText();
			}

			if (eleFound) {
				if (eleMarketName.contains((CharSequence) strMarket)) {
					System.out.println("Market '" + strMarket + "' seleccted successfully");
				} else {
					System.out.println("Failed to select Market " + strMarket);
				}
			} else {
				System.out.println("Failed to select Market " + strMarket);
			}
			return true;
		} catch (InterruptedException e) {
			actions.reportCreateFAIL("Verify 'Select Market' node is displayed", "'Select Market' node should be displayed", "'Select Market' node is not displayed", "Fail");
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Select Menu Option
	 * 
	 * @param strNavigateTo : Menu options separated by ">"
	 * @param strPageTitle : Title of the page expected after selecting the given Menu Option
	 */
	public void SelectMenuOption(String strNavigateTo, String strExptPageTitle) {
		try {
			String[] arrMenuOptions = (strNavigateTo).split(">");
			WebElement eleMenuOption = actions.getwebDriverLocator(actions.getLocator("Home.Mainmenu"));

			for (int mnuOption = 0; mnuOption < arrMenuOptions.length; mnuOption++) {
				System.out.println(arrMenuOptions[mnuOption].trim());
				eleMenuOption = eleMenuOption.findElement(By.xpath("//li/a[contains(text(),'" + arrMenuOptions[mnuOption].trim() + "')]"));
				eleMenuOption.click();
				Thread.sleep(1000);
				actions.waitForPageToLoad(3000);
			}
			if (driver.getTitle().equalsIgnoreCase(strExptPageTitle)) {
				System.out.println("Page '" + strExptPageTitle + "' is displayed as expected");
			} else {
				System.out.println("Page '" + strExptPageTitle + "' is NOT displayed. Actual page : '" + driver.getTitle() + "'");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	///
	public String Get_future_date(int x) {
		Calendar Date = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date.add(Calendar.DAY_OF_MONTH, x);
		String date = formatter.format(Date.getTime());
		return date;
	}

	// /** Verify Heading of the page
	// *
	// * @param strHeading
	// * @param strHeaderElementClass
	// */
	// public void VerifyPageHeading(String strHeading, String strHeaderElementClass){
	// WebElement elePageHeading = null;
	// elePageHeading = driver.findElement(By.className(strHeaderElementClass.trim()));
	// if(elePageHeading != null){
	// if(elePageHeading.getText().equalsIgnoreCase(strHeading)){
	// System.out.println("Page-heading is displayed as expected");
	// } else {
	// System.out.println("Page-heading is NOT displayed as expected. Actual heading is '" + elePageHeading.getText() + "'");
	// }
	// } else {
	// System.out.println("Sub-heading not found");
	// }
	// }

	// ============================================================================= Menu Items > Substitution Names
	public void NewSubstitutionName_Click() {
		boolean blnResult = false;
		String strResult = "";

		// Elements in action
		String strTableElement = "RFMSubstitutionNames.SubstitutionTable";
		String strNewSubstitutionButton = "RFMSubstitutionNames.NewSubstitution";

		// Get current row count
		int intCurrRowCount = mcd.GetTableRowCount(strTableElement);

		// Click 'New Substitution Name' button
		System.out.println("> Click 'New Substitution Name' button");
		actions.click(strNewSubstitutionButton);

		// Verify that new blank row is added
		int intNewRowCount = mcd.GetTableRowCount(strTableElement);
		System.out.println("New Rows : " + intNewRowCount);

		// Verify that new blank row is added
		System.out.println("> Verify that new blank row is added");
		if (intNewRowCount - intCurrRowCount == 1) {
			blnResult = mcd.VerifyTableColumnValues(strTableElement, intNewRowCount, "Code|Description", " | ", "input|input", "value|value", true);
			strResult = "New row added is not blank";
		} else {
			strResult = "New row is not added";
		}

		if (blnResult) {
			strResult = "New blank-row is added, as expected";
		} else {
			strResult = "Failed :: " + strResult;
		}

		System.out.println(strResult);
	}

	/**
	 * Click 'Cancel' button and verify the confirmation pop-up message displayed. Click 'alertActionButton' on pop-up and verify that new row is removed when
	 * 'OK' button clicked
	 * 
	 * @param strExptMessage : Expected message
	 * @param alertActionButton : Button to be clicked after message verification
	 */

	public void NewSubstitutionName_Cancel(String strExptMessage, AlertPopupButton alertActionButton) {
		boolean blnResult = false;
		String strResult = "";
		String strOperation = "";

		/** Elements in action */
		String strTableElement = "RFMSubstitutionNames.SubstitutionTable";
		String strSubstitutionCancelButton = "RFMSubstitutionNames.CancelButton";

		/** Get current row count */
		int intCurrRowCount = mcd.GetTableRowCount(strTableElement);
		System.out.println("Current Rows : " + intCurrRowCount);

		/** Get current new-row data */
		String strCode = " " + mcd.GetTableCellValue(strTableElement, intCurrRowCount, "Code", "input", "value");
		String strDescription = " " + mcd.GetTableCellValue(strTableElement, intCurrRowCount, "Description", "input", "value");

		/** Click 'Cancel' button */
		System.out.println("> Click 'Cancel' button");
		actions.click(strSubstitutionCancelButton);

		/** Verify confirmation popup message */
		String strMessageType = "Confirmation-popup";
		mcd.VerifyAlertMessageDisplayed(strMessageType, strExptMessage, true, alertActionButton);
		actions.waitForPageToLoad(3000);

		if (alertActionButton.equals(AlertPopupButton.OK_BUTTON)) {
			strOperation = "'Cancel'";

			/** Verify that new blank row is removed */
			System.out.println("> Verify that new blank row is removed");

			int intNewRowCount = mcd.GetTableRowCount(strTableElement);
			System.out.println("New Rows : " + intNewRowCount);

			if (intCurrRowCount == intNewRowCount) {
				blnResult = false;
				strResult = "New row is not removed";
			} else if (intCurrRowCount > intNewRowCount) {
				blnResult = true;
				strResult = "New row is removed, as expected";
			} else if (intCurrRowCount < intNewRowCount) {
				blnResult = false;
				strResult = "Unexpected new row is got added";
			}

		} else if (alertActionButton.equals(AlertPopupButton.CANCEL_BUTTON)) {
			strOperation = "Cancellation of 'Cancel'";

			/** Verify that new blank row is NOT removed */
			System.out.println("> Verify that new blank row is NOT removed");

			int intNewRowCount = mcd.GetTableRowCount(strTableElement);
			System.out.println("New Rows : " + intNewRowCount);

			if (intCurrRowCount == intNewRowCount) {
				blnResult = true;
				strResult = "New row is not removed, as expected";
			} else if (intCurrRowCount > intNewRowCount) {
				blnResult = false;
				strResult = "New row is removed";
			} else if (intCurrRowCount < intNewRowCount) {
				blnResult = false;
				strResult = "Unexpected new row is got added";
			}

			/** Verify new-row data */
			boolean blnRowData = mcd.VerifyTableColumnValues(strTableElement, intCurrRowCount, "Code|Description", strCode + "|" + strDescription, "input|input", "value|value", true);
			if (!blnRowData) {
				blnResult = false;
				strResult = strResult + ". However, existing data in the new-row was modified after cancellation of 'Cancel' operation";
			}
		}

		if (blnResult) {
			strResult = strOperation + " operation is performed as expected";
		} else {
			strResult = strOperation + " operation failed :: " + strResult;
		}
		System.out.println(strResult);
	}

	public boolean NewSubstitutionName_SaveInvalid(String strSaveErrMsgBlankCode, String strSaveErrMsgBlankDesc, String strSaveErrMsgDuplCode, String strSaveErrMsgDuplDesc) throws Exception {
		boolean blnReturn = true;
		String strMessageType = "Error-popup";

		/** Elements in action */
		String strTableElement = "RFMSubstitutionNames.SubstitutionTable";
		String strSubstitutionSaveButton = "RFMSubstitutionNames.SaveButton";

		/** Read Existing Values for Code and Description */
		int intRowNumber = mcd.GetTableRowCount(strTableElement);
		String strExCode = mcd.GetTableCellValue(strTableElement, intRowNumber - 1, "Code", "input", "value");
		String strExDescription = mcd.GetTableCellValue(strTableElement, intRowNumber - 1, "Description", "input", "value");
		String strNewCode = String.valueOf((Integer.valueOf(strExCode) + 1));

		/** Blank Code and Blank Description */
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Code", " ", "input", "value");
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Description", " ", "input", "value");

		actions.click(strSubstitutionSaveButton);
		mcd.VerifyAlertMessageDisplayed(strMessageType, strSaveErrMsgBlankCode, true, AlertPopupButton.OK_BUTTON);

		/** Duplicate Code and Blank Description */
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Code", strExCode, "input", "value");
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Description", " ", "input", "value");

		actions.click(strSubstitutionSaveButton);
		mcd.VerifyAlertMessageDisplayed(strMessageType, strSaveErrMsgBlankDesc, true, AlertPopupButton.OK_BUTTON);

		/** Duplicate Code and Duplicate Description */
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Code", strExCode, "input", "value");
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Description", strExDescription, "input", "value");

		actions.click(strSubstitutionSaveButton);
		mcd.VerifyAlertMessageDisplayed(strMessageType, strSaveErrMsgDuplCode, true, AlertPopupButton.OK_BUTTON);

		/** Valid Code and Duplicate Description */
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Code", strNewCode, "input", "value");
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Description", strExDescription, "input", "value");

		actions.click(strSubstitutionSaveButton);
		mcd.VerifyAlertMessageDisplayed(strMessageType, strSaveErrMsgDuplDesc, true, AlertPopupButton.OK_BUTTON);

		/** Create New Substitution Name - Valid Code and Valid Description */
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Code", strNewCode, "input", "value");
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Description", strExDescription + "_Auto", "input", "value");

		actions.click(strSubstitutionSaveButton);

		/** Verify on-screen message displayed */
		System.out.println("Verify on-screen message displayed");
		mcd.VerifyOnscreenMessage("RFMSubstitutionNames.OnScreenMessage", "Your changes have been saved", false);

		return blnReturn;
	}

	// ============================================================================= Menu Items > Grill Groups
	public void NewGrillGroups_Click() {
		boolean blnResult = false;
		String strResult = "";

		// Elements in action
		String strTableElement = "RFMGrillGroups.GrillGroupTable";
		String strNewSubstitutionButton = "RFMGrillGroups.NewGrillGroup";

		// Get current row count
		int intCurrRowCount = mcd.GetTableRowCount(strTableElement);

		// Click 'New Substitution Name' button
		System.out.println("> Click 'New Grill-Group Name' button");
		actions.click(strNewSubstitutionButton);

		// Verify that new blank row is added
		int intNewRowCount = mcd.GetTableRowCount(strTableElement);
		System.out.println("New Rows : " + intNewRowCount);

		// Verify that new blank row is added
		System.out.println("> Verify that new blank row is added");
		if (intNewRowCount - intCurrRowCount == 1) {
			blnResult = mcd.VerifyTableColumnValues(strTableElement, intNewRowCount, "Code|Description", " | ", "input|input", "value|value", true);
			strResult = "New row added is not blank";
		} else {
			strResult = "New row is not added";
		}

		if (blnResult) {
			strResult = "New blank-row is added, as expected";
		} else {
			strResult = "Failed :: " + strResult;
		}

		System.out.println(strResult);
	}

	/**
	 * Click 'Cancel' button and verify the confirmation pop-up message displayed. Click 'alertActionButton' on pop-up and verify that new row is removed when
	 * 'OK' button clicked
	 * 
	 * @param strExptMessage : Expected message
	 * @param alertActionButton : Button to be clicked after message verification
	 */

	public void NewGrillGroupName_Cancel(String strExptMessage, AlertPopupButton alertActionButton) {
		boolean blnResult = false;
		String strResult = "";
		String strOperation = "";

		/** Elements in action */
		String strTableElement = "RFMGrillGroups.GrillGroupTable";
		String strSubstitutionCancelButton = "RFMGrillGroups.CancelButton";

		/** Get current row count */
		int intCurrRowCount = mcd.GetTableRowCount(strTableElement);
		System.out.println("Current Rows : " + intCurrRowCount);

		/** Get current new-row data */
		String strCode = " " + mcd.GetTableCellValue(strTableElement, intCurrRowCount, "Code", "input", "value");
		String strDescription = " " + mcd.GetTableCellValue(strTableElement, intCurrRowCount, "Description", "input", "value");

		/** Click 'Cancel' button */
		System.out.println("> Click 'Cancel' button");
		actions.click(strSubstitutionCancelButton);

		/** Verify confirmation popup message */
		String strMessageType = "Confirmation-popup";
		mcd.VerifyAlertMessageDisplayed(strMessageType, strExptMessage, true, alertActionButton);

		if (alertActionButton.equals(AlertPopupButton.OK_BUTTON)) {
			strOperation = "'Cancel'";

			/** Verify that new blank row is removed */
			System.out.println("> Verify that new blank row is removed");

			int intNewRowCount = mcd.GetTableRowCount(strTableElement);
			System.out.println("New Rows : " + intNewRowCount);

			if (intCurrRowCount == intNewRowCount) {
				blnResult = false;
				strResult = "New row is not removed";
			} else if (intCurrRowCount > intNewRowCount) {
				blnResult = true;
				strResult = "New row is removed, as expected";
			} else if (intCurrRowCount < intNewRowCount) {
				blnResult = false;
				strResult = "Unexpected new row is got added";
			}

		} else if (alertActionButton.equals(AlertPopupButton.CANCEL_BUTTON)) {
			strOperation = "Cancellation of 'Cancel'";

			/** Verify that new blank row is NOT removed */
			System.out.println("> Verify that new blank row is NOT removed");

			int intNewRowCount = mcd.GetTableRowCount(strTableElement);
			System.out.println("New Rows : " + intNewRowCount);

			if (intCurrRowCount == intNewRowCount) {
				blnResult = true;
				strResult = "New row is not removed, as expected";
			} else if (intCurrRowCount > intNewRowCount) {
				blnResult = false;
				strResult = "New row is removed";
			} else if (intCurrRowCount < intNewRowCount) {
				blnResult = false;
				strResult = "Unexpected new row is got added";
			}

			/** Verify new-row data */
			boolean blnRowData = mcd.VerifyTableColumnValues(strTableElement, intCurrRowCount, "Code|Description", strCode + "|" + strDescription, "input|input", "value|value", true);
			if (!blnRowData) {
				blnResult = false;
				strResult = strResult + ". However, existing data in the new-row was modified after cancellation of 'Cancel' operation";
			}
		}

		if (blnResult) {
			strResult = strOperation + " operation is performed as expected";
		} else {
			strResult = strOperation + " operation failed :: " + strResult;
		}
		System.out.println(strResult);
	}

	public boolean NewGrillGroupName_SaveInvalid(String strSaveErrMsgBlankCode, String strSaveErrMsgBlankDesc, String strSaveErrMsgDuplCode, String strSaveErrMsgDuplDesc) {
		boolean blnReturn = true;
		String strMessageType = "Error-popup";

		/** Elements in action */
		String strTableElement = "RFMGrillGroups.GrillGroupTable";
		String strSubstitutionSaveButton = "RFMGrillGroups.SaveButton";

		/** Read Existing Values for Code and Description */
		int intRowNumber = mcd.GetTableRowCount(strTableElement);
		String strExCode = mcd.GetTableCellValue(strTableElement, intRowNumber - 1, "Code", "input", "value");
		String strExDescription = mcd.GetTableCellValue(strTableElement, intRowNumber - 1, "Description", "input", "value");
		String strNewCode = String.valueOf((Integer.valueOf(strExCode) + 1));

		/** Blank Code and Blank Description */
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Code", " ", "input", "value");
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Description", " ", "input", "value");

		actions.click(strSubstitutionSaveButton);
		mcd.VerifyAlertMessageDisplayed(strMessageType, strSaveErrMsgBlankCode, true, AlertPopupButton.OK_BUTTON);

		/** Duplicate Code and Blank Description */
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Code", strExCode, "input", "value");
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Description", " ", "input", "value");

		actions.click(strSubstitutionSaveButton);
		mcd.VerifyAlertMessageDisplayed(strMessageType, strSaveErrMsgBlankDesc, true, AlertPopupButton.OK_BUTTON);

		/** Duplicate Code and Duplicate Description */
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Code", strExCode, "input", "value");
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Description", strExDescription, "input", "value");

		actions.click(strSubstitutionSaveButton);
		mcd.VerifyAlertMessageDisplayed(strMessageType, strSaveErrMsgDuplCode, true, AlertPopupButton.OK_BUTTON);

		/** Valid Code and Duplicate Description */
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Code", strNewCode, "input", "value");
		mcd.SetTableCellValue(strTableElement, intRowNumber, "Description", strExDescription, "input", "value");

		actions.click(strSubstitutionSaveButton);
		mcd.VerifyAlertMessageDisplayed(strMessageType, strSaveErrMsgDuplDesc, true, AlertPopupButton.OK_BUTTON);

		return blnReturn;
	}
	// ==============DropDown

	public void DropDown1(String sElementName, String strOptionDropDown) {
		try {
			List<WebElement> dropdown = driver.findElements(By.xpath(".//select"));
			for (int i = 0; i < dropdown.size(); i++) {
				WebElement selected_dropdown = dropdown.get(i).findElement(By.xpath(actions.getLocator(sElementName)));
				List<WebElement> options_dropdown = selected_dropdown.findElements(By.tagName("option"));
				for (int j = 0; j < options_dropdown.size(); j++) {
					if (options_dropdown.get(j).getText().equals(strOptionDropDown)) {
						options_dropdown.get(j).click();
						return;
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// =====================
	public void DropDown2(String sElementName, String strOptionDropDown) {

		Select select = new Select(driver.findElement(By.xpath(actions.getLocator(sElementName))));
		select.selectByVisibleText(strOptionDropDown);

	}

	// Random email address function
	public void Randomemailaddress(String sElementName, String sStartwith) {
		long Random = Math.round(Math.random() * 1357);
		String Randomemailaddress = sStartwith + Random + "@domain.com";
		driver.findElement(By.xpath(actions.getLocator(sElementName))).sendKeys(Randomemailaddress);
	}

	public void Select_SearchOption(String strOptionLabel, List<String> lstOptionList, String strOption) {
		try {
			WebElement eleSearchOption = null;
			WebElement eleOption = null;
			String strLayoutType = "";
			List<WebElement> eleOptionList = null;
			String strInputID = "";

			try {
				eleSearchOption = actions.getwebDriverLocator("//td[@class='SmallHeading'][contains(text(),'" + strOptionLabel + "')]");
				strLayoutType = "Type_0";

				if (eleSearchOption == null) {
					eleSearchOption = actions.getwebDriverLocator("//td[@class='smallHeading']/span[contains(text(),'" + strOptionLabel + "')]/parent::td");
					strLayoutType = "Type_1";
				}
			} catch (Exception e) {
				System.out.println("Error :: " + e.toString());
			}

			if (lstOptionList.size() > 0) {
				int eleIndex = lstOptionList.indexOf(strOption) + 1;
				eleOption = eleSearchOption.findElement(By.xpath("./input[" + eleIndex + "]"));

			} else {
				switch (strLayoutType) {
				case "Type_0":
					eleOptionList = eleSearchOption.findElements(By.xpath("./label"));
					break;

				case "Type_1":
					eleOptionList = eleSearchOption.findElements(By.xpath("./input"));
					break;
				}

				for (int i = 0; i < eleOptionList.size(); i++) {
					eleOption = eleOptionList.get(i);

					if (eleOption.getText().equalsIgnoreCase(strOption)) {
						strInputID = eleOption.getAttribute("for");
						eleOption = eleSearchOption.findElement(By.id(strInputID));
						break;
					}
				}
			}

			if (eleOption == null) {
				System.out.println("Search-Option '" + strOption + "' in not available");

			} else {
				eleOption.click();
				System.out.println("Search-Option '" + strOption + "' selected successfully");
			}
		} catch (Exception e) {
			System.out.println("Failed to select Search-Option - '" + strOption + "'");
		}
	}

	public void Select_SearchByOption(List<String> lstOptionList, String string) {
		// TODO Auto-generated method stub

	}

	public boolean Select_SearchText(String strValue) throws Exception {
		boolean blnReturn = false;
		actions.setValue("RestaurantMenuItemList.SelectSearchText", strValue);
		Thread.sleep(1000);

		// actions.javaScriptClick("RestaurantMenuItemList.SelectSearchButton");
		// Thread.sleep(1000);
		// actions.waitForPageToLoad(100);

		System.out.println("> Verify that 'record is found'"); 		// i.e. 'No search record found' message is not displayed
		Alert popup = driver.switchTo().alert();
		if (popup == null) {
			blnReturn = true;
			System.out.println("Record found successfully");
		} else {
			blnReturn = false;
			popup.accept();
			System.out.println("No search record found for value '" + strValue + "'");
			// Reporter.log("No search record found for value '" + strValue + "'");
		}
		return blnReturn;
	}

	public void Select_SearchWithIn(String strOptionName, String strOptionElementId, String strValue) {
		WebElement eleSearchWithin, eleSearchDropDown;

		eleSearchWithin = actions.getwebDriverLocator("//td[@class='SmallHeading'][contains(text(),'Search within')]/span[contains(text(),'" + strOptionName + "')]/parent::td");

		eleSearchDropDown = eleSearchWithin.findElement(By.id(strOptionElementId));
		SelectDropdownOption(eleSearchDropDown, strValue);
	}

	public void SelectDropdownOption(String strElement, String strValue) throws InterruptedException {
		WebElement eleDropdown = actions.getwebDriverLocator(actions.getLocator(strElement));
		eleDropdown.click();
		Thread.sleep(1000);

		List<WebElement> eleOptionList = eleDropdown.findElements(By.tagName("option"));

		for (int i = 0; i < eleOptionList.size(); i++) {
			if (eleOptionList.get(i).getText().equalsIgnoreCase(strValue)) {
				eleOptionList.get(i).click();
			}
		}
	}

	public void SelectDropdownOption(WebElement eleDropdown, String strValue) {
		List<WebElement> eleOptionList = eleDropdown.findElements(By.tagName("option"));
		for (int i = 0; i < eleOptionList.size(); i++) {
			if (eleOptionList.get(i).getText().equalsIgnoreCase(strValue)) {
				eleOptionList.get(i).click();
				break;
			}
		}
	}

	public void Select_TreeNode(String strElementName, String strNodePath) {
		String[] arrNodePath = strNodePath.split(">");
		List<WebElement> eleSpan;
		WebElement eleLabel;

		WebElement eleTree = driver.findElement(By.xpath(actions.getLocator(strElementName)));
		WebElement eleCurrNode = eleTree;
		for (int i = 0; i < arrNodePath.length - 1; i++) {
			eleCurrNode = eleCurrNode.findElement(By.xpath(".//tr[@name='" + arrNodePath[i].trim() + "']"));

			// Check whether 'the node' needs to be expanded
			eleSpan = eleCurrNode.findElements(By.xpath("./td/span"));
			for (int s = 0; s < eleSpan.size(); s++) {
				if (eleSpan.get(s).getAttribute("class").equalsIgnoreCase("plusClosed")) {
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", eleSpan.get(s));

					break;
				}
			}
		}
		eleLabel = eleCurrNode.findElement(By.xpath(".//label[contains(text(), '" + arrNodePath[arrNodePath.length - 1].trim() + "')]"));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", eleLabel);
	}

	/**
	 * Function : Returns data node/element from a hierarchical data structure/table. Parameter : strElementName : Locator for the table : strNodePath :
	 * Hierarchy for the element (separated by ">")
	 * 
	 * @param strElementName
	 * @param strNodePath Example : In Admin > Roles : To view/update roles, we need to navigate through modules. The modules have a hierarchical structure.
	 * Example : PRICING > Price Sets > Future Changes By Menu Item This function returns this web element, using which we can read/update the roles.
	 */

	public WebElement Get_DataElement(String strElementName, String strNodePath) {
		WebElement eleDataElement = null;
		String[] arrNodePath = strNodePath.split(">");
		List<WebElement> eleSpan;
		WebElement eleLabel;

		WebElement eleTree = driver.findElement(By.xpath(actions.getLocator(strElementName)));
		WebElement eleCurrNode = eleTree;

		for (int i = 0; i < arrNodePath.length; i++) {
			if (i < arrNodePath.length - 1) {
				try {
					eleCurrNode = eleCurrNode.findElement(By.xpath(".//b[contains(text(), '" + arrNodePath[i].trim() + "')]/..//*[contains(@src, 'plus')]/../b"));
				} catch (Exception e) {
					try {
						eleCurrNode = eleCurrNode.findElement(By.xpath(".//td[contains(text(), '" + arrNodePath[i].trim() + "')]/..//*[contains(@src, 'plus')]/../b"));
					} catch (Exception e2) {
						try {
							eleCurrNode = eleCurrNode.findElement(By.xpath(".//b[contains(text(), '" + arrNodePath[i].trim() + "')]/..//*[contains(@src, 'minus')]/../b"));
						} catch (Exception e3) {
							try {
								eleCurrNode = eleCurrNode.findElement(By.xpath(".//td[contains(text(), '" + arrNodePath[i].trim() + "')]/..//*[contains(@src, 'minus')]/../b"));
							} catch (Exception e4) {
								try {
									eleCurrNode = eleCurrNode.findElement(By.xpath(".//../../following-sibling::tr[1]/.//b[contains(text(), '" + arrNodePath[i].trim() + "')]/..//*[contains(@src, 'minus')]/../b"));
								} catch (Exception e5) {
									eleCurrNode = eleCurrNode.findElement(By.xpath(".//../../following-sibling::tr[1]/.//td[contains(text(), '" + arrNodePath[i].trim() + "')]/..//*[contains(@src, 'minus')]/../b"));
								}
							}
						}
					}
				}

			} else {
				try {
					eleCurrNode = eleCurrNode.findElement(By.xpath("../../following-sibling::tr[1]//b[contains(text(), '" + arrNodePath[i].trim() + "')]"));
				} catch (Exception e1) {
					try {
						eleCurrNode = eleCurrNode.findElement(By.xpath("../../following-sibling::tr[1]//td[contains(text(), '" + arrNodePath[i].trim() + "')]"));
					} catch (Exception e2) {
						try {
							eleCurrNode = eleCurrNode.findElement(By.xpath(".//b[contains(text(), '" + arrNodePath[i].trim() + "')]"));
						} catch (Exception e3) {
							eleCurrNode = eleCurrNode.findElement(By.xpath(".//td[contains(text(), '" + arrNodePath[i].trim() + "')]"));
						}
					}
				}
			}

			// }catch (Exception e){
			// try{
			// eleCurrNode = eleCurrNode.findElement(By.xpath(".//td[contains(text(), '" + arrNodePath[i].trim() + "')]"));
			// }catch (Exception e1){
			// try{
			// eleCurrNode = eleCurrNode.findElement(By.xpath(".//../../.././/b[contains(text(), '" + arrNodePath[i].trim() + "')]"));
			// }catch (Exception e2){
			// eleCurrNode = eleCurrNode.findElement(By.xpath(".//../../.././/td[contains(text(), '" + arrNodePath[i].trim() + "')]"));
			// }

			// Check whether 'the node' needs to be expanded
			// eleSpan = eleCurrNode.findElements(By.xpath("../img[contains(@src, 'plus')]"));

			eleSpan = eleCurrNode.findElements(By.xpath("../img"));
			for (int s = 0; s < eleSpan.size(); s++) {
				if (eleSpan.get(s).getAttribute("src").contains("plus")) {
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", eleSpan.get(s));
					if (i != arrNodePath.length - 1) {
						eleCurrNode = eleCurrNode.findElement(By.xpath("../../following-sibling::tr"));
					}
					break;
				}
			}
		}
		System.out.println(eleCurrNode.getTagName());
		if (eleCurrNode.getTagName().equals("b")) {
			eleDataElement = eleCurrNode.findElement(By.xpath("../.."));
		} else if (eleCurrNode.getTagName().equals("tr")) {
			eleDataElement = eleCurrNode;
		} else {
			eleDataElement = eleCurrNode.findElement(By.xpath(".."));
		}
		return eleDataElement;
	}

	public WebElement Get_TreeDataElement(String strElementName, String strNodePath) {
		WebElement eleDataElement = null;
		String[] arrNodePath = strNodePath.split(">");
		WebElement eleSpan;
		WebElement eleLabel;

		WebElement eleTree = driver.findElement(By.xpath(actions.getLocator(strElementName)));
		WebElement eleCurrNode = eleTree;

		for (int i = 0; i < arrNodePath.length; i++) {
			try {
				// Get 'tr' tag for the node-element
				try {
					eleCurrNode = eleCurrNode.findElement(By.xpath(".//b[normalize-space(translate(text(), ':', ' ')) = '" + arrNodePath[i].trim() + "']/../.."));
				} catch (Exception e) {
					eleCurrNode = eleCurrNode.findElement(By.xpath(".//td[normalize-space(translate(text(), ':', ' ')) = '" + arrNodePath[i].trim() + "']/.."));
				}
				try {
					// Check for 'img' tag
					eleSpan = eleCurrNode.findElement(By.xpath(".//img"));

					// 'img' tag is present. Now check for 'plus' image... if found, click it
					if (eleSpan.getAttribute("src").contains("plus")) {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", eleSpan);

						JavascriptExecutor executor = (JavascriptExecutor) driver;
						executor.executeScript("arguments[0].click();", eleSpan);
					}

					// Get immediate sibling 'tr' node
					eleCurrNode = eleCurrNode.findElement(By.xpath("following-sibling::tr[1]"));

				} catch (Exception e) {
					// 'img tab is not found.... No problem, this must be field level node...
					// ignore it (do nothing)
				}

				eleDataElement = eleCurrNode;

			} catch (Exception e) {
				System.out.println("Failed to get node '" + arrNodePath[i].trim() + "'");
				eleDataElement = null;
			}
		}

		return eleDataElement;
	}

	/* This Function Creates Set of the Features
	 * 
	 * @Param : strAddNewSetName -> Feature set Name ,strrestlocator -> object repository name ,strrest - Restaurnat name
	 * 
	 * @return :String - > Feature set name
	 * 
	 * @Author :Priyanka */
	public String fn_CreateFeaturSet(String strAddNewSetName, String strrestlocator, String strrest, String strCopyExisting) {
		String strFeatureSetName = "";
		try {

			/** Click on New Set **/
			// Create Xpath
			String strXPath = "";
			strXPath = "//*[@class='button'][contains(text()," + "'" + strAddNewSetName + "')]";
			WebElement addNewSetButton = driver.findElement(By.xpath(strXPath));
			if (addNewSetButton != null) {
				actions.click(addNewSetButton);
			}

			/** -------Switch window to Add New Day Part Set---- **/
			// 21/8/2016------------------------------
			String strNewWindowName = "Add " + strAddNewSetName;
			// mcd.SwitchToWindow("Add New Coupon Set");
			mcd.SwitchToWindow(strNewWindowName);

			/** Set Value of Day part Set name and select name **/
			strFeatureSetName = mcd.GetTestData("DT_PREFIX") + "_" + RandomStringUtils.randomAlphabetic(5);
			actions.setValue("RFMAddNewSet.SetName", strFeatureSetName);
			actions.click("RFMAddNewSet.SelectBtn");

			// Select Hierarchy from select window
			mcd.SwitchToWindow("Select Node");

			mcd.Selectrestnode(strrestlocator, strrest);

			/** switching to new window */
			// 21/8/2016-------
			// mcd.SwitchToWindow("$Add New Coupon Set");
			mcd.SwitchToWindow("$" + strNewWindowName);

			/** Select Copy Existing **/
			if (strCopyExisting.equalsIgnoreCase("No")) {
				/** Click on Next **/
				actions.click("RFMAddNewSet.NextBtn");
				actions.waitForPageToLoad(180);
				// 21/8/2016-------
				// mcd.SwitchToWindow("Manage Coupon Set");
			}
		} catch (Exception e) {
			System.out.println("Failed Test" + e.getMessage());
		}

		return strFeatureSetName;
	}

	/* This Function Creates Set of the business
	 * 
	 * @Param : strAddNewSetName -> business set Name ,strrestlocator -> object repository name ,strrest - Restaurnat name
	 * 
	 * @return :String - > business set name
	 * 
	 * @Author :Priyanka */
	public String fn_BusinessLimitSet(String strAddNewSetName, String strrestlocator, String strrest, String strCopyExisting) {
		String strFeatureSetName = "";
		try {

			/** Click on New Set **/
			// Create Xpath
			String strXPath = "";
			strXPath = "//*[@class='button'][contains(text()," + "'" + strAddNewSetName + "')]";
			WebElement addNewSetButton = driver.findElement(By.xpath(strXPath));
			if (addNewSetButton != null) {
				actions.click(addNewSetButton);
			}

			/** -------Switch window to Add New Day Part Set---- **/
			mcd.SwitchToWindow("Add New Business Limit Set");

			/** Set Value of Day part Set name and select name **/
			strFeatureSetName = mcd.GetTestData("DT_PREFIX") + "_" + RandomStringUtils.randomAlphabetic(5);
			actions.setValue("RFMAddNewSet.SetName", strFeatureSetName);
			actions.click("RFMAddNewSet.SelectBtn");

			// Select Hierarchy from select window
			mcd.SwitchToWindow("Select Node");

			mcd.Selectrestnode(strrestlocator, strrest);

			/** switching to new window */
			mcd.SwitchToWindow("$Add New Business Limit Set");

			/** Select Copy Existing **/
			if (strCopyExisting.equalsIgnoreCase("No")) {
				/** Click on Next **/
				actions.click("RFMAddNewSet.NextBtn");
				actions.waitForPageToLoad(180);
				mcd.SwitchToWindow("@Manage Business Limits Set");
			}
		} catch (Exception e) {
			System.out.println("Failed Test" + e.getMessage());
		}

		return strFeatureSetName;
	}

	/* This Function Creates Set of the localizatrion
	 * 
	 * @Param : strAddNewSetName -> Feature set Name ,strrestlocator -> object repository name ,strrest - Restaurnat name
	 * 
	 * @return :String - > Feature set name
	 * 
	 * @Author :Priyanka */
	public String fn_localizationSet(String strAddNewSetName, String strrestlocator, String strrest, String strCopyExisting) {
		String strFeatureSetName = "";
		try {

			/** Click on New Set **/
			// Create Xpath
			String strXPath = "";
			strXPath = "//*[@class='button'][contains(text()," + "'" + strAddNewSetName + "')]";
			WebElement addNewSetButton = driver.findElement(By.xpath(strXPath));
			if (addNewSetButton != null) {
				actions.click(addNewSetButton);
			}

			/** -------Switch window to Add New Day Part Set---- **/
			mcd.SwitchToWindow("Add New Localization Set");

			/** Set Value of Day part Set name and select name **/
			strFeatureSetName = mcd.GetTestData("DT_PREFIX") + "_" + RandomStringUtils.randomAlphabetic(5);
			actions.setValue("RFMAddNewSet.SetName", strFeatureSetName);
			actions.click("RFMAddNewSet.SelectBtn");

			// Select Hierarchy from select window
			mcd.SwitchToWindow("Select Node");

			mcd.Selectrestnode(strrestlocator, strrest);

			/** switching to new window */
			mcd.SwitchToWindow("Add New Localization Set");

			/** Select Copy Existing **/
			if (strCopyExisting.equalsIgnoreCase("No")) {

				/** Click on Next **/
				actions.click("RFMAddNewSet.NextBtn");
				Thread.sleep(2000);
				actions.waitForPageToLoad(180);
				mcd.SwitchToWindow("@Manage Localization Set");
			}
		} catch (Exception e) {
			System.out.println("Failed Test" + e.getMessage());
		}

		return strFeatureSetName;
	}

	/**   */
	public String fn_CreateSet(String strAddNewSetName, String strrestlocator, String strrest, String strCopyExisting, String WindowName, String PopWinName) {
		String strFeatureSetName = "";
		try {

			/** Click on New Set **/
			// Create Xpath
			String strXPath = "";
			strXPath = "//*[@class='button'][contains(text()," + "'" + strAddNewSetName + "')]";
			WebElement addNewSetButton = driver.findElement(By.xpath(strXPath));
			if (addNewSetButton != null) {
				actions.click(addNewSetButton);
			}

			/** -------Switch window to Add New Day Part Set---- **/
			mcd.SwitchToWindow(PopWinName);

			/** Set Value of Day part Set name and select name **/
			strFeatureSetName = mcd.GetTestData("DT_PREFIX") + "_" + RandomStringUtils.randomAlphabetic(5);
			actions.setValue("RFMAddNewSet.SetName", strFeatureSetName);
			actions.click("RFM.SBSelectNode");

			// Select Hierarchy from select window
			mcd.SwitchToWindow("Select Node");

			// mcd.Selectrestnode(strrestlocator, strrest);
			mcd.Selectrestnode_JavaScriptClk(strrestlocator, strrest);

			/** switching to new window */
			// mcd.SwitchToWindow("$"+PopWinName);
			mcd.SwitchToWindow(PopWinName);

			/** Select Copy Existing **/
			if (strCopyExisting.equalsIgnoreCase("No")) {
				/** Click on Next **/
				actions.click("SelectNode.Next");
				mcd.waitAndSwitch("@" + WindowName);
			}
		} catch (Exception e) {
			System.out.println("Failed Test" + e.getMessage());
		}

		return strFeatureSetName;
	}

	/**
	 * "DT_PREFIX" - Pass 'Auto' any prefix "DT_COPYEXISTING" - Yes or No
	 */
	public String fn_CreateFeaturSet(String strAddNewSetName, String strrestlocator, String strrest, String strMainWindowName, String strDTPREFIX, String strCopy) {
		String strFeatureSetName = "";
		try {

			/** Click on New Set **/
			// Create Xpath
			String strXPath = "";
			strXPath = "//*[@class='button'][contains(text()," + "'" + strAddNewSetName + "')]";
			WebElement addNewSetButton = driver.findElement(By.xpath(strXPath));
			if (addNewSetButton != null) {
				actions.keyboardEnter(addNewSetButton);
//				addNewSetButton.click();
				Thread.sleep(8000);
			}

			/** -------Switch window to Add New Day Part Set---- **/
			mcd.SwitchToWindow("Add " + strAddNewSetName);

			/** Set Value of Day part Set name and select name **/

			// Get random string
			// String strPrefix =mcd.GetTestData("DT_PREFIX");
			strFeatureSetName = strDTPREFIX;
			Thread.sleep(2000);
			actions.setValue("RFMAddNewSet.SetName", strFeatureSetName);
			Thread.sleep(3000);
			actions.keyboardEnter("RFMAddNewSet.SelectBtn");
			Thread.sleep(8000);

			// Select Heriarchy from select window
			mcd.waitAndSwitch("Select Node");

			/* String eleSelectNode= actions.getLocator("RFMSelectNode.SelectNode"); WebElement selectNode = driver.findElement(By.xpath(eleSelectNode)); if
			 * (selectNode != null){ selectNode.click(); Thread.sleep(8000); } */

			Boolean blnSelect = mcd.Selectrestnode(strrestlocator, strrest);
			if (blnSelect == true) {
				actions.reportCreatePASS("Verify that Node is selected or not ", "Node Should get select ", "Node Selected successfully", "Pass");

			} else {
				actions.reportCreateFAIL("Verify that Node is selected or not ", "Node Should get select ", "Failed to select Node", "Fail");
			}
			// actions.click("RFMSelectNode.SelectNode");

			Thread.sleep(1000);
			mcd.waitAndSwitch("Add " + strAddNewSetName);

			/** Select Copy Existing **/
			SelectRadioCopyExisting(strCopy);

			if (strCopy.equalsIgnoreCase("No")) {
				/** Click on Next **/
				actions.click("RFMAddNewSet.NextBtn");
				Thread.sleep(3000);
				mcd.SwitchToWindow("@" + strMainWindowName);
			}
		} catch (Exception e) {
			Reporter.log("Failed Test" + e.getMessage());
		}

		return strFeatureSetName;
	}

	/* This Function Selects radio button
	 * 
	 * @Param : strCopy -> Yes / No
	 * 
	 * @return :Void
	 * 
	 * @Author :Priyanka */
	public void SelectRadioCopyExisting(String strCopy) {
		String strXPath;
		if (strCopy.equalsIgnoreCase("Yes")) {
			strXPath = "//*[@class='button'][@value='Yes']";
		} else {
			strXPath = "//*[@class='button'][@value='No']";
		}
		WebElement eleCopyFlag = driver.findElement(By.xpath(strXPath));
		if (eleCopyFlag != null) {
			eleCopyFlag.click();
		}
	}

	/* this function verify the presence of customize or reset to default button on page displayed and take action accordingly
	 * 
	 * @Param: strmsg->Are you sure you want to Reset the Default values
	 * 
	 * @Author: Neha MenuItemSets.Custbtn - */
	public void SelectCustOrResetButton(String strmsg, String strElemtlocator_Custbtn, String strElemtlocator_Resetbtn) {
		String str = "";
		try {
			if (mcd.fn_VerifyWebelementEnableDisable(strElemtlocator_Custbtn)) {
				// Reporter.log("customize setting button is displayed");
				System.out.println("customize setting button is displayed");
				actions.javaScriptClick(strElemtlocator_Custbtn);
				Thread.sleep(3000);
				actions.smartWait(180);
				// //Reporter.log("Clicked on Customize setting buttom");
				System.out.println("Clicked on Customize setting buttom");

			} else {
				// //Reporter.log("Reset to default button is displayed");
				System.out.println("Reset to default button is displayed");

				actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
				if(actions.isSafari()){
					actions.javaScriptClick(strElemtlocator_Resetbtn);
				}else{
					actions.keyboardEnter(strElemtlocator_Resetbtn);
				}
				// actions.javaScriptClick(strElemtlocator_Resetbtn);
				Thread.sleep(2000);
				// //Reporter.log("Clicked on Reset to default buttom");
				System.out.println("Clicked on Reset to default buttom");
				mcd.VerifyAlertMessageDisplayed("Warning", strmsg, false, AlertPopupButton.OK_BUTTON);
				Thread.sleep(3000);
				actions.smartWait(180);
				actions.javaScriptClick(strElemtlocator_Custbtn);
				// //Reporter.log("Clicked on Customize setting buttom");
				System.out.println("Clicked on Customize setting buttom");
			}
		} catch (Exception e) {
			// //Reporter.log("Failed Test"+e.getMessage());
		}
	}

	// ======================================================================================================== Audit-Log Verification

	/**
	 * Read value of 'ID' for the latest entry (first in the table) of operation 'strOperation
	 * 
	 * @param strOperation : Operation to verify
	 * @return
	 * @throws Exception
	 */
	public String GetAuditLogID(String strOperation) throws Exception {
		String strAuditLogID = "";
		try {
			/* // Navigate to Home page actions.select_menu("RFMHome.Navigation", "HOME");
			 * 
			 * //Selecting the Audit Log duration actions.WaitForElementPresent("RFMHomePage.AuditLogDuration", 120);
			 * 
			 * // Verify Page displayed mcd.VerifyPageTitle("RFM - Home");
			 * 
			 * //Selecting the Audit Log duration WebElement Element = driver.findElement(By.xpath(actions.getLocator("RFMHomePage.AuditLogDuration"))); Select
			 * select = new Select(Element); select.selectByVisibleText("Today");
			 * 
			 * 
			 * 
			 * actions.setValue("RFMHomePage.AuditLogDuration", "Today"); actions.WaitForElementPresent("RFMAuditLog.PPFirstRecord", 180); */
			// Read Audit Log ID
			strAuditLogID = mcd.GetTableCellValue("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a", "");

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return strAuditLogID;
	}

	/**
	 * Verify Activity and Level for the latest entry (first in the table) of operation 'strOperation'
	 * 
	 * @param strOperation : Operation to verify
	 * @param strExptActivityValue : Expected value of 'Activity'
	 * @param strExptLevelValue : Expected value of 'Level'
	 * @return
	 * @throws Exception
	 */
	public boolean VerifyAuditLog_Entry(String strOperation, String strExptActivityValue, String strExptLevelValue) throws Exception {
		boolean blnReturn = false;
		try {

			// Navigate to Home page
			actions.select_menu("RFMHome.Navigation", "HOME");
			actions.WaitForElementPresent("RFMHomePage.AuditLogDuration", 120);
			actions.waitForPageToLoad(120);

			// Verify Page displayed
			mcd.VerifyPageTitle("RFM - Home");

			// Selecting the Audit Log duration
			actions.setValue("RFMHomePage.AuditLogDuration", "Today");

			actions.WaitForElementPresent("RFMAuditLog.PPFirstRecord", 180);

			// Verify values
			blnReturn = mcd.VerifyTableColumnValues("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Activities|Level", strExptActivityValue + "|" + strExptLevelValue, "|", "|", false);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return blnReturn;
	}

	public boolean RFM_VerifyAuditLog_Details(String strDBName, String strUserID, String strOperation, String strActivity, String strLevel, String strNodeName, String strDescription) throws Exception {
		boolean blnReturn = true;
		try {

			/**
			 * commenting the code for navigation as it has already on the home page & to get the audit log we no longer need to navigate again
			 */
			/* // Navigate to Home page actions.select_menu("RFMHomePage.MainMenu", "HOME"); Thread.sleep(5000);
			 * actions.WaitForElementPresent("RFMHomePage.AuditLogDuration", 120); actions.waitForPageToLoad(130);
			 * 
			 * // Verify Page displayed mcd.VerifyPageTitle("RFM - Home"); */
			// Open Audit-Log details
			String AuditLogID = GetAuditLogID(strOperation);
			actions.keyboardEnter(mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a"));
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");

			/** Verify log details */
			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Id :", "", "", "#2", AuditLogID, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "DB Name :", "", "", "#2", strDBName, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "User :", "", "", "#4", strUserID, "", "", false);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Operation :", "", "", "#2", strOperation, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "Activity :", "", "", "#4", strActivity, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Level :", "", "", "#2", strLevel, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "Level Details :", "", "", "#4", strNodeName, "", "", false);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Description :", "", "", "#2", strDescription, "", "", true);

			/** Close Audit-Log window */
			actions.keyboardEnter("RFMHomePage.AuditLogDetailsOKButton");
			Thread.sleep(1000);
			// actions.windowSwitch(winHndManageAuditLog, "RFM - Home");
			mcd.SwitchToWindow("RFM - Home");

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return blnReturn;

	}

public boolean RFM_VerifyAuditLog_Details_Old_New_Setting(String strDBName, String strUserID, String strOperation,
			String strActivity, String strLevel, String strNodeName, String strDescription, String Field,
			String OldSettings, String NewSettings) throws Exception {
		boolean blnReturn = true;
		try {

			/**
			 * commenting the code for navigation as it has already on the home
			 * page & to get the audit log we no longer need to navigate again
			 */
			/*
			 * // Navigate to Home page
			 * actions.select_menu("RFMHomePage.MainMenu", "HOME");
			 * Thread.sleep(5000);
			 * actions.WaitForElementPresent("RFMHomePage.AuditLogDuration",
			 * 120); actions.waitForPageToLoad(130);
			 * 
			 * // Verify Page displayed mcd.VerifyPageTitle("RFM - Home");
			 */
			// Open Audit-Log details
			String AuditLogID = GetAuditLogID(strOperation);
			if (actions.isSafari()) {
				actions.javaScriptClick(
						mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a"));
			} else {
				mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations", strOperation, "", "", "Id", "a")
						.sendKeys(Keys.ENTER);
			}
			// mcd.GetTableCellElement("RFMHomePage.AuditLog", "Operations",
			// strOperation, "", "", "Id", "a");
			Thread.sleep(1000);
			mcd.waitAndSwitch("Manage Audit Log");

			/** Verify log details */
			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Id :", "", "",
					"#2", AuditLogID, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "DB Name :", "",
					"", "#2", strDBName, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "User :", "", "",
					"#4", strUserID, "", "", false);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Operation :", "",
					"", "#2", strOperation, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "Activity :", "",
					"", "#4", strActivity, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Level :", "", "",
					"#2", strLevel, "", "", true);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#3", "Level Details :",
					"", "", "#4", strNodeName, "", "", false);

			blnReturn = blnReturn && mcd.VerifyTableColumnValues("RFMHomePage.AuditLogDetails", "#1", "Description :",
					"", "", "#2", strDescription, "", "", false);

			String strField = mcd.GetTableCellValue("AdminHelp.Table", 1, "Field", "", "");
			String strOldSettings = mcd.GetTableCellValue("AdminHelp.Table", 1, "Old Settings", "", "");
			String strNewSettings = mcd.GetTableCellValue("AdminHelp.Table", 1, "New Settings", "", "");

			if (strField.contains(Field) && strOldSettings.contains(OldSettings)
					&& strNewSettings.contains(NewSettings)) {
				actions.reportCreatePASS("Verify updated Field, OldSettings and NewSettings value present in Audit Log",
						"Updated Field, OldSettings and NewSettings value should present in Audit Log.",
						"Updated Field " + strField + ", OldSettings " + strOldSettings + "and NewSettings "
								+ strNewSettings + " value is present in Audit Log.",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verify updated Field, OldSettings and NewSettings value present in Audit Log",
						"Updated Field, OldSettings and NewSettings value should present in Audit Log.",
						"Updated Field, OldSettings and NewSettings value is not present in Audit Log.", "Fail");
			}
			/** Close Audit-Log window */
			actions.keyboardEnter("RFMHomePage.AuditLogDetailsOKButton");
			Thread.sleep(1000);
			// actions.windowSwitch(winHndManageAuditLog, "RFM - Home");
			mcd.SwitchToWindow("RFM - Home");

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return blnReturn;

	}

	/**
	 * Function : To update a specific tag in the ADMIN > Update Settings module (For General Set only ) Parameter : strTagValue : Tag value to be set Example :
	 * True/False/0/1/2 etc. : strTagName1 : Name of the tag to be updated
	 */
	public void RFM_Admin_Update_PricingTags(String strTagValue, String strTagName1) throws InterruptedException {

		// Check for parameters :
		// General :
		// automatically-fill-price-type-attribute-option-price-value =
		// automatically-fill-price-type-attribute-option-tax-value =
		boolean blncountine = false;
		boolean flag = false;
		int cnt = 3;
		List<WebElement> Parameter_Lists = driver.findElements(By.xpath("//*[@id='ApplicationParameters']/tr/td[2]/b"));

		for (int i = 0; i < Parameter_Lists.size(); i++) {
			String curr_parameter = Parameter_Lists.get(i).getText();

			// Check whether section name is "General"
			if (curr_parameter.equals("General")) {
				/* Santosh 7thJuly2016: added the below try catch block, because earlier it is not validating whether that general setting is expanded or
				 * collapsed. */
				try {
					flag = driver.findElement(By.xpath("//*[@id='ApplicationParameters']/tr[" + cnt + "]/td[1]/img[contains(@src,'plus')]")).isDisplayed();
				} catch (Exception e) {
					flag = false;
				}
				if (flag) {
					driver.findElement(By.xpath("//*[@id='ApplicationParameters']/tr[" + cnt + "]/td[1]")).click();
				}
				Thread.sleep(1000);
				break;
			} else {
				cnt = cnt + 2;
			}
		}

		// Get row counts of parameters displayed
		int p_rows = mcd.GetTableRowCount("UpdateSettings.GeneralParamTbl");
		String tag = null;
		String curr_val = null;
		String new_val = null;
		int iTemp = 0;
		int tag_cnt = 0;
		Thread.sleep(1000);
		// Check for the mentioned 2 tags & check whether they are set to expected value
		for (int j = 1; j <= p_rows; j++) {
			tag = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[1]")).getText();
			Thread.sleep(1000);
			if (tag.equals(strTagName1)) {
				curr_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input")).getAttribute("value");

				if (curr_val.equalsIgnoreCase(strTagValue)) {
					// Reporter.log(tag+" - Tag value is already set to "+strTagValue);
					blncountine = true;
					System.out.println("blncountine value is true now ");
				} else {
					driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[3]/input")).sendKeys(strTagValue);
				}
				break;
			}

		}

		// Save the changes
		System.out.println(blncountine);
		Thread.sleep(1000);

		actions.click("UpdateSettings.SaveBtn");
		if (blncountine != false) {
			mcd.VerifyAlertMessageDisplayed("Warning Message", "No changes have been made", true, AlertPopupButton.OK_BUTTON);
		}
		Thread.sleep(2000);
		if (blncountine != true) {
			System.out.println("Verify text presesence - bln value is false");
			actions.verifyTextPresence("Your changes have been saved and cache is refreshed.", false);
		}
		// Verify tag values - whether changes are reflected correctly

		for (int j = 1; j <= p_rows; j++) {
			tag = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[1]")).getText();

			if (tag.equals(strTagName1)) {
				new_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input")).getAttribute("value");

				if (new_val.equalsIgnoreCase(strTagValue)) {
					// Reporter.log(tag+" - Tag value is correctly updated - PASS");
					System.out.println(tag + " - Tag value is correctly updated - PASS");
					// System.out.println("Tag 1 value correctly updated");
				} else {
					// Reporter.log(tag+" - Tag value is incorrectly updated - FAIL");
					System.out.println(tag + " - Tag value is incorrectly updated - FAIL");
				}
			}

		}
	}

	// =============
	public void RFM_VerifyFieldPermissions(String strFieldName, String strFieldPath) {

		// Get data from FieldPermissions.Table - required tr element
		WebElement eleData = Get_DataElement("FieldPermissions.TableData", strFieldPath);
		// int iNumOfCol = mcd.GetTableColumnCount("FieldPermissions.Table");
		List<WebElement> eRows = eleData.findElements(By.xpath("../../tbody/tr"));
		int iNumOfRows = eRows.size();

		String strActualField = null;
		int FldCheckCount = 0;

		// Get column numbers for coulmn names (Fields/Create/Update/Read Only/None
		for (int j = 0; j < iNumOfRows; j++) {
			strActualField = eRows.get(j).getText();
			strActualField = strActualField.split(":")[0].trim();
			System.out.println(strActualField);
			if (strFieldName.contains(strActualField)) {
				FldCheckCount++;
			} else {
				FldCheckCount = 0;
				break;
			}
		}

		if (FldCheckCount != 0) {
			actions.reportCreatePASS("Verify all Field permission fields are displayed", "All fields should be displayed", "All fields are displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify all Field permission fields are displayed", "All fields should be displayed", "All fields are not displayed", "FAIL");
		}

	}

	// ==================
	public WebElement Get_FieldPermissionFields(String strAccessType, String strFieldPath) {
		WebElement ele2 = null;
		try {

			WebElement eleData = Get_DataElement("FieldPermissions.TableData", strFieldPath);

			int reqdColNum = 0;

			// Get column numbers for coulmn names (Fields/Create/Update/Read Only/None
			reqdColNum = mcd.GetTableColumnNumber("FieldPermissions.HeaderTbl", strAccessType.trim());

			// Check whether the radio buttons for Create/Update/Read Only/None are displayed & enabled
			ele2 = eleData.findElement(By.xpath("./td[" + (reqdColNum - 1) + "]/input"));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return ele2;
	}

	// ==============
	// ============
	public boolean ISAttributePresent(WebElement elemlocator, String attribute) {
		boolean blnrslt = false;
		try {
			String is_present = elemlocator.getAttribute(attribute);
			if (is_present.equals("true")) {
				blnrslt = true;
			} else {
				blnrslt = false;

			}
		} catch (Exception e) {
			// Reporter.log(e.getMessage());
			blnrslt = false;
		}
		return blnrslt;
	}

	// =============

	public boolean Check_AttributePresent(WebElement elemlocator, String attribute) {
		boolean blnrslt = false;
		try {
			elemlocator.getAttribute(attribute);
			blnrslt = true;
		} catch (Exception e) {
			// Reporter.log(e.getMessage());
			blnrslt = false;
		}
		return blnrslt;
	}

	// ==========

	// =============

	public boolean Check_AttributePresent(String elemlocator, String attribute) {
		boolean blnrslt = false;
		try {

			String selemlocator = driver.findElement(By.xpath(actions.getLocator(elemlocator))).getAttribute(attribute);
			blnrslt = true;
		} catch (Exception e) {
			// Reporter.log(e.getMessage());
			blnrslt = false;
		}
		return blnrslt;
	}

	// ==========

	// ===================
	public void ViewGenerateReportDateSorting() throws InterruptedException {

		try {
			driver.findElement(By.xpath("//*[@id='sortReportName'][contains(text(),'Date / Time')]")).click();
			String strSortOrderValue = driver.findElement(By.xpath("//*[@id='sortReportName'][contains(text(),'Date / Time')]/img")).getAttribute("src");
			if (strSortOrderValue.contains("down")) {
				Thread.sleep(2000);
				strStatus = driver.findElement(By.xpath("//*[@class='whiteBox']/div/table/tbody/tr[1]/td[2]")).getText();
				strreportGneInPro();

			} else {
				Thread.sleep(5000);
				driver.findElement(By.xpath("//*[@id='sortReportName'][contains(text(),'Date / Time')]/img")).click();
				Thread.sleep(3000);
				strStatus = driver.findElement(By.xpath("//*[@class='whiteBox']/div/table/tbody/tr[1]/td[2]")).getText();
				strreportGneInPro();
			}
		} catch (Exception E) {
			strStatus = driver.findElement(By.xpath("//*[@class='whiteBox']/div/table/tbody/tr[1]/td[2]")).getText();

			if (strStatus.trim().equalsIgnoreCase("Generated")) {
				Thread.sleep(2000);
				actions.click("ViewGeneratedReports.FirstdataReportName");
			} else {
				Thread.sleep(8000);
				String strPageTitle1 = "View Generated Reports";
				String strNavigateToReport = "REPORTS > View Generated Reports";
				actions.select_menu(strPageTitle1, strNavigateToReport);
				Thread.sleep(1000);
				if (strStatus.trim().equalsIgnoreCase("Generated")) {
					Thread.sleep(3000);
					actions.click("ViewGeneratedReports.FirstdataReportName");
				} else {
					System.out.println("Status is in Process for latest file created");
				}
			}
		}
	}

	public void strreportGneInPro() throws InterruptedException {
		// strStatus = driver.findElement(By.xpath("//*[@class='whiteBox']/div/table/tbody/tr[1]/td[2]")).getText();
		if (strStatus.trim().equalsIgnoreCase("Generated")) {
			Thread.sleep(2000);
			actions.click("ViewGeneratedReports.FirstdataReportName");

		} else if (strStatus.trim().equalsIgnoreCase("In-Process")) {
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='sortReportName'][contains(text(),'Date / Time')]/img")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='sortReportName'][contains(text(),'Date / Time')]/img")).click();
			Thread.sleep(1000);
			String strSortOrderValue1 = driver.findElement(By.xpath("//*[@id='sortReportName'][contains(text(),'Date / Time')]/img")).getAttribute("src");
			if (strSortOrderValue1.contains("down")) {
				Thread.sleep(2000);
				strStatus = driver.findElement(By.xpath("//*[@class='whiteBox']/div/table/tbody/tr[1]/td[2]")).getText();
				if (strStatus.equals("Generated")) {
					Thread.sleep(2000);
					actions.click("ViewGeneratedReports.FirstdataReportName");
				} else {
					System.out.println("Status is in Process for latest file created");
				}
				System.out.println("Status is in Process for latest file created");
			}
		}
	}

	public void UpdateField(String eElementName, String strValues[]) {
		try {
			List<WebElement> POSSales = driver.findElements(By.xpath(actions.getLocator(eElementName)));
			int poscount = POSSales.size();
			String xpath = actions.getLocator(eElementName);
			for (int i = 1; i <= poscount; i++) {
				String PosValues = driver.findElement(By.xpath(xpath + "[" + i + "]/td[2]/input[1]")).getAttribute("value");
				System.out.println(PosValues);
				int lenPosValues = PosValues.length();
				System.out.println(lenPosValues);
				if (lenPosValues == 0) {
					driver.findElement(By.xpath(xpath + "[" + i + "]/td[2]/input[1]")).sendKeys(strValues[i]);

				} else {
					System.out.println("Textbox is not empty");
				}
			}
		} catch (Exception E) {
			System.out.println("Textbox is not empty");
		}
	}

	// ====
	// ==============
	public WebElement Get_UserRolesFields(String strAccessType, String strFieldPath) {
		WebElement ele2 = null;
		try {

			WebElement eleData = Get_DataElement("FieldPermissions.TableData", strFieldPath);

			int reqdColNum = 0;

			// Get column numbers for coulmn names (Fields/Create/Update/Read Only/None
			reqdColNum = mcd.GetTableColumnNumber("FieldPermissions.HeaderTbl", strAccessType.trim());

			// Check whether the radio buttons for Create/Update/Read Only/None are displayed & enabled
			try {
				ele2 = eleData.findElement(By.xpath("./td[" + (reqdColNum) + "]/input"));
			} catch (Exception er) {
				ele2 = eleData.findElement(By.xpath("./td[" + (reqdColNum) + "]/a"));
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return ele2;
	}

	// ===================================================================== Field Permissions

	// public boolean SetFieldPermissions (String strFPValNavigateTo, String strFPPageTitle, String strOperationPath, String[] arrFields, String strPermission,
	// boolean blnVerifyFields) throws Exception {
	public boolean SetFieldPermissions(String strOperationPath, String[] arrFields, String strPermission, boolean blnVerifyFields) throws Exception {
		boolean blnReturn = false;

		// /** Navigate to 'Field Permission' page */
		// System.out.println("> Navigate to :: " + strFPValNavigateTo);
		// actions.select_menu("RFMHomePage.MainMenu", strFPValNavigateTo);
		//
		// try {
		// Alert popup = driver.switchTo().alert();
		// popup.accept();
		// } catch (Exception e) {}
		//
		// /** Wait for page to load */
		// Thread.sleep(2000);
		// actions.waitForPageToLoad(120);
		// mcd.SwitchToWindow("#Title");
		//
		// /** Verify Page Title */
		// System.out.println("> Verify Page Title");
		// mcd.VerifyPageTitle(strFPPageTitle);

		/** Verify the Field permission fields (only for the first iteration) */
		if (blnVerifyFields) {
			if (!FP_VerifyFields(strOperationPath, arrFields)) {
				throw new Exception("Can not continue as one or more fileds are missing");
			}
		}

		/** Set Field Permission */
		for (int iFLD = 0; iFLD < arrFields.length; iFLD++) {
			String strFieldName = arrFields[iFLD].trim();
			FP_SetSpecificPermission(strOperationPath, strFieldName, strPermission);
		}

		/** Click 'Save' button */
		actions.click("FieldPermissions.SaveBtn");
		Thread.sleep(6000);

		/** Check if 'No changes done' popup message is displayed */
		try {
			Alert popup = driver.switchTo().alert();
			popup.accept();
		} catch (Exception e) {
			/** Verify on-screen message */
			actions.smartWait(120);
			mcd.VerifyOnscreenMessage("FieldPermissions.OnScreenMessage", "Your changes have been saved", false);
		}

		return blnReturn;
	}

	/**
	 * Verify that all the required fields are displayed
	 * 
	 * @param strOperationPath
	 * @param arrFields
	 * @return
	 */

	private boolean FP_VerifyFields(String strOperationPath, String[] arrFields) {
		boolean blnReturn = false;
		String strFields = "";
		String strExptField = "";
		String strMissingField = "";

		// Get 'tr' element for Operation
		WebElement eleOperation = Get_TreeDataElement("FieldPermissions.TableData", strOperationPath);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", eleOperation);

		// Get 'table' for Fields
		List<WebElement> eleFields = eleOperation.findElements(By.xpath(".//table//tr"));

		// Verify that ALL the required Fields are displayed
		for (int ExptIdx = 0; ExptIdx < arrFields.length; ExptIdx++) {
			strFields = strFields + ", " + arrFields[ExptIdx].trim();
			strExptField = arrFields[ExptIdx].trim();
			System.out.println("=========== Verify Field Name : " + strExptField);

			boolean blnFieldPresent = false;
			for (int ActIdx = 0; ActIdx < eleFields.size(); ActIdx++) {
				if (eleFields.get(ActIdx).getText().replace(":", "").trim().equals(strExptField)) {
					blnFieldPresent = true;
					break;
				}
			}
			if (!blnFieldPresent) strMissingField = strMissingField + strExptField + ",";
		}

		if (strMissingField.equals("")) {
			blnReturn = true;

			actions.reportCreatePASS("Verify required Field Permission fields", "Fields '" + strFields.replaceFirst(",", "").trim() + "' should be displayed", "All fields are displayed, as expected", "Pass");
		} else {
			blnReturn = false;
			strMissingField = strMissingField.substring(0, strMissingField.length() - 1);
			actions.reportCreateFAIL("Verify required Field Permission fields", "Fields '" + strFields.replaceFirst(",", "").trim() + "' should be displayed", "One or more fileds are NOT displayed - '" + strMissingField + "'", "Fail");
		}

		return blnReturn;
	}

	/**
	 * Set permission for the specified field from given operation
	 * 
	 * @param strOperationPath
	 * @param strFieldName
	 * @param strPermission
	 * @return
	 * @throws InterruptedException
	 */

	private boolean FP_SetSpecificPermission(String strOperationPath, String strFieldName, String strPermission) throws InterruptedException {
		final int COL_NUM_CREATE = 2;
		final int COL_NUM_UPDATE = 3;
		final int COL_NUM_READ_ONLY = 4;
		final int COL_NUM_NONE = 5;

		boolean blnReturn = true;
		int intColNum = -1;

		// Get 'tr' element for Operation
		WebElement eleOperation = Get_TreeDataElement("FieldPermissions.TableData", strOperationPath);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", eleOperation);

		// Get 'table' for Fields
		List<WebElement> eleFields = eleOperation.findElements(By.xpath(".//table//tr"));

		// Get column numbers for column names (Fields/Create/Update/Read Only/None
		switch (strPermission.toUpperCase()) {
		case "CREATE":
			intColNum = COL_NUM_CREATE;
			break;
		case "UPDATE":
			intColNum = COL_NUM_UPDATE;
			break;
		case "READ ONLY":
			intColNum = COL_NUM_READ_ONLY;
			break;
		case "NONE":
			intColNum = COL_NUM_NONE;
			break;
		}

		// Set the required Field Permission
		String strRptStep = "> Select '" + strPermission + "' permission for '" + strFieldName + "' field";
		String strRptExpected = "'" + strPermission + "' permission for '" + strFieldName + "' field should be selected";
		System.out.println("=========== Select '" + strPermission + "' permission for '" + strFieldName + "' field");

		boolean blnSetPermission = false;
		for (int idx = 0; idx < eleFields.size(); idx++) {
			blnSetPermission = false;
			if ((eleFields.get(idx).getText().replace(":", "").trim().equals(strFieldName))) {
				WebElement eleFieldPermission = eleFields.get(idx).findElement(By.xpath("./td[" + (intColNum) + "]/input"));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", eleFieldPermission);

				eleFieldPermission.click();
				Thread.sleep(1000);
				blnSetPermission = true;
				break;
			}
		}
		if (blnSetPermission) {
			actions.reportCreatePASS(strRptStep, strRptExpected, "Field permission selected", "Pass");
		} else {
			actions.reportCreateFAIL(strRptStep, strRptExpected, "Failed to select field permission", "Fail");
		}

		return blnReturn;
	}

	/**
	 * Validate Field Permissions
	 * 
	 * @param arrFields
	 * @param strFPValFieldDetails
	 * @param strCheckPermission
	 * @return
	 * @throws Exception
	 */
	public boolean ValidateFieldPermissions(String[] arrFields, String strFPValFieldDetails, String strCheckPermission) throws Exception {
		boolean blnReturn = false;
		String strFieldName = "", strFieldLocatorName = "";

		String strRptStep = "", strRptExpected = "", strRptActual = "", strRptStatus = "";

		try {
			/** Read Filed-Permission-Validation-Details and update the map */
			HashMap<String, String> mapFPValidation = new HashMap<>();
			String arrFPValFieldDetails[] = strFPValFieldDetails.split("#");
			for (int idx = 0; idx < arrFPValFieldDetails.length; idx++) {
				String arrFieldDetails[] = arrFPValFieldDetails[idx].split(":");
				String strKey = arrFieldDetails[0].trim().replace("  ", " ").replace("/", "_").replace(" ", "_");
				String strValue = arrFieldDetails[1].trim();
				mapFPValidation.put(strKey, strValue);
			}

			for (int idxFld = 0; idxFld < arrFields.length; idxFld++) {
				String strFieldFailed = "";

				strFieldName = arrFields[idxFld].trim();

				String strKey = strCheckPermission.toUpperCase().trim().substring(0, 1) + "_" + strFieldName.trim().replace("  ", " ").replace("/", "_").replace(" ", "_");
				String arrFPValElementDetails[] = mapFPValidation.get(strKey).replace("|", " | ").split("\\|");
				String strFPLocator = arrFPValElementDetails[0].trim();
				String arrFPValAttrDetails[] = arrFPValElementDetails[1].trim().split(",");

				System.out.println("=========== Validate '" + strCheckPermission + "' Permission for... " + strFieldName);

				// Get field element to be verified
				WebElement eleFPField = actions.getwebDriverLocator(actions.getLocator(strFPLocator));
				if (eleFPField != null) {
					// Check attribute values for the field element
					for (int idxAttr = 0; idxAttr < arrFPValAttrDetails.length; idxAttr++) {
						String strExptAttrName = arrFPValAttrDetails[idxAttr].trim().split("=")[0].trim();
						String strExptAttrValue = arrFPValAttrDetails[idxAttr].trim().split("=")[1].trim().replace("'", " ").trim();
						System.out.println("Locator : '" + strFPLocator + "' \nAttribute Name : '" + strExptAttrName + "' \nAttribute Value : '" + strExptAttrValue + "'");

						System.out.println("=========== Expt... " + strExptAttrName + " = " + strExptAttrValue);

						String strActlAttrValue = "";
						try {
							strActlAttrValue = eleFPField.getAttribute(strExptAttrName).trim();
						} catch (Exception e) {
							strActlAttrValue = "";
						}

						System.out.println("=========== Actual... " + strExptAttrName + " = " + strActlAttrValue);

						if (strExptAttrValue.equals("*")) {
							if (strActlAttrValue.equals("")) strFieldFailed = strFieldName;
						} else {
							if (!strActlAttrValue.equals(strExptAttrValue)) strFieldFailed = strFieldName;
						}
					}
				} else {
					strFieldFailed = strFieldName + " (" + strFPLocator + " :: " + actions.getLocator(strFPLocator) + ")";
				}

				// Construct result-strings for this field
				strRptStep = "> Verify '" + strCheckPermission + "' permission for '" + strFieldName + "' field";
				switch (strCheckPermission) {
				case "Create":
				case "Update":
					strRptExpected = "'" + strFieldName + "' field should be enabled";
					strRptActual = (strFieldFailed.equals("") ? "'" + strFieldName + "' field is enabled, as expected" : "Field '" + strFieldFailed + "' is NOT enabled");
					strRptStatus = (strFieldFailed.equals("") ? "Pass" : "Fail");
					break;

				case "Read Only":
					strRptExpected = "'" + strFieldName + "' field should be read-only";
					strRptActual = (strFieldFailed.equals("") ? "'" + strFieldName + "' field is read-only, as expected" : "Field '" + strFieldFailed + "' is NOT read-only");
					strRptStatus = (strFieldFailed.equals("") ? "Pass" : "Fail");
					break;

				case "None":
					strRptExpected = "'" + strFieldName + "' field should be disabled and blank";
					strRptActual = (strFieldFailed.equals("") ? "'" + strFieldName + "' field is disabled and blank, as expected" : "Field '" + strFieldFailed + "' is NOT disabled and blank");
					strRptStatus = (strFieldFailed.equals("") ? "Pass" : "Fail");
					break;
				}

				// Report the result
				blnReturn = strRptStatus.equals("Pass");
				if (blnReturn) {
					actions.reportCreatePASS(strRptStep, strRptExpected, strRptActual, strRptStatus);
				} else {
					actions.reportCreateFAIL(strRptStep, strRptExpected, strRptActual, strRptStatus);
				}
			}

		} catch (Exception e) {
			actions.reportCreateFAIL(strRptStep, strRptExpected, e.getMessage(), "Fail");
		}

		return blnReturn;
	}

	// ============
	/* Function: To create new color configuration Author: Murari Updated by: Neha */
	public String CreateColorConfiguration(String strColorName[], String R_ColorCode, String G_ColorCode, String B_ColorCode) throws Exception {
		boolean blnflag = false;
		String strColorN = "", strname = "";
		Thread.sleep(1000);
		actions.click("ColorConfiguration.NewColorbtn");
		Thread.sleep(1000);

		/** Step 2 : Switch to Color Configuration window */
		Thread.sleep(2000);
		mcd.SwitchToWindow("Color Configuration");

		/** Enter Color Name | R | G | B */

		/** Click on Save Button */
		do {
			Random rand_num = new Random();
			int ColorCode = rand_num.nextInt((99) + 1);

			actions.setValue("ColorConfiguration.red", ColorCode);
			actions.setValue("ColorConfiguration.green", ColorCode);
			actions.setValue("ColorConfiguration.blue", ColorCode);
			Thread.sleep(1000);
			actions.click("ColorConfiguration.colorParentNode");
			Thread.sleep(1000);

			List<WebElement> colorName = driver.findElements(By.xpath("//*[@id='test']/table[2]/tbody/tr/td[2]/table/tbody/tr/td[2]/input[2]"));
			strname = mcd.fn_GetRndName(strColorName[0]);
			driver.findElement(By.xpath("//*[@id='test']/table[2]/tbody/tr/td[2]/table/tbody/tr[1]/td[2]/input[2]")).sendKeys(strname);
			for (int i = 2; i <= colorName.size(); i++) {
				strColorN = mcd.fn_GetRndName(strColorName[i - 1]);
				driver.findElement(By.xpath("//*[@id='test']/table[2]/tbody/tr/td[2]/table/tbody/tr[" + i + "]/td[2]/input[2]")).sendKeys(strColorN);

			}

			// actions.setValue("ColorConfiguration.ColorName", strColorN);
			actions.click("ColorConfiguration.saveButton");
			try {

				driver.findElement(By.xpath("//*[@id='colorConfiguration_addUpdateColorConfiguration_errorCode']/li/span")).isDisplayed();
				blnflag = false;

			} catch (Exception E) {
				Thread.sleep(5000);
				mcd.SwitchToWindow("$Color Configuration");
				boolean is_Created = mcd.VerifyOnscreenMessage("ColorConfiguration.OnScreenMessage", "Your changes have been saved.", true);
				if (is_Created) {
					actions.reportCreatePASS("Verify that 'New Color' is created or not ", "New Color Set Should get created", "New Color is Created", "Pass");
				}
				blnflag = true;
			}

		} while (blnflag == false);

		return strname;
	}

	public void LaunchAndLoginRDI(Object strURL, Object strUserName, Object strPassword) {
		String strStep = "Login application as '" + strUserName + "'";
		String strExpt = "User '" + strUserName + "' should be able to login";

		try {
			driver.get("https://raj.paul:8uhgvMQU@rfmap211.rdisoftware.com/rfm2OnlineApp/rfmLogin.action?iv-user=etst0001&paramLogin=TEST-RDI");
			// Launch the application URL
			actions.launchApplication(strURL);
			// actions.waitForPageToLoad(3000);

			mcd.SwitchToWindow("Windows Security");

			if (uiActions.elementPresent(actions.getwebDriverLocator(actions.getLocator("RFMLoginPage.Page")))) {
				// Enter User Name and Password
				actions.getwebDriverLocator(actions.getLocator("RFMLoginPage.UserName")).sendKeys(strUserName.toString().trim());
				actions.getwebDriverLocator(actions.getLocator("RFMLoginPage.Password")).sendKeys(strPassword.toString().trim());

				// actions.setValue("RFMLoginPage.UserName", strUserName);
				// actions.setValue("RFMLoginPage.Password", strPassword);

				// Click 'Login' button
				// actions.click("RFMLoginPage.Login");
				actions.getwebDriverLocator(actions.getLocator("RFMLoginPage.Login")).click();
				Thread.sleep(2000);
				actions.smartWait(120);
				mcd.SwitchToWindow("");

				actions.reportCreatePASS(strStep, strExpt, "User logged-in successfully", "Pass");

			} else {
				System.out.println("RFM Login Page is not displated");
				throw new Exception("RFM Login Page is not displated");
			}
		} catch (Exception e) {
			actions.reportCreateFAIL(strStep, strExpt, e.getMessage(), "Fail");
			e.printStackTrace();
		}
	}

	public WebElement RestProfile_ViewEdit(String soption, String stype) {
		WebElement selement = null;
		try {

			selement = driver.findElement(By.xpath("//*[@id='profSingleSetForm']//*[contains(text(),'" + soption + "')]/..//" + stype));

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return selement;
	}

	// setting the values in the day part set for restaurant profile
	// int day part is the number for which start and end time is to be set//
	public String rfm_setdaypartvalues(int daypart, int start_time, int End_time) {
		String Daypart_name = null;
		try {

			List<WebElement> dayparts = driver.findElements(By.xpath("//*[@id='Sess1']/tbody/tr"));

			// getting the day part name
			Daypart_name = dayparts.get(daypart).findElement(By.xpath("./td[1]//input[1]")).getAttribute("value");

			// setting the values now for day part 1
			WebElement startinput_value = dayparts.get(daypart).findElement(By.xpath("./td[3]//tr[1]//input[1]"));
			WebElement Endinput_value = dayparts.get(daypart).findElement(By.xpath("./td[3]//tr[2]//input[1]"));
			startinput_value.clear();
			Endinput_value.clear();

			actions.setValue(startinput_value, "textbox", start_time + ":00");
			actions.setValue(Endinput_value, "textbox", End_time + ":00");

		} catch (Exception e1) {
			System.out.println(e1.getMessage());
		}
		return Daypart_name;
	}

	/* for validation of the Restaurant profile customization */
	public void ValidateCutomization(String Msg1, String Msg2, WebElement setfield1, String strField1, String Locator, int num, String fldtype) {
		String strvalue = null;
		boolean flag = false;
		WebElement Field1 = null;
		List<WebElement> Field3 = null;
		String selectedoption = "";
		try {

			// Clicking on the customization button
			actions.click("RestaurantProfile.SBCustomize");
			Thread.sleep(2000);

			// getting the values from field
			if (setfield1 == null) {
				if (fldtype.equalsIgnoreCase("select")) {
					Field1 = mcd.GetTableCellElement("UpdateSettings.table", 1, strField1, fldtype);
					Select dropdwn = new Select(Field1);
					selectedoption = dropdwn.getFirstSelectedOption().getText();
					String options = mcd.getdropdownvalues(setfield1);
					String[] fsize = options.split(",");
					for (int j = 0; j < fsize.length; j++) {
						if (!fsize[j].trim().equalsIgnoreCase(selectedoption)) {
							dropdwn.selectByVisibleText(fsize[j].trim());
							actions.reportCreatePASS("selecting the options from Drop down list", "Should select the available option from the drop down list", "Selected the option '" + fsize[j].trim(), "Pass");
							break;
						}
					}
				} else {
					Field1 = mcd.GetTableCellElement("UpdateSettings.table", 1, strField1, fldtype);
					strvalue = Field1.getAttribute("value");

					// Setting the first field value
					Field3 = driver.findElements(By.xpath(actions.getLocator(Locator)));
					Field3.get(0).clear();
					Field3.get(0).clear();
					actions.setValue(Field3.get(0), "textbox", num);
				}
			} else {

				if (fldtype.equalsIgnoreCase("select")) {
					Select dropdwn = new Select(setfield1);
					selectedoption = dropdwn.getFirstSelectedOption().getText();
					String options = mcd.getdropdownvalues(setfield1);
					String[] fsize = options.split(",");
					for (int j = 0; j < fsize.length; j++) {
						if (!fsize[j].trim().equalsIgnoreCase(selectedoption)) {
							dropdwn.selectByVisibleText(fsize[j].trim());
							actions.reportCreatePASS("selecting the options from Drop down list", "Should select the available option from the drop down list", "Selected the option '" + fsize[j].trim(), "Pass");
							break;
						}
					}
				} else {
					// getting the field value now
					strvalue = setfield1.getAttribute("value");

					// clearing & setting the new value in the field
					setfield1.clear();
					actions.setValue(setfield1, "textbox", num);
				}
			}
			// clicking on the apply button now
			actions.click("UpdtMultipleSet.Apply");
			Thread.sleep(1000);

			// verifying the alert pop up
			if (!Msg1.equals("")) {
				if (mcd.VerifyAlertMessageDisplayed("Confirmation", Msg1, true, AlertPopupButton.OK_BUTTON)) {

					actions.reportCreatePASS("Verifying the alert pop up message", Msg1 + " should be displayed", Msg1 + " is displayed", "Pass");

				} else {
					actions.reportCreateFAIL("Verifying the alert pop up message", Msg1.trim() + " should be displayed", Msg1.trim() + " is not displayed", "Fail");
				}
			}

			// checking for the field if got to set same value
			try {
				// switching to driver if present
				driver.switchTo().alert().accept();

				do {
					if (setfield1 == null) {
						Field3.get(0).clear();
						num = num + 3;
						Field3.get(0).sendKeys(Integer.toString(num));
					} else {

						// clearing & setting the new value in the field
						setfield1.clear();
						num = num + 3;
						setfield1.sendKeys(Integer.toString(num));
					}

					// clicking on the apply button now
					actions.click("UpdtMultipleSet.Apply");

					try {
						// switching to driver if present
						driver.switchTo().alert().accept();
					} catch (Exception e4) {
						System.out.println("Value set successfully");
						flag = true;
					}

				} while (flag == false);

			} catch (Exception e3) {
				System.out.println("Value got set sucessfully");
			}

			// Verifying the success message now
			actions.verifyTextPresence(Msg2, true);

		} catch (Exception e2) {
			System.out.println(e2.getMessage());
			actions.reportCreateFAIL("Verifying the Customization functionality", "Customizations should be done", "Customization Failed :" + e2.getMessage(), "Fail");
		}
	}

	// ==============
	// ===============

	/* ==== For validation of the reset functionality
	 * 
	 * ============== */

	public void ValidateReset(String strField) {
		try {
			/* Clicking & validating the reset button functionality */

			// getting the field value for the discount set before reset
			WebElement Ratefield = mcd.GetTableCellElement("UpdateSettings.table", 1, strField, "input");
			String num = Ratefield.getAttribute("value");

			actions.keyboardEnter("RestaurantProfile.SBDaypartReset");
			Thread.sleep(2000);

			driver.switchTo().alert().accept();

			// waiting for the page to laod
			Thread.sleep(2000);
			actions.smartWait(120);

			// getting the field value for the discount set and comparing it with default values
			Ratefield = mcd.GetTableCellElement("UpdateSettings.table", 1, strField, "input");
			String strvalue = Ratefield.getAttribute("value");

			if (strvalue.equals(num)) {
				actions.reportCreateFAIL("Verifying the Discount set reset to default behavior", "Reset to Default should reset the values for the Discount set", "Reset to default has not resetted the values to default", "Fail");
			} else {
				actions.reportCreatePASS("Verifying the Discount set reset to default behavior", "Reset to Default should reset the values for the Discount set", "Reset to default has resetted the values to default", "Pass");
			}

		} catch (Exception e3) {
			System.out.println(e3.getMessage());
		}

	}

	/// =====
	public boolean updateSettings(String attrvalue, String attrcompvalue, String SetValue, String CompValue) {
		boolean flag = false;
		try {
			List<WebElement> Parameter_Lists = driver.findElements(By.xpath("//*[@id='ApplicationParameters']/tr/td[2]/b"));
			int cnt = 3;
			for (int i = 0; i < Parameter_Lists.size(); i++) {
				String curr_parameter = Parameter_Lists.get(i).getText();

				// Check whether section name is "General"
				if (curr_parameter.equals("General")) {
					driver.findElement(By.xpath("//*[@id='ApplicationParameters']/tr[" + cnt + "]/td[1]")).click();
					Thread.sleep(1000);
					break;
				} else {
					cnt = cnt + 2;
				}
			}

			// Get row counts of parameters displayed
			int p_rows = mcd.GetTableRowCount("UpdateSettings.GeneralParamTbl");
			String tag = null;
			String curr_val = null;
			String new_val = null;
			int iTemp = 0;
			int tag_cnt = 0;

			// Check for the mentioned 2 tags & check whether they are set to expected value
			for (int j = 1; j <= p_rows; j++) {
				tag = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[1]")).getText();

				if (tag.equals("Restrict price type attribute from expanding")) {
					curr_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input")).getAttribute("value");

					if (curr_val.equalsIgnoreCase(attrcompvalue)) {
						driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[3]/input")).sendKeys(attrvalue);
						tag_cnt++;
					} else {
						// Reporter.log(tag+" - Tag value is already true.");
						// System.out.println(tag+" - Tag value is already true.");
						actions.reportCreatePASS("Verify tag value", tag + " - Tag value is already true.", tag + " - Tag value is already true.", "PASS");
					}
				}

				if (tag.equals("Display price type attribute as expanded by default")) {

					curr_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input")).getAttribute("value");

					if (curr_val.equalsIgnoreCase(CompValue)) {
						driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[3]/input")).sendKeys(SetValue);
						tag_cnt++;
					} else {
						actions.reportCreatePASS("Verify tag value", tag + " - Tag value is already true.", tag + " - Tag value is already true.", "PASS");
					}
				}
			}

			// Save the changes
			if (tag_cnt > 0) {
				actions.click("UpdateSettings.SaveBtn");
				actions.smartWait(120);
				actions.verifyTextPresence("Your changes have been saved and cache is refreshed.", true);
				flag = true;
			}
		} catch (Exception err) {
			System.out.println(err.getMessage());
		}

		return flag;
	}
	// =============

	/* This Function Creates Set of the Features
	 * 
	 * @Param : strAddNewSetName -> Feature set Name ,strrestlocator -> object repository name ,strrest - Restaurnat name
	 * 
	 * @return :String - > Feature set name
	 * 
	 * @Author :Priyanka */
	// public String fn_CreateFeaturSet(String strAddNewSetName,String strrestlocator,String strrest)
	// {
	// String strFeatureSetName="";
	// try{
	//
	// /**Click on New Set**/
	// //Create Xpath
	// String strXPath = "";
	// strXPath="//*[@class='button'][contains(text(),"+"'"+ strAddNewSetName +"')]";
	// WebElement addNewSetButton = driver.findElement(By.xpath(strXPath));
	// if (addNewSetButton != null){
	// addNewSetButton.click();
	// Thread.sleep(8000);
	// }
	//
	// String strMainWindow = driver.getWindowHandle();
	// /**-------Switch window to Add New Day Part Set----**/
	// String strSecondWindowName = "Add "+strAddNewSetName;
	// actions.windowSwitch(strMainWindow, strSecondWindowName);
	// System.out.println("swicted to second window : "+ driver.getTitle());
	// Thread.sleep(5000);
	//
	// /** Set Value of Day part Set name and select name**/
	// String strSecondWindow = driver.getWindowHandle();
	// //Get random string
	// //String strPrefix =mcd.GetTestData("DT_PREFIX");
	// strFeatureSetName = mcd.fn_GetRndName(mcd.GetTestData("DT_PREFIX"));
	// actions.setValue("RFMAddNewSet.SetName", strFeatureSetName);
	// System.out.println("Current Window : "+ driver.getTitle());
	// actions.click("RFMAddNewSet.SelectBtn");
	// Thread.sleep(8000);
	//
	// //Select Heriarchy from select window
	// actions.windowSwitch(driver.getWindowHandle(), "Select Node");
	// Thread.sleep(10000);
	// System.out.println("swicted to third window : "+ driver.getTitle());
	//
	// /*String eleSelectNode= actions.getLocator("RFMSelectNode.SelectNode");
	// WebElement selectNode = driver.findElement(By.xpath(eleSelectNode));
	// if (selectNode != null){
	// selectNode.click();
	// Thread.sleep(8000);
	// } */
	//
	// Boolean blnSelect = mcd.Selectrestnode(strrestlocator, strrest );
	// if(blnSelect == true)
	// {
	// //Reporter.log("Node Selected successfully");}else{
	// //Reporter.log("Failed to select node");
	// }
	// //actions.click("RFMSelectNode.SelectNode");
	//
	// driver.close();
	// Thread.sleep(10000);
	// driver.switchTo().window(strSecondWindow);
	// System.out.println("Back to Second window : "+driver.getTitle());
	//
	// /**Select Copy Existing **/
	// SelectRadioCopyExisting(mcd.GetTestData("DT_COPYEXISTING"));
	//
	// String strCopyExisting = mcd.GetTestData("DT_COPYEXISTING");
	//
	// if (strCopyExisting.equalsIgnoreCase("No"))
	// {
	// /**Click on Next**/
	// actions.click("RFMAddNewSet.NextBtn");
	// Thread.sleep(10000);
	// driver.switchTo().window(strMainWindow);
	// }
	// }
	// catch(Exception e){
	// //Reporter.log("Failed Test"+e.getMessage());
	// }
	//
	// return strFeatureSetName;
	// }

	/**
	 * "DT_PREFIX" - Pass 'Auto' any prefix "DT_COPYEXISTING" - Yes or No
	 */
	public String fn_CreateFeaturSet(String strAddNewSetName, String strrestlocator, String strrest, String strMainWindowName, String strDTPREFIX, String strCopy, int timeinsec) {
		String strFeatureSetName = "";
		try {

			/** Click on New Set **/
			// Create Xpath
			String strXPath = "";
			strXPath = "//*[@class='button'][contains(text()," + "'" + strAddNewSetName + "')]";
			WebElement addNewSetButton = driver.findElement(By.xpath(strXPath));
			if (addNewSetButton != null) {
				addNewSetButton.click();
				Thread.sleep(8000);
			}

			/** -------Switch window to Add New Day Part Set---- **/
			mcd.SwitchToWindow("Add " + strAddNewSetName);

			/** Set Value of Day part Set name and select name **/

			// Get random string
			// String strPrefix =mcd.GetTestData("DT_PREFIX");
			strFeatureSetName = strDTPREFIX;
			Thread.sleep(2000);
			actions.setValue("RFMAddNewSet.SetName", strFeatureSetName);
			Thread.sleep(3000);
			actions.keyboardEnter("RFMAddNewSet.SelectBtn");
			Thread.sleep(8000);

			// Select Heriarchy from select window
			mcd.SwitchToWindow("Select Node");

			/* String eleSelectNode= actions.getLocator("RFMSelectNode.SelectNode"); WebElement selectNode = driver.findElement(By.xpath(eleSelectNode)); if
			 * (selectNode != null){ selectNode.click(); Thread.sleep(8000); } */

			Boolean blnSelect = mcd.Selectrestnode(strrestlocator, strrest);
			if (blnSelect == true) {
				actions.reportCreatePASS("Verify that Node is selected or not ", "Node Should get select ", "Node Selected successfully", "Pass");

			} else {
				actions.reportCreateFAIL("Verify that Node is selected or not ", "Node Should get select ", "Failed to select Node", "Fail");
			}
			// actions.click("RFMSelectNode.SelectNode");

			Thread.sleep(1000);
			mcd.SwitchToWindow("Add " + strAddNewSetName);

			/** Select Copy Existing **/
			SelectRadioCopyExisting(strCopy);

			if (strCopy.equalsIgnoreCase("No")) {
				/** Click on Next **/
				actions.click("RFMAddNewSet.NextBtn");
				Thread.sleep(timeinsec);
				if (strMainWindowName.toLowerCase().contains("POS".toLowerCase())) {
					mcd.SwitchToWindow(strMainWindowName);
				} else {
					mcd.SwitchToWindow("@" + strMainWindowName);
				}
			}
		} catch (Exception e) {
			Reporter.log("Failed Test" + e.getMessage());
		}

		return strFeatureSetName;
	}

	public String CreateCouponSet(String strOnScreenMessageCreate, String strrest, String strstatus) throws Exception {
		String DtPrefix = mcd.fn_GetRndName("Auto");
		String strFeatureSetName = fn_CreateFeaturSet("New Coupon Set", "RFMSelectNode.SelectNode", strrest, "Manage Coupon Set", DtPrefix, "No", 3000);
		Thread.sleep(1000);
		// Select Active or inactive
		actions.setValue("RFMManageCouponSet.Status", strstatus);

		// Click on 'Add Coupon Set'
		actions.click("CouponSet.AddCoupon");
		Thread.sleep(1000);
		// Switch to 'Manage Tender Type'
		mcd.SwitchToWindow("Manage Tender Type");
		// Check any one Check box from the list and Click on Continue
		try {
			actions.setValue("CouponSet.CheckFirstTenderSet", Keys.SPACE);
		} catch (Exception E) {
			actions.reportCreateFAIL("Verify that Tender type should be assigned to coupon set", "Tender Type should assigned to Coupon set", "Tender type is not available", "Fail");
		}
		// Click on Continue button
		actions.click("CouponSet.Continuebtn");

		// Switch back to Main Window "Manage Coupon Set"
		mcd.SwitchToWindow("Manage Coupon Set");

		// Click on Apply button
		actions.click("RFMManageCouponSet.Applybtn");

		// Verify on screen message
		boolean is_created = mcd.VerifyOnscreenMessage("RFMManageCouponSet.OnScreenMessage", strOnScreenMessageCreate, true);
		if (is_created) {
			actions.reportCreatePASS("Verify that coupon set is created", "Coupon set should get created", "Coupon set has been created", "Pass");
		} else {

			actions.reportCreateFAIL("Verify that coupon set is created", "Coupon set should get created", "Coupon set is not created", "Fail");
		}

		return strFeatureSetName;

	}

	/**
	 * POS Function 1 : To Create POS Screen Set # timeinsec - wait time to load the Pos Layout Screen # strMarket - Market Name like US Office Country ,
	 * Australiasia etc Date 5/10 2016 - Not added in SVN Libary
	 */
	public String POS_CreateScreenSet(int timeinsec, String strMarket) throws Exception {

		String DtPrefix = mcd.fn_GetRndName("Auto");
		String strPOSName = fn_CreateFeaturSet("New Screen Set", "RFMSelectNode.SelectNode", strMarket, "POS Layout", DtPrefix, "No", timeinsec);

		actions.WaitForElementPresent("POSLayout.Edit", 10);
		actions.WaitForElementPresent("POSLayout.Edit", 10);
		actions.keyboardEnter("POSLayout.Edit");
		actions.setValue("POSLayout.SetStatus", "Active");
		actions.keyboardEnter("POSLayout.Save");
		actions.smartWait(100);

		/** Verify Message */
		boolean verify1 = driver.getPageSource().contains("Your changes have been saved.");
		System.out.println(verify1);
		if (verify1) {
			System.out.println("Your changes have been saved.");
		} else {
			System.out.println("Unable to save the changes");
		}

		Thread.sleep(3000);

		actions.keyboardEnter("POSLayout.Exit");

		mcd.SwitchToWindow("Screen Set");
		return strPOSName;

	}

	/**
	 * Verify error messages for ">>" or">" and "<<" or "<" transfer buttons
	 * 
	 * @param strAvailableListAreaHeader i.e.Available Restaurant List Area
	 * @param strWarningMessage1 -Message displayed for ">>" or ">" button validation
	 * @param strWarningMessage2 -Message displayed for "<<" or "<" button validation
	 * @param strLocatorSelectedListAreaHeader i.e.Selected Restaurant List Area
	 * @param eleLocatorAddLeftAllButton
	 * @param eleLocatorAddRightAllButton
	 * @param strRightdataTransferBtn ie.whether user has to click on ">>" or ">" button
	 * @param strLeftdataTransferBtn ie.whether user has to click on "<<" or "<" button
	 */

	public void ErrorMessagesForDataTransferButtons(String strAvailableListAreaHeader, String strWarningMessage1, String strWarningMessage2, String strLocatorSelectedListAreaHeader, String eleLocatorAddLeftButton, String eleLocatorAddRightButton, String strLeftdataTransferBtn, String strRightdataTransferBtn) throws InterruptedException {

		// Verify 'error message when user clicks on '<<' button or '<' button when no data is available in Selected list area

		Actions builder = new Actions(driver);
		builder.moveByOffset(0, 500).click().perform();

		actions.click(eleLocatorAddLeftButton);
		Boolean Flag1 = mcd.VerifyAlertMessageDisplayed("Warning Message", strWarningMessage1, true, AlertPopupButton.OK_BUTTON);

		// Switch to verify clicked on which button "<" or "<<"
		switch (strLeftdataTransferBtn) {
		case "<<":
			if (Flag1) actions.reportCreatePASS("Verify that correct error message is displayed after user clicks on '<<' button when no data is available in " + strLocatorSelectedListAreaHeader + "list area", "Correct error message should get displayed after user clicks on '<<' button when no data is available in " + strLocatorSelectedListAreaHeader + "list area", "Correct error message is displayed after user clicks on '<<' button wwhen no data is available in " + strLocatorSelectedListAreaHeader + "list area", "Pass");
			else actions.reportCreateFAIL("Verify that correct error message is displayed after user clicks on '<<' button when no data is available in " + strLocatorSelectedListAreaHeader + "list area", "Correct error message should get displayed after user clicks on '<<' button when no data is available in " + strLocatorSelectedListAreaHeader + "list area", "Correct error message is not displayed after user clicks on '<<' button wwhen no data is available in " + strLocatorSelectedListAreaHeader + "list area", "Fail");
			break;

		case "<":
			if (Flag1) actions.reportCreatePASS("Verify that correct error message is displayed after user clicks on '<' button when no data is available in " + strLocatorSelectedListAreaHeader + "list area", "Correct error message should get displayed after user clicks on '<' button when no data is available in " + strLocatorSelectedListAreaHeader + "list area", "Correct error message is displayed after user clicks on '<' button wwhen no data is available in " + strLocatorSelectedListAreaHeader + "list area", "Pass");
			else actions.reportCreateFAIL("Verify that correct error message is displayed after user clicks on '<' button when no data is available in " + strLocatorSelectedListAreaHeader + "list area", "Correct error message should get displayed after user clicks on '<' button when no data is available in " + strLocatorSelectedListAreaHeader + "list area", "Correct error message is not displayed after user clicks on '<' button wwhen no data is available in " + strLocatorSelectedListAreaHeader + "list area", "Fail");
			break;

		default:
			break;
		}

		// Verify error message when user clicks on '>>' button or '>' button when no data is available in Available restaurants list area
		actions.smartWait(10);
		actions.click(eleLocatorAddRightButton);
		Boolean Flag2 = mcd.VerifyAlertMessageDisplayed("Warning Message", strWarningMessage2, true, AlertPopupButton.OK_BUTTON);
		switch (strRightdataTransferBtn) {
		case ">>":
			if (Flag2) actions.reportCreatePASS("Verify that correct error message is displayed after user clicks on '>>' button when no data is available in " + strAvailableListAreaHeader + "list area", "Correct error message should get displayed after user clicks on '>>' button when no data is available in " + strAvailableListAreaHeader + "list area", "Correct error message is displayed after user clicks on '>>' button when no data is available in " + strAvailableListAreaHeader + "list area", "Pass");
			else actions.reportCreateFAIL("Verify that correct error message is displayed after user clicks on '>>' button when no data is available in " + strAvailableListAreaHeader + "list area", "Correct error message should get displayed after user clicks on '>>' button when no data is available in " + strAvailableListAreaHeader + "list area", "Correct error message is not displayed after user clicks on '>>' button wwhen no data is available in " + strAvailableListAreaHeader + "list area", "Fail");
			break;

		case ">":
			if (Flag1) actions.reportCreatePASS("Verify that correct error message is displayed after user clicks on '>' button when no data is available in " + strAvailableListAreaHeader + "list area", "Correct error message should get displayed after user clicks on '>' button when no data is available in " + strAvailableListAreaHeader + "list area", "Correct error message is displayed after user clicks on '>' button wwhen no data is available in " + strAvailableListAreaHeader + "list area", "Pass");
			else actions.reportCreateFAIL("Verify that correct error message is displayed after user clicks on '>' button when no data is available in " + strAvailableListAreaHeader + "list area", "Correct error message should get displayed after user clicks on '>' button when no data is available in " + strAvailableListAreaHeader + "list area", "Correct error message is not displayed after user clicks on '>' button wwhen no data is available in " + strAvailableListAreaHeader + "list area", "Fail");
			break;

		default:
			break;
		}

	}

	/**
	 * Verify functionality of ">>" and "<<" transfer buttons
	 * 
	 * @param strAvailableListAreaHeader i.e.Available Restaurant List Area
	 * @param strWarningMessage1
	 * @param strLocatorSelectedListAreaHeader i.e.Selected Restaurant List Area
	 * @param eleLocatorAddLeftAllButton i.e. Locator for "<<" button
	 * @param eleLocatorAddRightAllButton i.e. Locator for ">>" button
	 * @param eleLocatorViewFullListButton Note -On some screens Search button will do same function as View Full List button
	 * @param eleLocatorAvailableListArea
	 * @param eleLocatorSelectedListArea
	 * @param eleLocatorAddRightSelectedButton
	 */

	public void AllDataTransferButtonFunctionality(String strAvailableListAreaHeader, String strWarningMessage1, String strLocatorSelectedListAreaHeader, String eleLocatorAddLeftAllButton, String eleLocatorAddRightAllButton, String eleLocatorViewFullListButton, String eleLocatorAvailableListArea, String eleLocatorSelectedListArea, String eleLocatorAddRightSelectedButton) throws InterruptedException {

		// Verify that when user clicks on '>>' button ,all data is moved from available list area to selected list area
		String strActualMsg = null;
		Boolean AFlag = false;
		Boolean MDisplay = false;

		int RowCountB = mcd.GetTableRowCount(eleLocatorAvailableListArea);
		System.out.println("RowCountB" + RowCountB);

		// if pop up message displayed specifying market limit for maximum data selection handle it or check whether dat is moved or not
		try {
			actions.keyboardEnter(eleLocatorAddRightAllButton);
			Alert popup = driver.switchTo().alert();
			System.out.println("Alert displayed");
			strActualMsg = popup.getText();
			System.out.println("> strActualMsg" + strActualMsg);
			if (strActualMsg.contains("cannot exceed")) {
				AFlag = true;
				popup.accept();
				MDisplay = true;

			}
		}

		catch (Exception e) {
			e.printStackTrace();
			int RowCountA = mcd.GetTableRowCount(eleLocatorAvailableListArea);
			System.out.println("RowCountA" + RowCountA);
			if (RowCountA < RowCountB) AFlag = true;
			else AFlag = false;
		}

		if (AFlag) actions.reportCreatePASS("Verify that when user clicks on '>>'all records are moved from the " + strAvailableListAreaHeader + " to the " + strLocatorSelectedListAreaHeader + ".", "When user clicks on '>>' button,all Records should get moved from the" + strAvailableListAreaHeader + " to the " + strLocatorSelectedListAreaHeader + ".", "When user clicks on '>>' button,all Records are moved from the" + strAvailableListAreaHeader + " to the " + strLocatorSelectedListAreaHeader + ".", "Pass");
		else actions.reportCreateFAIL("Verify that when user clicks on '>>'all records are moved from the " + strAvailableListAreaHeader + " to the " + strLocatorSelectedListAreaHeader + ".", "When user clicks on '>>' button,all Records should get moved from the" + strAvailableListAreaHeader + " to the " + strLocatorSelectedListAreaHeader + ".", "When user clicks on '>>' button,all Records are not moved from the" + strAvailableListAreaHeader + " to the " + strLocatorSelectedListAreaHeader + ".", "Fail");

		// Verify that when user clicks on '<<' button ,all data is moved from selected list area to available list area
		if (MDisplay) {
			actions.click(eleLocatorViewFullListButton);
			mcd.select_row(eleLocatorAvailableListArea, 0);
			mcd.select_row(eleLocatorAvailableListArea, 1);
			actions.click(eleLocatorAddRightSelectedButton);
			actions.smartWait(10);
		}

		int RowCountB1 = RowCountSelected(eleLocatorSelectedListArea);
		actions.click(eleLocatorAddLeftAllButton);
		int RowCountA1 = RowCountSelected(eleLocatorSelectedListArea);

		if (RowCountA1 < RowCountB1) actions.reportCreatePASS("Verify that when user clicks on '<<'all records are moved from the " + strLocatorSelectedListAreaHeader + " to the " + strAvailableListAreaHeader + ".", "When user clicks on '<<' button,all Records should get moved from the" + strLocatorSelectedListAreaHeader + " to the " + strAvailableListAreaHeader + ".", "When user clicks on '<<' button,all Records are moved from the" + strLocatorSelectedListAreaHeader + " to the " + strAvailableListAreaHeader + ".", "Pass");
		else actions.reportCreateFAIL("Verify that when user clicks on '<<'all records are moved from the " + strLocatorSelectedListAreaHeader + " to the " + strAvailableListAreaHeader + ".", "When user clicks on '<<' button,all Records should get moved from the" + strLocatorSelectedListAreaHeader + " to the " + strAvailableListAreaHeader + ".", "When user clicks on '<<' button,all Records are not moved from the" + strLocatorSelectedListAreaHeader + " to the " + strAvailableListAreaHeader + ".", "Fail");

	}

	public int RowCountSelected(String strTableElement1) {
		int intReturn;
		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator(strTableElement1));
		try {
			List<WebElement> eleRows = eleTable.findElements(By.xpath(".//thead/tr"));
			intReturn = eleRows.size();
		} catch (Exception e) {
			try {
				List<WebElement> eleRows = eleTable.findElements(By.xpath(".//tbody/tr"));
				intReturn = eleRows.size();
			} catch (Exception e1) {
				intReturn = -1;
			}
		}
		return intReturn;
	}

	/**
	 * Verify error message displayed for ">" and "<" transfer buttons when clicked on respective button without selecting data
	 * 
	 * @param strWarningMessage1 -warning message displayed when user clicks on '>' button without selecting any data from available list area
	 * @param strWarningMessage2-warning message displayed when user clicks on '<' button without selecting any data from selected list area
	 * @param eleLocatorAddLeftSelectedButton i.e. Locator for "<" button
	 * @param eleLocatorAddRightSelectedButton i.e. Locator for ">" button
	 * @param eleLocatorViewFullListButton Note -On some screens Search button will do same function as View Full List button
	 * @param eleLocatorAvailableListArea
	 */

	public void SelectedDataTransferErrorMessage(String strWarningMessage1, String strWarningMessage2, String eleLocatorAddLeftSelectedButton, String eleLocatorAddRightSelectedButton, String eleLocatorViewFullListButton, String eleLocatorAvailableListArea) throws InterruptedException {

		actions.click(eleLocatorViewFullListButton);

		// Verify that correct error message is displayed when user clicks on '>' button without selecting any data
		actions.click(eleLocatorAddRightSelectedButton);
		Boolean result1 = mcd.VerifyAlertMessageDisplayed("Warning Message", strWarningMessage1, true, AlertPopupButton.OK_BUTTON);
		if (result1) actions.reportCreatePASS("Verify that correct error message is displayed after user clicks on '>' button without selecting data", "Correct error message should get displayed after user clicks on '>' button  without selecting data", "Correct error message is displayed after user clicks on '>' button  without selecting data", "Pass");
		else actions.reportCreateFAIL("Verify that correct error message is displayed after user clicks on '>' button without selecting data", "Correct error message should get displayed after user clicks on '>' button  without selecting data", "Correct error message is not displayed after user clicks on '>' button  without selecting data", "Fail");

		// Verify that when user clicks on '>' button ,selected data is moved from available list area to selected list area
		mcd.select_row(eleLocatorAvailableListArea, 0);
		mcd.select_row(eleLocatorAvailableListArea, 1);

		// Click on > button after selecting 1st 2 rows
		actions.click(eleLocatorAddRightSelectedButton);

		// Verify that correct error message is displayed when user clicks on '<' button without selecting any data
		actions.click(eleLocatorAddLeftSelectedButton);
		Boolean result11 = mcd.VerifyAlertMessageDisplayed("Warning Message", strWarningMessage2, true, AlertPopupButton.OK_BUTTON);
		if (result11) actions.reportCreatePASS("Verify that correct error message is displayed after user clicks on '<' button without selecting data", "Correct error message should get displayed after user clicks on '<' button  without selecting data", "Correct error message is displayed after user clicks on '<' button  without selecting data", "Pass");
		else actions.reportCreateFAIL("Verify that correct error message is displayed after user clicks on '<' button without selecting data", "Correct error message should get displayed after user clicks on '<' button  without selecting data", "Correct error message is not displayed after user clicks on '<' button  without selecting data", "Fail");

	}

	/**
	 * Verify functionality of ">" and "<" transfer buttons
	 * 
	 * @param strAvailableListAreaHeader i.e.Available Restaurant List Area
	 * @param strWarningMessage1
	 * @param strLocatorSelectedListAreaHeader i.e.Selected Restaurant List Area
	 * @param eleLocatorAddLeftSelectedButton i.e. Locator for "<" button
	 * @param eleLocatorAddRightSelectedButton i.e. Locator for ">" button
	 * @param eleLocatorViewFullListButton Note -On some screens Search button will do same function as View Full List button
	 * @param eleLocatorAvailableListArea
	 * @param eleLocatorSelectedListArea
	 */

	public void SelectedDataTransferButtonFunctionality(String strAvailableListAreaHeader, String strWarningMessage1, String strLocatorSelectedListAreaHeader, String eleLocatorAddLeftSelectedButton, String eleLocatorAddRightSelectedButton, String eleLocatorViewFullListButton, String eleLocatorAvailableListArea, String eleLocatorSelectedListArea) throws InterruptedException {

		String strActualMsg = null;
		Boolean AFlag = false;
		Boolean MDisplay = false;

		actions.click(eleLocatorViewFullListButton);

		// Verify that when user clicks on '>' button ,selected data is moved from available list area to selected list area
		int RowCountA = mcd.GetTableRowCount(eleLocatorAvailableListArea);
		mcd.select_row(eleLocatorAvailableListArea, 0);
		mcd.select_row(eleLocatorAvailableListArea, 1);

		// Click on > button after selecting 1st 2 rows
		actions.click(eleLocatorAddRightSelectedButton);
		int RowCountB = mcd.GetTableRowCount(eleLocatorAvailableListArea);
		System.out.println("RowCountB" + RowCountB);

		// check whether no of rows are reduced in available list area
		if (RowCountA > RowCountB) AFlag = true;
		else AFlag = false;

		if (AFlag) actions.reportCreatePASS("Verify that when user clicks on '>'button,selected records are moved from the " + strAvailableListAreaHeader + " to the " + strLocatorSelectedListAreaHeader + ".", "When user clicks on '>'button,selected records should get moved from the" + strAvailableListAreaHeader + " to the " + strLocatorSelectedListAreaHeader + ".", "When user clicks on '>'button,selected records are moved from the" + strAvailableListAreaHeader + " to the " + strLocatorSelectedListAreaHeader + ".", "Pass");
		else actions.reportCreateFAIL("Verify that when user clicks on '>'button,selected records are moved from the " + strAvailableListAreaHeader + " to the " + strLocatorSelectedListAreaHeader + ".", "When user clicks on '>'button,selected records should get moved from the" + strAvailableListAreaHeader + " to the " + strLocatorSelectedListAreaHeader + ".", "When user clicks on '>'button,selected records are not moved from the" + strAvailableListAreaHeader + " to the " + strLocatorSelectedListAreaHeader + ".", "Fail");

		// Verify that when user clicks on '<' button ,selected data is moved from selected list area to available list area
		int RowCountB1 = RowCountSelected(eleLocatorSelectedListArea);

		// select first 2 rows from selected list area
		select_row_SelectedArea(eleLocatorSelectedListArea, 0);
		select_row_SelectedArea(eleLocatorSelectedListArea, 1);
		actions.click(eleLocatorAddLeftSelectedButton);
		int RowCountA1 = RowCountSelected(eleLocatorSelectedListArea);

		if (RowCountA1 < RowCountB1) actions.reportCreatePASS("Verify that when user clicks on '>'button,selected records are moved from the " + strLocatorSelectedListAreaHeader + " to the" + strAvailableListAreaHeader + ".", "When user clicks on '>'button,selected records should get moved from the " + strLocatorSelectedListAreaHeader + " to the" + strAvailableListAreaHeader + ".", "When user clicks on '>'button,selected records are moved from the" + strLocatorSelectedListAreaHeader + " to the " + strAvailableListAreaHeader + ".", "Pass");
		else actions.reportCreateFAIL("Verify that when user clicks on '>'button,selected records are moved from the " + strLocatorSelectedListAreaHeader + " to the" + strAvailableListAreaHeader + ".", "When user clicks on '>'button,selected records should get moved from the " + strLocatorSelectedListAreaHeader + " to the" + strAvailableListAreaHeader + ".", "When user clicks on '>'button,selected records are not moved from the" + strLocatorSelectedListAreaHeader + " to the " + strAvailableListAreaHeader + ".", "Fail");

	}

	public boolean select_row_SelectedArea(String strTableElement, int index) {
		Boolean blResult = false;
		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator(strTableElement));
		if (eleTable != null) {
			List<WebElement> eleRows = eleTable.findElements(By.xpath(".//thead/tr"));
			eleRows.get(index).click();
			blResult = true;
		}
		return blResult;

	}

	/**
	 * Verify particular field is enabled or disabled
	 * 
	 * @param eLocatorWebElement
	 * @param strFieldNameWithType specify field name with field type e.g. Status Drop down,Search Button
	 * @param strStatusToVerify i.e.whether field is enabled or disabled e.g.Enable/Disable
	 */

	public void GUI_EnableDisableValidation(String eLocatorWebElement, String strFieldNameWithType, String strStatusToVerify) {
		Boolean flag = mcd.fn_VerifyWebelementEnableDisable(eLocatorWebElement);

		switch (strStatusToVerify.toLowerCase()) {
		case "enable":
			if (flag) actions.reportCreatePASS("Verify that " + strFieldNameWithType + " is enabled", "The " + strFieldNameWithType + " should be enabled", "The " + strFieldNameWithType + " is enabled", "Pass");
			else actions.reportCreateFAIL("Verify that " + strFieldNameWithType + " is enabled", "The " + strFieldNameWithType + " should be enabled", "The " + strFieldNameWithType + " is not enabled", "Fail");
			break;

		case "disable":
			if (flag) actions.reportCreateFAIL("Verify that " + strFieldNameWithType + " is disabled", "The " + strFieldNameWithType + " should be disabled", "The " + strFieldNameWithType + " is not disabled", "Fail");
			else

			break;
			actions.reportCreatePASS("Verify that " + strFieldNameWithType + " is disabled", "The " + strFieldNameWithType + " should be disabled", "The " + strFieldNameWithType + " is disabled", "Pass");

		default:
			System.out.println("Please enter valid state to verify");
			break;

		}
	}

	/**
	 * Verify object is displayed
	 * 
	 * @param eLocatorWebElement -Locator of element which has to be checked for display
	 * @param strFieldNameWithType specify field name with field type e.g. Status Drop down,Search Button
	 */

	public void GUI_ObjectDisplayedValidation(String strWebElement, String strFieldNameWithType) {
		Boolean flag = false;
		try {
			flag = mcd.fn_VerifyWebObjectsDisplayed(strWebElement);
		} catch (Exception e) {
			try {
				flag = actions.isElementPresent(strWebElement);
			} catch (Exception e1) {
				System.out.println("Element not found");
			}
		}

		if (flag) actions.reportCreatePASS("Verify that " + strFieldNameWithType + " is displayed", "The " + strFieldNameWithType + " should be displayed", "The " + strFieldNameWithType + " is displayed", "Pass");
		else actions.reportCreateFAIL("Verify that " + strFieldNameWithType + " is displayed", "The " + strFieldNameWithType + " should be displayed", "The " + strFieldNameWithType + " is not displayed", "Fail");

	}

	/**
	 * Verify that text field is blank
	 * 
	 * @param eLocatorTextField -Locator of text field
	 * @param strFieldName specify field name e.g. Search
	 */

	public void GUI_TextFieldIsBlank(String eLocatorTextField, String strFieldName) {

		String strValue = driver.findElement(By.xpath(actions.getLocator(eLocatorTextField))).getAttribute("value");
		if (strValue.isEmpty()) actions.reportCreatePASS("Verify that " + strFieldName + " text field is blank", "The" + strFieldName + " text field should be displayed", "The " + strFieldName + " text field is blank", "Pass");
		else actions.reportCreateFAIL("Verify that " + strFieldName + " text field is blank", "The" + strFieldName + " text field should be displayed", "The " + strFieldName + " text field is not displayed", "Fail");

	}

	/**
	 * Verify that correct message is displayed when clicked on Search button with blank search criteria
	 * 
	 * @param eLocatorSearchTextBox -Locator of Search Text field
	 * @param strFieldName specify field name e.g. Search
	 */

	public void ErrorMsgBlankSearch(String eLocatorSearchTextBox, String strWarningMessage) throws InterruptedException {
		Boolean blnSearch = false;

		// Enter serach text
		actions.setValue(eLocatorSearchTextBox, " ");

		// Click on Search button
		WebElement searchBtn = driver.findElement(By.xpath("//*[(normalize-space(text())='Search')]"));
		actions.keyboardEnter(searchBtn);
		Boolean Flag11 = mcd.VerifyAlertMessageDisplayed("Warning Message", strWarningMessage, true, AlertPopupButton.OK_BUTTON);

		if (Flag11) actions.reportCreatePASS("Verify that alert message displayed when clicked on Search button without entering any data", "Alert message should be displayed when clicked on Search button without entering any data", "Alert message is displayed when clicked on Search button without entering any data", "Pass");
		else actions.reportCreateFAIL("Verify that alert message displayed when clicked on Search button without entering any data", "Alert message should be displayed when clicked on Search button without entering any data", "Alert message is not displayed when clicked on Search button without entering any data", "Fail");

	}

	/***
	 * Function for creating new Tag Set Returns display name for tag set
	 * 
	 * @return strPosName : POS Name of tag created
	 */
	public String createNewTagSet() {
		// create new tag set
		String strPosName = "";
		try {

			/** Click on add tag button */

			actions.keyboardEnter("TagDefinitions.SPVSAddTag");

			mcd.SwitchToWindow("#Title");

			String strDisplayName = mcd.fn_GetRndName("Auto_TSDN_");

			/** Enter values in display name text box */

			actions.clear("TagDefinitions.SPVSDisplayName");

			actions.setValue("TagDefinitions.SPVSDisplayName", strDisplayName);

			// Enter Values in NewPOS Name

			strPosName = "Auto" + RandomStringUtils.randomAlphabetic(6);

			actions.clear("WorkflowsUpdateWorkflow.name");

			actions.setValue("WorkflowsUpdateWorkflow.name", strPosName);

			// select applicable menu item class

			driver.findElement(By.xpath(actions.getLocator("MICP.SelectAllChkBox"))).sendKeys(Keys.SPACE);

			// click on save btn
			actions.keyboardEnter("WorkflowsUpdateWorkflow.save");

			mcd.SwitchToWindow("#Title");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return strPosName;
	}

	/*******
	 * Function for checking values of dropdown
	 * 
	 * @param strDropdownLocator : locator of dropdown
	 * @param strOptions : String containg options of dropdown seperated by # eg. ACTIVE#INACTIVE
	 * @param strDropdownName : Name/Label of dropdown eg. status
	 */

	public void GUI_checkDropdownValues(String strDropdownLocator, String strOptions, String strDropdownName) {

		try {
			boolean flag = false;

			String[] strOptionList = strOptions.split("#");

			int length = strOptionList.length;
			Select select = new Select(driver.findElement(By.xpath(actions.getLocator(strDropdownLocator))));

			List<WebElement> options = select.getOptions();

			Iterator iterate = options.iterator();

			WebElement value;

			while (iterate.hasNext()) {
				value = (WebElement) iterate.next();

				// comparing all values

				for (int i = 0; i < length; i++) {
					if (value.getText().equalsIgnoreCase(strOptionList[i])) {
						flag = true;
						break;
					}

					else {
						flag = false;

					}
				}
			}

			strOptions = strOptions.replace("#", ",");

			if (flag) {
				actions.reportCreatePASS("To verify that \"" + strDropdownName + "\" contains \"" + strOptions + "\" values", "\"" + strDropdownName + "\" should contain \"" + strOptions + "\" values", "\"" + strDropdownName + "\" contains \"" + strOptions + "\" values", "PASS");
			} else {
				actions.reportCreateFAIL("To verify that \"" + strDropdownName + "\" contains \"" + strOptions + "\" values", "\"" + strDropdownName + "\" should contain \"" + strOptions + "\" values", "\"" + strDropdownName + "\" doesnt contains \"" + strOptions + "\" values", "FAIL");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/******
	 * Function for checking default value of a dropdown
	 * 
	 * @param strDropdownLocator : locator of dropdown
	 * @param strDefaultValue : Default value of dropdrown
	 * @param strDropdownName : Name/Label of dropdown eg. status
	 */

	public void GUI_CheckDefaultDrpdownValue(String strDropdownLocator, String strDefaultValue, String strDropdownName) {
		String defaultValue = "";
		try {
			Select select = new Select(driver.findElement(By.xpath(actions.getLocator(strDropdownLocator))));

			WebElement selectedOption = select.getFirstSelectedOption();

			defaultValue = selectedOption.getText();

		} catch (Exception e) {
			defaultValue = driver.findElement(By.xpath(actions.getLocator(strDropdownLocator))).getAttribute("Value");
		}

		if (defaultValue.equalsIgnoreCase(strDefaultValue)) {
			actions.reportCreatePASS("To verify that '" + strDefaultValue + "' is default selected value of '" + strDropdownName + "' dropdown ", "'" + strDefaultValue + "' should be default selected value of '" + strDropdownName + "' dropdown", "'" + strDefaultValue + "' is default selected value of '" + strDropdownName + "' dropdown", "PASS");
		} else {
			actions.reportCreateFAIL("To verify that '" + strDefaultValue + "' is default selected value of '" + strDropdownName + "' dropdown ", "'" + strDefaultValue + "' should be default selected value of '" + strDropdownName + "' dropdown", "'" + strDefaultValue + "' is not default selected value of '" + strDropdownName + "' dropdown", "FAIL");
		}

	}

	/*****************
	 * Function for check in default radio button selected
	 * 
	 * @param eLocatorRadioLocator : locator of radio button
	 * @param strRadioName : name\label of radio button
	 */
	public void GUI_checkDefaultRBtnSelected(String eLocatorRadioLocator, String strRadioName) {
		Boolean NowRBtnSelected = false;
		try {
			NowRBtnSelected = driver.findElement(By.xpath(actions.getLocator(eLocatorRadioLocator))).isSelected();
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (NowRBtnSelected) actions.reportCreatePASS("Verify that '" + strRadioName + "' radio button is selected by default", "'" + strRadioName + "' radio button should be selected by default", "'" + strRadioName + "' radio button is selected by default", "Pass");

		else actions.reportCreateFAIL("Verify that '" + strRadioName + "' radio button is selected by default", "'" + strRadioName + "' radio button should be selected by default", "'" + strRadioName + "' radio button is not selected by default", "Fail");

	}

	/*****************
	 * Function to select particular number of rows from table
	 * 
	 * @param strAvailableListArea- locator of available list area in table
	 * @param eLocatorViewFullList -Locator of View Full List
	 * @param NoOfRow- number of rows
	 * @param eLocatorTransferLeftSelected-Locator of > button In many places Search without criteria functions as View Full list button
	 */
	public void SelectParticularNoOfRows(String eLocatorViewFullList, String eLocatorListArea, int NoOfRows, String eLocatorTransferLeftSelected) {
		// Click on View Full List button

		actions.click(eLocatorViewFullList);

		actions.smartWait(120);

		for (int i = 0; i < NoOfRows; i++) {
			mcd.select_row(eLocatorListArea, i);
		}
		actions.click(eLocatorTransferLeftSelected);
	}

	/*****************
	 * Function to search and move searched record to Selected list area
	 * 
	 * @param strSearchButton -Locator of Search button
	 * @param eLocatorAvailableListArea- locator of available list area in table
	 * @param eLocatorTransferLeftSelected-Locator of > button
	 * @param strSearchCriteria-Search criteria
	 */
	public void TransferSearchedRecords(String eLocatorSearchButtonLocator, String eLocatorAvailableListArea, String eLocatorSearchTextField, String strSearchCriteria, String eLocatorTransferLeftSelected) {

		// Enter search criteria
		actions.setValue(eLocatorSearchTextField, strSearchCriteria);

		// Click on Search button
		actions.click(eLocatorSearchButtonLocator);
		actions.smartWait(120);

		mcd.select_row(eLocatorAvailableListArea, 0);
		actions.click(eLocatorTransferLeftSelected);

	}

	/*****************
	 * Function to select particular number of stores in hierarchy
	 * 
	 * @param strCountryOrReg -Name of Country or region displayed in hierarchy e.g.New Zealand,Region
	 * @param strCoop -Name of Coop displayed in hierarchy e.g.OZARK Coop ..applicable for US market
	 * @param eLocatorAvailableListArea- locator of available list area in table
	 * @param NoOfRestToSelect-Number of restaurant to be selected
	 * @param strMarket-Market whether it is US or Australasia
	 */
	public void TransferNoOfRest(String strCountryOrReg, String eLocatorAvailableListArea, String NoOfRestToSelect, String strMarketName, String strCoop) {
		WebElement eleMarketTree = actions.getwebDriverLocator(actions.getLocator(eLocatorAvailableListArea));

		if (strMarketName.equalsIgnoreCase("US Country Office")) {
			// Need to expand region and then coop
			eleMarketTree.findElement(By.xpath("//tr[@name='" + strCountryOrReg + "']/td/span[@class='plusClosed']")).click();
			eleMarketTree.findElement(By.xpath("//tr[@name='" + strCoop + "']/td/span[@class='plusClosed']")).click();
		} else

		{
			eleMarketTree.findElement(By.xpath("//tr[@name='" + strCountryOrReg + "']/td/span[@class='plusClosed']")).click();
		}
		int RowsCount = Integer.parseInt(NoOfRestToSelect);
		try {
			if (strMarketName.equalsIgnoreCase("US Country Office")) {
				for (int i = 1; i <= RowsCount; i++) {
					driver.findElement(By.xpath("//tr[@levelname='Store'][" + i + "]/td/span/span")).click();
				}
			} else {
				for (int i = 1; i <= RowsCount; i++) {
					driver.findElement(By.xpath("//tr[@levelname='Restaurant'][" + i + "]/td/span/span")).click();
				}
			}
		} catch (Exception e) {

			System.out.println("Provided number of stores does not exists under exapnded " + strCountryOrReg + "Node");
		}
	}

	/**
	 * Function : To update a specific tag in the ADMIN > Application Settings > Update Settings module (For Menu Item Set only ) Parameter : strTagValue : Tag
	 * value to be set Example : True/False/0/1/2 etc. : strTagName1 : Name of the tag to be updated
	 */
	public void RFM_MenuItem_Update_PricingTags(String strTagValue, String strTagName1) throws InterruptedException {

		// Check for parameters :
		// General :
		// automatically-fill-price-type-attribute-option-price-value =
		// automatically-fill-price-type-attribute-option-tax-value =
		boolean blncountine = false;
		boolean flag = false;
		int cnt = 3;
		int i = 0;
		List<WebElement> Parameter_Lists = driver.findElements(By.xpath("//*[@id='ApplicationParameters']/tr/td[2]/b"));

		for (i = 0; i < Parameter_Lists.size(); i++) {
			String curr_parameter = Parameter_Lists.get(i).getText();

			// Check whether section name is "General"
			if (curr_parameter.equals("Menu Item")) {
				/* Santosh 7thJuly2016: added the below try catch block, because earlier it is not validating whether that general setting is expanded or
				 * collapsed. */
				try {
					flag = driver.findElement(By.xpath("//*[@id='ApplicationParameters']/tr[" + cnt + "]/td[1]/img[contains(@src,'plus')]")).isDisplayed();
				} catch (Exception e) {
					flag = false;
				}
				if (flag) {
					driver.findElement(By.xpath("//*[@id='ApplicationParameters']/tr[" + cnt + "]/td[1]/img")).click();
				}
				Thread.sleep(1000);
				break;
			} else {
				cnt = cnt + 2;
			}
		}

		// Get row counts of parameters displayed
		int p_rows = mcd.GetTableRowCount("UpdateSettings.menuItemDataTable");
		String tag = null;
		String curr_val = null;
		String new_val = null;
		int iTemp = 0;
		int tag_cnt = 0;
		Thread.sleep(1000);
		// Check for the mentioned 2 tags & check whether they are set to expected value
		for (int j = 1; j <= p_rows; j++) {
			tag = driver.findElement(By.xpath("//*[@id='div" + (i + 2) + "']//tr[" + j + "]/td[1]")).getText();
			Thread.sleep(1000);
			if (tag.equals(strTagName1)) {
				curr_val = driver.findElement(By.xpath("//*[@id='div" + (i + 2) + "']//tr[" + j + "]/td[2]/input")).getAttribute("value");

				if (curr_val.equalsIgnoreCase(strTagValue)) {
					// Reporter.log(tag+" - Tag value is already set to "+strTagValue);
					blncountine = true;
					System.out.println("blncountine value is true now ");
				} else {
					driver.findElement(By.xpath("//*[@id='div" + (i + 2) + "']//tr[" + j + "]/td[3]/input")).sendKeys(strTagValue);
				}
				break;
			}

		}

		// Save the changes
		System.out.println(blncountine);
		Thread.sleep(1000);
		actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
		actions.javaScriptClick("UpdateSettings.SaveBtn");
		if (blncountine != false) {
			mcd.VerifyAlertMessageDisplayed("Warning Message", "No changes have been made", true, AlertPopupButton.OK_BUTTON);
		}
		Thread.sleep(2000);
		if (blncountine != true) {
			System.out.println("Verify text presesence - bln value is false");
			actions.verifyTextPresence("Your changes have been saved and cache is refreshed.", false);
		}
		// Verify tag values - whether changes are reflected correctly

		for (int j = 1; j <= p_rows; j++) {
			tag = driver.findElement(By.xpath("//*[@id='div" + (i + 2) + "']//tr[" + j + "]/td[1]")).getText();

			if (tag.equals(strTagName1)) {
				new_val = driver.findElement(By.xpath("//*[@id='div" + (i + 2) + "']//tr[" + j + "]/td[2]/input")).getAttribute("value");

				if (new_val.equalsIgnoreCase(strTagValue)) {
					// Reporter.log(tag+" - Tag value is correctly updated - PASS");
					System.out.println(tag + " - Tag value is correctly updated - PASS");
					// System.out.println("Tag 1 value correctly updated");
				} else {
					// Reporter.log(tag+" - Tag value is incorrectly updated - FAIL");
					System.out.println(tag + " - Tag value is incorrectly updated - FAIL");
				}
			}

		}
	}

	// =============

	public void RFM_MenuItem_Update_GeneralTags(String strTagValue, String strTagName1) throws InterruptedException {

		// Check for parameters :
		// General :
		// automatically-fill-price-type-attribute-option-price-value =
		// automatically-fill-price-type-attribute-option-tax-value =
		boolean blncountine = false;
		boolean flag = false;
		int cnt = 3;
		int i = 0;
		List<WebElement> Parameter_Lists = driver.findElements(By.xpath("//*[@id='ApplicationParameters']/tr/td[2]/b"));

		for (i = 0; i < Parameter_Lists.size(); i++) {
			String curr_parameter = Parameter_Lists.get(i).getText();

			// Check whether section name is "General"
			if (curr_parameter.equals("General")) {
				/* Santosh 7thJuly2016: added the below try catch block, because earlier it is not validating whether that general setting is expanded or
				 * collapsed. */
				try {
					flag = driver.findElement(By.xpath("//*[@id='ApplicationParameters']/tr[" + cnt + "]/td[1]/img[contains(@src,'plus')]")).isDisplayed();
				} catch (Exception e) {
					flag = false;
				}
				if (flag) {
					driver.findElement(By.xpath("//*[@id='ApplicationParameters']/tr[" + cnt + "]/td[1]")).click();
				}
				Thread.sleep(1000);
				break;
			} else {
				cnt = cnt + 2;
			}
		}

		// Get row counts of parameters displayed
		int p_rows = mcd.GetTableRowCount("UpdateSettings.menuItemDataTable");
		String tag = null;
		String curr_val = null;
		String new_val = null;
		int iTemp = 0;
		int tag_cnt = 0;
		Thread.sleep(1000);
		// Check for the mentioned 2 tags & check whether they are set to expected value
		for (int j = 1; j <= p_rows; j++) {
			tag = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[1]")).getText();
			Thread.sleep(1000);
			if (tag.equals(strTagName1)) {
				curr_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input")).getAttribute("value");

				if (curr_val.equalsIgnoreCase(strTagValue)) {
					// Reporter.log(tag+" - Tag value is already set to "+strTagValue);
					blncountine = true;
					System.out.println("blncountine value is true now ");
				} else {
					driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[3]/input")).sendKeys(strTagValue);
				}
				break;
			}

		}

		// Save the changes
		System.out.println(blncountine);
		Thread.sleep(1000);

		actions.click("UpdateSettings.SaveBtn");
		if (blncountine != false) {
			mcd.VerifyAlertMessageDisplayed("Warning Message", "No changes have been made", true, AlertPopupButton.OK_BUTTON);
		}
		Thread.sleep(2000);
		if (blncountine != true) {
			System.out.println("Verify text presesence - bln value is false");
			actions.verifyTextPresence("Your changes have been saved and cache is refreshed.", false);
		}
		// Verify tag values - whether changes are reflected correctly

		for (int j = 1; j <= p_rows; j++) {
			tag = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[1]")).getText();

			if (tag.equals(strTagName1)) {
				new_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input")).getAttribute("value");

				if (new_val.equalsIgnoreCase(strTagValue)) {
					// Reporter.log(tag+" - Tag value is correctly updated - PASS");
					System.out.println(tag + " - Tag value is correctly updated - PASS");
					// System.out.println("Tag 1 value correctly updated");
				} else {
					// Reporter.log(tag+" - Tag value is incorrectly updated - FAIL");
					System.out.println(tag + " - Tag value is incorrectly updated - FAIL");
				}
			}

		}
	}

	// =============

	// Create a promotion
	// Used in MNU_1258, MNU_1254 for pre-requisite development.
	// Author : Pooja Panse

	public void RFM_CreatePromotion(String strTemplateName, String strDispenserTarget, String strNodeNum, String strNamePrefix, String strApplicationDate, String strMessage1, String strSuccessMsg) throws Exception {
		// Click on New Promotion button
		actions.keyboardEnter("PromotionMgmt.NewPromotionBtn");
		Thread.sleep(2000);
		actions.waitForPageToLoad(180);

		// Switch to New Window : Add New Promotion
		mcd.SwitchToWindow("Add New Promotion");

		// Select Template
		// actions.setValue("PromotionMgmt.TemplateList", strTemplateName);

		Select select = new Select(driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.TemplateList"))));
		for (int i = 1; i < select.getOptions().size(); i++) {
			System.out.println(select.getOptions().get(i).getText().trim());
			if ((select.getOptions().get(i).getText().trim().equalsIgnoreCase(strTemplateName))) {
				select.selectByIndex(i);
				break;
			}
		}

		// Set Promotion Name
		String strNewPromName = mcd.fn_GetRndName(strNamePrefix).substring(0, 10);
		actions.setValue("PromotionMgmt.PromName", strNewPromName);

		// Select Node
		// Select a Restaurant
		actions.keyboardEnter("PromotionMgmt.SelectNode");

		Thread.sleep(2000);

		mcd.waitAndSwitch("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);
		actions.setValue("SelectNode.SearchBox", strNodeNum);
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");

		Thread.sleep(3000);
		actions.waitForPageToLoad(120);

		Boolean blnSelectNode = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);
		if (blnSelectNode) {
			actions.reportCreatePASS("Verify Node Selection", "Node should be selected", "Node selected", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Node Selection", "Node should be selected", "Node not selected", "FAIL");
		}

		// Switch back to Add new
		mcd.SwitchToWindow("Add New Promotion");

		// Click Next
		actions.keyboardEnter("RFM.NextBtn");

		// Switch title
		// driver.switchTo().window("");
		mcd.waitAndSwitch("Promotion");
		// mcd.SwitchToWindow("Promotion");

		actions.WaitForElementPresent("PromotionMgmt.PromCode", 180);

		// Enter Prom Code
		// Generate a random code
		Random rand_num = new Random();
		int iPromCode = rand_num.nextInt((500) + 50);

		driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.PromCode"))).sendKeys(Integer.toString(iPromCode));

		// Enter From date
		driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.FromCalender"))).click();
		mcd.Get_future_date(0, "close", strApplicationDate);

		// Enter To Date
		driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.ToCalender"))).click();
		mcd.Get_future_date(3, "close", strApplicationDate);

		// Check the target dispenser check box
		if (strDispenserTarget.equalsIgnoreCase("Yes")) {
			driver.findElement(By.xpath(actions.getLocator("PromotionManagement.PPTargetPrmCheckBox"))).sendKeys(Keys.SPACE);
		}

		// Click Next
		actions.keyboardEnter("RFM.NextBtn");

		// Try if promo code is duplicate
		Boolean blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Error", strMessage1, true, AlertPopupButton.OK_BUTTON);
			Thread.sleep(2000);
			// Generate a random code
			rand_num = new Random();
			iPromCode = rand_num.nextInt((500) + 50);

			driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.PromCode"))).sendKeys(Integer.toString(iPromCode));
			Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println("No Errors");
		}

		// Add the money back amount
		actions.WaitForElementPresent("Promotion.MoneyBackAmount", 180);
		actions.setValue("Promotion.MoneyBackAmount", "1");

		// click on next
		actions.click("AddPromotion.NextP");
		actions.smartWait(10);
		actions.keyboardEnter("Promotion.Save");

		actions.smartWait(30);

		actions.verifyTextPresence(strSuccessMsg, true);

		actions.keyboardEnter("RFM.CancelBtn");
		Thread.sleep(2000);
		actions.smartWait(30);
	}

	/**
	 * Function created to Wait & Verify whether the Report is generated in View Generated Reports Module
	 * 
	 * @return boolean value true : if report is generated, false : if report is in in-process/not generated state
	 * @throws InterruptedException
	 */

	public boolean fn_WaitForReportGeneration() throws InterruptedException {
		// Iterator implemented for waiting for the in-process state of report to change to Generated
		int iterator = 0;
		String temp = mcd.gblTestData.get("StepTimeOut");
		int time = Integer.parseInt(temp);
		int val = 3000 / time;
		int tempMin = time / 60;
		boolean switchFlag = false;
		int i = 0;
		String Status = null;

		do {
			// Replacing actions.click as want to avoid reporting as this is just to verify whether the report is generated or not.
			driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReports.DateTimeLink"))).click();
			Thread.sleep(3000);
			driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReports.DateTimeLink"))).click();
			Thread.sleep(3000);
			Status = mcd.GetTableCellValue("ViewGeneratedReport.ContentTable_1", 1, 2, "", "");
			Status = Status.trim();
			i = i + 1;
			Thread.sleep(3000);
			System.out.println(i);
			iterator = iterator + 3;
			System.out.println("Status still in-progress, will wait few more seconds");

		} while ((iterator <= val) && (!(Status.equals("Generated"))));

		if ((!(Status.equals("Generated")))) {
			switchFlag = false;
		} else {
			switchFlag = true;
		}
		return switchFlag;
	}

	/**
	 * @author Shahid Sayyad
	 * @param listLocator - ListLocator is xpath for the list we want to verify
	 * @return True if list is in Ascending order or false if list is not sorted
	 */
	public Boolean verifySorting(String listLocator) {

		boolean isListSorted = true;

		try {

			LinkedList<String> autoBindNumberList = new LinkedList<String>();
			List<WebElement> numberElementList = driver.findElements(By.xpath(actions.getLocator(listLocator)));

			for (WebElement autoBindNumber : numberElementList) {

				autoBindNumberList.add(autoBindNumber.getText().toLowerCase());
			}

			// System.out.println("List after clicking is : "+autoBindNumberList);
			String previousAutoBindNumber = "";

			if (numberElementList.isEmpty()) {
				isListSorted = false;
			} else {
				for (final String currentRoleName : autoBindNumberList) {

					if (currentRoleName.compareTo(previousAutoBindNumber) < 0) {
						isListSorted = false;
						System.out.println("Current String and Previous String are not in ascending");
						System.out.println("Current String : " + currentRoleName);
						System.out.println("Previous String : " + previousAutoBindNumber);
						break;
					}

					previousAutoBindNumber = currentRoleName;
				}
			}

			return isListSorted;

		} catch (Exception e) {

			return isListSorted;
		}
	}

	/**
	 * @author Shahid Sayyad
	 * @param listLocator - ListLocator is xpath for the list we want to verify
	 * @return True if list is in Ascending order or false if list is not sorted
	 */
	public Boolean verifyNumberSorting(String listLocator) {

		boolean isListSorted = true;

		try {

			LinkedList<Integer> autoBindNumberList = new LinkedList<Integer>();
			List<WebElement> numberElementList = driver.findElements(By.xpath(actions.getLocator(listLocator)));

			for (WebElement autoBindNumber : numberElementList) {

				autoBindNumberList.add(Integer.parseInt(autoBindNumber.getText().trim()));
			}

			// System.out.println("List after clicking is : "+autoBindNumberList);
			int previousAutoBindNumber = 0;

			if (numberElementList.isEmpty()) {
				isListSorted = false;
			} else {
				for (final int currentRoleName : autoBindNumberList) {
					if (currentRoleName < previousAutoBindNumber) {
						isListSorted = false;
						System.out.println("Current Number is less than previous number");
						System.out.println("Current Number : " + currentRoleName);
						System.out.println("Previous Number : " + previousAutoBindNumber);
						break;
					}

					previousAutoBindNumber = currentRoleName;
				}
			}

			return isListSorted;

		} catch (Exception e) {

			return isListSorted;
		}
	}

	/**
	 * This function schedules the new package by navigating to ADMIN>Package Management>Package Schedule [Pre-requisite: User should be on Package Schedule
	 * page ]
	 * 
	 * @param strRestNumber is restaurant number
	 */
	public void scheduleNewPackage(String strRestNumber, String Message) {

		try {

			// Click on New package schedule button
			actions.WaitForElementPresent("PackageStatusReport.NBNewPackageScheduleButton");
			actions.keyboardEnter("PackageStatusReport.NBNewPackageScheduleButton");
			actions.smartWait(180);

			// Schedule a package for a restaurant by selecting Generate Now option
			Thread.sleep(3000);
			actions.javaScriptClick("PackageSchedule.NBGenerateNowRButton");
			actions.setValue("RFMSelectNode.SearchEditbox", strRestNumber);
			actions.keyboardEnter("RFMSelectNode.SearchButton");

			mcd.Selectrestnode_JavaScriptClk("RFMHome.LeftTable", strRestNumber);
			actions.click("RFMHome.Button>");
			actions.click("UpdatePromotionGroup.Apply");
			Thread.sleep(2000);
			mcd.smartsync(180);
			// add verification to check if changes have been saved or not
			try {
				String successMessage = actions.getWebElement("GlobalLookup.SuccessMessage").getText();
				boolean isPackageSaved = successMessage.equalsIgnoreCase(Message);

				if (isPackageSaved) {
					actions.reportCreatePASS("Schedule a package for a restaurant by selecting Generate Now option", "Package should get scheduled for selected restaurant ", "Package is scheduled for selected restaurant ", "Pass");
				} else {
					actions.reportCreateFAIL("Schedule a package for a restaurant by selecting Generate Now option", "Package should get scheduled for selected restaurant ", "Package is not scheduled for selected restaurant ", "Fail");
				}
			} catch (Exception e) {
				actions.reportCreateFAIL("Schedule a package for a restaurant by selecting Generate Now option", "Package should get scheduled for selected restaurant ", "Package is not scheduled for selected restaurant ", "Fail");
			}

		} catch (Exception e) {
			actions.reportCreateFAIL("Schedule a package for a restaurant by selecting Generate Now option", "Package should get scheduled for selected restaurant ", "Exception occured while scheduling package for selected restaurant", "Fail");
		}
	}

	// Created by: Smita Kolate
	// Date:21 Dec 2016
	// Function is used in approve restaurant scripts
	public void verifyGUIElementsOnApproveRestaurantPage() {

		GUI_ObjectDisplayedValidation("ApproveRestaurant.FromDateField", "From Date TextBox");
		GUI_ObjectDisplayedValidation("ApproveRestaurant.FromDateWidget", "From Date Calendar Widget");
		GUI_ObjectDisplayedValidation("ApproveRestaurant.ToDateField", "To Date TextBox");
		GUI_ObjectDisplayedValidation("ApproveRestaurant.ToDateWidget", "To Date Calendar Widget");
		GUI_ObjectDisplayedValidation("ApproveRestaurant.SelectSearchOptionLabel", "Select Search Option Lable");
		GUI_ObjectDisplayedValidation("ApproveRestaurant.ContainsRadio", "Contains Radio Button");
		GUI_ObjectDisplayedValidation("ApproveRestaurant.ExactMatchRadio", "Exact Match Radio Button");

		verifyGUILabelPresent("ApproveRestaurant.SearchbyRestaurantNumberorNameLabel", "Search by Restaurant Number or Name");
		GUI_ObjectDisplayedValidation("ApproveRestaurant.SearchTextBox", "Search TextBox");
		GUI_ObjectDisplayedValidation("ApproveRestaurant.SearchButton", "Search Button");
		GUI_ObjectDisplayedValidation("ApproveRestaurant.ViewFullListBtn", "View Full List Button");
		verifyGUILabelPresent("ApproveRestaurant.ImportIndicatorLabel", "import indicator");
		GUI_ObjectDisplayedValidation("ApproveRestaurant.IndicatorDDL", "Import Indicator DDL");

		Select importIndicatorDDL = new Select(driver.findElement(By.xpath(actions.getLocator("ApproveRestaurant.IndicatorDDL"))));
		String defaultSelectedValue = importIndicatorDDL.getFirstSelectedOption().getText();
		if (defaultSelectedValue.equalsIgnoreCase("All")) {
			actions.reportCreatePASS("Verify default selected value in import indicator DDL", "All should be selected by default in DDL", "All is selected by default in DDL", "Pass");
		} else {
			actions.reportCreateFAIL("Verify default selected value in import indicator DDL", "All should be selected by default in DDL", "All is NOT selected by default in DDL", "Fail");
		}

		verifyTablecolumnsPresent("ApproveRestaurant.ApproveRestTable", "Number");
		verifyTablecolumnsPresent("ApproveRestaurant.ApproveRestTable", "Name");
		verifyTablecolumnsPresent("ApproveRestaurant.ApproveRestTable", "Date");
		verifyTablecolumnsPresent("ApproveRestaurant.ApproveRestTable", "Indicator");
		verifyTablecolumnsPresent("ApproveRestaurant.ApproveRestTable", "Approve");

	}

	// Created by: Smita Kolate
	// Date:21 Dec 2016
	// Function is used in approve restaurant scripts
	public void verifyGUILabelPresent(String eleLocator, String eleName) {

		String importIndicatorLabel = driver.findElement(By.xpath(actions.getLocator(eleLocator))).getText();

		if (importIndicatorLabel.toLowerCase().contains(eleName.toLowerCase())) {

			actions.reportCreatePASS("Verify " + eleName + "Label is present'", eleName + " Label should be present", eleName + " Label is present", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + eleName + "Label is present'", eleName + " Label should be present", eleName + " Label is NOT present", "Fail");
		}
	}

	// Created by: Smita Kolate
	// Date:21 Dec 2016
	// Function is used in approve restaurant scripts
	public void verifyTablecolumnsPresent(String tableLocator, String colName) {

		boolean iscolPresent = mcd.RFM_VerifyTableColumns(tableLocator, colName);

		if (iscolPresent) {
			actions.reportCreatePASS("Verify " + colName + " Column is present in Approve Restaurant Table", colName + " Column should be present in Approve Restaurant Table", colName + " Column is present in Approve Restaurant Table", "Pass");
		} else {
			actions.reportCreateFAIL("Verify " + colName + " Column is present in Approve Restaurant Table", colName + " Column should be present in Approve Restaurant Table", colName + " Column is NOT present in Approve Restaurant Table", "Fail");
		}
	}

	// Created by : Rehanshu
	// Date:01/02/2017
	// Function is use to update tag value for Promotoins in Update Settings window

	/**
	 * Function : To update a specific tag in the ADMIN > Update Settings module (For Promotions Set only ) Parameter : strTagValue : Tag value to be set
	 * Example : True/False/0/1/2 etc. : strTagName1 : Name of the tag to be updated
	 */
	public void RFM_Admin_Update_PromotionsTag(String strTagValue, String strTagName1) throws InterruptedException {

		// Check for parameters :
		// Promotions :
		// Sale Amount: Maximum number of Exclude Items =
		// Sale Item: Maximum number of Exclude Items =
		boolean blncountine = false;
		boolean flag = false;
		int cnt = 3;
		List<WebElement> Parameter_Lists = driver.findElements(By.xpath("//*[@id='test']/table[3]/tbody/tr[1]/td[1]/b"));

		for (int i = 0; i < Parameter_Lists.size(); i++) {
			String curr_parameter = Parameter_Lists.get(i).getText().trim();

			// Check whether section name is "General"
			if (curr_parameter.equals("Promotions")) {
				try {
					flag = driver.findElement(By.xpath("//*[@id='test']/table[3]/tbody/tr[1]/td[1]//img[contains(@src,'plus')]")).isDisplayed();
				} catch (Exception e) {
					flag = false;
				}
				if (flag) {
					driver.findElement(By.xpath("//*[@id='test']/table[3]/tbody/tr[1]/td[1]//img[contains(@src,'plus')]")).click();
				}
				Thread.sleep(1000);
				break;
			} else {
				cnt = cnt + 2;
			}
		}

		// Get row counts of parameters displayed
		int p_rows = mcd.GetTableRowCount("PromotionManagement.PromotionsTblInUpdateSetng");
		String tag = null;
		String curr_val = null;
		String new_val = null;
		int iTemp = 0;
		int tag_cnt = 0;
		Thread.sleep(1000);
		// Check for the mentioned 2 tags & check whether they are set to expected value //*[@id='divPromotionsExtension']/tbody/tr[1]/td[1]
		for (int j = 1; j <= p_rows; j++) {
			tag = driver.findElement(By.xpath("//*[@id='divPromotionsExtension']/tbody/tr[" + j + "]/td[1]")).getText();
			Thread.sleep(1000);
			if (tag.equals(strTagName1)) {
				curr_val = driver.findElement(By.xpath("//*[@id='divPromotionsExtension']/tbody/tr[" + j + "]/td[2]/input")).getAttribute("value");

				if (curr_val.equalsIgnoreCase(strTagValue)) {
					// Reporter.log(tag+" - Tag value is already set to "+strTagValue);
					blncountine = true;
					System.out.println("blncountine value is true now ");
				} else {
					driver.findElement(By.xpath("//*[@id='divPromotionsExtension']/tbody/tr[" + j + "]/td[3]/input")).sendKeys(strTagValue);
				}
				break;
			}

		}

		// Save the changes
		System.out.println(blncountine);
		Thread.sleep(1000);

		actions.click("RFMUpdateLocalizationSet.SaveButton");
		if (blncountine != false) {
			mcd.VerifyAlertMessageDisplayed("Warning Message", "No changes have been made", true, AlertPopupButton.OK_BUTTON);
		}
		Thread.sleep(2000);
		if (blncountine != true) {
			System.out.println("Verify text presesence - bln value is false");
			actions.verifyTextPresence("Your changes have been saved and cache is refreshed.", false);
		}
		// Verify tag values - whether changes are reflected correctly

		for (int j = 1; j <= p_rows; j++) {
			tag = driver.findElement(By.xpath("//*[@id='divPromotionsExtension']/tbody/tr[" + j + "]/td[1]")).getText();

			if (tag.equals(strTagName1)) {
				new_val = driver.findElement(By.xpath("//*[@id='divPromotionsExtension']/tbody/tr[" + j + "]/td[2]/input")).getAttribute("value");

				if (new_val.equalsIgnoreCase(strTagValue)) {
					// Reporter.log(tag+" - Tag value is correctly updated - PASS");
					System.out.println(tag + " - Tag value is correctly updated - PASS");
					// System.out.println("Tag 1 value correctly updated");
				} else {
					// Reporter.log(tag+" - Tag value is incorrectly updated - FAIL");
					System.out.println(tag + " - Tag value is incorrectly updated - FAIL");
				}
			}

		}
	}
}

// =============

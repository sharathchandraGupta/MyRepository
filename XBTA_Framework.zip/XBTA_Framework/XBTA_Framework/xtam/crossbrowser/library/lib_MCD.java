package crossbrowser.library;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.apache.commons.exec.ExecuteException;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.thoughtworks.selenium.webdriven.commands.WaitForCondition;

import crossbrowser.helper.PropertyReader;

public class lib_MCD {
	private WebDriver driver;
	private Keywords actions;
	private Map input;
	private UIValidations uiActions;
	private List<Boolean> flags;

	private List<String> strListWindowHandle; // List all the windows displayed
												// or closed during current
												// session (for
												// switch-to-window)
	private List<String> strListWindowTitle; // List Titles of all the windows
												// displayed or closed during
												// current session (for
												// switch-to-window)
	private int intWindowHandleIndex = -1; // List index of the current window
											// (for switch-to-window)

	public HashMap<String, String> gblTestData; // Global test-data values from
													// 'GlobalConfigurations.txt'
													// file

	public enum AlertPopupButton {
		OK_BUTTON, CANCEL_BUTTON;
	}

	public String gPlatform = "";
	public String gBrowserName = "";
	public String gBrowserVersion = "";
	public String gInstance = "";

	public String gTestReport = "";

	public lib_MCD(WebDriver driver, Keywords actions2, UIValidations uiActions, Map inputData) {
		this.driver = driver;
		this.actions = actions2;
		this.uiActions = uiActions;
		this.input = inputData;

		// Read global Test-Data
		gblTestData = new HashMap<String, String>();
		File gblFile = new File("crossbrowser.properties");
		if (gblFile.exists() && !gblFile.isDirectory()) {
			// try {
			//// Scanner gblFileScnr = new Scanner(gblFile);
			//// while (gblFileScnr.hasNext()) {
			//// String strGblTDLine = gblFileScnr.nextLine();
			//// if (! strGblTDLine.trim().startsWith("'")) {
			//// String strTDName = strGblTDLine.substring(0,
			// strGblTDLine.indexOf(":")).trim().toUpperCase();
			//// String strTDValue =
			// strGblTDLine.substring(strGblTDLine.indexOf(":") +1).trim();
			////
			//// gblTestData.put(strTDName, strTDValue);
			//// }
			//// }
			//// gblFileScnr.close();
			////
			gblTestData = PropertyReader.getAllProperty();
			// } catch (FileNotFoundException e) {
			// System.out.println("Error reading global test-data file
			// 'assets/TestData/GlobalConfigurations.txt'");
			// e.printStackTrace();
			// }
		} else {
			System.out.println("Global test-data file ('assets/TestData/GlobalConfigurations.txt') is missng");
		}
		System.out.println("Global Test-Data : " + gblTestData);

		Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
		this.gPlatform = cap.getPlatform().toString();
		this.gBrowserName = cap.getBrowserName().toString();
		this.gBrowserVersion = cap.getVersion().toString();
		this.gInstance = gPlatform + "-" + gBrowserName + " v" + gBrowserVersion;
		System.out.println("mcd : " + gInstance);

		this.gTestReport = InitializeReport();

		this.strListWindowHandle = new ArrayList<>();
		this.strListWindowTitle = new ArrayList<>();
	}

	/*
	 * =========================================================================
	 * ============================================ Execution Report
	 */

	public String InitializeReport() {
		String blnResult = "";

		System.out.println("Generate report for " + this.gInstance + " and update report object");
		return blnResult;
	}

	/*
	 * =========================================================================
	 * ============================================ Table Element
	 */

	/**
	 * Get number of rows in given table element
	 * 
	 * @param strTableElement
	 * @return
	 */
	public int GetTableRowCount(String strTableElement) {
		int intReturn;
		try {
			WebElement eleTable = actions.getwebDriverLocator(actions.getLocator(strTableElement));
			List<WebElement> eleRows = eleTable.findElements(By.xpath(".//tbody/tr"));
			intReturn = eleRows.size();
		} catch (Exception e) {
			intReturn = -1;
		}
		return intReturn;
	}

/** 
* Description: This Function returns number of rows present in "thead" tag. This is used if data is
*present in "thead" rather than "tbody".
* @param strTableElement 
* @return 
*/ 
        public int GetTableRowCountForThead(String strTableElement) { 
                int intReturn; 
                try { 
                        WebElement eleTable = actions.getwebDriverLocator(actions.getLocator(strTableElement)); 
                        List<WebElement> eleRows = eleTable.findElements(By.xpath(".//thead/tr")); 
                        intReturn = eleRows.size(); 
                } catch (Exception e) { 
                        intReturn = -1; 
                } 
                return intReturn; 
        }
	/**
	 * Get number of columns in given table element
	 * 
	 * @param strTableElement
	 * @return
	 */
	public int GetTableColumnCount(String strTableElement) {
		int intReturn = -1;

		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator(strTableElement));
		List<WebElement> eleCols = eleTable.findElements(By.xpath(".//thead/tr/th"));

		intReturn = eleCols.size();
		if (eleCols.size() == 0) {
			System.out.println("Header row not present. Checking column-count by reference of first row");
			eleCols = eleTable.findElements(By.xpath(".//thead/tr[1]/td"));
			intReturn = eleCols.size();
		}
		// Changed to handle table where thead is not present, tbody is present
		if (eleCols.size() == 0) {
			System.out.println("Header row not present. Checking column-count by reference of body");
			eleCols = eleTable.findElements(By.xpath(".//tbody/tr/th"));
			intReturn = eleCols.size();
		}
		// Changed to handle table where thead is not present, tbody is present
		// & element is in td
		if (eleCols.size() == 0) {
			System.out.println("Header row not present. Checking column-count by reference of body");
			eleCols = eleTable.findElements(By.xpath(".//tbody/tr[1]/td"));
			intReturn = eleCols.size();
		}
		return intReturn;
	}

	/**
	 * Get Row Number matching given search criteria
	 * 
	 * @param strTableElement
	 * @param strSearchColumns
	 *            : Name or number (prefix #) of the columns to search. Multiple
	 *            columns should be separated by "|"
	 * @param strSearchColumnValues
	 *            : Column values to search for. Multiple values should be
	 *            separated by "|" and should match with number columns in
	 *            strSearchColumns
	 * @param strSearchColumnElementTypes
	 *            : Element type of the columns which are to search. Multiple
	 *            values should be separated by "|" and should match with number
	 *            columns in strSearchColumns
	 * @return
	 */
	public int GetTableRowNumber(String strTableElement, String strSearchColumns, String strSearchColumnValues,
			String strSearchColumnElementTypes, String strSearchColumnElementAttributes) {
		int intReturn = -1;
		boolean blnColumnsFound = true;

		String[] arrColumnNames = strSearchColumns.replace("|", " | ").split("\\|");
		String[] arrColumnValues = strSearchColumnValues.replace("|", " | ").split("\\|");
		String[] arrElementTypes = strSearchColumnElementTypes.replace("|", " | ").split("\\|");
		String[] arrElementAttributes = strSearchColumnElementAttributes.replace("|", " | ").split("\\|");

		int intColNum = -1;
		String strColumnNumbers = "";
		String strColumnNotFound = "";
		String[] arrColumnNumbers;
		String strExptColValue = "";
		boolean blnEqualToFlag = true;
		boolean blnMatchWholeFlag = true;

		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator(strTableElement));

		// Get column numbers to check
		for (int i = 0; i < arrColumnNames.length; i++) {
			intColNum = GetTableColumnNumber(strTableElement, arrColumnNames[i].trim());
			if (intColNum != -1) {
				strColumnNumbers = strColumnNumbers + Integer.toString(intColNum) + "|";
			} else {
				strColumnNotFound = strColumnNotFound + ", " + arrColumnNames[i].trim();
				blnColumnsFound = false;
				break;
			}
		}
		if (blnColumnsFound = true) {
			arrColumnNumbers = strColumnNumbers.split("\\|");

			// Check for the required row
			String strColValue = "";
			int RowCount = GetTableRowCount(strTableElement);
			for (int rw = 1; rw <= RowCount; rw++) {
				for (int cl = 0; cl < arrColumnNumbers.length; cl++) {
					strColValue = GetTableCellValue(strTableElement, rw, Integer.parseInt(arrColumnNumbers[cl].trim()),
							arrElementTypes[cl].trim(), arrElementAttributes[cl].trim());

					// Get conditions for comparison
					strExptColValue = arrColumnValues[cl].trim() + "   ";

					if (strExptColValue.substring(0, 1).contains("@")) { // Check
																			// condition
																			// as
																			// 'CONTAINS'
						blnMatchWholeFlag = false;
						strExptColValue = strExptColValue.replaceFirst("@", "");
					}
					if (strExptColValue.substring(0, 1).contains("#")) { // Check
																			// condition
																			// as
																			// 'NOT-EQUAL-TO'
						blnEqualToFlag = false;
						strExptColValue = strExptColValue.replaceFirst("#", "");
					}

					// Check current column-value
					strExptColValue = strExptColValue.trim();
					if (blnMatchWholeFlag) {
						if (blnEqualToFlag) {
							if (strColValue.trim().equalsIgnoreCase(strExptColValue)) {
								blnColumnsFound = true;
							} else {
								blnColumnsFound = false;
								break;
							}
						} else {
							if (!strColValue.equalsIgnoreCase(strExptColValue)) {
								blnColumnsFound = true;
							} else {
								blnColumnsFound = false;
								break;
							}
						}
					} else {
						if (blnEqualToFlag) {
							if (strColValue.contains(strExptColValue)) {
								blnColumnsFound = true;
							} else {
								blnColumnsFound = false;
								break;
							}
						} else {
							if (!strColValue.contains(strExptColValue)) {
								blnColumnsFound = true;
							} else {
								blnColumnsFound = false;
								break;
							}
						}
					}
				}
				if (blnColumnsFound) {
					intReturn = rw;
					break;
				}
			}

		} else {
			strColumnNotFound = strColumnNotFound.replaceFirst(", ", "");
			System.out.println("Column(s) not found - " + strColumnNotFound);
		}
		return intReturn;
	}

	/**
	 * Get column-number for the given column
	 * 
	 * @param strTableElement
	 * @param strColumn
	 *            : Name or number (prefix #) of the column
	 * @return
	 */
	public int GetTableColumnNumber(String strTableElement, String strColumn) {
		int intReturn = -1;
		boolean blnFound = false;
		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator(strTableElement));
		int intCols = 0;
		String strColName = "";

		if (strColumn.trim().startsWith("#")) { // Column number is specified
			intReturn = Integer.parseInt(strColumn.trim().replace("#", ""));
			blnFound = true;

		} else { // Search for column number
			intCols = GetTableColumnCount(strTableElement);
			String strColXpath = "";

			for (int i = 1; i <= intCols; i++) {
				if (strColXpath == "")
					strColXpath = ".//thead/tr/th";
				try {
					strColName = eleTable.findElement(By.xpath(strColXpath + "[" + i + "]")).getText();
				} catch (Exception e) {
					strColXpath = ".//thead/tr/td";
					try {
						strColName = eleTable.findElement(By.xpath(strColXpath + "[" + i + "]")).getText();
					} catch (Exception e2) {
						strColXpath = ".//tbody/tr/th";
						try {
							strColName = eleTable.findElement(By.xpath(strColXpath + "[" + i + "]")).getText();
						} catch (Exception e3) {
							strColXpath = ".//tbody/tr/td";
							strColName = eleTable.findElement(By.xpath(strColXpath + "[" + i + "]")).getText();
						}
					}
				}
				if (strColName.trim().equalsIgnoreCase(strColumn)) {
					intReturn = i;
					blnFound = true;
					break;
				}
			}
			if (blnFound == false) {
				System.out.println("Column '" + strColumn + "' not found");
			}
		}
		return intReturn;
	}

	public String GetTableCellValue(String strTableElement, int intRow, int intCol, String strColumnElementType,
			String strColumnElementAttribute) {

		String strReturn = "";
		WebElement eleColumn = null;
		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator(strTableElement));

		try {
			if (strColumnElementType.equals("")) {
					try{
					eleColumn = eleTable.findElement(By.xpath(".//tbody/tr[" + intRow + "]/td[" + intCol + "]"));
				} catch (Exception e) {
					
					eleColumn = eleTable.findElement(By.xpath(".//thead/tr[" + intRow + "]/td[" + intCol + "]"));
				}
			} else {
				try {
					eleColumn = eleTable.findElement(
							By.xpath(".//tbody/tr[" + intRow + "]/td[" + intCol + "]/" + strColumnElementType));
				} catch (Exception e) {
					eleColumn = eleTable.findElement(
							By.xpath(".//thead/tr[" + intRow + "]/td[" + intCol + "]/" + strColumnElementType));
				}
			}
		} catch (Exception e) {
			System.out.println(
					"Required column or column-element-type is not found at row:'" + intRow + "' col:'" + intCol + "'");
			throw e;
		}

		if (strColumnElementAttribute.equals("")) {
			switch (eleColumn.getTagName()) {
			case "td":
			case "a":
			case "th":
				strReturn = eleColumn.getText();
				break;
			case "input":
				strReturn = eleColumn.getAttribute("value");
				break;

			default:
				break;
			}

		} else {
			strReturn = eleColumn.getAttribute(strColumnElementAttribute);
		}
		return strReturn;
	}

	public String GetTableCellValue(String strTableElement, int intRow, String strColumnName,
			String strColumnElementType, String strColumnElementAttribute) {
		String strReturn = "";
		int intCol = GetTableColumnNumber(strTableElement, strColumnName);
		strReturn = GetTableCellValue(strTableElement, intRow, intCol, strColumnElementType, strColumnElementAttribute);
		return strReturn;
	}

	public String GetTableCellValue(String strTableElement, String strSearchColumns, String strSearchColumnValues,
			String strSearchColumnElementTypes, String strSearchColumnElementAttributes, String strColumnName,
			String strColumnElementType, String strColumnElementAttribute) throws Exception {
		String strReturn = "";
		int intRow = GetTableRowNumber(strTableElement, strSearchColumns, strSearchColumnValues,
				strSearchColumnElementTypes, strSearchColumnElementAttributes);
		if (intRow == -1) {
			System.out.println("Value '" + strSearchColumnValues + "' is not available");
			Exception e = null;
			throw e;
		}
		int intCol = GetTableColumnNumber(strTableElement, strColumnName);
		strReturn = GetTableCellValue(strTableElement, intRow, intCol, strColumnElementType, strColumnElementAttribute);
		return strReturn;
	}

	public WebElement GetTableCellElement(String strTableElement, int intRow, int intCol, String strColumnElementType) {
		WebElement strReturn = null;
		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator(strTableElement));

		try {
			try {
				strReturn = eleTable.findElement(
						By.xpath(".//tbody/tr[" + intRow + "]/td[" + intCol + "]/" + strColumnElementType));
			} catch (Exception e) {
				strReturn = eleTable.findElement(
						By.xpath(".//thead/tr[" + intRow + "]/td[" + intCol + "]/" + strColumnElementType));
			}
		} catch (Exception err) {
			// To handle : extra '/' when strColumnElementType = "".
			try {
				strReturn = eleTable.findElement(By.xpath(".//tbody/tr[" + intRow + "]/td[" + intCol + "]"));
			} catch (Exception e) {
				strReturn = eleTable.findElement(By.xpath(".//thead/tr[" + intRow + "]/td[" + intCol + "]"));
			}
		}
		return strReturn;
	}

	public WebElement GetTableCellElement(String strTableElement, int intRow, String strColumnName,
			String strColumnElementType) {
		WebElement strReturn = null;
		int intCol = GetTableColumnNumber(strTableElement, strColumnName);
		strReturn = GetTableCellElement(strTableElement, intRow, intCol, strColumnElementType);
		return strReturn;
	}

	public WebElement GetTableCellElement(String strTableElement, String strSearchColumns, String strSearchColumnValues,
			String strSearchColumnElementTypes, String strSearchColumnElementAttributes, String strColumnName,
			String strColumnElementType) {
		WebElement strReturn = null;
		int intRow = GetTableRowNumber(strTableElement, strSearchColumns, strSearchColumnValues,
				strSearchColumnElementTypes, strSearchColumnElementAttributes);
		int intCol = GetTableColumnNumber(strTableElement, strColumnName);
		strReturn = GetTableCellElement(strTableElement, intRow, intCol, strColumnElementType);
		return strReturn;
	}

	public boolean VerifyTableColumnValues(String strTableElement, String strSearchColumns,
			String strSearchColumnValues, String strSearchColumnElementTypes, String strSearchColumnElementAttributes,
			String strReadColumns, String strExptValues, String strReadColumnElementTypes,
			String strReadColumnElementAttributes, boolean blnMatchWholeValue) throws Exception {
		boolean blnReturn = true;
		String strReturn = "";
		String[] arrReadColumns = strReadColumns.replace("|", " | ").split("\\|");
		String[] arrColumnExptValues = strExptValues.replace("|", " | ").split("\\|");
		String[] arrColumnTypes = strReadColumnElementTypes.replace("|", " | ").split("\\|");
		String[] arrColumnAttributes = strReadColumnElementAttributes.replace("|", " | ").split("\\|");

		for (int i = 0; i < arrReadColumns.length; i++) {
			String strActualValue = GetTableCellValue(strTableElement, strSearchColumns, strSearchColumnValues,
					strSearchColumnElementTypes, strSearchColumnElementAttributes, arrReadColumns[i].trim(),
					arrColumnTypes[i].trim(), arrColumnAttributes[i].trim());
			System.out.println("Cell Value :: " + strActualValue);

			if (blnMatchWholeValue) {
				blnReturn = strActualValue.trim().equalsIgnoreCase(arrColumnExptValues[i].trim());
			} else {
				blnReturn = strActualValue.trim().contains(arrColumnExptValues[i].trim());
			}

			if (!blnReturn) {
				strReturn = strReturn + "<br/> - Value of Column '" + arrReadColumns[i].trim()
						+ "' is NOT as expected. Actual value is '" + strActualValue + "' (Expected '"
						+ arrColumnExptValues[i].trim() + "')";
			}
		}

		if (!strReturn.equals("")) {
			blnReturn = false;
			strReturn = "Column value(s) are NOT as expected..." + strReturn;
		} else {
			blnReturn = true;
			strReturn = "Column value(s) are as expected";
		}
		System.out.println("Result :: " + blnReturn + " - " + strReturn);
		return blnReturn;
	}

	public boolean VerifyTableColumnValues(String strTableElement, int intRowNumber, String strReadColumns,
			String strExptValues, String strReadColumnElementTypes, String strReadColumnElementAttributes,
			boolean blnMatchWholeValue) {
		boolean blnReturn = true;
		String strReturn = "";
		String[] arrReadColumns = strReadColumns.split("\\|");
		String[] arrColumnExptValues = strExptValues.split("\\|");
		String[] arrColumnTypes = strReadColumnElementTypes.split("\\|");
		String[] arrColumnAttributes = strReadColumnElementAttributes.split("\\|");

		for (int i = 0; i < arrReadColumns.length; i++) {
			String strActualValue = GetTableCellValue(strTableElement, intRowNumber, arrReadColumns[i],
					arrColumnTypes[i], arrColumnAttributes[i]);
			System.out.println("Cell Value :: '" + strActualValue + "'");

			if (blnMatchWholeValue) {
				blnReturn = strActualValue.trim().equalsIgnoreCase(arrColumnExptValues[i].trim());
			} else {
				blnReturn = strActualValue.trim().contains(arrColumnExptValues[i].trim());
			}

			if (!blnReturn) {
				strReturn = strReturn + "<br/> - Value of Column '" + arrReadColumns[i]
						+ "' is NOT as expected. Actual value is '" + strActualValue + "' (Expected '"
						+ arrColumnExptValues[i].trim() + "')";
			}
		}

		if (!strReturn.equals("")) {
			blnReturn = false;
			strReturn = "Column value(s) are NOT as expected..." + strReturn;
		} else {
			blnReturn = true;
			strReturn = "Column value(s) are as expected";
		}
		System.out.println("Result :: " + blnReturn + " - " + strReturn);
		return blnReturn;
	}

	public boolean VerifyTableColumnElementExists(String strTableElement, String strSearchColumns,
			String strSearchColumnValues, String strSearchColumnElementTypes, String strSearchColumnElementAttributes,
			String strReadColumn, String strReadColumnElementType) {
		boolean blnReturn = false;
		String strReturn = "";
		WebElement eleReturn = GetTableCellElement(strTableElement, strSearchColumns, strSearchColumnValues,
				strSearchColumnElementTypes, strSearchColumnElementAttributes, strReadColumn, strReadColumnElementType);
		blnReturn = (eleReturn != null);

		if (blnReturn) {
			strReturn = "Element exist as expected";
		} else {
			strReturn = "Element do NOT exist";
		}

		System.out.println("Result :: " + strReturn);
		return blnReturn;
	}

	public boolean VerifyTableColumnElementNotExist(String strTableElement, String strSearchColumns,
			String strSearchColumnValues, String strSearchColumnElementTypes, String strSearchColumnElementAttributes,
			String strReadColumn, String strReadColumnElementType) {
		boolean blnReturn = false;
		String strReturn = "";
		WebElement eleReturn = GetTableCellElement(strTableElement, strSearchColumns, strSearchColumnValues,
				strSearchColumnElementTypes, strSearchColumnElementAttributes, strReadColumn, strReadColumnElementType);
		blnReturn = (eleReturn == null);

		if (blnReturn) {
			strReturn = "Element do not exist as expected";
		} else {
			strReturn = "Element exists";
		}

		System.out.println(strReturn);
		return blnReturn;
	}

	/*
	 * =========================================================================
	 * ============================================ Page Verification
	 */

	/**
	 * Verify Heading of the page
	 * 
	 * @param strHeading
	 * @param strHeaderElementClass
	 */
	public void VerifyPageHeading(String strHeading, String strHeaderElementClass) {
		WebElement elePageHeading = null;
		new WebDriverWait(driver, 20).until(ExpectedConditions.visibilityOfElementLocated(By.className(strHeaderElementClass)));
		elePageHeading = driver.findElement(By.className(strHeaderElementClass.trim()));
		if (elePageHeading != null) {
			if (elePageHeading.getText().equalsIgnoreCase(strHeading)) {
				System.out.println("Page-heading is displayed as expected, '" + strHeading + "'");
				actions.reportCreatePASS("Verify page Heading ", "Page Heading should be " + strHeading,
						"Page Heading is " + strHeading, "Pass");
				// Reporter.log("Page-heading is displayed as expected");
			} else {
				System.out.println("Page-heading is NOT displayed as expected. Actual heading is '"
						+ elePageHeading.getText() + "'");
				actions.reportCreateFAIL("Verify page Heading ", "Page Heading should be " + strHeading,
						"Page Heading is not displayed as " + strHeading, "Fail");

			}
		} else {
			System.out.println("Sub-heading not found");
			actions.reportCreateFAIL("Verify page Heading ", "Sub-Heading should found", "Sub-heading not found",
					"Fail");
		}
	}

	/*
	 * =========================================================================
	 * ============================================ Udated to handle the Alert-Popup on safari
	 */
	
	public boolean VerifyAlertMessageDisplayed(String strMessageType, String strExptMessage, Boolean blnVerifyExactMsg,
			AlertPopupButton alertActionButton) {
		boolean blnReturn = false;
		String strReturn = "";
		String strActualMsg = "";

		try {
			/*if(actions.isSafari()) {
				System.out.println("In MAC Safari Alert Handling is not supported.");
				Thread.sleep(2000);
				String alertText = ((JavascriptExecutor)driver).executeScript("var text=localStorage.alertText; return text;").toString();
				if(blnVerifyExactMsg){
					if(alertText.equalsIgnoreCase(strExptMessage)){
						return true;
					}else{
						return false;
					}
				}else{
					if(alertText.toUpperCase().contains(strExptMessage.toUpperCase())){
						return true;
					}else{
						return false;
					}
				}
			}*/
			// Verify that confirmation popup is displayed
			System.out.println("> Verify that " + strMessageType.toLowerCase() + " is displayed");
			//To check the popup before switching 6/9/2016
			new WebDriverWait(driver,
					30).until(ExpectedConditions.alertIsPresent());
			Alert popup = driver.switchTo().alert();
			if (popup != null) {
				// Verify the message displayed
				System.out.println("> Verify the message displayed");
				strActualMsg = popup.getText().trim();
				if (blnVerifyExactMsg) {
					System.out.println("*******************" + strActualMsg.length());
					System.out.println("*******************" + strExptMessage.trim().length());
					// actions.verifyTextContains(strActualMsg.trim(),
					// strExptMessage.trim(), false);
					if (strActualMsg.equalsIgnoreCase(strExptMessage.trim())) {
						blnReturn = true;
						strReturn = strMessageType + " message is displayed as expected";

						// actions.verifyTestStep(actual, expected,
						// continueExecution);
					} else {
						blnReturn = false;
						strReturn = strMessageType + " message displayed is NOT as expected. Actual message : '"
								+ strActualMsg + "' (Expected message : '" + strExptMessage + "')";
					}
				} else {
					System.out.println("*******************" + strActualMsg.length());
					System.out.println("*******************" + strExptMessage.trim().length());
					// actions.verifyTextContains(strActualMsg.trim().toUpperCase(),
					// strExptMessage.trim().toUpperCase(), false);
					if (strActualMsg.toUpperCase().contains(strExptMessage.trim().toUpperCase())) {
						blnReturn = true;
						strReturn = strMessageType + " message is displayed as expected";
					} else {
						blnReturn = false;
						strReturn = strMessageType + " message displayed is NOT as expected. Actual message : '"
								+ strActualMsg + "' (Expected message : '" + strExptMessage + "')";
					}
				}
			} else {
				blnReturn = false;
				strReturn = strMessageType + " is NOT displayed";
			}

			// Click 'strPopupAction' button on confirmation popup
			if (alertActionButton.equals(AlertPopupButton.OK_BUTTON)) {
				System.out.println("> Click 'OK' button on confirmation popup");
				popup.accept();

			} else if (alertActionButton.equals(AlertPopupButton.CANCEL_BUTTON)) {
				System.out.println("> Click 'Cancel' button on confirmation popup");
				popup.dismiss();
			}

			Thread.sleep(3000);
			;
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println(strReturn);
		return blnReturn;
	}
	/*
	 * =========================================================================
	 * ============================================ Test-Data
	 */
	/**
	 * Read test-data from the test-data file
	 * 
	 * @param DTName
	 *            : Name of the column to read from test-data. > Test-Data-Value
	 *            prefix... > GBL#[Parameter] : Read [Parameter] value from
	 *            global-configuration file. (i.e. GBL#URL_RFMQM) > RND#[Prefix]
	 *            : Generate random number string with specified (optional)
	 *            prefix. (i.e. RND#Auto OR RND#)
	 * 
	 * @return String : Test-Data
	 */
	public String GetTestData(String DTName) {
		String strReturn = "";
		try {
			strReturn = input.get(DTName).toString().trim();

			if (strReturn.startsWith("GBL#")) {
				// Read Test-Data from Global Configuration file
				strReturn = gblTestData.get(strReturn.replace("GBL#", ""));

			} else if (strReturn.startsWith("RND#")) {
				// Generate random string value

			}
		} catch (Exception e) {
			strReturn = "";
		}
		return strReturn;
	}

	/** To read config parameter from crossbrowser properties file   **/
	public String GetGlobalData(String DTName) {	
		return gblTestData.get(DTName);
	}
	
	///
	public boolean ISAttributePresent(String elemlocator, String status) {
		boolean blnrslt = false;
		try {

			WebElement elem = driver.findElement(By.xpath(actions.getLocator(elemlocator)));
			String is_disabled = elem.getAttribute(status);
			if (is_disabled.equals("true")) {
				blnrslt = true;
			} else {
				blnrslt = false;

			}
		} catch (Exception e) {
			// Reporter.log(e.getMessage());
			blnrslt = false;
		}
		return blnrslt;
	}
	////

	public void SetTableCellValue(String strTableElement, int intRow, String strSetColumns, String strSetValues,
			String strSetColumnElementTypes, String strSetColumnElementAttributes) {
		WebElement eleCell = null;
		String[] arrColumnNames = strSetColumns.split("\\|");
		String[] arrColumnValues = strSetValues.split("\\|");
		String[] arrColumnElementTypes = strSetColumnElementTypes.split("\\|");

		for (int i = 0; i < arrColumnNames.length; i++) {
			eleCell = GetTableCellElement(strTableElement, intRow, arrColumnNames[i], arrColumnElementTypes[i]);
			if (eleCell != null) {
				if (strSetColumnElementTypes.equalsIgnoreCase("input")) {
					String strType = eleCell.getAttribute("type");
					if (strType.equalsIgnoreCase("text")) {
						eleCell.clear();
						eleCell.sendKeys(arrColumnValues[i].trim());

					} else if (strType.equalsIgnoreCase("radio")) {
						if (arrColumnValues[i].trim().equalsIgnoreCase("Yes")
								|| arrColumnValues[i].trim().equalsIgnoreCase("Select")
								|| arrColumnValues[i].trim().equalsIgnoreCase("true")) {
							eleCell.click();
						}
					} else if (strType.equalsIgnoreCase("checkbox")) {
						// TODO :
					}
				} else if (strSetColumnElementTypes.equalsIgnoreCase("select")) {
					Select eleSelect = new Select(eleCell);
					eleSelect.selectByVisibleText(arrColumnNames[i].trim());

				}
			} else {
				System.out.println("Cell Element not found");
				break;
			}
		}
	}

	/// =======Function switch window
	/**
	 * Switch to window (new or previous) and confirm that it is switched to the
	 * expected window (by title)
	 * 
	 * @param strWindowTitle
	 *            : Title of the target window OR.. '#Title' to update the list
	 *            with title of the current window '#Title of the window : to
	 *            remove window details from the list '$Title of the window : to
	 *            switch to specified PREVIOUS window '@Title of the window : to
	 *            switch to the main window with UPDATED title
	 * @return
	 * @throws Exception
	 */
	public boolean SwitchToWindow(String strWindowTitle) throws Exception {
		
		if(actions.isMicrosoftEdge()){
			if(strWindowTitle.equalsIgnoreCase("#Title")){
				return true;
			}else if(strWindowTitle.startsWith("#") ||strWindowTitle.startsWith("$") || strWindowTitle.startsWith("@")){
				strWindowTitle = strWindowTitle.substring(1);
			}else if(strWindowTitle.trim().equals("")){
				return true;
			}
			
			return actions.windowSwitch(driver.getWindowHandle(), strWindowTitle);
		} 

		boolean blnReturn = false, blnNewWindow = false;
		String strNewWindowHND = "", strPrevWindowHND = "", strTargetWindowHND = "";

		// Get title of the current window
		String strCurrWindowTitle = (intWindowHandleIndex == -1 ? ""
				: strListWindowTitle.get(intWindowHandleIndex).trim());
		System.out.println(">> Switching from '" + strCurrWindowTitle + "' window to '" + strWindowTitle + "'");

		// Get possible window handle (for previous window)
		int intExptWindowIndex = strListWindowTitle.lastIndexOf(strWindowTitle.trim());
		String strExptWindowHND = (intExptWindowIndex != -1 ? strListWindowHandle.get(intExptWindowIndex) : "");

		if (strWindowTitle.trim().equals("")) {
			// Initialize list of window-handlers
			Thread.sleep(1000);
			String strHome;
			do {
				strHome = driver.getTitle();
			} while (!strHome.contains("Home"));

			strListWindowHandle.add(driver.getWindowHandle());
			strListWindowTitle.add(driver.getTitle().trim());
			intWindowHandleIndex = strListWindowHandle.lastIndexOf(driver.getWindowHandle());

		} else if (strWindowTitle.trim().equalsIgnoreCase("#Title")) {
			// Re-switch to the current window (refresh-driver) and update title
			// for existing window
			driver.switchTo().window("");
			driver.switchTo().window(strListWindowHandle.get(intWindowHandleIndex));
			Thread.sleep(1000);

			strListWindowHandle.add(strListWindowHandle.get(intWindowHandleIndex));
			
			//To Verify the #Title is switched in 180 seconds, it will return blnReturn=true if switched.
			String strUpdatedTitle = null;
			int iterator = 0;
			String temp = gblTestData.get("StepTimeOut");
			int time = Integer.parseInt(temp);
			int val = 3000/time;
			int tempMin=time/60;
			do{
				try{
					strUpdatedTitle = driver.getTitle().trim();
					blnReturn = true;
					break;
				}catch(Exception err){
					Thread.sleep(3000);
	            	   iterator=iterator+1;
	                   System.out.println("window not available will wait few more seconds");
				}
			}while((strUpdatedTitle.equals(null) && (iterator<=val)));
			
			if(!blnReturn){
				actions.reportCreateFAIL("Switch to Window :"+strWindowTitle, "Should Switch to Window :"+strWindowTitle, "Failed to switch/Title not updated within time :"+tempMin+" min", "Fail");
			}
			
			strListWindowTitle.add(driver.getTitle().trim());
			intWindowHandleIndex = strListWindowHandle.lastIndexOf(strListWindowHandle.get(intWindowHandleIndex));

		} else if (strWindowTitle.trim().startsWith("#")) {
			// Remove specified window from the list

			int intRmvWindowIndex = strListWindowTitle.lastIndexOf(strWindowTitle.trim().replace("#", ""));
			if (intWindowHandleIndex != intRmvWindowIndex) {
				strListWindowHandle.remove(intRmvWindowIndex);
				strListWindowTitle.remove(intRmvWindowIndex);
				System.out.println("Window '" + strWindowTitle.trim().replace("#", "") + "' is removed");
			} else {
				System.out.println("Can not remove current window '" + strWindowTitle.trim().replace("#", "") + "'");
			}
			intWindowHandleIndex = (intRmvWindowIndex < intWindowHandleIndex ? intWindowHandleIndex - 1
					: intWindowHandleIndex);

		} else if (strWindowTitle.trim().startsWith("$")) {
			// Switch to specified PREVIOUS window
			strWindowTitle = strWindowTitle.trim().replace("$", "");

			// intExptWindowIndex =
			// strListWindowTitle.lastIndexOf(strWindowTitle);
			// strTargetWindowHND = (intExptWindowIndex != -1 ?
			// strListWindowHandle.get(intExptWindowIndex) : "");

			// ======== Search for Previous WindowIndex
			int CurrIndex = -1;
			for (int i = 0; i < strListWindowTitle.size(); i++) {
				if (strListWindowTitle.get(i).equals(strWindowTitle)) {
					CurrIndex = i;
					if (CurrIndex != intWindowHandleIndex) {
						intExptWindowIndex = CurrIndex;
					} else
						break;
				}
			}
			strTargetWindowHND = (intExptWindowIndex != -1 ? strListWindowHandle.get(intExptWindowIndex) : "");
			// ========

			// Switch to target window and verify page-title
			if (!strTargetWindowHND.trim().equals("")) {
				// Switch to previous window
				driver.switchTo().window(strTargetWindowHND);
				Thread.sleep(1000);	
				try{
					driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
				}catch(Exception E){
				driver.manage().timeouts().pageLoadTimeout(180, TimeUnit.SECONDS);
				}
				// Update Lists
				strListWindowHandle.add(strTargetWindowHND);
				strListWindowTitle.add(driver.getTitle().trim());
				intWindowHandleIndex = strListWindowHandle.lastIndexOf(strTargetWindowHND);

				// Verify Title
				if (driver.getTitle().trim().equalsIgnoreCase(strWindowTitle)) {
					System.out.println("Control transfered to previous window '" + strWindowTitle);
					blnReturn = true;
				} else {
					System.out.println("Failed to transfer control to '" + strWindowTitle + "' Actual window title is '"
							+ driver.getTitle() + "'");
					blnReturn = false;
				}

			} else {
				// Required previous window is not displayed
				throw new Exception("Previous window '" + strWindowTitle + "' is not available");
			}

		} else if (strWindowTitle.trim().startsWith("@")) {
			// Switch to the main window with UPDATED title
			strWindowTitle = strWindowTitle.trim().replace("@", "");
			if(!actions.isSafari()){
				driver.switchTo().window("");
			}else{
				blnReturn= actions.windowSwitch(strWindowTitle);
			}
				strListWindowHandle.add(driver.getWindowHandle());
				strListWindowTitle.add(driver.getTitle().trim());
				intWindowHandleIndex = strListWindowHandle.lastIndexOf(driver.getWindowHandle());
				
				// Verify Title
				
				if (driver.getTitle().trim().equalsIgnoreCase(strWindowTitle)) {
					System.out.println("Control transfered to '" + strWindowTitle + "'");
					blnReturn = true;
				} else {
					System.out.println("Failed to transfer control to '" + strWindowTitle + "' Actual window title is '"
							+ driver.getTitle() + "'");
					blnReturn = false;
				}
			

		} else {
			
			// Switch to Next OR Previous window as applicable
			if (!((RemoteWebDriver) driver).getCapabilities().getPlatform().toString().equalsIgnoreCase("mac")) 
				driver.switchTo().window("");
				int intWinHNDIndex = -1;
				for (String WinHND : driver.getWindowHandles()) {
					intWinHNDIndex = strListWindowHandle.lastIndexOf(WinHND);

					// Compare current window handles with existing list of
					// window-handles
					if (intWinHNDIndex == -1) {
						// WinHND is NOT present in the list --- its new window
						blnNewWindow = true;
						strNewWindowHND = WinHND;

					} else {
						// WinHND is present in the list
						if (intWinHNDIndex != intWindowHandleIndex) {
							// This is previous window (i.e. its NOT the current
							// window) --- Check if this is the required one
							if (strExptWindowHND.equalsIgnoreCase(WinHND)) {
								blnNewWindow = false;
								strPrevWindowHND = WinHND;
							}
						}
					}
				}

				// Get window handle for the target window
				strTargetWindowHND = (blnNewWindow ? strNewWindowHND : strPrevWindowHND);

				// Switch to target window and verify page-title
				if (!strTargetWindowHND.trim().equals("")) {
					// Switch to target window
					Thread.sleep(2000);
					driver.switchTo().window(strTargetWindowHND);
					driver.manage().timeouts().pageLoadTimeout(180, TimeUnit.SECONDS);

					// Update Lists
					try {
						strListWindowTitle.add(driver.getTitle().trim());
						strListWindowHandle.add(strTargetWindowHND);
						intWindowHandleIndex = strListWindowHandle.lastIndexOf(strTargetWindowHND);

						// Verify Title
						if (driver.getTitle().trim().equalsIgnoreCase(strWindowTitle.trim())) {
							System.out.println(
									"Control transfered to '" + strWindowTitle + "' [" + strTargetWindowHND + "]");

							blnReturn = true;
						} else {
							System.out.println("Failed to transfer control to '" + strWindowTitle
									+ "' Actual window title is '" + driver.getTitle() + "'");
							blnReturn = false;
						}

					} catch (Exception e) {
						System.out.println("Closing the Dangling windhandle from the application.");

						if (!((RemoteWebDriver) driver).getCapabilities().getPlatform().toString()
								.equalsIgnoreCase("mac"))
							driver.switchTo().window("");
						blnReturn = SwitchToWindow(strWindowTitle);
					}

				} else {
					// Required window is not displayed
					throw new Exception("New Window '" + strWindowTitle + "' is not available");
				}
			
		}

		return blnReturn;
	}

	
	// ========= Selecting the future date
	// @param x = number of days to go forward
	// @param Elementlocator = locator name of the element in UI MAP
	// public void Get_future_date(int x, String Elementlocator) {
	// // adding the calendar instance
	// Calendar Date = Calendar.getInstance();
	// // creating the date format constructor
	// SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	// Date.add(Calendar.DAY_OF_MONTH, x); //// ==adding the number of days in
	// //// current app date
	// String date = formatter.format(Date.getTime());
	// WebElement apptime = getdate();
	// String app_date = apptime.getText();
	// String[] future_date = (date).split("/");
	// String[] curr_date = (app_date).split("/");
	// // comparing the month of the current date and future date to be set
	// //Reporter.log(
	// "selecting the date" + future_date[0] + "/" + future_date[1] + "/" +
	// future_date[2].substring(0, 4));
	// if (!future_date[1].toString().equals(curr_date[1].toString())) {
	// String month = "next";
	//
	// select_date(future_date[0], month, Elementlocator);
	// } else {
	// String month = "current";
	//
	// select_date(future_date[0], month, Elementlocator);
	// }
	// }

	// x - Number of days
	// Calendar Type : close/open
	public void Get_future_date(int x, String Calender_Type, String app_date) {
		// adding the calendar instance
		Calendar Date = Calendar.getInstance();
		// creating the date format constructor
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date.add(Calendar.DAY_OF_MONTH, x); //// ==adding the number of days in
											//// current app date
		String date = formatter.format(Date.getTime());

		//Converting application current date to date format
		app_date = DateFormatter(app_date);
		// ----- Added to Handle US Market ----END-----

		String[] future_date = (date).split("/");
		String[] curr_date = (app_date).split("/");
		// comparing the month of the current date and future date to be set

		String MyNewDate = future_date[0] + "/" + future_date[1] + "/" + future_date[2].substring(0, 4);
		System.out.println(MyNewDate);
		System.out.println(
				"selecting the date" + future_date[0] + "/" + future_date[1] + "/" + future_date[2].substring(0, 4));
		Select_SpecificDate(MyNewDate, Calender_Type);
	}

	/// ===========getting the element for the application time
	public WebElement getdate() {
		try {
			WebDriverWait w = new WebDriverWait(driver, 30);
			w.until(ExpectedConditions.visibilityOfElementLocated(By.id("rfmTimerDate")));
			WebElement apptime = driver.findElement(By.id("rfmTimerDate"));
			return apptime;
		} catch (Exception e) {
			WebDriverWait w = new WebDriverWait(driver, 30);
			w.until(ExpectedConditions.visibilityOfElementLocated(By.id("date")));
			WebElement apptime = driver.findElement(By.id("date"));
			return apptime;
		}
	}

	/// ==============
	// ========= Selecting the current date
	// @param Elementlocator = locator name of the element in UI MAP
	public void sel_current_date(String Elementlocator) {

		WebElement apptime = getdate();
		String app_date = apptime.getText();
		app_date = DateFormatter(app_date);
		String[] curr_date = app_date.split("/");
		select_date(curr_date[0], "current", Elementlocator);
	}

	/// ==============
	// ========= Selecting the current date
	// @param Elementlocator = locator name of the element in UI MAP
	// @param app_date = Application Date which is available on the main page of
	/// the application
	public void sel_current_date(String Elementlocator, String app_date) {
		app_date = DateFormatter(app_date);
		String[] curr_date = app_date.split("/");
		select_date(curr_date[0], "current", Elementlocator);
	}

	// =========selecting the back date
	// @param x = number of days to go back
	// @param Elementlocator = locator name of the element in UI MAP
	public void Get_back_date(int x, String Elementlocator) {
		Calendar Date = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date.add(Calendar.DAY_OF_MONTH, (-x));
		String date = formatter.format(Date.getTime());
		WebElement apptime = getdate();
		String app_date = apptime.getText();
		app_date = DateFormatter(app_date);
		String[] back_date = (date).split("/");
		String[] curr_date = (app_date).split("/");
		if (!back_date[1].toString().equals(curr_date[1].toString())) {
			String month = "prev";
			int backmonth = Integer.parseInt(back_date[1]);
			int curmonth = Integer.parseInt(curr_date[1]);
			int month_diff = curmonth - backmonth;
			select_date(back_date[0], month, Elementlocator);
		} else {
			String month = "current";

			select_date(back_date[0], month, Elementlocator);
		}
	}

	public String DateFormatter(String app_date) {
		String strNewFormattedDate = null;
		try {
			//Getting the format for date from test data
			String dtForm = GetTestData("DT_DATE_FORMAT");
			
            // Getting the date part from entire application date string based on the date format
            try{
            app_date = app_date.trim().substring(0, dtForm.length()).trim();
            }catch (Exception err){
                            System.out.println("date is already formatted");
                            return app_date;
            }
			
			//Create a basic formatter for dd/mm/yyyy
			DateFormat olddate = new SimpleDateFormat(dtForm);
			DateFormat formatterNew = new SimpleDateFormat("dd/MM/yyyy");
			

			//Parsing the date object dateNew into new format & given date string
			strNewFormattedDate = formatterNew.format(olddate.parse(app_date));
            System.out.println(strNewFormattedDate);
			
		} catch (Exception err) {
			System.out.println(err.getMessage());
		}
		return strNewFormattedDate;
	}

	// ===========>>>
	/// selecting the date from the date picker
	// @param date = only date without month and year
	// @param month = pass "current" for current month , "next" for next month
	// and "prev" for previous month
	// @param month diff - difference of the months between dates
	public void select_date(String date, String month, String Elementlocator) {

		try {
			WebElement datepicker = null;
			// clicking on the date picker
			WebElement dateWidget = driver.findElement(By.xpath(actions.getLocator(Elementlocator)));
			// Reporter.log("Clicking on the datepicker");
			actions.click(dateWidget);

			// getting the date picker from available matching elements
			List<WebElement> num_datepickers = driver.findElements(By.className("datepicker"));
			for (int a = 0; a < num_datepickers.size(); a++) {

				String is_visible = num_datepickers.get(a).getAttribute("style"); ///
				try{
					if (is_visible.contains("visible")) {
						datepicker = num_datepickers.get(a);
						break;
					}	
				}catch(Exception e){
					
				}
				
			}
			// setting the navigators on datepicker pop up
			WebElement go_next = datepicker.findElement(By.className("datepickerGoNext"));
			WebElement go_next_link = go_next.findElement(By.xpath(".//a")); // go
																				// next
																				// link
			WebElement go_prev = datepicker.findElement(By.className("datepickerGoPrev"));
			WebElement go_prev_link = go_prev.findElement(By.xpath(".//a")); // go
																				// to
																				// prev
																				// link
			WebElement Date_dayview = datepicker.findElement(By.className("datepickerDays"));
			List<WebElement> get_row = Date_dayview.findElements(By.xpath(".//tr")); // getting
																						// the
																						// rows
																						// in
																						// calendar
			// Checking the future date month is same or not
			if (month.equals("next")) {

				actions.click(go_next_link);
				Thread.sleep(900);
				// Reporter.log("Clicking on the Next month");

			} else // Checking the back date month is same or not
				if (month.equals("prev")) {
				actions.click(go_prev_link);
				Thread.sleep(900);
				// Reporter.log("Clicking on the prev month");
			}

			// checking the number of cells
			try {
				for (int i = 0; i < get_row.size(); i++) {
					List<WebElement> get_col = get_row.get(i).findElements(By.xpath(".//td"));

					for (int j = 0; j < get_col.size(); j++) {
						// System.out.println("td: "+get_col.get(j).getText());

						String selectdate = get_col.get(j).getText(); // getting
																		// the
																		// text
																		// of
																		// the
																		// cell
																		// columns
						if (selectdate.length() < date.length()) {
							selectdate = "0" + selectdate;
						}
						if (selectdate.equals(date)) {
							String classname = get_col.get(j).getAttribute("Class");
							/// Checking for the dates from prev/next months are
							/// displayed or not and if displayed skip them..
							if (!classname.contains("datepickerNotInMonth")) {
								
								actions.reportCreatePASS("Select the Date '"+date,
										"Should select the date '"+date, 
										"Selected the date '"+date, "Pass");
								
								actions.javaScriptClick(get_col.get(j).findElement(By.tagName("a")));
									 /// selecting the date
															/// now and moving out
															/// of the loop
								
								List<WebElement> dis_datepickers = driver.findElements(By.className("datepicker"));
								for (int a = 0; a < dis_datepickers.size(); a++) {

									JavascriptExecutor js = (JavascriptExecutor) driver;
									js.executeScript("arguments[0].style.visibility = 'hidden';",
											dis_datepickers.get(a));

									String is_visible = dis_datepickers.get(a).getAttribute("style"); ///
									// System.out.println("vis: "+is_visible);

								}
								return;
							}
						}

					}
				}
			} catch (Exception e) {
				System.out.println("calendar picker is refreshed with new month");
				// again calling the function with current date parameter as
				// calendar got refreshed.
				select_date(date, "current", Elementlocator);
			}
		} catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
	}

	// ===========================

	/// selecting the date from the date picker
	// @param date = only date without month and year
	// @param month = pass "current" for current month , "next" for next month
	/// and "prev" for previous month
	// @param month diff - difference of the months between dates
	public void select_date(String date, String month) {
		try {
			WebElement datepicker = null;
			// get the date picker from available matching elements
			List<WebElement> num_datepickers = driver.findElements(By.className("datepicker"));
			for (int a = 0; a < num_datepickers.size(); a++) {
				String is_visible = num_datepickers.get(a).getAttribute("style");
				try{
					if (is_visible.contains("visible")) {
						datepicker = num_datepickers.get(a);
						break;
					}	
				}catch(Exception e){
					
				}
				
			}
			// set the navigators on datepicker pop up
			WebElement go_next = datepicker.findElement(By.className("datepickerGoNext"));
			WebElement go_next_link = go_next.findElement(By.xpath(".//a")); // go
																				// next
																				// link
			WebElement go_prev = datepicker.findElement(By.className("datepickerGoPrev"));
			WebElement go_prev_link = go_prev.findElement(By.xpath(".//a")); // go
																				// to
																				// prev
																				// link
			WebElement Date_dayview = datepicker.findElement(By.className("datepickerDays"));
			List<WebElement> get_row = Date_dayview.findElements(By.xpath(".//tr")); // getting
																						// the
																						// rows
																						// in
																						// calendar

			// Checking the future date month is same or not
			if (month.equals("next")) {
				go_next_link.sendKeys(Keys.ENTER);
				// Reporter.log("Select the Next month");
			} else if (month.equals("prev")) {
				go_prev_link.sendKeys(Keys.ENTER);
				// Reporter.log("Select the Previous month");
			}

			// checking the number of cells
			try {
				for (int i = 0; i < get_row.size(); i++) {
					List<WebElement> get_col = get_row.get(i).findElements(By.xpath(".//td"));

					for (int j = 0; j < get_col.size(); j++) {
						// System.out.println("td: "+get_col.get(j).getText());

						String selectdate = get_col.get(j).getText(); // getting
																		// the
																		// text
																		// of
																		// the
																		// cell
																		// columns
						if (selectdate.length() < date.length()) {
							selectdate = "0" + selectdate;
						}
						if (selectdate.equals(date)) {
							String classname = get_col.get(j).getAttribute("Class");
							/// Checking for the dates from prev/next months are
							/// displayed or not and if displayed skip them..
							if (!classname.contains("datepickerNotInMonth")) {
								// date now and moving out of the loop

								actions.reportCreatePASS("Select the Date '"+date,
										"Should select the date '"+date, 
										"Selected the date '"+date, "Pass");
								get_col.get(j).findElement(By.tagName("a")).click();
								// Reporter.log("the date selected
								// successfully");

								List<WebElement> dis_datepickers = driver.findElements(By.className("datepicker"));
								for (int a = 0; a < dis_datepickers.size(); a++) {

									JavascriptExecutor js = (JavascriptExecutor) driver;
									js.executeScript("arguments[0].style.visibility = 'hidden';",
											dis_datepickers.get(a));

									String is_visible = dis_datepickers.get(a).getAttribute("style"); ///
									// System.out.println("vis: "+is_visible);

								}
								return;
							}
						}

					}
				}
			} catch (Exception e) {
				System.out.println("calendar picker is refreshed with new month");
				// again calling the function with current date parameter as
				// calendar got refreshed.
				select_date(date, "current");
			}
		} catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
	}

	// =============================
	// This Function click on the row in a table
	/*
	 * Parameters - >strTableElement - > Table id ,index -> row number return :
	 * Boolean value author :Anubhuti modifie by :Priyanka
	 */
	public boolean select_row(String strTableElement, int index) {
		Boolean blResult = false;
		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator(strTableElement));
		if (eleTable != null) {
			List<WebElement> eleRows = eleTable.findElements(By.xpath(".//tbody/tr"));
			actions.click(eleRows.get(index));
			blResult = true;
		}
		return blResult;
	}

	/*
	 * @Function : This function will create and return unique name
	 * //@Parameters : strPrefix = "Auto" //@Author:Priyanka
	 */
	public String fn_GetRndName(String strPrefix) {
		Calendar cal = Calendar.getInstance();
		int milliSeconds = cal.get(Calendar.MILLISECOND);
		int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
		int month = cal.get(Calendar.MONTH);
		int currentHour = cal.get(Calendar.HOUR_OF_DAY);
		int currentMinute = cal.get(Calendar.MINUTE);

		String strRndName = strPrefix + "_" + String.valueOf(milliSeconds) + String.valueOf(currentMinute)
				+ String.valueOf(dayOfMonth) + String.valueOf(month) + String.valueOf(currentHour);

		return strRndName;
	}

	/*
	 * @Function :This function will create and return random numeric string
	 * // @Parameters :intStringLimit - Length of the string needs to create
	 */
	public String fn_GetRndNumericString(int intStringLimit) {
		String[] all_Num = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
		String strNum = "";
		for (int i = 1; i < intStringLimit; i++) {
			int random = (int) (Math.random() * 10 + 1);
			strNum = strNum + all_Num[random];
		}
		return strNum;
	}

	// @function: This function will generate random number within range
	// @param: int startrange- takes min limit,int endrange- takes max limit
	public int fn_GetRndNumInRange(int startrange, int endrange) {
		Random r = new Random();
		int i1 = r.nextInt(endrange - startrange + 1) + startrange;
		return i1;
	}

	/*
	 * @Function:This function will create and return random alphabetic string
	 * //*@Parameters :intStringLimit - Length of the string needs to create
	 */
	public String fn_GetRndAlphabaticString(int intStringLimit) {
		String[] all_Char = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "S",
				"T", "U", "V", "W", "X", "Y", "Z" };

		String strChar = "";
		for (int i = 1; i < intStringLimit; i++) {
			int random = (int) (Math.random() * 25 + 1);
			strChar = strChar + all_Char[random];
		}
		return strChar;
	}

	/*
	 * This function verifies objects are displayed on page or not
	 * 
	 * @Param : strWebElement -> Object Repository name
	 * 
	 * @return : boolean value true/False
	 */
	public boolean fn_VerifyWebObjectsDisplayed(String strWebElement) {
		boolean blnResult = false;
		try {
			WebElement eleWebEdit = actions.getwebDriverLocator(actions.getLocator(strWebElement));
			if (eleWebEdit != null) {
				blnResult = uiActions.elementPresent(eleWebEdit);
			} else {
				//// Reporter.log(strWebElement + " does not exists");
				this.flags.add(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
			//// Reporter.log("Failed to locate webelement '" + e.getMessage() +
			//// "'");
		}
		return blnResult;
	}

	/*
	 * Function to select required restaurant from market heirarchy
	 * 
	 * @param: strrestlocator- xpath for left and right table strrest-
	 * restaurant number to be selected
	 * 
	 * Santosh 17thFeb2016: Changing strXPath = "//label[contains(text(),'" +
	 * strrest + "')]"; to strXPath = "//*[contains(text(),'" + strrest + "')]";
	 * 
	 * 
	 */
	
	
	
	public boolean Selectrestnode(String strrestlocator, String strrest) throws InterruptedException {

		String strXPath = "";
		WebElement eleMarketTree = null;
		boolean blnReturn = false;
		eleMarketTree = actions.getwebDriverLocator(actions.getLocator(strrestlocator));
		strXPath = "//*[contains(text(),'" + strrest + "')]";
		
		//(new WebDriverWait(driver, (Integer.parseInt((GetGlobalData("StepTimeOut")))))).until(ExpectedConditions.visibilityOfAllElementsLocatedBy((By.xpath(strXPath))));
		//smartsync(180);
		
		WebElement eleMarket = eleMarketTree.findElement(By.xpath(strXPath));
		
		actions.checkElement(actions.getLocator(strrestlocator), 180);
		if (eleMarket != null) {
			eleMarket.click();
			blnReturn = true;
			System.out.println("Restaurant-" + strrest + " selected successfully");
		} else {
			blnReturn = false;
			System.out.println("Failed to select restaurant-" + strrest);
		}
		return blnReturn;
	}

	//Select Restaurant window function using Java Script click.
	//Author - Pooja
	//Date : 08-August-2016
	//Comments : click / keyboard enter is not working on few screens/ instances. Hence using javascript click
	public boolean Selectrestnode_JavaScriptClk(String strrestlocator, String strrest) throws InterruptedException {

		String strXPath = "";
		WebElement eleMarketTree = null;
		boolean blnReturn = false;
		eleMarketTree = actions.getwebDriverLocator(actions.getLocator(strrestlocator));
		strXPath = "//*[contains(text(),'" + strrest + "')]";
		
		smartsync(180);
		
		WebElement eleMarket = eleMarketTree.findElement(By.xpath(strXPath));
		
		actions.checkElement(actions.getLocator(strrestlocator), 180);
		if (eleMarket != null) {
			actions.javaScriptClick(eleMarket);
			blnReturn = true;
			System.out.println("Restaurant-" + strrest + " selected successfully");
		} else {
			blnReturn = false;
			System.out.println("Failed to select restaurant-" + strrest);
		}
		return blnReturn;
	}
	
	/*
	 * This Function verifies elements of the page are disabled or enabled
	 * 
	 * @Param : strWebElement -> Object Repository name
	 * 
	 * @return : boolean value true-> Enabled /False-> Disabled
	 * 
	 * @Author :Priyanka
	 */
	public boolean fn_VerifyWebelementEnableDisable(String strWebElement) {
		boolean blnResult = false;
		try {
			WebElement eleWebElement = actions.getwebDriverLocator(actions.getLocator(strWebElement));
			if (eleWebElement != null) {
				new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf(eleWebElement));
				blnResult = uiActions.elementEnabled(eleWebElement);
			} else {
				System.out.println(strWebElement + " does not exists");
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return blnResult;
	}

	//// @param Elem_locator = Locator name of the element in UI map
	/// @param dropdownname = Name of the drop down in UI
	// @param arrvalues = string column from the test data sheet should be in
	//// order with the UI elements
	public boolean checkdropdownvalues(String Elem_locator, String dropdownname, String arrvalues) {
		String no_match = "";
		boolean blnrslt = false;
		boolean str_result=true;
		try {
			WebElement dropdown = driver.findElement(By.xpath(actions.getLocator(Elem_locator)));
			List<WebElement> values = dropdown.findElements(By.xpath(".//option"));
			 String[]list_val = arrvalues.split(",");
			for (int b=0;b<list_val.length;b++){
				blnrslt = false;
			for (int a = 0; a < values.size(); a++) {
				String dropdown_value = values.get(a).getText(); 
				if (list_val[b].trim().contains(dropdown_value)) {
					blnrslt=true;
					break;
				}

			}
			if(blnrslt==false){
				System.out.println("Option "+list_val[b].trim()+" is not displayed");
				str_result=false;
			}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return str_result;
	}

	///==================
	
	////@param Elem_locator = Locator name of the element in UI map
	/// @param dropdownname = Name of the drop down in UI
	// @param arrvalues = string column from the test data sheet should be in
	//// order with the UI elements
	public boolean checkdropdownvalues(WebElement Elem_locator, String strValue) {
		boolean blnrslt = false;
		try {
			List<WebElement> values = Elem_locator.findElements(By.xpath(".//option"));

			for (int a = 0; a < values.size(); a++) {
				String dropdown_value = values.get(a).getText(); // getting the
																	// value of
																	// the drop
																	// down

				if (strValue.trim().equalsIgnoreCase((dropdown_value))) {
					blnrslt=true;

			} 
			}
		}catch (Exception e) {
			System.out.println(e);
		}
		return blnrslt;
	}
	
	
	///===============
	
	
	//// =============
	/// @param Elem_locator = Locator name of the element in UI map
	/// 
	public String getdropdownvalues(String Elem_locator) {

		String dropdown_values = "";

		try {
			WebElement dropdown = driver.findElement(By.xpath(actions.getLocator(Elem_locator)));
			List<WebElement> values = dropdown.findElements(By.xpath(".//option"));
			// String[]list_val = arrvalues.split(",");

			for (int a = 0; a < values.size(); a++) {
				String tmp = values.get(a).getText(); // getting the value of
														// the drop down
				dropdown_values = tmp + "," + dropdown_values;
			}

		} catch (Exception err) {
			// Reporter.log(err.getMessage());
		}
		return dropdown_values;
	}

	/// ======================

////=============
	/// @param Elem_locator = Locator name of the element in UI map
	/// 
	public String getdropdownvalues(WebElement Selement) {

		String dropdown_values = "";

		try {
			List<WebElement> values = Selement.findElements(By.xpath(".//option"));
			// String[]list_val = arrvalues.split(",");

			for (int a = 0; a < values.size(); a++) {
				String tmp = values.get(a).getText(); // getting the value of
														// the drop down
				dropdown_values = tmp + "," + dropdown_values;
			}

		} catch (Exception err) {
			// Reporter.log(err.getMessage());
		}
		return dropdown_values;
	}
	
	
	
	////===================
	/*
	 * This Function verifies columns of given table
	 * 
	 * @Param : strTableElement -> Element,columnNames -> expected column names
	 * separated by ","
	 * 
	 * @return -> Boolean value -> true/false
	 * 
	 * @author :Priyanka
	 */
	public boolean RFM_VerifyTableColumns(String strTableElement, String columnNames) {
		int intReturn = -1;
		boolean blnResult = false;
		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator(strTableElement));
		List<WebElement> eleCols = eleTable.findElements(By.xpath(".//thead/tr/th"));
		if (eleCols.size() == 0) {
			eleCols = eleTable.findElements(By.xpath(".//tr/th"));
			intReturn = eleCols.size();
		}
		if (eleCols.size() == 0) {
			eleCols = eleTable.findElements(By.xpath(".//thead/tr/td"));
		}
		intReturn = eleCols.size();
		if (eleCols.size() == 0) {
			System.out.println("Header row not present. Checking columns by reference of first row");
			eleCols = eleTable.findElements(By.xpath(".//tr[1]/td"));
			intReturn = eleCols.size();
		}
		// Split Column Names string
		String[] columnNamesArr = columnNames.split(",");
		for (int i = 0; i < eleCols.size(); i++) {
			String strColName = eleCols.get(i).getText();
			for (String colName : columnNamesArr) {
				if (colName.toUpperCase().equals(strColName.toUpperCase().trim())) {
					blnResult = true;
				}
			}
		}
		return blnResult;
	}

	/*
	 * This Function verifies List options of weblist
	 * 
	 * @Param : strListElement -> Object Repository name ,listOptions ->
	 * Expected list option separated by ","
	 * 
	 * @return : boolean value true-> Options are as expected /False-> options
	 * are not as expected
	 * 
	 * @Author :Priyanka
	 */
	public boolean fn_WebList_Verify_ListOptions_Exact(String strListElement, String listOptions) {
		boolean blnResult = false;
		try {
			String eleWebListXpath = actions.getLocator(strListElement);
			WebElement eleWebList = driver.findElement(By.xpath(eleWebListXpath));
			List<WebElement> options = eleWebList.findElements(By.tagName("option"));
			if (options.size() == 0) {
				System.out.println("Weblist is not present");
			}
			String[] optionsArr = listOptions.split(",");
			for (int i = 1; i < options.size(); i++) {
				String strWebListOptionName = options.get(i).getText();
				for (String option : optionsArr) {
					if (option.toUpperCase().equals(strWebListOptionName.toUpperCase())) {
						blnResult = true;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			// Reporter.log("Failed to find weblist '" + e.getMessage() + "'");

		}
		return blnResult;
	}

	public boolean VerifyPageTitle(String strPageTitle) {
		boolean blnReturn = false;
		if (driver.getTitle().trim().equalsIgnoreCase(strPageTitle)) {
			blnReturn = true;
			actions.reportCreatePASS("Verify the Page Title", "Page Title should be '" + strPageTitle + "'",
					"Page Title displayed as expected", "Pass");

		} else {
			blnReturn = false;
			actions.reportCreateFAIL("Verify the Page Title", "Page Title should be '" + strPageTitle + "'",
					"Expected page is NOT displayed. Actual page displayed is : '" + driver.getTitle().trim() + "'",
					"Fail");
		}
		System.out.println(blnReturn);
		return blnReturn;
	}

	// ===========>>>
	/// selecting the date from the date picker of a calender which is already
	// in open state
	// @param date = only date without month and year
	// @param month = pass "current" for current month , "next" for next month
	// and "prev" for previous month

	public void SelectDate_OpenCalender(String date, String month) {
		try {
			WebElement datepicker = null;
			
			date = DateFormatter(date);
			
			String[] sel_date = (date).split("/");
			// getting the date picker from available matching elements
			List<WebElement> num_datepickers = driver.findElements(By.className("datepicker"));
			for (int a = 0; a < num_datepickers.size(); a++) {

				String is_visible = num_datepickers.get(a).getAttribute("style"); ///
				datepicker = num_datepickers.get(a);
				break;
			}
			// setting the navigators on datepicker pop up
			WebElement go_next = datepicker.findElement(By.className("datepickerGoNext"));
			WebElement go_next_link = go_next.findElement(By.xpath(".//a")); // go
																				// next
																				// link
			WebElement go_prev = datepicker.findElement(By.className("datepickerGoPrev"));
			WebElement go_prev_link = go_prev.findElement(By.xpath(".//a")); // go
																				// to
																				// prev
																				// link
			WebElement Date_dayview = datepicker.findElement(By.className("datepickerDays"));
			List<WebElement> get_row = Date_dayview.findElements(By.xpath(".//tr")); // getting
																						// the
																						// rows
																						// in
																						// calendar
			// Checking the future date month is same or not
			if (month.equals("next")) {

				actions.keyboardEnter(go_next_link);
				// Reporter.log("Clicking on the Next month");

			} else // Checking the back date month is same or not
				if (month.equals("prev")) {
				go_prev_link.click();
				// Reporter.log("Clicking on the prev month");
			}

			// checking the number of cells
			try {
				for (int i = 0; i < get_row.size(); i++) {
					List<WebElement> get_col = get_row.get(i).findElements(By.xpath(".//td"));

					for (int j = 0; j < get_col.size(); j++) {
						// System.out.println("td: "+get_col.get(j).getText());

						String selectdate = get_col.get(j).getText(); // getting
																		// the
																		// text
																		// of
																		// the
																		// cell
																		// columns
						if (selectdate.length() < sel_date[0].length()) {
							selectdate = "0" + selectdate;
						}
						if (selectdate.equals(sel_date[0])) {
							String classname = get_col.get(j).getAttribute("Class");
							/// Checking for the dates from prev/next months are
							/// displayed or not and if displayed skip them..
							if (!classname.contains("datepickerNotInMonth")) {
								//get_col.get(j).click(); /// selecting the date
														/// now and moving out
								actions.reportCreatePASS("Select the Date '"+sel_date[0],
										"Should select the date '"+sel_date[0], 
										"Selected the date '"+sel_date[0], "Pass");
								actions.javaScriptClick(get_col.get(j).findElement(By.tagName("a")));					/// of the loop
								// Reporter.log("Selected the date
								// successfully");
//								List<WebElement> dis_datepickers = driver.findElements(By.className("datepicker"));
//								for (int a = 0; a < dis_datepickers.size(); a++) {
//
//									// JavascriptExecutor js =
//									// (JavascriptExecutor) driver;
//									// js.executeScript("arguments[0].style.visibility
//									// = 'hidden';",
//									// dis_datepickers.get(a));
//
//									// String is_visible =
//									// dis_datepickers.get(a).getAttribute("style");
//									// ///
//									// System.out.println("vis: "+is_visible);
//
//								}
								return;
							}
						}
					}
				}
			} catch (Exception e) {
				System.out.println("calendar picker is refreshed with new month");
				// again calling the function with current date parameter as
				// calendar got refreshed.
				SelectDate_OpenCalender(date, "current");
			}
		} catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
	}
	
	
	///============
	
	// ===========>>>
	/// selecting the date from the date picker of a calender which is already
	// in open state
	// @param date = only date without month and year
	// @param month = pass "current" for current month , "next" for next month
	// and "prev" for previous month

	public void SelectDate_OpenCalender_Priceset(String date, String month) {
		try {
			WebElement datepicker = null;
			
			date = DateFormatter(date);
			
			String[] sel_date = (date).split("/");
			// getting the date picker from available matching elements
			List<WebElement> num_datepickers = driver.findElements(By.className("datepicker"));
			for (int a = 0; a < num_datepickers.size(); a++) {

				String is_visible = num_datepickers.get(a).getAttribute("style"); ///
				datepicker = num_datepickers.get(a);
				break;
			}
			// setting the navigators on datepicker pop up
			WebElement go_next = datepicker.findElement(By.className("datepickerGoNext"));
			WebElement go_next_link = go_next.findElement(By.xpath(".//a")); // go
																				// next
																				// link
			WebElement go_prev = datepicker.findElement(By.className("datepickerGoPrev"));
			WebElement go_prev_link = go_prev.findElement(By.xpath(".//a")); // go
																				// to
																				// prev
																				// link
			WebElement Date_dayview = datepicker.findElement(By.className("datepickerDays"));
			List<WebElement> get_row = Date_dayview.findElements(By.xpath(".//tr")); // getting
																						// the
																						// rows
																						// in
																						// calendar
			// Checking the future date month is same or not
			if (month.equals("next")) {

				actions.keyboardEnter(go_next_link);
				// Reporter.log("Clicking on the Next month");

			} else // Checking the back date month is same or not
				if (month.equals("prev")) {
				go_prev_link.click();
				// Reporter.log("Clicking on the prev month");
			}

			// checking the number of cells
			try {
				for (int i = 0; i < get_row.size(); i++) {
					List<WebElement> get_col = get_row.get(i).findElements(By.xpath(".//td"));

					for (int j = 0; j < get_col.size(); j++) {
						// System.out.println("td: "+get_col.get(j).getText());

						String selectdate = get_col.get(j).getText(); // getting
																		// the
																		// text
																		// of
																		// the
																		// cell
																		// columns
						if (selectdate.length() < sel_date[0].length()) {
							selectdate = "0" + selectdate;
						}
						if (selectdate.equals(sel_date[0])) {
							String classname = get_col.get(j).getAttribute("Class");
							/// Checking for the dates from prev/next months are
							/// displayed or not and if displayed skip them..
							if (!classname.contains("datepickerNotInMonth") && !classname.contains("datepickerSelected")) {
								//get_col.get(j).click(); /// selecting the date
														/// now and moving out
								actions.reportCreatePASS("Select the Date '"+sel_date[0],
										"Should select the date '"+sel_date[0], 
										"Selected the date '"+sel_date[0], "Pass");
								actions.javaScriptClick(get_col.get(j).findElement(By.tagName("a")));					/// of the loop
								// Reporter.log("Selected the date
								// successfully");
//								List<WebElement> dis_datepickers = driver.findElements(By.className("datepicker"));
//								for (int a = 0; a < dis_datepickers.size(); a++) {
//
//									// JavascriptExecutor js =
//									// (JavascriptExecutor) driver;
//									// js.executeScript("arguments[0].style.visibility
//									// = 'hidden';",
//									// dis_datepickers.get(a));
//
//									// String is_visible =
//									// dis_datepickers.get(a).getAttribute("style");
//									// ///
//									// System.out.println("vis: "+is_visible);
//
//								}
							return ;
							}
						}
					}
				}
				//for setting the value on promotional price set
				SelectDate_OpenCalender_Priceset(date, "next");
				
			} catch (Exception e) {
				System.out.println("calendar picker is refreshed with new month");
				// again calling the function with current date parameter as
				// calendar got refreshed.
				SelectDate_OpenCalender_Priceset(date, "current");
				
			}
		} catch (Exception e) {
			System.out.println(e.getStackTrace());
		}
	}
	
	
	
	
	
	
	
	
	///================
	
	
	

	public int RanNum(int ranValue) {
		int random = 0;
		Random randomValue = new Random();
		for (int i = ranValue; i <= 999; ++i) {
			random = randomValue.nextInt(999);

		}

		return random;
	}

	public boolean VerifyOnscreenMessage(String strElementName, String strExptMesssage, boolean blnExactMatch)
			throws Exception {
		String strError = "";
		boolean blnErrorFlag;

		System.out.println("Verify message '" + strExptMesssage + "'");
		try {
			strError = actions.getwebDriverLocator(actions.getLocator(strElementName)).getText();
			System.out.println(strError);
		} catch (Exception e) {
			throw new Exception("On-screen message element is not found");
		}

		if (blnExactMatch) {
			if (strError.equalsIgnoreCase(strExptMesssage)) {
				blnErrorFlag = true;
				System.out.println(blnErrorFlag);
				System.out.println("Message Displayed as expected : '" + strError + "'");

			} else {
				blnErrorFlag = false;
				System.out.println("Message is not displayed as expected. Actual message :'" + strError + "'");
			}
		} else {
			if (strError.contains(strExptMesssage)) {
				blnErrorFlag = true;
				System.out.println(blnErrorFlag);
				System.out.println("Message Displayed as expected : '" + strError + "'");

			} else {
				blnErrorFlag = true;
				System.out.println("Message is not displayed as expected. Actual message :'" + strError + "'");
			}
		}
		return blnErrorFlag;
	}

	/// ======== Function for Pagination
	public void verifyPagination() throws InterruptedException {

		List<WebElement> pagination = driver.findElements(By.xpath("//*[@id='paginationLinks']"));
		System.out.println(pagination.size());
		// checkif pagination link exists

		if (pagination.size() > 0) {
			actions.reportCreatePASS("Verify Pagination exists",
					"Pagination should present provided sufficient records exists in market", "Pagination is present",
					"Pass");
			System.out.println("pagination exists");

			// click on pagination link
			Thread.sleep(5000);
			for (int i = 0; i < pagination.size(); i++) {
				Thread.sleep(5000);
				pagination.get(i).click();
			}
		} else {
			System.out.println("pagination not exists");
			actions.reportCreateFAIL("Verify Pagination exists",
					"Pagination should present provided sufficient records exists in market",
					"Pagination doesnot exists", "Fail");
		}
		// ==========================
	}
	
	
	
	//==========
	public void ClickPagination_link(int pagenum) throws InterruptedException {

		List<WebElement> pagination = driver.findElements(By.xpath("//*[@id='paginationLinks']//td"));
		System.out.println(pagination.size());
		// checkif pagination link exists

		if (pagination.size() > 0) {
			
			if(pagination.size()<pagenum){
				actions.click(pagination.get(pagination.size()-1));
				actions.reportCreatePASS("Clicking Pagination link '"+pagenum,
						"Should click on the Pagination link '"+pagenum, "Click on the Pagination link '"+pagenum+"is successful",
						"Pass");
			}else{
			System.out.println("pagination exists");
			actions.click(pagination.get(pagenum));
			
			Thread.sleep(1000);
			actions.reportCreatePASS("Clicking Pagination link '"+pagenum,
					"Should click on the Pagination link '"+pagenum, "Click on the Pagination link '"+pagenum+"is successful",
					"Pass");
			}

		} else {
			System.out.println("pagination not exists");
			actions.reportCreateFAIL("Verify Pagination exists",
					"Pagination should present provided sufficient records exists in market",
					"Pagination doesnot exists", "Fail");
		}
		// ==========================
	}
	
	
	
	
	
	
	//=========

	/**
	 * Function : To select a specific date from an open calender Parameter :
	 * DateToSelect : date in format dd/mm/yyyy : Calender_Type : "close" or
	 * "open"
	 * 
	 * @param DateToSelect
	 * @param Calender_Type
	 */

	public void Select_SpecificDate(String DateToSelect, String Calender_Type) {

		String DateDisplayed = null;
		if (Calender_Type.trim().equalsIgnoreCase("close")) {
			WebElement datepicker = null;
			// get the date picker from available matching elements
			List<WebElement> num_datepickers = driver.findElements(By.className("datepicker"));
			for (int a = 0; a < num_datepickers.size(); a++) {
				String is_visible = num_datepickers.get(a).getAttribute("style");
				try{
					if (is_visible.contains("visible")) {
						datepicker = num_datepickers.get(a);
						break;
					}	
				}catch(Exception e){
					
				}
				
			}
			// set the navigators on datepicker pop up
			WebElement MnthName = datepicker.findElement(By.className("datepickerMonth"));
			DateDisplayed = MnthName.findElement(By.xpath(".//a")).getText();
		} else if (Calender_Type.trim().equalsIgnoreCase("open")) {
			DateDisplayed = driver.findElement(By.xpath("//*[@class = 'datepicker']//th[@class = 'datepickerMonth']/a"))
					.getText();
		} else {
			System.out.println("Enter correct calender type");
		}

		String MnthDisplayed = DateDisplayed.split(",")[0].trim();
		String YearDisplayed = DateDisplayed.split(",")[1].trim();
		int iFromYear = Integer.parseInt(YearDisplayed);
		int iFromMnth = 0;
		System.out.println(MnthDisplayed);

		String Arr_Mnth[] = { "January", "February", "March", "April", "May", "June", "July", "August", "September",
				"October", "November", "December" };

		// Get mnth number for FromDate:
		for (int i = 0; i < Arr_Mnth.length; i++) {
			if ((Arr_Mnth[i].equalsIgnoreCase(MnthDisplayed))) {
				iFromMnth = i + 1;
				break;
			}
		}

		// DateToSelect = "25/08/2015";

		String go_toDt = DateToSelect.split("/")[0].trim();

		int go_Mnth = Integer.parseInt(DateToSelect.split("/")[1].trim());
		String go_Mnth_name = Arr_Mnth[go_Mnth - 1];

		int iTo_Year = Integer.parseInt(DateToSelect.split("/")[2].trim());
		int Yr_Flag = 0;
		int Mnth_Flag = 0;
		String strDirection = null;
		if (iFromYear == iTo_Year) {
			Yr_Flag = 0;
			if (iFromMnth == go_Mnth) {
				strDirection = "current";
			} else if (iFromMnth < go_Mnth) {
				strDirection = "next";
			} else {
				strDirection = "previous";
			}

		} else if (iFromYear < iTo_Year) {
			Yr_Flag = 1;
			strDirection = "next";
		} else {
			Yr_Flag = -1;
			strDirection = "previous";
		}

		WebElement datepicker = null;
		List<WebElement> num_datepickers = null;
		// getting the date picker from available matching elements
		num_datepickers = driver.findElements(By.xpath("//*[@class='datepicker'][contains(@style,'visible')]"));
		if(num_datepickers.isEmpty()){
			num_datepickers = driver.findElements(By.xpath("//*[@class='datepicker']"));
		}
		for (int a = 0; a < num_datepickers.size(); a++) {

			String is_visible = num_datepickers.get(a).getAttribute("style");
			datepicker = num_datepickers.get(a);
			break;
		}
		// setting the navigators on datepicker pop up
		WebElement go_next = datepicker.findElement(By.className("datepickerGoNext"));
		WebElement go_next_link = go_next.findElement(By.xpath(".//a")); // go
																			// next
																			// link
		WebElement go_prev = datepicker.findElement(By.className("datepickerGoPrev"));
		WebElement go_prev_link = go_prev.findElement(By.xpath(".//a")); // go
																			// to
																			// prev
																			// link

		Boolean chk1 = false;
		Boolean chk2 = false;
		do {

			if (strDirection.equals("next")) {
				go_next_link.click();
				// Reporter.log("Clicking on the Next month");
			} else if (strDirection.equals("previous")) {
				go_prev_link.click();
				// Reporter.log("Clicking on the prev month");
			} else {
				System.out.println("Need to select date from current month");
			}

			String New_Mnth = null;

			if (Calender_Type.trim().equalsIgnoreCase("close")) {
				datepicker = null;
				// get the date picker from available matching elements
				num_datepickers = driver.findElements(By.className("datepicker"));
				for (int a = 0; a < num_datepickers.size(); a++) {
					String is_visible = num_datepickers.get(a).getAttribute("style");
					if (is_visible.contains("visible")) {
						datepicker = num_datepickers.get(a);
						break;
					}
				}
				// set the navigators on datepicker pop up
				WebElement New_MnthName = datepicker.findElement(By.className("datepickerMonth"));
				New_Mnth = New_MnthName.findElement(By.xpath(".//a")).getText();
			} else if (Calender_Type.trim().equalsIgnoreCase("open")) {
				New_Mnth = driver.findElement(By.xpath("//*[@class = 'datepicker']//th[@class = 'datepickerMonth']/a"))
						.getText();
			} else {
				System.out.println("Enter correct calender type");
			}

			System.out.println(New_Mnth);
			MnthDisplayed = New_Mnth.split(",")[0].trim();
			YearDisplayed = New_Mnth.split(",")[1].trim();
			iFromYear = Integer.parseInt(YearDisplayed);
			chk1 = MnthDisplayed.equalsIgnoreCase(go_Mnth_name);
			chk2 = (iFromYear == iTo_Year);
		} while (!((chk1) && (chk2)));

		if (Calender_Type.trim().equalsIgnoreCase("open")) {
			SelectDate_OpenCalender(go_toDt, "current");
		} else if (Calender_Type.trim().equalsIgnoreCase("close")) {
			select_date(go_toDt, "current");
		}
	}

	/**
	 * Select drop down value
	 * 
	 * @param sElementName
	 * @param strCaption
	 * @param strValue
	 */
	public void selectDropDownValue(String sElementName, String strCaption, String strValue) {
		if (actions.getwebDriverLocator(actions.getLocator(sElementName)) != null) {
			WebElement eleDropDown = actions.getwebDriverLocator(actions.getLocator(sElementName));
			Select select = new Select(eleDropDown);
			try {
				select.selectByVisibleText(strValue);
				actions.reportCreatePASS("Select value for '" + strCaption + "'",
						"Value '" + strValue + "' should be selected", "Value selected successfully", "Pass");
			} catch (Exception e) {
				actions.reportCreateFAIL("Select value for '" + strCaption + "'",
						"Value '" + strValue + "' should be selected", "Value '" + strValue + "' is not available",
						"Fail");
			}
		} else {
			actions.reportCreateFAIL("Select value for '" + strCaption + "'",
					"Value '" + strValue + "' should be selected", "Element not found", "Fail");
		}

	}

	/** Function to open generated report on View Generated report page */
	public String VerifyGeneratedReprt(String strReportName, String DestReportTitle) throws Exception {

		// To click on 'Date/Time'
		Thread.sleep(5000);
		int rowCount = GetTableRowCount("ViewGeneratedReport.TableElements");
		String DateTimeStamp = null;
		try {
			if (rowCount == 1) {
				DateTimeStamp = driver
						.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.FirstEleDateTimeStamp")))
						.getText();
				driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.SelectReportName"))).click();
				SwitchToWindow("@" + DestReportTitle);
				actions.smartWait(150);
			} else {
				driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.SortDateTime"))).click();
				Thread.sleep(5000);

				// To click on 'Date/Time' upward arrow button
				String ReprtStatus;
				do {
					driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.SortDateTimeArrowUp"))).click();
					Thread.sleep(6000);
					ReprtStatus = driver
							.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.StatusFirstElement")))
							.getText();

					actions.smartWait(200);

					if (ReprtStatus.trim().equalsIgnoreCase("Generated")) {
						// To click on Report Name link
						DateTimeStamp = driver
								.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.FirstEleDateTimeStamp")))
								.getText();
						WebElement keyh = driver
								.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.SelectReportName")));
						actions.keyboardEnter(keyh);
						System.out.println(ReprtStatus);
						break;
					} else {
						driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.SortDateTimeArrowUp")))
								.click();
						Thread.sleep(6000);
					}

				} while (ReprtStatus != "Failed" || ReprtStatus != "Generated");

				// actions.smartWait(70);
				SwitchToWindow("@" + DestReportTitle);
				actions.smartWait(150);

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return (DateTimeStamp);
	}

	/** Function to verify OK button functionality of the report */
	public void VerifyReportOKBtnFunct(String strReportName, String DestReportTitle) throws Exception {

		/** Open generated report */
		String VG_Previous_Title = driver.getTitle();
		System.out.println("> VG_Previous_Title :: " + VG_Previous_Title);
		// driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.FirstEleDateTimeStamp"))).getText();
		String DateTimeStamp = VerifyGeneratedReprt(strReportName, DestReportTitle);
		System.out.println("> DateTimeStamp :: " + DateTimeStamp);

		// Verify functionality of OK button at the top of the report

		List<WebElement> ElementsOK = driver.findElements(By.xpath(actions.getLocator("RFM_Report.OKButton")));
		actions.keyboardEnter(ElementsOK.get(0));
		// actions.smartWait(20);

		SwitchToWindow("@View Generated Reports");
		actions.smartWait(20);

		// Get title after clicked on 'Ok' button of generated report
		String CWindow_Title = driver.getTitle();
		System.out.println("> CWindow_Title :: " + CWindow_Title);

		if (CWindow_Title.trim().equalsIgnoreCase(VG_Previous_Title))
			actions.reportCreatePASS(
					"Verify that the application is navigated to the View Generated Report screen when user clicks on OK button on the bottom of  the report",
					"The application should be navigated to the View Generated Report screen when user clicks on OK button on the bottom the report",
					"The application is navigated to the View Generated Report screen when user clicks on OK button on the bottom of  the report",
					"Pass");
		else
			actions.reportCreateFAIL(
					"Verify that the application is navigated to the View Generated Report screen when user clicks on OK button on the bottom of  the report",
					"The application should be navigated to the View Generated Report screen when user clicks on OK button on the bottom of  the report",
					"The application is not navigated to the View Generated Report screen when user clicks on OK button on the bottom of  the report",
					"Fail");

		// Open the report again

		driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.SortDateTime"))).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.SortDateTimeArrowUp"))).click();
		Thread.sleep(2000);

		String DateTimeStampC = null;
		String ReportLink = null;

		for (int i = 1;; i = i + 1) {

			WebElement a = driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.TableElements")));
			DateTimeStampC = a.findElement(By.xpath("./tr[" + i + "]/td[3]")).getText();
			System.out.println("> DateTimeStampC :: " + DateTimeStampC);

			if (DateTimeStampC.trim().equalsIgnoreCase(DateTimeStamp.trim())) {

				WebElement a1 = driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.TableElements")));
				a1.findElement(By.xpath("./tr[" + i + "]/td[3]")).getText();
				break;
			} else
				i++;
		}

		driver.findElement(By.xpath(actions.getLocator("ViewGeneratedReport.SelectReportName"))).click();
		SwitchToWindow("@" + DestReportTitle);
		actions.smartWait(150);

		// Verify functionality of OK button at the bottom of the report
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,500)", "");

		ElementsOK = driver.findElements(By.xpath(actions.getLocator("RFM_Report.OKButton")));
		actions.keyboardEnter(ElementsOK.get(1));

		SwitchToWindow("@View Generated Reports");
		actions.smartWait(20);

		// Get title after clicked on 'Ok' button of generated report
		String CWindow_Title2 = driver.getTitle();
		System.out.println("> CWindow_Title2 :: " + CWindow_Title2);

		if (CWindow_Title2.trim().equalsIgnoreCase(VG_Previous_Title))
			actions.reportCreatePASS(
					"Verify that the application is navigated to the View Generated Report screen when user clicks on OK button on the bottom on the bottom of the report",
					"The application should be navigated to the View Generated Report screen when user clicks on OK button on the bottom of the report",
					"The application is navigated to the View Generated Report screen when user clicks on OK button on the bottom of the report",
					"Pass");
		else
			actions.reportCreateFAIL(
					"Verify that the application is navigated to the View Generated Report screen when user clicks on OK button on the bottom of the report",
					"The application should be navigated to the View Generated Report screen when user clicks on OK button on the bottom of the report",
					"The application is not navigated to the View Generated Report screen when user clicks on OK button on the bottom of the report",
					"Fail");

	}

	/** Verify Print all functionality on report */
	// PrintAllWndTitle string is the title of window opened when clicked on
	// print all button on report
	// DestReportTitle is title of page opnede when required report is opened

	public void VerifyReportPrintAllBtnFunct(String PrintAllWndTitle, String DestReportTitle) throws Exception {
		List<WebElement> ElementsOK = driver.findElements(By.xpath(actions.getLocator("RFM_Report.PrintAllButton")));
		actions.keyboardEnter(ElementsOK.get(0));

		SwitchToWindow(PrintAllWndTitle);
		actions.smartWait(50);

		// Verify Print All functionality
		// Verify Save As CSV buttons are displayed

		List<WebElement> ElementsSaveAsCSV = driver
				.findElements(By.xpath(actions.getLocator("RFM_Report_PrintAll.SaveAsCSVBtn")));

		if (ElementsSaveAsCSV.size() == 2)
			actions.reportCreatePASS(
					"Verify that 'Save As CSV' button is displayed on the top and bottom of the generated report",
					"'Save As CSV' button should be displayed on the top and bottom of the generated report",
					"'Save As CSV' button is displayed on the top and bottom of the generated report", "Pass");
		else
			actions.reportCreateFAIL(
					"Verify that 'Save As CSV' button is displayed on the top and bottom of the generated report",
					"'Save As CSV' button should be displayed on the top and bottom of the generated report",
					"'Save As CSV' button is not displayed on the top and bottom of the generated report", "Fail");

		// Verify Print Page buttons are displayed

		List<WebElement> ElementsPrintpage = driver
				.findElements(By.xpath(actions.getLocator("RFM_Report_PrintAll.PrintPageBtn")));

		if (ElementsPrintpage.size() == 2)
			actions.reportCreatePASS(
					"Verify that 'Print Page' button is displayed on the top and bottom of the generated report",
					"'Print Page' button should be displayed on the top and bottom of the generated report",
					"'Print Page' button is displayed on the top and bottom of the generated report", "Pass");
		else
			actions.reportCreateFAIL(
					"Verify that 'Print Page' button is displayed on the top and bottom of the generated report",
					"'Print Page' button should be displayed on the top and bottom of the generated report",
					"'Print Page' button is not displayed on the top and bottom of the generated report", "Fail");

		// Verify Cancel buttons are displayed

		List<WebElement> ElementsCancel = driver
				.findElements(By.xpath(actions.getLocator("RFM_Report_PrintAll.CancelBtn")));

		if (ElementsCancel.size() == 2)
			actions.reportCreatePASS(
					"Verify that 'Cancel' button is displayed on the top and bottom of the generated report",
					"'Cancel' button should be displayed on the top and bottom of the generated report",
					"'Cancel' button is displayed on the top and bottom of the generated report", "Pass");
		else
			actions.reportCreateFAIL(
					"Verify that 'Cancel' button is displayed on the top and bottom of the generated report",
					"'Cancel' button should be displayed on the top and bottom of the generated report",
					"'Cancel' button is not displayed on the top and bottom of the generated report", "Fail");

		ElementsCancel.get(0).click();
		SwitchToWindow("$" + DestReportTitle);
		actions.smartWait(20);
	}

	/** Verify Generate Report button related messages on the report */
	// This function validate message displayed when clicked on Generate Report
	// button without any data and after selecting all required fields values

	public void VerifyGenerateReportBtnMesgVal(String elocatorViewFullListBtn, String elocatorGenerateReportBtn,
			String elocatorAddrightbutton, String elocatorAvailableListArea, String elocatorOnScreenMessage,
			String strWithoutDataSelMessage, String strSuccessMessage) throws Exception {
		// Verify error message displayed when user clicks on Generate Button
		// without selecting price set
		actions.click(elocatorViewFullListBtn);

		actions.click(elocatorGenerateReportBtn);
		Boolean Flag2 = VerifyAlertMessageDisplayed("Warning Message", strWithoutDataSelMessage, true,
				AlertPopupButton.OK_BUTTON);
		if (Flag2)
			actions.reportCreatePASS(
					"Verify that correct error message is displayed when user clicks on 'Generate Report' button without any data selection",
					"Correct error message gets displayed when user clicks on 'Generate Report' button without any data selection",
					"Correct error message is displayed when user clicks on 'Generate Report' button without any data selection",
					"Pass");
		else
			actions.reportCreateFAIL(
					"Verify that correct error message is displayed when user clicks on 'Generate Report' button without any data selection",
					"Correct error message is not displayed when user clicks on 'Generate Report' button without any data selection",
					"Correct error message is displayed when user clicks on 'Generate Report' button without any data selection",
					"Fail");

		// Verify message displayed after report has been generated

		select_row(elocatorAvailableListArea, 0);
		actions.click(elocatorAddrightbutton);
		actions.smartWait(10);

		actions.click(elocatorGenerateReportBtn);
		Boolean Flag3 = VerifyOnscreenMessage(elocatorOnScreenMessage, strSuccessMessage, true);
		if (Flag3)
			actions.reportCreatePASS(
					"Verify that correct message is displayed when user clicks on 'Generate Report' button with required data selection",
					"Correct message gets displayed when user clicks on 'Generate Report' button with required data selection",
					"Correct message is displayed when user clicks on 'Generate Report' button with required data selection",
					"Pass");
		else
			actions.reportCreateFAIL(
					"Verify that correct message is displayed when user clicks on 'Generate Report' button with required data selection",
					"Correct message is not displayed when user clicks on 'Generate Report' button with required data selection",
					"Correct message is displayed when user clicks on 'Generate Report' button with required data selection",
					"Fail");

	}

	/**
	 * Function to verify report generated by details on View Generated report
	 * page
	 */
	public void VerifyReportGeneratedBy(String Report_UserId) throws Exception {

		String ExpectRGBy = "Report generated by " + Report_UserId;
		System.out.println("ExpectRGBy" + ExpectRGBy);
		Boolean Flag_RGenerator = actions.isTextPresence(ExpectRGBy, true);

		if (Flag_RGenerator)
			actions.reportCreatePASS("Verify that correct report generator name is displayed on generated report",
					"Correct report generator name should get displayed on generated report",
					"Correct report generator name is displayed on generated report", "Pass");
		else
			actions.reportCreateFAIL("Verify that correct report generator name is displayed on generated report",
					"Correct report generator name should get displayed on generated report",
					"Correct report generator name is not displayed on generated report", "Fail");
	}

	/** Function to open generated report on View Generated report page */

	/**
	 * to verify Button Element on the page.
	 * 
	 * @param elementvalue
	 *            which are seperated by '#'
	 */

	public void verifyButtonElement(String elementvalue) {
		Boolean Flag = false;
		String[] ElementValues = elementvalue.split("#");
		Integer strELength = ElementValues.length;
		for (int i = 0; i <= strELength - 1; i++) {
			String xpath = "//*[normalize-space(text()) = '" + ElementValues[i] + "']";
			try {
				Flag = driver.findElement(By.xpath(xpath)).isDisplayed();
				if (Flag) {
					System.out.println("Present");
					Flag = true;
				}
			} catch (Exception e) {
				try {
					List<WebElement> list = driver.findElements(By.xpath(xpath));
					if (list.size() > 0) {
						for (int j = 0; j < list.size(); j++) {
							Flag = list.get(j).isDisplayed();
							if (Flag) {
							} else {
								Flag = false;
							}
						}
					} else {
						Flag = false;
					}
				} catch (Exception err) {
					Flag = false;
				}
			}
			if (Flag) {
				actions.reportCreatePASS("'Element'" + ElementValues[i] + " is Displayed",
						"Element" + ElementValues[i] + "should Displayed",
						"Element" + ElementValues[i] + "is Displayed", "Pass");
			} else {
				actions.reportCreateFAIL("'Element'" + ElementValues[i] + " is Displayed",
						"Element" + ElementValues[i] + "should Displayed",
						"Element" + ElementValues[i] + "is not Displayed", "Fail");
			}
		}
	}

	/**
	 * Search Function
	 */

	public void SearchFunction(String eElemtSearchTextBox, String strSearchValue, String strTableFirstData,
			String strSearchScenario) throws InterruptedException {

		Boolean blnSearch = false;

		// Enter serach text
		actions.setValue(eElemtSearchTextBox, strSearchValue);

		// Click on Search button
		WebElement searchBtn = driver.findElement(By.xpath("//*[(normalize-space(text())='Search')]"));
		actions.keyboardEnter(searchBtn);

		// Wait
		Thread.sleep(1000);
		actions.smartWait(120);

		// Switch to verify valid/invalid search
		switch (strSearchScenario.toLowerCase()) {
		case "valid":
			// Verify that Search String appears or not
			String strSearchString = driver.findElement(By.xpath(actions.getLocator(strTableFirstData))).getText();
			if (strSearchString.trim().equalsIgnoreCase(strSearchValue)) {
				actions.reportCreatePASS("Verify the Search String is getting displayed or not",
						" Searched String should get displayed", "Search is getting displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify the Search String is getting displayed or not",
						" Searched String should get displayed", "Search is not getting displayed", "Fail");
			}
			break;
		case "invalid":
			// Verify that Search String appears or not
			try {
				blnSearch = driver.findElement(By.xpath(actions.getLocator(strTableFirstData))).isDisplayed();

				if (!blnSearch) {
					actions.reportCreatePASS("Verify invalid Search String", "No records should be fetched",
							"No records fetched for invalid string", "PASS");
				} else {
					actions.reportCreateFAIL("Verify invalid Search String", "No records should be fetched",
							"Records fetched for invalid string", "FAIL");
				}
			} catch (Exception err) {
				if (!blnSearch) {
					actions.reportCreatePASS("Verify invalid Search String", "No records should be fetched",
							"No records fetched for invalid string", "PASS");
				} else {
					actions.reportCreateFAIL("Verify invalid Search String", "No records should be fetched",
							"Records fetched for invalid string", "FAIL");
				}
			}
			break;
		default:
			break;
		}
	}

	/**
	 * String Sorting Function
	 */
	public void Verify_Sorting_String(String elemTableRow, String elemSortOrder, String elemHeader,
			String strColumnName, int iColumnNum, String strDataType) throws InterruptedException {
		String strSortOrderValue = "";
		String TableXpath = actions.getLocator(elemTableRow);

		// Verify whether any default sort is present
		if (!(ISAttributePresent(elemSortOrder, "src"))) {
			actions.keyboardEnter(elemHeader);
			Thread.sleep(2000);
			actions.smartWait(120);
		} else {
			System.out.println("Default sort is present");
		}

		// Verify SORTING

		List<WebElement> eleRws = driver.findElements(By.xpath(TableXpath));
		int iNewMIRwCnt = eleRws.size();

		// Take 1st two elements for comparison by Name
		String MI_Num1 = eleRws.get(0).findElement(By.xpath("./td[" + iColumnNum + "]")).getText();
		String MI_Num2 = eleRws.get(1).findElement(By.xpath("./td[" + iColumnNum + "]")).getText();

		String strSortOrder = null;
		strSortOrderValue = driver.findElement(By.xpath(actions.getLocator(elemSortOrder))).getAttribute("src");

		if (strSortOrderValue.contains("up")) {
			strSortOrder = "Ascending";
			Verify_Sort_Ascending(MI_Num1, MI_Num2, strColumnName, strDataType);

		} else if (strSortOrderValue.contains("down")) {
			strSortOrder = "Descending";
			Verify_Sort_Descending(MI_Num1, MI_Num2, strColumnName, strDataType);
		} else {
			actions.reportCreateFAIL("Verify Sorting", "Sorting direction (Ascending/Descing) should be displayed",
					"Sorting direction (Ascending/Descing) is displayed", "PASS");
		}

		// Click again to verify next sorting order
		Thread.sleep(2000);
		actions.keyboardEnter(elemHeader);
		Thread.sleep(2000);
		actions.smartWait(120);

		List<WebElement> eleRws1 = driver.findElements(By.xpath(TableXpath));
		int iNewMIRwCnt1 = eleRws.size();
		String MI_Num3 = eleRws1.get(0).findElement(By.xpath("./td[" + iColumnNum + "]")).getText();
		String MI_Num4 = eleRws1.get(1).findElement(By.xpath("./td[" + iColumnNum + "]")).getText();

		strSortOrderValue = driver.findElement(By.xpath(actions.getLocator(elemSortOrder))).getAttribute("src");

		if (strSortOrderValue.contains("up")) {
			strSortOrder = "Ascending";
			Verify_Sort_Ascending(MI_Num3, MI_Num4, strColumnName, strDataType);

		} else if (strSortOrderValue.contains("down")) {
			strSortOrder = "Descending";
			Verify_Sort_Descending(MI_Num3, MI_Num4, strColumnName, strDataType);
		} else {
			actions.reportCreateFAIL("Verify Sorting", "Sorting direction (Ascending/Descing) should be displayed",
					"Sorting direction (Ascending/Descing) is displayed", "PASS");
		}

	}

	/**
	 * Sorting Ascending
	 */

	public void Verify_Sort_Ascending(String strValue1, String strValue2, String strColumnName, String strDataType) {

		switch (strDataType.toLowerCase()) {
		case "integer":
			if (Integer.parseInt(strValue1) <= Integer.parseInt(strValue2)) {
				actions.reportCreatePASS("Verify Ascending Sorting according to " + strColumnName,
						"List should be sorted(Ascending)correctly", "List is sorted(Ascending) correctly", "PASS");
				// System.out.println("sorted ascending correct");
			} else {
				actions.reportCreateFAIL("Verify Ascending Sorting according to " + strColumnName,
						"List should be sorted(Ascending) correctly", "List is not sorted(Ascending) correctly",
						"FAIL");
				// System.out.println("sorted ascending incorrect");
			}
			break;
		case "string":
			int ReturnNumber = strValue1.toUpperCase().compareTo(strValue2.toUpperCase());
			if (ReturnNumber <= 0) {
				actions.reportCreatePASS("Verify Ascending Sorting according to " + strColumnName,
						"List should be sorted(Ascending)correctly", "List is sorted(Ascending) correctly", "PASS");
				// System.out.println("sorted ascending correct");
			} else {
				actions.reportCreateFAIL("Verify Ascending Sorting according to " + strColumnName,
						"List should be sorted(Ascending) correctly", "List is not sorted(Ascending) correctly",
						"FAIL");
				// System.out.println("sorted ascending incorrect");
			}
			break;
		default:
			break;
		}

	}

	/**
	 * Sort Descending Funtion
	 */

	public void Verify_Sort_Descending(String strValue1, String strValue2, String strColumnName, String strDataType) {

		switch (strDataType.toLowerCase()) {
		case "integer":
			if (Integer.parseInt(strValue1) >= Integer.parseInt(strValue2)) {
				actions.reportCreatePASS("Verify Descending Sorting according to " + strColumnName,
						"List should be sorted(Descending) correctly", "List is sorted correctly(Descending)", "PASS");
				// System.out.println("sorted descending correct");
			} else {
				actions.reportCreateFAIL("Verify Descending Sorting according to " + strColumnName,
						"List should be sorted(Descending) correctly", "List is not sorted(Descending) correctly",
						"FAIL");
				// System.out.println("sorted descending incorrect");
			}
			break;
		case "string":
			int ReturnNumber = strValue1.toUpperCase().compareTo(strValue2.toUpperCase());
			if (ReturnNumber >= 0) {
				actions.reportCreatePASS("Verify Descending Sorting according to " + strColumnName,
						"List should be sorted(Descending) correctly", "List is sorted correctly(Descending)", "PASS");
				// System.out.println("sorted descending correct");
			} else {
				actions.reportCreateFAIL("Verify Descending Sorting according to " + strColumnName,
						"List should be sorted(Descending) correctly", "List is not sorted(Descending) correctly",
						"FAIL");
				// System.out.println("sorted descending incorrect");
			}
			break;
		default:
			break;
		}
	}

	/**
	 * Select drop down value
	 * 
	 * @param eleDropDown
	 * @param strCaption
	 * @param strValue
	 */
	public void selectDropDownValue(WebElement eleDropDown, String strCaption, String strValue) {
		if (eleDropDown != null) {
			Select select = new Select(eleDropDown);
			try {
				select.selectByVisibleText(strValue);
				actions.reportCreatePASS("Select value for '" + strCaption + "'",
						"Value '" + strValue + "' should be selected", "Value selected successfully", "Pass");
			} catch (Exception e) {
				actions.reportCreateFAIL("Select value for '" + strCaption + "'",
						"Value '" + strValue + "' should be selected", "Value '" + strValue + "' is not available",
						"Fail");
			}
		} else {
			actions.reportCreateFAIL("Select value for '" + strCaption + "'",
					"Value '" + strValue + "' should be selected", "Element not found", "Fail");
		}

	}
	
	///select value for drop by index
	public void selectDropDownValue(WebElement eleDropDown, String strCaption, int indexval) {
		String strValue= null;
		if (eleDropDown != null) {
			Select select = new Select(eleDropDown);
			try {
				select.selectByIndex(indexval);
				strValue = select.getFirstSelectedOption().getText();
				actions.reportCreatePASS("Select value for '" + strCaption + "'",
						"Value '" + strValue + "' should be selected", "Value selected successfully", "Pass");
			} catch (Exception e) {
				actions.reportCreateFAIL("Select value for '" + strCaption + "'",
						"Value '" + strValue + "' should be selected", "Value '" + strValue + "' is not available",
						"Fail");
			}
		} else {
			actions.reportCreateFAIL("Select value for '" + strCaption + "'",
					"Value '" + strValue + "' should be selected", "Element not found", "Fail");
		}

	}

	/** Function for View Full List */
	public void ViewFullListFunctionality(String eElemtTableRowCount, String functionalityName)
			throws InterruptedException {

		WebElement viewFullListBtn = driver.findElement(By.xpath("//*[(normalize-space(text())='View Full List')]"));
		actions.keyboardEnter(viewFullListBtn);

		Thread.sleep(1000);
		actions.smartWait(10);

		// Verify that View Full List button functionality
		int count_NumberofRows = driver.findElements(By.xpath(actions.getLocator(eElemtTableRowCount))).size();
		if (count_NumberofRows > 0) {
			actions.reportCreatePASS("Verify the Search " + functionalityName + " by View Full List",
					"All Active & Inactive " + functionalityName
							+ "  available in the Market are displayed in the grid ",
					"Total " + count_NumberofRows + functionalityName
							+ "  available in the Market are displayed in the grid ",
					"Pass");
		} else {
			actions.reportCreatePASS("Verify the Search " + functionalityName + " by View Full List",
					"All Active & Inactive " + functionalityName
							+ "  available in the Market are displayed in the grid ",
					"Total  '0 ' " + functionalityName + "  available in the Market are displayed in the grid ",
					"Fail");
		}

	}

	/** Function for Filter with Status */

	public void FilterwithStatus(String elocatorFilterStatus, String strStatus, String eElementLoactor,
			int ColumnNumber, String elocatoronScreenMessage) throws Exception {
		// Select "Active" from Status dropdown
		Thread.sleep(2000);
		boolean blnStatus = false;
		boolean blnextecution = true;
		actions.setValue(elocatorFilterStatus, strStatus);
		// wait
		// try{
		Thread.sleep(1000);
		actions.smartWait(10);

		List<WebElement> Element = driver.findElements(By.xpath(actions.getLocator(eElementLoactor)));
		if (Element.size() > 0) {

			// Verify that only active set are getting displayed
			for (int i = 1; i <= Element.size(); i++) {
				String eleTextValue = "";
				try {
					eleTextValue = Element.get(0)
							.findElement(By.xpath("./td[" + ColumnNumber + "]/select/option[@selected='selected']"))
							.getText();
				} catch (Exception E) {
					eleTextValue = Element.get(0).findElement(By.xpath("./td[" + ColumnNumber + "]")).getText();
				}
				if (eleTextValue.equalsIgnoreCase(strStatus)) {
					blnStatus = true;
				} else {
					blnStatus = false;
					break;
				}

			}
			if (blnStatus) {
				actions.reportCreatePASS("Verify that Status with" + strStatus + " set are getting displayed",
						"All set Should displayed with " + strStatus + " Status",
						"All set are getting displayed with " + strStatus + " Status", "Pass");
			} else {
				actions.reportCreateFAIL("Verify that Status with " + strStatus + " set are getting displayed",
						"All set Should displayed with " + strStatus + " Status",
						"All set are not getting displayed with " + strStatus + " Status", "Fail");
			}
		} else {
			boolean is_deleted = VerifyOnscreenMessage(elocatoronScreenMessage, "Search returned no matching results.",
					true);
			if (is_deleted) {
				actions.reportCreatePASS("Verify the Search returned no matching results for Status : " + strStatus,
						"On Screen Message should get displayed - 'Search returned no matching results'",
						"On Screen Message is displayed ", "Pass");
			} else {
				actions.reportCreateFAIL("Verify the Search returned no matching results for Status : " + strStatus,
						"On Screen Message should get displayed - 'Search returned no matching results'",
						"On Screen Message is not displayed ", "Fail");
			}
		}

	}
	
	//Create New Restaurant DB Definition
	
	public String CreateNewRestaurantDBDefinations(String eLoactorTabName , String eLoactorbtnName , String tabName) throws Exception {
	       /** Step 1 : Click on  Adaptors tab */
	       actions.click(eLoactorTabName);
	       Thread.sleep(1000);

	       /** Step 2 : Click on  New Adaptors button */
	       actions.click(eLoactorbtnName);
	       Thread.sleep(1000);

	       /** Step 3 : Switch Title  */
	       //mcd.SwitchToWindow("#Title");

	       /** Step 4 : Enter all required details */
	       // Create Random name :
	       String DtPrefix = fn_GetRndName("Auto");
	       //New POS Name Value
	       actions.setValue("RestaurantDBDefinitions.NewPOSName", DtPrefix);
	       //Click on new Section 
	       actions.click("RestaurantDBDefinitions.NewSection");
	       //Enter New Section - New POS Name
	       actions.setValue("RestaurantDBDefinitions.NewSectionNewPosName", DtPrefix);
	       //Select Status as inactive 
	       actions.setValue("RestaurantDBDefinitions.status1", "Inactive");
	       Thread.sleep(1000);
	       //Click on Save button 
	       actions.click("RestaurantDBDefinitions.Savebtn");
	       Thread.sleep(1000);
	       // Verification - New Section has been Created or Not 
	       boolean isCreated = VerifyOnscreenMessage("RestaurantDBDefinitions.OnScreenSave", "Your changes have been saved.", true);
	       if(isCreated){
	       actions.reportCreatePASS("Verify that New Section for "+tabName +" has been Created or not", "New Section for "+tabName +" should be created ", "New Section for "+tabName +" has been Created", "Pass");
	       }else{
	       actions.reportCreateFAIL("Verify that New Section for "+tabName +" has been Created or not", "New Section for "+tabName +" should be Created", "New Section for "+tabName +" has not created", "Fail");
	       }

	              return DtPrefix;
	       
	       }

    public boolean waitAndSwitch(String strWindowTitle) throws InterruptedException {         
		int iterator=0;
		String temp = gblTestData.get("StepTimeOut");
		int time = Integer.parseInt(temp);
		int val = 3000/time;
		int tempMin=time/60;
		boolean switchFlag = false;
        do {
               try {
                     /** Switch Window */
                     System.out.println("in try");
                     switchFlag=SwitchToWindow(strWindowTitle);
                     break;
               } catch (Exception err) {
            	   Thread.sleep(3000);
            	   iterator=iterator+1;
                   System.out.println("window not available will wait few more seconds");
               }
        } while (iterator<=val);
        if (switchFlag==false) {
			actions.reportCreateFAIL("Switch to Window :"+strWindowTitle, "Should Switch to Window :"+strWindowTitle, "Failed to Switch to Window within time :"+tempMin+" min", "Fail");
		}   
        
        return true;       
 }
    
    /** TODO waiting for the page to load for specific time */
    public void smartsync(int wait){
           int iterator = 0;
           boolean blnrtrn,blnajaxIsComplete;
           try{
           do {
                  JavascriptExecutor js = (JavascriptExecutor) driver;
                  blnrtrn = js.executeScript("return document.readyState").equals("complete");
                  blnajaxIsComplete = (Boolean) js.executeScript("return jQuery.active == 0");     
                  if (blnrtrn && blnajaxIsComplete) {
                        break;
                  } else {
                        iterator = iterator + 1;          
                               Thread.sleep(2000);
                  }
           } while (iterator < (Integer.parseInt(GetGlobalData("StepTimeOut"))/2));
           
           if(!blnrtrn && blnajaxIsComplete){
                  actions.reportCreateFAIL("Waiting for the Page to load", "Page should load successfully", "Page does not loaded successfully in time "+wait, "Fail");
           }
           
    } catch (InterruptedException e) {
           // TODO Auto-generated catch block
           actions.reportCreateFAIL("Waiting for the Page to load", "Page should load successfully", "Page does not loaded successfully in time "+wait, "Fail");
    }
    }
/**VERIFY ALERT & ONSCREEN MESSAGES
     * TODO In order to handle sync in alert & onscreen messages
     * 
     * @param msgType - either 'onscreen' OR 'warning'
     * @param msgTxt - message text
     * @param extraMsgPrint - if need to display extra message
     * @param msgLocator - message locator for onscreen messages
     * 
     */
    
    
    public boolean waitForMsg(String msgType,String msgTxt,String extraMsgPrint,String msgLocator) throws InterruptedException {   
          
              int iterator=0;
              String temp = "150";
              int time = Integer.parseInt(temp);
              int val = 3000/time;
              int tempMin=time/60;
              boolean switchFlag = false;
                            
              
           do {
                 try {
                       
                       System.out.println("in try");
                       /**verifying & handling the ALERT type of message*//**verifying the ONSCREEN type of message*/
                       switch(msgType.toUpperCase()){
                       case "WARNING" : switchFlag = VerifyAlertMessageDisplayed("Warning", msgTxt, true, AlertPopupButton.OK_BUTTON);                       
                                  actions.reportCreatePASS("Verify the Alert: '"+ msgTxt+"' is displayed"+extraMsgPrint+".",
                                                                                  msgType+" :'"+ msgTxt+"' Should be present"+extraMsgPrint+".", 
                                                                                  "Message '"+ msgTxt+"' is diaplayed "+extraMsgPrint+".", 
                                                                                  "PASS");
                                  switchFlag = true;
                                  break;
                       
                       case "ONSCREEN" : switchFlag = VerifyOnscreenMessage(msgLocator, msgTxt, true);                       
                       actions.reportCreatePASS("Verify the Alert: '"+ msgTxt+"' is displayed"+extraMsgPrint+".",
                                                             msgType+" :'"+ msgTxt+"' Should be present"+extraMsgPrint+".",
                                                             "Message '"+ msgTxt+"' is diaplayed "+extraMsgPrint+".",
                                                             "PASS");
                       switchFlag = true;
                       break;
                       }
                       
                 } catch (Exception err) {                             
                        iterator=iterator+1;
                        Thread.sleep(2000);
                     System.out.println("window not available will wait few more seconds");
                 }
          } while (iterator<=val && !switchFlag);
          if (switchFlag==false) {
                     actions.reportCreateFAIL("Verify the Alert: '"+ msgTxt+"' is displayed"+extraMsgPrint+".",
                                                              msgType+" :"+ msgTxt+" Should be present"+extraMsgPrint+".", 
                                                              "Message isn't diaplayed within time :"+tempMin+" min", 
                                                              "FAIL");
              }   
          
          return true;       
   }

   
    /**VERIFY ALERT & ONSCREEN MESSAGES
     * TODO In order to handle sync in alert & onscreen messages
     * 
     * @param msgType - either 'onscreen' OR 'warning'
     * @param msgTxt - message text
     * @param extraMsgPrint - if need to add extra message in report
     * @param msgLocator - message locator for onscreen messages
     * @param actionPerformd - this parameter is useful for Alert messages, whether want to click 'Ok' button OR 'Cancel' button
     * 
     */
    
    
    public boolean waitAndVerifyMsg(String msgType,String msgTxt,String extraMsgPrint,String msgLocator,String actionPerformd) throws InterruptedException {   
          
              int iterator=0;
              String temp = "150";
              int time = Integer.parseInt(temp);
              int val = 3000/time;
              int tempMin=time/60;
              boolean switchFlag = false;
                            
              
           do {
                 try {
                       
                       System.out.println("in try");
                       /**verifying & handling the ALERT type of message*//**verifying the ONSCREEN type of message*/
                       switch(msgType.toUpperCase()){
                       case "WARNING" : 
                     if(actionPerformd.equalsIgnoreCase("ok")){
                           switchFlag = VerifyAlertMessageDisplayed("Warning", msgTxt, true, AlertPopupButton.OK_BUTTON);   
                     }else if(actionPerformd.equalsIgnoreCase("cancel")){
                           switchFlag = VerifyAlertMessageDisplayed("Warning", msgTxt, true, AlertPopupButton.CANCEL_BUTTON);
                    }                          
                                  actions.reportCreatePASS("Verify the Alert: '"+ msgTxt+"' is displayed"+extraMsgPrint+".",
                                                                           msgType+" :'"+ msgTxt+"' Should be present"+extraMsgPrint+".", 
                                                                           "Message '"+ msgTxt+"' is diaplayed "+extraMsgPrint+".",
                                                                           "PASS");
                                  switchFlag = true;
                                  break;
                       
                       case "ONSCREEN" : switchFlag = VerifyOnscreenMessage(msgLocator, msgTxt, true);                       
                       actions.reportCreatePASS("Verify the Alert: '"+ msgTxt+"' is displayed"+extraMsgPrint+".",
                              msgType+" :'"+ msgTxt+"' Should be present"+extraMsgPrint+".", 
                              "Message '"+ msgTxt+"' is diaplayed "+extraMsgPrint+".", 
                              "PASS");
                       switchFlag = true;
                       break;
                       }
                       
                 } catch (Exception err) {                             
                        iterator=iterator+1;
                        Thread.sleep(2000);
                     System.out.println("window not available will wait few more seconds");
                 }
          } while (iterator<=val && !switchFlag);
          if (switchFlag==false) {
                     actions.reportCreateFAIL("Verify the Alert: '"+ msgTxt+"' is displayed.",msgType+" :"+ msgTxt+" Should be present.", "Message isn't diaplayed within time :"+tempMin+" min", "FAIL");
              }   
          
          return true;       
   }

}
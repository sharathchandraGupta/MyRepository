/*
 * Copyright 2012 iGATE GROUP OF COMPANIES. All rights reserved
 * (Subject to Limited Distribution and Restricted Disclosure Only.)
 * THIS SOURCE FILE MAY CONTAIN INFORMATION WHICH IS THE PROPRIETARY
 * information of IGATE GROUP OF COMPANIES AND IS INTENDED FOR USE
 * ONLY BY THE ENTITY WHO IS ENTITLED TO AND MAY CONTAIN
 * INFORMATION THAT IS PRIVILEGED, CONFIDENTIAL, OR EXEMPT FROM
 * DISCLOSURE UNDER APPLICABLE LAW.
 * YOUR ACCESS TO THIS SOURCE FILE IS GOVERNED BY THE TERMS AND
 * CONDITIONS OF AN AGREEMENT BETWEEN YOU AND IGATE GROUP OF COMPANIES.
 * The USE, DISCLOSURE REPRODUCTION OR TRANSFER OF THIS PROGRAM IS
 * RESTRICTED AS SET FORTH THEREIN
 */

package crossbrowser.library;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.galenframework.api.Galen;
import com.galenframework.reports.GalenTestInfo;
import com.galenframework.reports.HtmlReportBuilder;
import com.galenframework.reports.model.LayoutReport;

import crossbrowser.helper.DateFormatter;
import crossbrowser.helper.JsonFormatter;
import crossbrowser.library.helper.Helper;
import crossbrowser.logger.FrameworkLogger;
import crossbrowser.logger.FrameworkLogger.LEVEL;
import crossbrowser.logger.TestReportLogger;

public class UIValidations extends Helper {
	
	public void takeScreenShot(WebDriver driver,String pageName,Class<?> clazz){
		Date date=new Date();
		String dateStr=DateFormatter.formatDate(date, "ddMMMyyyy-HHmmssS-z");
		String browserName=((RemoteWebDriver) driver).getCapabilities()
				.getBrowserName().trim();
		String version=((RemoteWebDriver) driver).getCapabilities()
				.getVersion();
		String testCaseName=clazz.getName().toString().replace("xtam.test.", "");
		String screenShotName = (testCaseName+ "-"+ pageName+ "-"+ browserName+ version+ "-"+ dateStr + ".png").replaceAll("\\s", "");
		String filePath="./test-output/screenShots/"+screenShotName;
		File screenShotFile=screenShot(driver);
		if (!crossbrowser.utils.FileUtil
				.folderExists("./test-output")) {
			crossbrowser.utils.FileUtil
					.makeFolder("./test-output/screenShots/");
		}
		File destFile=new File(filePath);
		String jsonStepPass=JsonFormatter.format(date, "Take screenshot for "+pageName, "Should take screenshot.", "Took screenshot successfully.", "Pass", filePath);
		String jsonStepFail=JsonFormatter.format(date, "Take screenshot for "+pageName, "Should take screenshot.", "Failed to take screenshot.", "Fail", filePath);
		
		try {
			FileUtils.copyFile(screenShotFile, destFile);
			FrameworkLogger.log("Taking screenshot for '"+pageName+"'.", LEVEL.info, this.getClass());
			TestReportLogger.log(jsonStepPass);
		} catch (IOException e) {
			TestReportLogger.log(jsonStepFail);
			FrameworkLogger.log("Error while coping screenshot file in 'screenShots' folder. Exception: "+e.getMessage(), LEVEL.debug, this.getClass());
			FrameworkLogger.log("Error while taking screenshot for '"+pageName+"'.", LEVEL.error, this.getClass());
		}
	}
	
	public boolean checkLayout(WebDriver driver,Object specsPath, String pageName, Class<?> clazz){
		boolean testResult=false;
        List<String> includedTags = new ArrayList<String>();
        Date date=new Date();
		String jsonStepPass="";
		String jsonStepFail="";
        if ("android".equalsIgnoreCase(((RemoteWebDriver) driver).getCapabilities().getPlatform().name().trim())){
                        includedTags.add("mobile");
        }
        else{
                        includedTags.add("desktop");
        }
        
        try {
        	LayoutReport layoutReport = Galen.checkLayout(driver, specsPath.toString().trim(), includedTags, null,new Properties(), null);
            List<GalenTestInfo> tests = new LinkedList<GalenTestInfo>() ;
            GalenTestInfo testInfo = GalenTestInfo.fromString(pageName);
            testInfo.getReport().layout(layoutReport, "Check layout for "+pageName);
            tests.add(testInfo);
            String reporFolderName = clazz.getName().toString()+"-"+pageName.replaceAll("\\s", "")+"-"+((RemoteWebDriver) driver).getCapabilities().getBrowserName().trim().replaceAll("\\s", "")+((RemoteWebDriver) driver).getCapabilities().getVersion();
			String folderPath="./test-output/layout-reports/"+reporFolderName;
			String filePath=folderPath+"/report.html";
            new HtmlReportBuilder().build(tests, folderPath);
            jsonStepPass=JsonFormatter.format(date, "Layout Test for : "+pageName, "Should check layout.", "View Layout test report.", "Pass", filePath);
            jsonStepFail=JsonFormatter.format(date, "Layout Test for : "+pageName, "Should check layout.", "View Layout test report.", "Fail", filePath);
			if (layoutReport.errors() <= 0){
		           testResult=true;
		           TestReportLogger.log(jsonStepPass);
		    }else{
		    	TestReportLogger.log(jsonStepFail);
		    }
			
			
		} catch (IOException e) {
			TestReportLogger.log(jsonStepFail);
			FrameworkLogger.log("Error while checking layout for '"+pageName+"'. Exception: "+e.getMessage(), LEVEL.debug, this.getClass());
			FrameworkLogger.log("Error while checking layout for '"+pageName+"'.", LEVEL.error, this.getClass());

		}
        
		return testResult;
	}
	
	
	
	/**** from old framework ***/
	public Boolean elementPresent(WebElement element) {
		if (element.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean elementSelected(WebElement element) {
		if (element.isSelected()) {
			return true;
		} else {
			return false;
		}
	}

	public Boolean elementEnabled(WebElement element) {
		if (element.isEnabled()) {
			return true;
		} else {
			return false;
		}
	}
	
	
}

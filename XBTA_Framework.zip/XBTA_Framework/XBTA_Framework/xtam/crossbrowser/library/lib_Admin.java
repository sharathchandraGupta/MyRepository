package crossbrowser.library;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.lib_MCD.AlertPopupButton;

public class lib_Admin {
	
	private Keywords actions;
	private WebDriver driver;
	String STenderName = null;
	private lib_RFM2 rfm;
	private lib_MCD mcd;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	
	public lib_Admin(WebDriver nodeDriver, Keywords actions, UIValidations uiActions, Map inputData, lib_MCD mcd,
			lib_RFM2 rfm, Object or) {
		this.driver = nodeDriver;
		this.rfm = rfm;
		this.actions = actions;
		this.uiActions = uiActions;
		this.input = inputData;
		this.mcd = mcd;
	}
	
	// ----------------------------------
		/*
		 * Feature Name : ADMIN > Users : To Create new role without coping existing role
		 * New Script New Script Scenario ID : Used in RFM_3198_RPT_ACNvefyError Author : Akanksha
		 * Rani
		 */
		// -----------------------------------
	 public String RFM_ADM_createNewRole(String Status,String Market,String Level,String Global,String Permission)throws Exception{
  	   
  	   actions.WaitForElementPresent("Roles.NewRoleBtn", 180);
  	   actions.keyboardEnter("Roles.NewRoleBtn");
  	   
  	   actions.waitForPageToLoad(180);
  	   mcd.SwitchToWindow("Add Role");
  	   
  	   String strNewRoleName = mcd.fn_GetRndName("Auto_NR");
  	   actions.setValue("Roles.NewRoleName", strNewRoleName);
  	   actions.keyboardEnter("Roles.NextBtn");
  	   
  	   actions.waitForPageToLoad(180);
  	   mcd.SwitchToWindow("Roles");
  	      	
	    	   if(!Status.equals("")){	   
	    	   actions.setValue("Roles.StatusDDL", Status);
	    	   }
  	   
  	   actions.setValue("Roles.DescriptionText", "Creating Role");
  	    	  

  		   if(!Global.equals("")){
      	   actions.setValue(" Roles.GlobalDDL",Global);
  		   }
      	   
  	   
  	   
  		   if(!Market.equals("")){
	    		   Select select = new Select(driver.findElement(By.xpath(actions.getLocator("Roles.MarketDDL"))));
	    		   select.selectByVisibleText(Market);
  		   }
      	  
  	   try{
  		   if(!Level.equals("")){
  		   Select select = new Select(driver.findElement(By.xpath(actions.getLocator("Roles.LevelDDL"))));
  		   select.selectByVisibleText(Level);
  		   }
      	   }catch(Exception e){
      		   actions.reportCreateFAIL("Verify Level",
  						"Level need to be selected",
  						"Level is not selected",
  						"Fail");   
      	   }
  	   
  	   try{
  		   switch(Permission){
				case "Full Access":
					actions.click("Roles.ARPermisionFull");
					break;
				case "Update Access":
					actions.click("Roles.ARPermisionUpdate");
					break;
				case "View Only":
					actions.click("Roles.ARPermisionView");
					break;
				case "None":
					actions.click("Roles.ARPermisionNone");
					break;
				default	:
					actions.click("Roles.ARPermisionFull");
  		   }
      	   
      	   }catch(Exception e){
      		   actions.reportCreateFAIL("Verify Permission",
  						"Permission need to be selected",
  						"Permission is not selected",
  						"Fail");   
      	   }
  	   
  	   actions.keyboardEnter("RFM.SaveBtn");
  	   actions.smartWait(180);
  	   actions.WaitForElementPresent("Roles.ARMessage", 180);
  	   
  	   //To verify on screen msg
  	   boolean flag = mcd.VerifyOnscreenMessage("Roles.ARMessage","Your changes have been saved", false);
  	   
  	   if(flag){
  		   actions.reportCreatePASS("Verify Role created successfully",
						"Role should created successfully",
						"Role is created successfully",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verify Role created successfully",
						"Role should created successfully",
						"Role is not created successfully",
						"Fail"); 
  	   }
  	   return strNewRoleName;
     }
	 

	// ----------------------------------
		/*
		 * Feature Name : ADMIN > Users : To assign role to user
		 * New Script New Script Scenario ID : Used in RFM_3198_RPT_ACNvefyError Author : Akanksha
		 * Rani
		 */
		// -----------------------------------
	 public void RFM_ADM_AssignRoleToUser(String User,String Node,String NodeSearchBy,String RoleName)throws Exception{
    	 
  	   //Enter User ID to whom role will be assigned.
  	   actions.WaitForElementPresent("ManageUser.ARsearchTextBox", 180);
  	   if(!User.equals("")){
  		   actions.setValue("ManageUser.ARsearchTextBox", User);
  	   }else{
  		   actions.setValue("ManageUser.ARsearchTextBox", mcd.GetGlobalData("UID_Admin"));  
  	   }
  	   actions.keyboardEnter("ManageUser.ARSearchBtn");
  	   actions.smartWait(180);
  	   
  	   try{
  	   WebElement ElementUserID=mcd.GetTableCellElement("AccessControlbyUser(s).DataGrid", 1, "User ID", "a");
         ElementUserID.click();
         actions.waitForPageToLoad(180);
         
         mcd.SwitchToWindow("#Title");
  	   }catch(Exception e){
  		   actions.reportCreateFAIL("Verify User ID present in table",
						"User ID should present in table",
						"User ID is present in table",
						"Fail"); 
  	   }
  	   
  	   actions.WaitForElementPresent("SetAssignmentReport.ARSelectedMenuTable", 180);
  	   //Checking user is already assigned to Hierarchy Selections
  	   WebElement AssignedNode=mcd.GetTableCellElement("SetAssignmentReport.ARSelectedMenuTable", 3,1,"select/option[0]");    	 
  	   String strAssignedHerSection=AssignedNode.getText();
     
  	   if(strAssignedHerSection.equals("")){
  		   actions.click("SelectNode.ExactMatchRadioButton");
  		   switch(NodeSearchBy){
				case "Restaurant Number":
					actions.click("SelectNode.RestaurantNumberRadioButton");
					break;
				case "Restaurant Name":
					actions.click("SelectNode.RestaurantNameRadioButton");
					break;
				case "Hierarchies":
					actions.click("SelectNode.HierarchiesRadioButton");
					break;
				default	:
					actions.click("SelectNode.RestaurantNumberRadioButton");
  		   }
  		   actions.setValue("AccessControlByNode.ARSearchTextTreeTextBox",Node);
  		   actions.keyboardEnter("ViewGeneratedReports.Button");
  		   mcd.smartsync(60);
  		   mcd.Selectrestnode("ManageUser.ARTable", Node);
  		   actions.keyboardEnter("AccessControlbyNode.moveSelectedItemsToRight");
  	   }
  	   
  	  //Click on Assigned Roles Tab
  	   actions.keyboardEnter("UsersUpdateUser.ARAssignRole");
  	   actions.smartWait(180);
  	   actions.waitForPageToLoad(180);
  	   
  	   //Click on assigned role button
  	   actions.keyboardEnter("UsersUpdateUser.assignedRolebutton");
  	   
  	   mcd.SwitchToWindow("Assign Roles :");
  	   
  	   //Clicking on checkbox of role
  	   Integer assignrRoleTableCount=mcd.GetTableRowCount("AssignRole.ARtable");
  	   for(int i=3;i<=assignrRoleTableCount;i++){
  		   //List<WebElement> listEle1 = driver.findElements(By.xpath("//*[@id='userRoleList']/table/tbody/tr[i]/td[2]"));
  		  // String strAvialableRole=driver.findElement(By.xpath("//*[@id='userRoleList']/table/tbody/tr[i]/td[2]")).getAttribute("value");
  		   String strAvialableRole=driver.findElement(By.xpath("//*[@id='userRoleList']/table/tbody/tr["+i+"]/td[2]")).getText();
  		   //String strAvialableRole=listEle1.get(i).getText();
  		   if(strAvialableRole.equals(RoleName)){
  			   driver.findElement(By.xpath("//*[@id='userRoleList']/table/tbody/tr["+i+"]/td[2]/preceding-sibling::td/input")).click();
  			   actions.click("AssignRoles.ARselect");    			  
  			   break;
  		   }
  	   }
  	   actions.waitForPageToLoad(180);
  	   mcd.SwitchToWindow("Users : Update User");
		   actions.keyboardEnter("RFM.SaveBtn");
		   actions.smartWait(180);
		   
		  // To verify "Your changes have been saved" on screen msg
		  actions.WaitForElementPresent("UsersUpdateUser.ARMessage", 180);
		  boolean flag = mcd.VerifyOnscreenMessage("UsersUpdateUser.ARMessage","Your changes have been saved", false);
		  if(flag){
			  actions.reportCreatePASS("Verify Role"+RoleName+" assined to user"+User+" successfully",
						"Role"+RoleName+" should assined to user"+User+" successfully",
						"Role"+RoleName+" assined to user"+User+" successfully",
						"Pass");
			} else {
				actions.reportCreateFAIL("Verify Role"+RoleName+" assined to user"+User+" successfully",
						"Role"+RoleName+" should assined to user"+User+" successfully",
						"Role"+RoleName+" assined to user"+User+" successfully",
						"Fail"); 
		  }
		  
     }

}
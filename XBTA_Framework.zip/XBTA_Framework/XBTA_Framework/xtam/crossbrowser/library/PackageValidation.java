package crossbrowser.library;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;

import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.asserts.SoftAssert;

import com.google.common.base.Function;



public class PackageValidation {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();
	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private XMLValidations xValidations;

	public PackageValidation(WebDriver driver, Keywords actions, UIValidations uiActions, Map inputData, lib_MCD mcd,
			lib_RFM2 rfm) {
		this.driver = driver;
		this.actions = actions;
		this.uiActions = uiActions;
		this.input = inputData;
		this.mcd = mcd;
		this.rfm = rfm;
		xValidations = new XMLValidations();

	}

	/*****************************************************************************
	 * Function Name: PKG_Schedule_ViewFullList () Date Created:30-Dec-2016
	 * Author : Archana Savanji Arguments: Description: This functions is used
	 * to view full list of scheduled packages. Pre-Rq. is Package Schedule page
	 * should be open. Used in script :
	 * 
	 ******************************************************************************/
	public void fnPKG_Schedule_ViewFullList() {

		System.out
				.println("*********************************** Start Test-Steps executions: PKG_Schedule_ViewFullList");

		try {

			actions.keyboardEnter("RFM.ViewFullListBtn");
			mcd.smartsync(180);

			actions.WaitForElementPresent("RestaurantProfile.table", 10);
			int row_viewStatus = mcd.GetTableRowCount("RestaurantProfile.table");

			if (row_viewStatus == 0) {
				System.out.println("No Results found.");
				actions.reportCreatePASS("Verify that matched reults are displayed in the result grid",
						"matched reults should be displayed in the result grid", "There are no matching results",
						"PASS");
			} else {
				actions.reportCreatePASS("Verify that matched reults are displayed in the result grid",
						"matched reults should be displayed in the result grid", "There are matching results", "PASS");
			}

		} catch (Exception err1) {
			System.out.println("Error:" + err1);
		}
		System.out.println("*********************************** End of function ");

	}

	/*****************************************************************************
	 * Function Name: PKG_Schedule_SearchWithOption () 
	 * Date Created:30-Dec-2016
	 * Author : Archana Savanji 
	 * Arguments: 
	 * Description: This functions is used
	 * to Search with options. Pre-Rq. is Package Schedule page should be open.
	 * Used in script :
	 * 
	 ******************************************************************************/
	public void fnPKG_Schedule_SearchWithOption(String strSearchOption, String strSearch) {

		System.out.println(
				"*********************************** Start Test-Steps executions: PKG_Schedule_SearchWithOption");

		try {

			// Select Radio button for search option

			switch (strSearchOption) {
			case "BeginsWith": {
				actions.click("RFM.BeginsWithRadioButton");
				break;
			}
			case "EndsWith": {
				actions.click("RFM.EndsWithRadioButton");
				break;
			}
			case "Contains": {
				actions.click("RFM.ContainsRadioButton");
				break;
			}
			case "ExactMatch": {
				actions.click("RFM.ExactMatchRadioButton");
				break;
			}
			default: {
				actions.click("RFM.ContainsRadioButton");
				break;
			}

			}

			// Enter Search value and click search
			actions.setValue("RFMLookups.SearchLookup", strSearch);
			Thread.sleep(2000);

			actions.keyboardEnter("RFMHome.SearchButton");
			mcd.smartsync(180);

		} catch (Exception err1) {
			System.out.println("Error:" + err1);
		}
		System.out.println("*********************************** End of function ");

	}

	/*****************************************************************************
	 * Function Name: fnNew_Package_Schedule_Type () 
	 * Date Created:30-Dec-2016
	 * Author: Archana Savanji 
	 * Arguments: 
	 * Description: This function schedules
	 * the new package by navigating to ADMIN>Package Management>Package
	 * Schedule Pre-Rq. is Package Schedule page should be open. Used in script
	 * :
	 * 
	 ******************************************************************************/

	public void fnNew_Package_Schedule_Type(String strPackType) {

		try {

			// Click New Package Schedule button
			actions.WaitForElementPresent("Package.NewPackageScheduleButton");
			actions.keyboardEnter("Package.NewPackageScheduleButton");
			actions.waitForPageToLoad(180);
			mcd.waitAndSwitch("#Title");
			actions.WaitForElementPresent("Package.CreateSchedule", 180);
			
			// Select Radio button for Package Request Type
			switch (strPackType) {
			case "CreateSchedule": {
				actions.click("Package.CreateSchedule");
				break;
			}
			case "GenerateNow": {
				actions.javaScriptClick("Package.GenerateNow");
				break;
			}
			case "AdhocSchedule": {
				actions.click("Package.AdhocSchedule");
				break;
			}
			case "PartialExport": {
				actions.click("Package.PartialExport");
				break;
			}
			default: {
				actions.click("Package.GenerateNow");				
				System.out.println("Package option is not macting: " + strPackType + "Selected Generate Now option");
				break;
			}

			}

		} catch (Exception e) {
			actions.reportCreateFAIL("Schedule a package for a restaurant by selecting option",
					"Package should get scheduled for selected restaurant ",
					"Exception occured while scheduling package for selected restaurant", "Fail");
		}
	}

	/*****************************************************************************
	 * Function Name: fnNew_Package_Schedule_Now () 
	 * Date Created:30-Dec-2016
	 * Author : Archana Savanji 
	 * Arguments: 
	 * Description: This function schedules
	 * the new package by navigating to ADMIN>Package Management>Package
	 * Schedule Pre-Rq. is Package Schedule page should be open. Used in script
	 * :
	 * 
	 ******************************************************************************/

	public void fnNew_Package_Schedule(String strRestNumber, String strSuccessMsg) {

		try {
			// Click Exact Match
			
			actions.WaitForElementPresent("PackageReport.ExactMatch", 180);
			actions.javaScriptClick("PackageReport.ExactMatch");
			//driver.findElement(By.xpath(actions.getLocator("PackageReport.ExactMatch"))).click();
			
			
			// Search Resto. number to schedule package
			actions.setValue("RFMSelectNode.Searchbox", strRestNumber);
			
			actions.WaitForElementPresent("RFMSelectNode.SearchButton");
			actions.javaScriptClick("RFMSelectNode.SearchButton");
			actions.smartWait(180);

			// Select node			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			actions.WaitForElementPresent("RFMHome.LeftTable");
			mcd.Selectrestnode_JavaScriptClk("RFMHome.LeftTable", strRestNumber);

			// Click > button
			actions.WaitForElementPresent("RFMHome.Button>", 180);
			actions.keyboardEnter("RFMHome.Button>");
			
			try{
				String AssignedHierarchyValue=mcd.GetTableCellElement("RecipeReport.SelectedMenuTable", 2,1, "select/option[1]").getText();
				if(!AssignedHierarchyValue.equals("")){
					actions.reportCreatePASS("Verify Available Hierarchy Selections Node got transferted to Assigned Hierarchy Selections",
							"Available Hierarchy Selections Node should got transferted to Assigned Hierarchy Selections",
							"Available Hierarchy Selections Node got transferted to Assigned Hierarchy Selections",
							"Pass");
					// click Apply button and Save the changes
					actions.keyboardEnter("RFM.SSApply");			
					actions.waitForPageToLoad(180);					
					mcd.SwitchToWindow("#Title");					
					actions.WaitForElementPresent("SubstitutionGroups.InfoMessage", 180);
					
					// Verification to check if changes have been saved or not
					try {
						actions.verifyTextPresence(strSuccessMsg, true);

					} catch (Exception e) {
						System.out.print("Success Message is not displayed...");
					}
				} else {
					actions.reportCreateFAIL("Verify Available Hierarchy Selections Node got transferted to Assigned Hierarchy Selections",
							"Available Hierarchy Selections Node should got transferted to Assigned Hierarchy Selections",
							"Available Hierarchy Selections Node got transferted to Assigned Hierarchy Selections.",
							"Fail"); 
				}
			}catch(Exception e){
				actions.reportCreateFAIL("Verify Available Hierarchy Selections Node got transferted to Assigned Hierarchy Selections",
						"Available Hierarchy Selections Node should got transferted to Assigned Hierarchy Selections",
						"Available Hierarchy Selections Node got transferted to Assigned Hierarchy Selections.",
						"Fail"); 
			}
			

		} catch (Exception e1) {
			actions.reportCreateFAIL("Schedule a package for a restaurant by selecting option",
					"Package should get scheduled for selected restaurant ",
					"Exception occured while scheduling package for selected restaurant", "Fail");

		}
	}

	/*****************************************************************************
	 * Function Name: fnNew_Package_Report_Search () 
	 * Date Created:30-Dec-2016
	 * Author : Archana Savanji 
	 * Arguments: 
	 * Description: This function schedules
	 * the new package by navigating to ADMIN>Package Management>Package Report
	 * Pre-Rq. is Package Schedule page should be open. Used in script :
	 * 
	 ******************************************************************************/

	public boolean fnNew_Package_Report_Search(String strRestNumber, String strApplicationDate) {
		boolean bSearchResult = false;
		try {

			/** Navigate to' Package Report' screen */
			System.out.println("> Navigate to :: " + "ADMIN > Package Management > Package Report");
			actions.select_menu("RFMHome.Navigation", "ADMIN > Package Management > Package Report");
			Thread.sleep(5000);
			mcd.waitAndSwitch("#Title");

			// If package time is before 11.30, it will select previous date
			String GetTimeNow[] = strApplicationDate.split(" ");
			String GetHHNow[] = GetTimeNow[3].split(":", 2);
			System.out.println("Time now : " + GetHHNow[0]);

			if (Integer.parseInt(GetHHNow[0]) < 12) {
				// Select a From Date
				actions.click("PackagesReport.FromCalen");
				Thread.sleep(1000);
				mcd.Get_future_date(-2, "close", strApplicationDate);
				mcd.smartsync(180);

				// Select a To Date
				actions.click("PackagesReport.ToCalen");
				Thread.sleep(1000);
				mcd.Get_future_date(-1, "close", strApplicationDate);
				mcd.smartsync(180);
			} else {
				// Select a From Date
				actions.click("PackagesReport.FromCalen");
				Thread.sleep(1000);
				mcd.Get_future_date(-1, "close", strApplicationDate);
				mcd.smartsync(180);

				// Select a To Date
				actions.click("PackagesReport.ToCalen");
				Thread.sleep(1000);
				mcd.Get_future_date(0, "close", strApplicationDate);
				mcd.smartsync(180);
			}

			// Enter Restaurant number for which package is generated
			actions.setValue("PackagesReport.SearchText", strRestNumber);

			for (int i = 0; i < 2; i++) {
				actions.keyboardEnter("RestaurantProfile.searchbutton");
				mcd.smartsync(180);

				actions.WaitForElementPresent("RestaurantProfile.table", 10);
				int row_viewStatus = mcd.GetTableRowCount("RestaurantProfile.table");

				if (row_viewStatus == 0) {
					System.out.println("No Results found. waiting for Package generated...");
					if (i == 2)
						actions.reportCreateFAIL("Verify Package Generated", "Package should be genereated",
								"Package is taking longer time to Export - generate", "Fail");
				} else {
					bSearchResult = true;
					break;
				}
				// wait for package generation 5 mins to generate package
				int Timer = Integer.parseInt(mcd.GetGlobalData("StepTimeOut"));
				Thread.sleep(Timer);
			}

		} catch (Exception e1) {
			System.out.println("Error in Package Report: " + e1);

		}
		return bSearchResult;
	}

	public boolean fnNew_Package_Report_Search_New(String strRestNumber, String strApplicationDate , String Package_Schedule_Type)throws InterruptedException  {
		boolean bSearchResult = false;
		final String strRestNum =strRestNumber;
		try {

			/** Navigate to' Package Report' screen */
			System.out.println("> Navigate to :: " + "ADMIN > Package Management > Package Report");
			actions.select_menu("RFMHome.Navigation", "ADMIN > Package Management > Package Report");
			Thread.sleep(5000);
			mcd.waitAndSwitch("#Title");

			// If package time is before 11.30, it will select previous date
			 /** Get application time */
			WebElement apptime = mcd.getdate();
			strApplicationDate = apptime.getText();
			
			String GetTimeNow[] = strApplicationDate.split(" ");
			String GetHHNow[] = GetTimeNow[3].split(":", 2);
			String time1 = GetTimeNow[3];
			System.out.println("Time now : " + GetHHNow[0]);

			if (Integer.parseInt(GetHHNow[0]) <12 && GetTimeNow[4].equals("PM") ) {
				// Select a From Date
				actions.javaScriptClick("PackagesReport.FromCalen");
				Thread.sleep(1000);
				mcd.Get_future_date(-1, "close", strApplicationDate);
				mcd.smartsync(180);

				// Select a To Date
				actions.javaScriptClick("PackagesReport.ToCalen");
				Thread.sleep(1000);
				mcd.Get_future_date(-1, "close", strApplicationDate);
				mcd.smartsync(180);
			} else {
				// Select a From Date
				actions.javaScriptClick("PackagesReport.FromCalen");
				Thread.sleep(1000);
				mcd.Get_future_date(0, "close", strApplicationDate);
				mcd.smartsync(180);

				// Select a To Date
				actions.javaScriptClick("PackagesReport.ToCalen");
				Thread.sleep(1000);
				mcd.Get_future_date(0, "close", strApplicationDate);
				mcd.smartsync(180);
			}

			// Enter Restaurant number for which package is generated
			actions.setValue("PackagesReport.SearchText", strRestNumber);
			
			int i =1;
			do{
			
				try{
					actions.WaitForElementPresent("RestaurantProfile.searchbutton", 180);
					actions.keyboardEnter("RestaurantProfile.searchbutton");
					mcd.smartsync(180);
					
					//Filter the generated package based on package schedule type and generated "View Status"and short the generated report in descending order in respect of package generation time .
					packagvalidation(Package_Schedule_Type);
					
					//WebElement apptime = mcd.getdate();
                  
                    
				ExpectedCondition<Boolean> expectedCondition = new ExpectedCondition<Boolean>() {

						public Boolean apply(WebDriver webDriver) {

							WebElement element = webDriver.findElement(By.xpath(actions.getLocator("ManagePackagesReport.ARgenratedFile")));
							System.out.println("Checking for the object!!");
							String strExportvalue=element.getText();
						
							//Checking Restaurant no difference, if Restaurant no is different,it will click on search button again for 5 min. 
							String Restaurentno=mcd.GetTableCellValue("RFMPage.MISTable",1,1, "", "");
							
							//Checking time difference, if time difference will be more than 5 min ,it will click on search button again
							/** Get application time */	                     
							String DateRequestedTime=mcd.GetTableCellValue("RFMPage.MISTable",1,5, "", "");
							String DateRequestedTimeAr[]=DateRequestedTime.split(" ");
							
		                    String time2 = DateRequestedTimeAr[3];

		                     SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
		                     long difference=0;
							try {
								
								String  strApplicationDate = mcd.getdate().getText();
								String GetTimeNow[] = strApplicationDate.split(" ");
								String time1 = GetTimeNow[3];
								
								System.out.println("time1: "+time1);
								System.out.println("time1: "+time2);
								
								Date date1 = format.parse(time1.trim());
								Date date2 = format.parse(time2.trim());
								//give time difference in min
			                    difference = (date1.getTime() - date2.getTime())/60000; 
			                    System.out.print("difference:"+difference);
							} catch (ParseException e) {
								e.printStackTrace();								
								return false;
							}

								if((!Restaurentno.equals(strRestNum)) || (!strExportvalue.contains("zip")) || (difference > 6)){
									return false;								
								}
								return true;	
							}
					};
					Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)							
							.withTimeout(30, TimeUnit.SECONDS) 			
							.pollingEvery(15, TimeUnit.SECONDS) 			
							.ignoring(Exception.class);
					bSearchResult = wait.until(expectedCondition);
					
				}catch(Exception e){
					i = i+1;
					System.out.println(i);
					if(i<=9){	
						actions.keyboardEnter("RestaurantProfile.searchbutton");
						mcd.smartsync(180);	
						continue;
					}else{
						actions.reportCreateFAIL("Verify Package Generation status", "It should be Package Generated and Status should be Y withine 5 min", "Failed to Generate package in 5 min", "FAIL");
						break;
					}				
				}				
			}while(bSearchResult==false);	
				
		} catch (Exception e1) {
			System.out.println("Error in Package Report: " + e1);

		}
		return bSearchResult;
	}

	/*****************************************************************************
	 * Function Name: fnPKG_XMLValidation () 
	 * Date Created:1-Jan-2017 
	 * Author : Archana Savanji 
	 * Arguments: 
	 * Description: This function verify the XML node attribute.  
	 * 
	 ******************************************************************************/
	public void fnPKG_XMLValidation(String strFileName, String strXPATH, String strAttributeName,
			String strAttributeValue) {

		System.out.println("*********************************** Start Test-Steps executions: fnPKG_XMLValidation");

		boolean bflag = false;
		try {

			// bflag = xValidations.validateAttributeValue("product-db.xml",
			// "Product[@statusCode='ACTIVE']", "statusCode", "ACTIVE", true);
			bflag = xValidations.validateAttributeValue(strFileName, strXPATH, strAttributeName, strAttributeValue,
					true);

			if (bflag)
				actions.reportCreatePASS("Verify package file", strFileName + " File should be generated.",
						"File is generated.", "Pass");
			else
				actions.reportCreateFAIL("Verify package file", strFileName + " File should be generated.",
						"File is not generated.", "Fail");

		} catch (Exception err1) {
			System.out.println("Error:" + err1);
		}

		System.out.println("*********************************** End of function ");
	}
	
	/*****************************************************************************
   	 * Function Name: PKG_PRC_Create_PriceSet () Date Created: 02-Feb-2017
   	 * Author : Sarthak Gupta Arguments: Description: This functions is used 
   	 * to create a Price set. Pre-Req: None; Used in script :
   	 ******************************************************************************/
      
       		public String PKG_PRC_Create_PriceSet(String strNewPrcSet, String strPrcSetType, String strResMessage,
     		String strNodeNum, String strNumOfMenuItem, String strStatus_Msg, String strNewPrice, String strStatus) throws Exception {
       		
     		/** Get application time */
       			WebElement apptime = mcd.getdate();
         		String strApplicationDate = apptime.getText();

     		int iTemp = 0;

     		actions.click("PriceSet.NewBtn");
     		
     		// Switch to New Price Sets
     		mcd.waitAndSwitch("New Price Sets");

     		// Generate unique strNewPrcSet for Base/Promotion Price Set

     		switch (strPrcSetType) {
     		case "Base":
     			strNewPrcSet = strNewPrcSet + mcd.fn_GetRndName("Base");
     			break;
     		case "Promotional":
     			strNewPrcSet = strNewPrcSet + mcd.fn_GetRndName("Prom");
     			actions.click("NewPriceSet.PromRadioBtn");
     			
     			actions.javaScriptClick("PriceSet.startDate");
     			mcd.Get_future_date(0,"close",strApplicationDate);
     			
     			actions.javaScriptClick("PriceSet.EndDate");
     			mcd.Get_future_date(2,"close",strApplicationDate);
     			break;
     		default:
     			actions.reportCreateFAIL("Verify data", "Enter correct price set name", "Incorrect data", "FAIL");
     			break;
     		}
     		
     		Thread.sleep(500);
     		
     		// Enter new price set name :
     		actions.WaitForElementPresent("NewPriceSet.Name");
     		actions.setValue("NewPriceSet.Name", strNewPrcSet);
     		
     		Thread.sleep(500);
     		actions.click("NewPriceSet.SelectNode");
     		
     		// Switch to Select Node Window - Title - Select Node
     		mcd.waitAndSwitch("Select Node");
     		     		
    		Boolean Node_chk = mcd.Selectrestnode_JavaScriptClk("SelectNode.NodeTable", strNodeNum);
     		mcd.waitAndSwitch("New Price Sets");

     		switch (strPrcSetType) {
     		case "Base":

     		    actions.keyboardEnter("NewPriceSet.BaseRadioBtn");
     			Thread.sleep(1000);
     			break;
     		
     		case "Promotion":
     			actions.javaScriptClick("NewPriceSet.PromRadioBtn");
     			Thread.sleep(1000);

     			driver.findElement(By.id("startDateAnchor")).click();
     			mcd.Get_future_date(0, "close", strApplicationDate);
    			driver.findElement(By.id("endDateAnchor")).click();
     			mcd.Get_future_date(3, "close", strApplicationDate);
     			break;
     			
     		default:
     			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
     			break;
     		}

     		// Click Next
     		actions.keyboardEnter("NewPriceSet.Next");
     		mcd.waitAndSwitch("@Price Sets : Common Menu Item Selector");

     		// Switch to Price Sets : Common Menu Item Selector - to add new menu items
     		     		
     		actions.keyboardEnter("CommonSelector.ViewFullBtn");
     		actions.smartWait(180);
     		actions.WaitForElementPresent("CommonSelector.AvailabilityDrpDwn");
     		
     		// Select Available from Availability drop down
     		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
     		Thread.sleep(2000);

     		// Get Row Count
     		List<WebElement> Add_Chkbox = driver.findElements(By.xpath(actions.getLocator("PriceSet.AddMICheckBox")));
     		
     		int Item_Counts = Add_Chkbox.size();
     		List<String> MnuItem_Names = new ArrayList<String>();
     		
     		// Check items and add accordingly

     		int i_temp = 0;
     		for (int n = 0; n <= Item_Counts; n++) {
     			// Check whether enabled for Add or not
     			if ((Add_Chkbox.get(n).isEnabled())) {
     				// Check box enabled - Add Item
     				Add_Chkbox.get(n).sendKeys(Keys.SPACE);

     				// Get Item Name
     				String p = Integer.toString(n + 1);
     				String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
     				MnuItem_Names.add(e);

     				i_temp++;
     				
     			} 
     			
     			else {
     				System.out.println("This MI is already added");
     			}

     			if (i_temp == Integer.parseInt(strNumOfMenuItem)) 
     			{
     				System.out.println("Selected items for Add MI");
     				break;
     			}
     			
     		}
     		Thread.sleep(2000);
     		
     		// Save Changes
     		actions.javaScriptClick("CommonSelector.Save");
     		actions.WaitForElementPresent("ManagePS.Status");
     		
     		// Verify success message
     		actions.verifyTextPresence(strResMessage, true);

     		// Verify success message - creation of price set
     		// Change status of the price set to active

     		String currStatus = actions.getValue("ManagePS.Status");
     		if (!currStatus.equals(strStatus)) {
     			actions.setValue("ManagePS.Status", strStatus);
     			Thread.sleep(1000);
     			
     			// Set price to all menu items
     			actions.clear("UpdtMultipleSet.AllPrc");
     			Thread.sleep(1000);
     			actions.clear("UpdtMultipleSet.AllPrc");
     			Thread.sleep(1000);
     			actions.setValue("UpdtMultipleSet.AllPrc", strNewPrice);
     			actions.WaitForElementPresent("UpdtMultipleSet.Apply");
     			actions.click("UpdtMultipleSet.Apply");
     			actions.WaitForElementPresent("NewPriceSet.SaveBtn");
     			
     			// Save changes
     			actions.click("NewPriceSet.SaveBtn");
     			actions.smartWait(180);

     		}

     		Thread.sleep(2000);

     		// Verify success message for status & price updates
     		actions.verifyTextPresence(strStatus_Msg, true);
     		actions.reportCreatePASS("Verify price set set active", "Price set should be set as active", "Price set saved as active", "PASS");
     		mcd.Get_future_date(2, "open", strApplicationDate);
     		Thread.sleep(1000);
 			actions.setValue("UpdtMultipleSet.AllPrc", strNewPrice);
 			actions.WaitForElementPresent("UpdtMultipleSet.Apply");
 			actions.javaScriptClick("UpdtMultipleSet.Apply");
 			actions.WaitForElementPresent("PriceSet.ApplyButton2");
 			actions.javaScriptClick("PriceSet.ApplyButton2");
     		System.out.println(strNewPrcSet+" is created.");
     		
     		// Return price set name
     		return strNewPrcSet;
     		
     	}
              
              
/**************************************************************************************
           * Function Name: PKG_PRC_Assign_to_Restaurant() Date Created: 02-Feb-2017
           * Author : Sarthak Gupta Arguments: Description: This functions is used 
           * to add a Restaurant to a set(Price set/MenuItem Set/Pos). Pre-Req: None; Used in script :
***************************************************************************************/
              
             
       	public void Set_Assign_to_Restaurant(String restName,String choseSetType,String SetName,String strResMessage) 
            throws Exception
    {
       		String strNavigateToRestProfile = mcd.GetTestData("DT_NAVIGATE_TO_RESTPRO");
       	   	
       		//Navigate to Restaurant Profile
       		actions.waitForPageToLoad(180);
       		System.out.println("> Navigate to :: " + strNavigateToRestProfile);
            actions.select_menu("RFMHome.Navigation",strNavigateToRestProfile);
            
            //Select Exact match Radio Button
            actions.WaitForElementPresent("MenuItemDetails.exactMatchRadioBtn");
            actions.javaScriptClick("MenuItemDetails.exactMatchRadioBtn");
            
            //Search for the specified Restaurant
            actions.setValue("RestaurantProfile.SearchTextBox", restName);
            actions.keyboardEnter("UpdatePromotionGroup.Apply");
            
            Thread.sleep(2000);
            actions.WaitForElementPresent("RFM.Table");
            actions.keyboardEnter(mcd.GetTableCellElement("RFM.Table", 1, 1, "a"));
            
            //Select MenuItem/ POS/ Pricing Tab
            mcd.waitAndSwitch("#Title");
   		 	actions.smartWait(180);
            actions.WaitForElementPresent("RestaurantProfile.MenuItemPOSPricing");
            actions.keyboardEnter("RestaurantProfile.MenuItemPOSPricing");
    
            //choose from Drop Down(Menu Item/Price Set/Pos)
   		 	actions.WaitForElementPresent("RestaurantProfile.ChooseSetTypeDDL");
            actions.setValue("RestaurantProfile.ChooseSetTypeDDL", choseSetType);
            
            //search Set Name(PriceSet/Menu Item Set/POS)
            actions.smartWait(180);
            actions.WaitForElementPresent("RFMParameterSet.SearchSetName");
            actions.setValue("RFMParameterSet.SearchSetName", SetName);
            Thread.sleep(2000);
                    
           //click on search button 
            String form ="//*[@id='profLayeredSetForm']";
            actions.keyboardEnter(actions.getwebDriverLocator(form+actions.getLocator("RFMPage.SearchButton")));
            
         
            actions.smartWait(180);
            Thread.sleep(2000);
            actions.javaScriptClick(mcd.GetTableCellElement("RFMSelectNode.SelectNodeTable", 1, 1, "a"));
            actions.keyboardEnter("RFM.RightArrowButton");
            
           // used simple click
            driver.findElement(By.xpath("//a[contains(@class, 'button')][contains(text(), 'Apply')]")).click(); 
           
            
            
            mcd.waitAndSwitch("Apply Changes Details");
            actions.keyboardEnter("RFM.SaveButton");
            
            mcd.waitAndSwitch("Run Validation Report");
            actions.keyboardEnter("RFM.CancelBtn");
            
            mcd.waitAndSwitch("@Restaurant Profile");
                      
            actions.verifyTextPresence(strResMessage, true);
            
            
        }  
       	
/**************************************************************************************
         * Function Name: RFM_PRC_PriceSet_Alterations() Date Created: 02-Feb-2017
         * Author : Sarthak Gupta Arguments: Description: This functions price set 
         * is operated in different ways according to the switch case . Pre-Req: None;
***************************************************************************************/
        public String RFM_PRC_PriceSet_Alterations(String strEntercase,String priceSetName,String strNumOfMenuItem,String strAddMenuMessage,int daysinfuture,int strNewPrice,int futureDateNo) throws Exception{
			WebElement apptime = mcd.getdate();
         	String strApplicationDate = apptime.getText(); 
			 
	    	 //Navigate to Restaurant Profile
        	String strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");
	      	 
	      	 System.out.println("> Navigate to :: " + strNavigateTo);
	         actions.select_menu("RFMHome.Navigation",strNavigateTo);
	         actions.waitForPageToLoad(180);
	         Thread.sleep(2000);
	         
	        //actions.WaitForElementPresent("RFM.Search");
	         Thread.sleep(2000);
	         actions.waitForPageToLoad(180);
	         driver.findElement(By.xpath("//*[@id='searchText']")).sendKeys(priceSetName);
	    	// actions.setValue("RFM.Search", priceSetName );  
	         Thread.sleep(2000);
	         actions.click("RFMPriceSets.PriceSetSearch");
	         actions.smartWait(180);
	         actions.javaScriptClick(mcd.GetTableCellElement("RFM.Table", 1, 1, "a"));
	         actions.smartWait(180);
	         String futureDate=null;
	         
	         switch (strEntercase) {
	         //IF want to update price tax setting in future date assigned to the price set
				case "UPDATE_PRICE_TAX_SETTING_IN_FUTURE_DATE":
					
					//Select 1st Future date
					futureDate = actions.getLocator("PriceSet.SelectFutureDate").replace("#","1");
					actions.getwebDriverLocator(futureDate).click();
					
					actions.smartWait(120);
		            actions.click("PriceSet.Taxbtn");
		            actions.smartWait(120);
		            
		            //click on Max Tax Settings Button
		            actions.click("PriceSet.MassTaxSettings");
		            mcd.SwitchToWindow("Mass Update Tax");
		            actions.setValue("MassUpdateTax.TaxCode", "Always");
		            actions.click("RFM.ApplyButton");
		            actions.smartWait(120);
		            mcd.SwitchToWindow("@Price Sets");
		           
		           /* List<WebElement> tax = driver.findElements(By.xpath(actions.getLocator("PriceSet.Taxcode")));
		            for(int i =0; i<tax.size(); i++){
		            	//actions.setValue(tax.get(i).getText(), "Always");
		            	Select oSelect = new Select(tax.get(i));
		            	oSelect.selectByIndex(0);
		            }
		            */  
		             actions.click("PriceSet.ApplyButton2");					
					
					//Returns future date which is selected to update the tax settings
		            String future_date_selected = actions.getWebElement("PriceSet.SelectFutureDate").getText();
					return future_date_selected;
						
				//IF want to add Menu Item to the Prices Set in Future Setting.Returns the future date .
				case "ADD_MENUITEM_IN_FUTURE_DATE":
					
					
					futureDate = actions.getLocator("PriceSet.SelectFutureDate").replace("#","1");
					actions.WaitForElementPresent(futureDate);
					actions.getwebDriverLocator(futureDate).click();
					
					actions.smartWait(180);
					//actions.WaitForElementPresent("PriceSet.AddRemoveBtn");
					Thread.sleep(2000);
					actions.click("SubstitutionGroup.BONewMenuItem");
	          		mcd.waitAndSwitch("Price Sets : Common Menu Item Selector");

	          		// Switch to Price Sets : Common Menu Item Selector - to add new menu items
	          		// View Full List
	          		actions.keyboardEnter("CommonSelector.ViewFullBtn");
	          		Thread.sleep(2000);
	          		//actions.smartWait(180);
	          		actions.WaitForElementPresent("CommonSelector.AvailabilityDrpDwn");
	          		// Select Available from Availability drop down
	          		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
	          		Thread.sleep(2000);

	          		// Get Row Count
	          		List<WebElement> Add_Chkbox = driver
	          				.findElements(By.xpath(actions.getLocator("PriceSet.AddMICheckBox")));
	          		
	          		int Item_Counts = Add_Chkbox.size();
	          		List<String> MnuItem_Names = new ArrayList<String>();
	          		// Check items and add accordingly

	          		int i_temp = 0;
	          		for (int n = 0; n <= Item_Counts; n++) {
	          			// Check whether enabled for Add or not
	          			if ((Add_Chkbox.get(n).isEnabled())) {
	          				// Check box enabled - Add Item
	          				Add_Chkbox.get(n).sendKeys(Keys.SPACE);

	          				// Get Item Name
	          				String p = Integer.toString(n + 1);
	          				String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
	          				MnuItem_Names.add(e);
	          				i_temp++;
	          			} else {
	          				System.out.println("This MI is already added");
	          			}

	          			if (i_temp == Integer.parseInt(strNumOfMenuItem)) {
	          				System.out.println("Selected items for Add MI");
	          				break;
	          			}
	          			
	          		}
	          		Thread.sleep(2000);
	          		// Save Changes
	          		actions.keyboardEnter("CommonSelector.Save");
	          		Thread.sleep(3000);
					
	          		mcd.waitAndSwitch("@Price Sets");
	          		Thread.sleep(5000);
	          		//actions.waitForPageToLoad(180);
					actions.verifyTextPresence(strAddMenuMessage, true);
					future_date_selected = actions.getWebElement("PriceSet.SelectFutureDate").getText();
					actions.keyboardEnter("RFM.CancelBtn");
					return future_date_selected;
					
	          	//If want to add future dates to the price set.Returns the future date .     		
	          		
				case "CHANGE_FUTURE_DATE":
					Thread.sleep(1000);
					mcd.Get_future_date(daysinfuture, "open", strApplicationDate);
					actions.clear("UpdtMultipleSet.AllPrc");
	      			Thread.sleep(1000);
	      			actions.setValue("UpdtMultipleSet.AllPrc", strNewPrice);
	      			actions.WaitForElementPresent("UpdtMultipleSet.Apply");
	      			actions.javaScriptClick("UpdtMultipleSet.Apply");
	      			actions.WaitForElementPresent("PriceSet.ApplyButton2");
	      			actions.javaScriptClick("PriceSet.ApplyButton2");
	      			actions.smartWait(180);
	      			futureDate = actions.getLocator("PriceSet.SelectFutureDate").replace("1", Integer.toString(futureDateNo));
	      			
	      			future_date_selected = actions.getwebDriverLocator(futureDate).getText();
					return future_date_selected;
						
				default:
					//Returns the future date .
					future_date_selected = actions.getWebElement("PriceSet.SelectFutureDate").getText();
					return future_date_selected;
				}
	    	   
	    	   
	       }
        
       	
/*****************************************************************************************
* Function Name: PKG_Select_Instructions () Date Created: 07-Feb-2017
* Author : Kandarp Prakash Arguments: Description: This functions is used 
* to select the instuction type for package creation. Pre-Req: None; Used in script :
*****************************************************************************************/
        public void PKG_Select_Instructions(String InstructionType) {
            
            WebElement ele;
            String instr;
            
            switch (InstructionType) {
         // Enter Instruction Type for selecting radio Buttons     
            case "Regular Package":
                  instr= actions.getLocator("PackageSchedule.PackageOptions").replace("#", "Regular Package");
                       ele = actions.getwebDriverLocator(instr);
                       ele.click();
                 break;
                 
            case "Package with no image":
                  instr= actions.getLocator("PackageSchedule.PackageOptions").replace("#", "Package with no image");
                       ele = actions.getwebDriverLocator(instr);
                       ele.click();
                 break;
                 
            case "Package of New/Replaced images only":    
                 
                  instr= actions.getLocator("PackageSchedule.PackageOptions").replace("#", "Package of New/Replaced images only");
                       ele = actions.getwebDriverLocator(instr);
                       ele.click();
                       break;
                       
            case "Package with all images":    
                 
                  instr= actions.getLocator("PackageSchedule.PackageOptions").replace("#", "Package with all images");
                       ele = actions.getwebDriverLocator(instr);
                       ele.click();
                       break;
                       
                       
            default:
                      actions.reportCreateFAIL("Verify data", "Enter correct Instruction Type", "Incorrect data", "FAIL");
                      break;
         
             }
         }
           
 /*********************************************************************************************
 * Function Name: PKG_Select_ExportInstructions () Date Created: 07-Feb-2017
 * Author : Kandarp Prakash Arguments: Description: This functions is used 
 * to select the Export instuction type for package creation. Pre-Req: None; Used in script :
 *********************************************************************************************/
           
           public void PKG_Select_ExportInstructions(String ExpInstructionType) {
             
            WebElement ele;
            String instr;
            // Enter Export Instruction Type for selecting radio Buttons
            switch (ExpInstructionType) {
                
            case "Packages with messages, file output and file exports":
                  instr= actions.getLocator("PackageSchedule.ExportPackageOptions").replace("#", "Packages with messages, file output and file exports");
                       ele = actions.getwebDriverLocator(instr);
                       ele.click();
                 break;
                 
            case "Packages with messages and file output":       
                 
                  instr= actions.getLocator("PackageSchedule.ExportPackageOptions").replace("#", "Packages with messages and file output");
                       ele = actions.getwebDriverLocator(instr);
                       ele.click();
                       break;
                       
            case "Packages with messages only":      
                 
                  instr= actions.getLocator("PackageSchedule.ExportPackageOptions").replace("#", "Packages with messages only");
                       ele = actions.getwebDriverLocator(instr);
                       ele.click();
                       break;
                       
            default:
                      actions.reportCreateFAIL("Verify data", "Enter correct Export Instruction Type", "Incorrect data", "FAIL");
                      break;
                      
            }
         
         }
 	/*****************************************************************************
	 * Function Name: fnPKG_XMLNodeValidation ()
	 * Date Created:11-Jan-2017 
	 * Author :	 * Archana Savanji 
	 * Arguments: 
	 * Description: This function verify the XML node.  
	 * 
	 ******************************************************************************/
	public void fnPKG_XMLNodeValidation(String strFileName, String strXPATH) {

		System.out.println("*********************************** Start Test-Steps executions: fnPKG_XMLNodeValidation");

		boolean bflag = false;
		try {
				
			bflag = xValidations.isNodePresent(strFileName, strXPATH, true);

			if (bflag)
				actions.reportCreatePASS("Verify XML node", strFileName + " File should be generated.",
						"File is generated as expected and found node : "+strXPATH, "Pass");
			else
				actions.reportCreateFAIL("Verify XML node", strFileName + " File should be generated.",
						"File is not generated as expected and node not found  : "+strXPATH,
						"Fail");

		} catch (Exception err1) {
			System.out.println("Error:" + err1);
		}

		System.out.println("*********************************** End of function ");
	}

	public void packagvalidation(String Package_Schedule_Type){
		boolean flag=false;
		flag=actions.isElementEnabled("PackagesReport.ViewType");
		if(flag){

			switch (Package_Schedule_Type) {
			case "CreateSchedule": {
				actions.setValue("PackagesReport.ViewType", "Schedule Batch");
				actions.smartWait(180);
				break;
			}
			case "GenerateNow": {
				actions.setValue("PackagesReport.ViewType", "Schedule Batch Now");
				actions.smartWait(180);
				break;
			}
			case "AdhocSchedule": {
				actions.setValue("PackagesReport.ViewType", "Ad hoc");
				actions.smartWait(180);
				break;
			}
			case "PartialExport": {
				actions.setValue("PackagesReport.ViewType", "Partial Export");
				actions.smartWait(180);
				break;
			}
			default: {
				actions.setValue("PackagesReport.ViewType", "All");
				actions.smartWait(180);
				System.out.println("Package option is not macting: " + Package_Schedule_Type + "Selected Generate Now option");
				break;
			}								
			
			}

			flag=actions.isElementEnabled("PackagesReport.ViewStatus");
			if(flag){
				actions.setValue("PackagesReport.ViewStatus", "Package Generated");	
				actions.smartWait(180);
				
				try{
					String strTagName=driver.findElement(By.xpath(actions.getLocator("ManagePackagesReport.DateRequested"))).getTagName();
					if(strTagName.equals("a")){
						try{
						//To make it sorted by descending
						actions.WaitForElementPresent("ManagePackagesReport.DateRequested", 50);
						actions.click("ManagePackagesReport.DateRequested");
						actions.smartWait(180);
						actions.WaitForElementPresent("ManagePackagesReport.DateRequested", 50);
						actions.click("ManagePackagesReport.DateRequested");
						actions.smartWait(180);
						actions.WaitForElementPresent("ManagePackagesReport.DownArrow", 50);
						flag=actions.isElementPresent("ManagePackagesReport.DownArrow");
							if(flag){
								actions.reportCreatePASS("Verify Package sorted by desending",
		           						"Package should sorted by desending",
		           						"Package sorted by desending",
		           						"Pass");
		           			} else {
		           				actions.reportCreateFAIL("Verify Package sorted by desending",
		           						"Package should sorted by desending",
		           						"Package not sorted by desending",
		           						"Fail"); 
							}
						}catch (Exception e1) {
								actions.reportCreateFAIL("Verify Package sorted by desending",
			       						"Package should sorted by desending",
			       						"Package not sorted by desending",
			       						"Fail"); 
						}
					}	
				}catch (Exception e1) {
				System.out.println("No record present");
				}
			}
		}
	}
}
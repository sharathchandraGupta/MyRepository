package crossbrowser.library.helper;

import java.io.File;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Helper {
	protected File screenShot(WebDriver driver){
		File screenShotFile = null;
		try{
		 screenShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		}catch(Exception e){}
		return screenShotFile;
	}
}

package crossbrowser.library;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.lib_MCD.AlertPopupButton;

public class Pricing_Oldv1 {
	private Keywords actions;
	private WebDriver driver;
	String STenderName = null;
	private lib_RFM2 rfm;
	private lib_MCD mcd;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	public Pricing_Oldv1(WebDriver nodeDriver, Keywords actions, UIValidations uiActions, Map inputData, lib_MCD mcd,
			lib_RFM2 rfm, Object or) {
		this.driver = nodeDriver;
		this.rfm = rfm;
		this.actions = actions;
		this.uiActions = uiActions;
		this.input = inputData;
		this.mcd = mcd;
	}

	@Test

	// ----------------------------------
	/*
	 * Feature Name : Master Tender Type Functionality :Create New Tender Type
	 * Scenario ID : PRC_0077 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_ValidationsCreateTenderType(String strTenderName, String strTenderId, String strLegacyId,
			String strFiscalIndex, String strDefSkimAmt, String DefHaloAmt, String strCurrencyDecimal,
			String ChgMaxAllwd, String[] strMessages) {
		try {

			actions.click("TenderTypeList.NewTenderType");
			actions.WaitForElementPresent("NewTenderType.TenderName", 10000);

			// Text box capacity verification

			actions.setValue("NewTenderType.TenderName", strTenderName);
			Thread.sleep(500);
			actions.setValue("NewTenderType.TenderId", strTenderId);
			Thread.sleep(500);
			actions.setValue("NewTenderType.LegacyId", strLegacyId);
			Thread.sleep(500);
			actions.setValue("NewTenderType.FiscalIndex", strFiscalIndex);
			Thread.sleep(500);
			actions.setValue("NewTenderType.DefSkimAmt", strDefSkimAmt);
			Thread.sleep(500);
			actions.setValue("NewTenderType.DefHaloAmt", DefHaloAmt);
			Thread.sleep(500);
			actions.setValue("NewTenderType.CurrencyDecimal", strCurrencyDecimal);

			if (Integer.parseInt(strCurrencyDecimal) > 6) {
				actions.click("NewTenderType.Save");
				Boolean VerifyErr = mcd.VerifyAlertMessageDisplayed("Error", strMessages[0].trim(), true,
						AlertPopupButton.OK_BUTTON);
				if (VerifyErr) {
					actions.reportCreatePASS("Verify Currency Decimal (less than 6)", "Should be less than 6",
							"Working as expected", "PASS");
					// Reporter.log("Currency Decimal (less than 6) Validation
					// PASS");
					actions.clear("NewTenderType.CurrencyDecimal");
					actions.setValue("NewTenderType.CurrencyDecimal", 4);
				} else {
					actions.reportCreateFAIL("Verify Currency Decimal (less than 6)", "Should be less than 6",
							"Not working as expected", "PASS");
					// Reporter.log("Currency Decimal (less than 6) Validation
					// FAILED");
				}

			}

			actions.setValue("NewTenderType.ChgMaxAllwd", ChgMaxAllwd);

			// Enter Unique Tender Name

			STenderName = Get_Unique_ID_Name("Tender Name");
			actions.clear("NewTenderType.TenderName");

			actions.click("NewTenderType.Save");
			Thread.sleep(2000);
			Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[1].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Tender Name Mandatory Validation", "Tender Name should be mandatory",
						"Tender Name is mandatory", "PASS");
				// Reporter.log("Tender Name Validation PASS");
			} else {
				actions.reportCreateFAIL("Tender Name Mandatory Validation", "Tender Name should be mandatory",
						"Tender Name is not mandatory", "FAIL");
				// Reporter.log("Tender Name Validation FAILED");
			}
			Thread.sleep(1000);
			actions.setValue("NewTenderType.TenderName", STenderName);
			Thread.sleep(1000);

			// Tender Id Non-decimal Verification

			actions.clear("NewTenderType.TenderId");
			actions.click("NewTenderType.Save");
			Thread.sleep(1000);
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[2].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Tender Id Mandatory Validation", "Tender Id should be mandatory",
						"Tender Id is mandatory", "PASS");
				// Reporter.log("Tender Id Validation PASS");
			} else {
				actions.reportCreateFAIL("Tender Id Mandatory Validation", "Tender Id should be mandatory",
						"Tender Id is not mandatory", "FAIL");
				// Reporter.log("Tender Id Validation FAILED");
			}

			actions.setValue("NewTenderType.TenderId", 12.15);
			Thread.sleep(1000);
			actions.click("NewTenderType.Save");
			Thread.sleep(1000);

			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[3].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Tender Id Non-decimal Validation", "Decimal value should not be allowed",
						"Decimal value is not allowed", "PASS");
				// Reporter.log("Tender Id Non-decimal Validation PASS");
			} else {
				actions.reportCreateFAIL("Tender Id Non-decimal Validation", "Decimal value should not be allowed",
						"Decimal value is allowed", "FAIL");
				// Reporter.log("Tender Id Non-decimal Validation FAILED");
			}

			// Enter Tender ID
			// Getting unique Tender ID
			String STenderID = Get_Unique_ID_Name("Tender ID");
			actions.clear("NewTenderType.TenderId");
			actions.setValue("NewTenderType.TenderId", STenderID);
			Thread.sleep(1000);

			// Enter Legacy ID
			String SLeagcyID = Get_Unique_ID_Name("Legacy ID");
			actions.clear("NewTenderType.LegacyId");
			actions.click("NewTenderType.Save");
			Thread.sleep(1000);
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[4].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Legacy Id Mandatory Validation", "Legacy Id should be mandatory",
						"Legacy Id is mandatory", "PASS");
				// Reporter.log("Legacy Id Validation PASS");
			} else {
				actions.reportCreateFAIL("Legacy Id Mandatory Validation", "Legacy Id should be mandatory",
						"Legacy Id is not mandatory", "FAIL");
				// Reporter.log("Legacy Id Validation FAILED");
			}
			actions.setValue("NewTenderType.LegacyId", SLeagcyID);
			Thread.sleep(1000);

			// Amount Field blank validation
			// For Payment Type"TENDER_GIFT_COUPON"

			Select select = new Select(driver.findElement(By.xpath(actions.getLocator("NewTenderType.PaymentType"))));
			select.selectByVisibleText("TENDER_GIFT_COUPON");
			Thread.sleep(1000);

			// Click Save
			actions.click("NewTenderType.Save");
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[5].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Amount Field Mandatory Validation", "Amount should be mandatory",
						"Amount is mandatory", "PASS");
				// Reporter.log("Amount Field Blank Validation PASS");
			} else {
				actions.reportCreateFAIL("Amount Field Mandatory Validation", "Amount should be mandatory",
						"Amount is not mandatory", "FAIL");
				// Reporter.log("Amount Field Blank Validation FAILED");
			}

			// Enter any alphabetic value in amount field to validate error
			actions.setValue("NewTenderType.Amount", "Auto123");

			actions.click("NewTenderType.Save");
			Thread.sleep(500);
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[6].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Amount Field Numeric Validation", "Amount should accept only numeric value",
						"Amount field accepts only numeric value", "PASS");
				// Reporter.log("Amount Field Numeric Validation PASS");
			} else {
				actions.reportCreateFAIL("Amount Field Numeric Validation", "Amount should accept only numeric value",
						"Amount field accepts non-numeric value", "FAIL");
				// Reporter.log("Amount Field Numeric Validation FAILED");
			}

			actions.smartWait(120);
			// Click on cancel to close the page
			actions.click("NewTenderType.Cancel");
			Thread.sleep(2000);
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessages[7].trim(), true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify Unsaved data warning message",
						"Unsaved data warning message should come", "Unsaved data warning message found", "PASS");
				// Reporter.log("Unsaved record message PASS");
			} else {
				actions.reportCreateFAIL("Verify Unsaved data warning message",
						"Unsaved data warning message should come", "Unsaved data warning message not found", "FAIL");
				// Reporter.log("Unsaved record message FAILED");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Master Tender Type Functionality :Create New Tender Type
	 * Scenario ID : PRC_0076 Author : Pooja Panse
	 */
	// -----------------------------------
	public String RFM_PRC_CreateNewTenderType(String strPaymentType, String strTaxOption, String strTaxSubTotalOption,
			String strChangeName, String strStatus, String strForeignCurrency, String strExchangeRate,
			String strOrientation, String strPrecision, String strRounding, String strExchMode, String strAmount)
					throws Exception {

		// Generate Unique Tender Name, Tender ID, Legacy ID
		String STenderName = Get_Unique_ID_Name("Tender Name");
		String STenderID = Get_Unique_ID_Name("Tender ID");
		String SLeagcyID = Get_Unique_ID_Name("Legacy ID");

		// Click New Tender Type button
		actions.click("TenderTypeList.NewTenderType");
		actions.WaitForElementPresent("NewTenderType.TenderName", 10000);

		Thread.sleep(1000);

		// Enter Tender Name
		actions.setValue("NewTenderType.TenderName", STenderName);
		System.out.println("NewTenderType.TenderName" + STenderName);
		// Enter Tender ID
		actions.setValue("NewTenderType.TenderId", STenderID);

		// Enter Legacy ID
		actions.setValue("NewTenderType.LegacyId", SLeagcyID);

		// Enter Payment Type
		Select select = new Select(driver.findElement(By.xpath(actions.getLocator("NewTenderType.PaymentType"))));
		select.selectByVisibleText(strPaymentType);

		// Creating for Payment type gift coupon- and set Currency Decimal to
		// .00
		actions.setValue("NewTenderType.CurrencyDecimal", "2");

		// Verifying Amount Field
		if (strPaymentType.equals("TENDER_GIFT_COUPON")) {
			Boolean AmtFldStatus = driver.findElement(By.xpath(actions.getLocator("NewTenderType.Amount"))).isEnabled();
			if (AmtFldStatus) {
				actions.reportCreatePASS("Amount field for TENDER_GIFT_COUPON payement type", "Should be enabled",
						"Is Enabled", "PASS");
				// Reporter.log("Amount Field is enabled for Payment Type :
				// "+strPaymentType+" - PASS");
				actions.setValue("NewTenderType.Amount", strAmount);
				Thread.sleep(500);
			} else {
				actions.reportCreateFAIL("Amount field for TENDER_GIFT_COUPON payement type", "Should be enabled",
						"Is Disabled", "FAIL");
				// Reporter.log("Amount Field is not enabled for Payment Type :
				// "+strPaymentType+ " - FAIL");
			}

		}

		// Mandatory Fields for PaymentType == "TENDER_FOREIGN_CURRENCY"
		if (strPaymentType.equalsIgnoreCase("TENDER_FOREIGN_CURRENCY")) {
			// Default Foreign Currency
			select = new Select(driver.findElement(By.xpath(actions.getLocator("NewTenderType.DefForeignCurr"))));
			select.selectByVisibleText(strForeignCurrency);
			Thread.sleep(500);

			// Exchange Rate
			actions.setValue("NewTenderType.ExchangeRate", strExchangeRate);
			Thread.sleep(500);

			// Orientation
			select = new Select(driver.findElement(By.xpath(actions.getLocator("NewTenderType.Orientation"))));
			select.selectByVisibleText(strOrientation);
			Thread.sleep(500);

			// Precision
			select = new Select(driver.findElement(By.xpath(actions.getLocator("NewTenderType.Precision"))));
			select.selectByVisibleText(strPrecision);
			Thread.sleep(500);

			// Rounding
			select = new Select(driver.findElement(By.xpath(actions.getLocator("NewTenderType.Rounding"))));
			select.selectByVisibleText(strRounding);
			Thread.sleep(500);

			// Exchange Mode
			select = new Select(driver.findElement(By.xpath(actions.getLocator("NewTenderType.ExchMode"))));
			select.selectByVisibleText(strExchMode);
			Thread.sleep(500);
		}

		// Enter Tax Option
		select = new Select(driver.findElement(By.xpath(actions.getLocator("NewTenderType.TaxOptions"))));
		select.selectByVisibleText(strTaxOption);

		// Enter Tax Sub Option
		select = new Select(driver.findElement(By.xpath(actions.getLocator("NewTenderType.TaxSubtotalOpt"))));
		select.selectByVisibleText(strTaxSubTotalOption);

		// Enter Change Type
		select = new Select(driver.findElement(By.xpath(actions.getLocator("NewTenderType.TendChangeType"))));
		select.selectByVisibleText(strChangeName);

		// Enter Status
		select = new Select(driver.findElement(By.xpath(actions.getLocator("NewTenderType.Status"))));
		select.selectByVisibleText(strStatus);

		// Click Save
		actions.keyboardEnter("NewTenderType.Save");
		Thread.sleep(4000);
		actions.smartWait(120);
		
		while(actions.isElementPresent("ManageTenderType.MsgText")){
			
			//Generate ID again
			STenderID = Get_Unique_ID_Name("Tender ID");
			
			actions.clear("NewTenderType.TenderId");
			// Enter Tender ID
			actions.setValue("NewTenderType.TenderId", STenderID);
			
			// Click Save
			actions.keyboardEnter("NewTenderType.Save");
			Thread.sleep(4000);
			actions.smartWait(120);
		};
		
		String Result = driver.findElement(By.xpath(actions.getLocator("UpdateTTypeSettings.Msg"))).getText();
		if (Result.equals("Tender Type created successfully.")) {
			actions.reportCreatePASS("Verify creation of New Tender Type", "Tender Type should be created successfully",
					"Tender Type created successfully", "PASS");
			// Reporter.log("Tender Type created successfully. - PASS");
		} else {
			actions.reportCreateFAIL("Verify creation of New Tender Type", "Tender Type should be created successfully",
					"Tender Type not created successfully", "FAIL");
			// Reporter.log("Tender Type not created successfully. - FAIL");
		}

		return STenderName;
	}

	// -----------------------------------------------------------
	/*
	 * Feature Name : Master Tender Type Functionality :Create unique values for
	 * Tender Type functions Author : Pooja Panse
	 */
	// ------------------------------------------------------------

	public String Get_Unique_ID_Name(String FieldName) {
		String s = null;
		switch (FieldName) {
		case "Tender Name":
			s = mcd.fn_GetRndName("Auto");
			break;
		case "Tender ID":
			// Getting unique Tender ID

			Date d = new Date();
			int i = (int) d.getTime();
			String temp = Integer.toString(i).substring(1);
			s = "" + d.getSeconds() + "" + temp;
			break;
		case "Legacy ID":
			s = mcd.fn_GetRndName("").split("_")[1];
			break;

		default:
			break;
		}
		return s;
	}

	// ----------------------------------
	/*
	 * Feature Name : Mass Price Update Functionality : Navigating to the Mass
	 * update Price Page Pre-requisites for Mass Update Test Scenarios Scenario
	 * ID : PRC_0238/239/245 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_MUP_Prerquisite() throws InterruptedException {
		// Menu Item

		actions.keyboardEnter("UpdateSet.VwFullList");
		Thread.sleep(2000);
		actions.smartWait(180);
		mcd.select_row("UpdateSet.MenuItemTable", 0);
		Thread.sleep(500);
		actions.click("UpdateSet.AddRow");
		Thread.sleep(500);
		actions.click("UpdateSet.NextBtn");
		Thread.sleep(2000);
		actions.smartWait(180);

		// Price Sets
		actions.click("UpdatePrcSet.VwFullList");
		Thread.sleep(2000);
		actions.smartWait(180);
		mcd.select_row("UpdatePrcSet.PriceSetTable", 0);
		Thread.sleep(500);
		actions.click("UpdatePrcSet.AddRow");
		Thread.sleep(500);
		actions.click("UpdatePrcSet.NextBtn");
		Thread.sleep(2000);
		actions.smartWait(180);
	}

	// ----------------------------------
	/*
	 * Feature Name : Mass Price Update Functionality : Error Validations for
	 * Mass Update Prices Scenario ID : PRC_0238 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_MassUpdatePricesValidations(String strStartDateMessage, String strValidAmtMessage,
			String strMessageBeforeSave, String strResultMessage, String strNewPrice, String strTaxCode,
			String strTaxRule, String strTaxEntry, String strTaxType, String strApplicationDate) throws Exception {

		this.RFM_PRC_MUP_Prerquisite();

		// Updating Prices
		Boolean Check1 = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate"))).isDisplayed();
		Boolean Check2 = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate"))).isEnabled();
		if (Check1) {
			if (Check2) {
				actions.reportCreatePASS("Verify Start Date TextBox", "Should be present & enabled",
						"Present & Enabled", "PASS");
				// Reporter.log("Start Date txtbox is present and enabled -
				// PASS");
			} else {
				actions.reportCreateFAIL("Verify Start Date TextBox", "Should be present & enabled",
						"Present but disabled", "FAIL");
				// Reporter.log("Start Date txtbox is disabled - FAIL");
			}
		} else {
			actions.reportCreateFAIL("Verify Start Date TextBox", "Should be present & enabled", "Not Present", "PASS");
			// Reporter.log("Start Date btn is not present - FAIL");
		}

		// Selecting Today's date (Today Button)
		Thread.sleep(1000);
		actions.click("UpdtMultipleSet.TodayBtn");

		// Getting today's date in required format

		WebElement apptime = mcd.getdate();
		String app_date = apptime.getText();

		String dtForm = mcd.GetTestData("DT_DATE_FORMAT");
		String TodayDt = app_date.substring(0, dtForm.length());

		// Reading date displayed in the application
		String CurrDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate")))
				.getAttribute("value");

		// Verifying date
		if (CurrDate.equals(TodayDt)) {
			actions.reportCreatePASS("Verify Today's date", "Today's date should be correctly updated",
					"Correctly displayed", "PASS");
			// Reporter.log("Today's date correctly updated - PASS");
		} else {
			actions.reportCreateFAIL("Verify Today's date", "Today's date should be correctly updated",
					"Not correctly displayed", "FAIL");
			// Reporter.log("Today's date wrongly updated - FAIL");
		}

		// Verifying Clear button functionality
		actions.click("UpdtMultipleSet.Clear");
		Thread.sleep(500);
		Boolean chk = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.SDateVal"))).getAttribute("value")
				.isEmpty();

		if (chk) {
			actions.reportCreatePASS("Verify Clear button functionality", "Field data should be cleared",
					"Data cleared", "PASS");
			// Reporter.log("Clear Button Verification - PASS");
		} else {
			actions.reportCreateFAIL("Verify Clear button functionality", "Field data should be cleared",
					"Data not cleared", "FAIL");
			// Reporter.log("Clear Button Verification - FAIL");
		}

		// "Please enter start date." - Validation
		Thread.sleep(2000);
		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(2000);
		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strStartDateMessage, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Start Date Mandatory Validation", "Start Date should be Mandatory",
					"Start Date is Mandatory", "PASS");
			// Reporter.log("Start Date Mandatory Validation PASS");
		} else {
			actions.reportCreateFAIL("Start Date Mandatory Validation", "Start Date should be Mandatory",
					"Start Date is not Mandatory", "FAIL");
			// Reporter.log("Start Date Mandatory Validation FAIL");
		}
		Thread.sleep(1000);

		// Calendar Icon check
		actions.click("UpdtMultipleSet.CalenderIcon");
		Thread.sleep(500);

		// mcd.Get_future_date(5, "UpdtMultipleSet.CalenderIcon", );
		mcd.Get_future_date(1, "close", strApplicationDate);
		
		chk = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.SDateVal"))).getAttribute("value")
				.isEmpty();

		if (!chk) {
			actions.reportCreatePASS("Date selection using calender", "Date should be selected", "Date selected",
					"PASS");
			// Reporter.log("Date selection using calender - PASS");
		} else {
			actions.reportCreateFAIL("Date selection using calender", "Date should be selected", "Date not selected",
					"FAIL");
			// Reporter.log("Date selection using calender - FAIL");
		}

		Thread.sleep(1000);

		// Valid input for All Prices Validation(non Numeric data)

		actions.click("UpdtMultipleSet.Clear");
		actions.click("UpdtMultipleSet.TodayBtn");
		actions.setValue("UpdtMultipleSet.AllPrc", "abc");
		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(3000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strValidAmtMessage, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Field - All Price - Non Numeric Validation",
					"Should not accept non-numeric values", "Does not accept non-numeric value", "PASS");
			// Reporter.log("Field - All Price - Non Numeric Validation PASS");
		} else {
			actions.reportCreateFAIL("Field - All Price - Non Numeric Validation",
					"Should not accept non-numeric values", "Accepts non-numeric value", "FAIL");
			// Reporter.log("Field - All Price - Non Numeric Validation FAIL");
		}


		// Mass Updating Prices
		// Verifying Date & Prices entered are updated correctly.

		actions.clear("UpdtMultipleSet.AllPrc");
		actions.clear("UpdtMultipleSet.AllPrc");
		actions.setValue("UpdtMultipleSet.AllPrc", strNewPrice);
		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(1000);
		actions.smartWait(120);

		String InpStrtDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate")))
				.getAttribute("value");
		String AppliedDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewDate")))
				.getAttribute("value");

		String ALL_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewAllPrc")))
				.getAttribute("value");

		if (InpStrtDate.equals(AppliedDate)) {
			actions.reportCreatePASS("Verify Start Date", "Start Date should be updated against for all prices",
					"Start Date entered is updated against for all prices", "PASS");
			// Reporter.log("Start Date entered is updated against for all
			// prices correctly - PASS");
		} else {
			actions.reportCreateFAIL("Verify Start Date", "Start Date should be updated against for all prices",
					"Start Date entered is not correctly updated against for all prices", "FAIL");
			// Reporter.log("Start Date entered is not updated correctly -
			// FAIL");
		}

		try {
			driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.ExpandImg"))).click();
		} catch (Exception err) {
			System.out.println("Price already expanded");
		}
		// actions.keyboardEnter("UpdtMultipleSet.ExpandImg");

		// Reading Eating/take out/other prices
		String Eating_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewEatingPrc")))
				.getAttribute("value");
		String TakeOut_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewTkOutPrc")))
				.getAttribute("value");
		String Other_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewOtherPrc")))
				.getAttribute("value");

		if ((ALL_Price.equals(strNewPrice)) && (Eating_Price.equals(strNewPrice)) && (TakeOut_Price.equals(strNewPrice))
				&& (Other_Price.equals(strNewPrice))) {
			actions.reportCreatePASS("Verify All Prices/Eating/Take out/Other Prices", "Should be updated correctly",
					"Updated correctly", "PASS");
			// Reporter.log("All Prices/Eating/Take out/Other Prices updated
			// correctly - PASS");
		} else {
			actions.reportCreateFAIL("Verify All Prices/Eating/Take out/Other Prices", "Should be updated correctly",
					"Not updated correctly", "FAIL");
			// Reporter.log("All Prices/Eating/Take out/Other Prices not updated
			// correctly - FAIL");
		}

		// ------------------------------------------------------------------------------
		// Update Tax Functionality
		// -----------------------------------------------------------------------------

		actions.click("UpdtMultipleSet.UpdtTax");
		Thread.sleep(5000);

		// String CurrHandle = driver.getWindowHandle();
		// //System.out.println("Current-" +driver.getTitle());
		// actions.windowSwitch(CurrHandle, "Mass Update Prices");
		// Thread.sleep(2000);

		mcd.SwitchToWindow("Mass Update Prices");

		// Update Tax
		Boolean TaxResult = this.RFM_MassUpdatePrc_UpdateTax(strTaxCode, strTaxRule, strTaxEntry, strTaxType);
		if (TaxResult) {
			actions.reportCreatePASS("Verify Update Tax", "Tax should be correctly updated", "Correctly updated",
					"PASS");
			// Reporter.log("Update Tax done successfully - PASS");
		} else {
			actions.reportCreateFAIL("Verify Update Tax", "Tax should be correctly updated", "Not correctly updated",
					"FAIL");
			// Reporter.log("Update Tax not done successfully - FAIL");
		}

		// String NewHandle = driver.getWindowHandle();
		// actions.windowSwitch(NewHandle, "Mass Update Prices");
		// Thread.sleep(3000);

		// ------------------------------------------------------------------------------------

		// Save & Apply Changes

		this.RFM_PRC_MUP_SaveAndApply(strMessageBeforeSave, strResultMessage);

		// Verifying correct prices are saved

		Thread.sleep(1000);

		try {
			driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.ExpandImg"))).click();
			Thread.sleep(1000);
		} catch (Exception e2) {
			System.out.println("Already expanded");
		}

		ALL_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewAllPrc"))).getAttribute("value");
		Eating_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewEatingPrc")))
				.getAttribute("value");
		TakeOut_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewTkOutPrc")))
				.getAttribute("value");
		Other_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewOtherPrc")))
				.getAttribute("value");

		if ((ALL_Price.equals(strNewPrice)) || ((Eating_Price.equals(strNewPrice)) && (TakeOut_Price.equals(strNewPrice))
				&& (Other_Price.equals(strNewPrice)))) {
			actions.reportCreatePASS("Verify All Prices/Eating/Take out/Other Prices", "Should be saved correctly",
					"Saved correctly", "PASS");
			// Reporter.log("All Prices/Eating/Take out/Other Prices saved
			// correctly - PASS");
		} else {
			actions.reportCreateFAIL("Verify All Prices/Eating/Take out/Other Prices", "Should be saved correctly",
					"Not saved correctly", "FAIL");
			// Reporter.log("All Prices/Eating/Take out/Other Prices not saved
			// correctly - FAIL");
		}
		Thread.sleep(1000);

	}

	// ----------------------------------
	/*
	 * Feature Name : Mass Price Update Functionality : Save & Apply Mass update
	 * prices Scenario ID : PRC_0238/239/345 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_MUP_SaveAndApply(String strMessageBeforeSave, String strResultMessage) throws Exception {
		// Click Save
		Thread.sleep(2000);
		actions.click("UpdtMultipleSet.Save");
		Thread.sleep(3000);
		// actions.smartWait(120);

		// Check Alert message
		try {
			Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessageBeforeSave, true,
					AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify Alert message before save", "Alert message should be given",
						"Alert message is given", "PASS");
				// Reporter.log("Alert Message before save is displayed -
				// PASS");
			} else {
				actions.reportCreateFAIL("Verify Alert message before save", "Alert message should be given",
						"Alert message is not given", "FAIL");
				// Reporter.log("Alert Message before save is not displayed -
				// FAIL");
			}
		} catch (Exception err) {
			System.out.println("No alerts");
		}

		// as the page is continously loading bcoz of pop up , only hard wait
		// can be solution here.
		// Thread.sleep(10000);

		actions.WaitForElementPresent("OutputWindow.OutputMsg", 180);
		// actions.smartWait(120);
		// Check Success Message

		String Result = driver.findElement(By.xpath(actions.getLocator("OutputWindow.OutputMsg"))).getText();
		if (Result.equals(strResultMessage)) {
			actions.reportCreatePASS("Verify Mass update of prices", "Should be done successfully", "Done successfully",
					"PASS");
			// Reporter.log("Mass update of prices done successfully - PASS");
		} else {
			actions.reportCreateFAIL("Verify Mass update of prices", "Should be done successfully",
					"Not done successfully", "PASS");
			// Reporter.log("Mass update of prices failed - FAIL");
		}

		// Activating Menu Item case
		try {
			String Result_Img = driver.findElement(By.xpath(actions.getLocator("ActivateMISet.DoneImg2")))
					.getAttribute("src");
			if (Result_Img.contains("approve.jpg")) {
				actions.reportCreatePASS("Verify Activate Menu Item", "Activate Menu Item should be done successfully",
						"Activate Menu Item is done successfully", "PASS");
				// Reporter.log("Activate Menu Item is done successfully");
			} else {
				actions.reportCreateFAIL("Verify Activate Menu Item", "Activate Menu Item should be done successfully",
						"Activate Menu Item is not done successfully", "FAIL");
				// Reporter.log("Activate Menu Item is done successfully");
			}
		} catch (Exception e) {
			// Reporter.log("Activating Menu Item is unchecked");
		}
		// Click OK button

		Thread.sleep(2000);
		actions.click("OutputWindow.OkBtn");
		Thread.sleep(5000);

		// Window navigated back to main window
		// System.out.println(driver.getTitle());
		if (driver.getTitle().equals("Mass Update Prices")) {
			actions.reportCreatePASS("Verify navigation after final output",
					"Window should be navigated back after updating prices",
					"Window navigated back after updating prices", "PASS");
			// Reporter.log("Window navigated back after updating prices -
			// PASS");
		} else {
			actions.reportCreateFAIL("Verify navigation after final output",
					"Window should be navigated back after updating prices",
					"Window not navigated back after updating prices", "FAIL");
			// Reporter.log("Window not navigated back after updating prices -
			// FAIL");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Mass Update Price Functionality : Update Tax Scenario ID :
	 * PRC_0238 covers >> PRC_0245, PRC_0127 Author : Pooja Panse
	 */
	// -----------------------------------

	public boolean RFM_MassUpdatePrc_UpdateTax(String strTaxCode, String strTaxRule, String strTaxEntry,
			String strTaxType) throws Exception {
		Boolean blnResult = false;

		// Read the already existing tax entry value
		Select select = new Select(driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.MITaxEntry"))));
		String currEntry = select.getFirstSelectedOption().getText().trim();
		System.out.println(currEntry);

		// Enter Tax Code
		actions.setValue("UpdateTax.TaxCode", strTaxCode);
		Thread.sleep(3000);

		// Check Clear functionality
		// actions.click("UpdateTax.Clear");
		actions.keyboardEnter("UpdateTax.Clear");
		Thread.sleep(3000);
		String Str2 = actions.getValue("UpdateTax.TaxCode");
		if (Str2.equals("Default")) {
			// if (actions.getValue("UpdateTax.TaxCode").equals("Default")){
			actions.reportCreatePASS("Update Tax : Verify Clear button", "Field should get cleared",
					"Clear working as expected", "PASS");
			// Reporter.log("Clear button function in Update Tax - PASS");
		} else {
			actions.reportCreateFAIL("Update Tax : Verify Clear button", "Field should get cleared",
					"Clear not working as expected", "FAIL");
			// Reporter.log("Clear button function in Update Tax - FAIL");
		}

		Thread.sleep(2000);
		// Select rule before tax code - error message
		actions.setValue("UpdateTax.TaxRule", strTaxRule);
		Thread.sleep(500);
		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", "Please select Tax Code.", true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify Tax Code should be entered", "Correct message should be given",
					"Correct message is displayed", "PASS");
			// Reporter.log("Tax code must be selected before Tax rule
			// verification - PASS");
		} else {
			actions.reportCreateFAIL("Verify Tax Code should be entered", "Correct message should be given",
					"Correct message is not displayed, User is allowed to proceed without entering Tax code", "FAIL");
			// Reporter.log("Tax code must be selected before Tax rule
			// verification - FAIL");
		}
		Thread.sleep(1000);

		// Select Tax Code
		actions.setValue("UpdateTax.TaxCode", strTaxCode);
		Thread.sleep(1000);

		// Select Tax Rule
		actions.setValue("UpdateTax.TaxRule", strTaxRule);
		Thread.sleep(1000);

		// Apply Tax - Mandatory Rule Validation
		actions.click("UpdateTax.ApplyTax");
		// actions.javaScriptClick("UpdateTax.ApplyTax");
		Thread.sleep(1000);

		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", "Tax Entry is mandatory if a Tax Rule is selected.",
				true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify Tax entry", "Tax entry should be mandatory is tax rule is selected",
					"Tax entry is mandatory", "PASS");
			// Reporter.log("Tax Entry must be entered message is displayed -
			// PASS");
		} else {
			actions.reportCreateFAIL("Verify Tax entry", "Tax entry should be mandatory is tax rule is selected",
					"Tax entry is not mandatory", "FAIL");
			// Reporter.log("Tax Entry must be entered message is not displayed
			// - FAIL");
		}
		Thread.sleep(1000);


		select = new Select(driver.findElement(By.xpath(actions.getLocator("UpdateTax.TaxEntry"))));
		
		
		// enter different Tax Entry
		for (int i = 0; i < select.getOptions().size(); i++) {
			if ((select.getOptions().get(i).getText().trim().equals(currEntry))
					|| (select.getOptions().get(i).getText().trim().equals("Default"))) {
				// Same as existing. Do nothing
				System.out.println(select.getOptions().get(i).getText().trim());
			} else {
				select.selectByIndex(i);
				break;
			}
		}

		strTaxEntry = actions.getValue("UpdateTax.TaxEntry");
		System.out.println(strTaxEntry);

		// Select Tax Type
		actions.setValue("UpdateTax.TaxType", strTaxType);
		Thread.sleep(1000);

		// Apply Tax

		actions.click("UpdateTax.ApplyTax");
		Thread.sleep(3000);

		// Apply the Tax settings
		actions.click("RFMMassUpdatePrices.Save");

		driver.switchTo().window("");
		mcd.SwitchToWindow("@Mass Update Prices");

		actions.click("UpdtMultipleSet.UpdtTax");
		Thread.sleep(2000);

		mcd.SwitchToWindow("Mass Update Prices");

		// String CurrHandle = driver.getWindowHandle();
		// //System.out.println("Current-" +driver.getTitle());
		// actions.windowSwitch(CurrHandle, "Mass Update Prices");
		// Thread.sleep(2000);

		// Verify Tax - All/Eating/Take out/Other
		String All_TaxCode = actions.getValue("UpdateTax.NewTaxCode");
		Thread.sleep(500);
		String All_TaxRule = actions.getValue("UpdateTax.NewTaxRule");
		Thread.sleep(500);
		String All_TaxEntry = actions.getValue("UpdateTax.NewTaxEntry");
		Thread.sleep(1500);

		// Expand Tax setting
		try {
			actions.click("UpdateTax.ExpandBtn");
			Thread.sleep(2000);
		} catch (Exception err) {
			System.out.println("Already expanded");
		}

		String Eat_TaxCode = actions.getValue("UpdateTax.NewEatingTxCode");
		Thread.sleep(500);
		String Eat_TaxRule = actions.getValue("UpdateTax.NewEatingTxRule");
		Thread.sleep(500);
		String Eat_TaxEntry = actions.getValue("UpdateTax.NewEatingTxEntry");
		Thread.sleep(500);

		String TO_TaxCode = actions.getValue("UpdateTax.NewTkOutCode");
		Thread.sleep(500);
		String TO_TaxRule = actions.getValue("UpdateTax.NewTkOutRule");
		Thread.sleep(500);
		String TO_TaxEntry = actions.getValue("UpdateTax.NewTkOutEntry");
		Thread.sleep(500);

		String Other_TaxCode = actions.getValue("UpdateTax.NewOtherCode");
		Thread.sleep(500);
		String Other_TaxRule = actions.getValue("UpdateTax.NewOtherRule");
		Thread.sleep(500);
		String Other_TaxEntry = actions.getValue("UpdateTax.NewOtherEntry");
		Thread.sleep(500);

		if (All_TaxCode.equals(strTaxCode) && Eat_TaxCode.equals(strTaxCode) && TO_TaxCode.equals(strTaxCode)
				&& Other_TaxCode.equals(strTaxCode)) {
			actions.reportCreatePASS("Verify Tax Code for ALL/Eating/Take out/Other fields",
					"Tax code should be updated", "Tax code is updated", "PASS");
			// Reporter.log("ALL/Eating/Take out/Other Tax Code update - PASS");
			blnResult = true;
		} else {
			actions.reportCreateFAIL("Verify Tax Code for ALL/Eating/Take out/Other fields",
					"Tax code should be updated", "Tax code is not updated", "FAIL");
			// Reporter.log("ALL/Eating/Take out/Other Tax Code update - FAIL");
			blnResult = false;
		}

		if (All_TaxRule.equals(strTaxRule) && Eat_TaxRule.equals(strTaxRule) && TO_TaxRule.equals(strTaxRule)
				&& Other_TaxRule.equals(strTaxRule)) {
			actions.reportCreatePASS("Verify Tax Rule for ALL/Eating/Take out/Other fields",
					"Tax rule should be updated", "Tax rule is updated", "PASS");
			// Reporter.log("ALL/Eating/Take out/Other Tax Rule update - PASS");
			blnResult = true;
		} else {
			actions.reportCreateFAIL("Verify Tax Rule for ALL/Eating/Take out/Other fields",
					"Tax rule should be updated", "Tax rule is not updated", "FAIL");
			// Reporter.log("ALL/Eating/Take out/Other Tax Rule update - FAIL");
			blnResult = false;
		}

		if (All_TaxEntry.equals(strTaxEntry) && Eat_TaxEntry.equals(strTaxEntry) && TO_TaxEntry.equals(strTaxEntry)
				&& Other_TaxEntry.equals(strTaxEntry)) {
			actions.reportCreatePASS("Verify Tax Entry for ALL/Eating/Take out/Other fields",
					"Tax entry should be updated", "Tax entry is updated", "PASS");
			// Reporter.log("ALL/Eating/Take out/Other Tax Entry update -
			// PASS");
			blnResult = true;
		} else {
			actions.reportCreateFAIL("Verify Tax Entry for ALL/Eating/Take out/Other fields",
					"Tax entry should be updated", "Tax entry is not updated", "FAIL");
			// Reporter.log("ALL/Eating/Take out/Other Tax Entry update -
			// FAIL");
			blnResult = false;
		}

		actions.keyboardEnter("RFM.CancelBtn");
		Thread.sleep(2000);

		driver.switchTo().window("");
		mcd.SwitchToWindow("@Mass Update Prices");

		return blnResult;

	}

	// ----------------------------------
	/*
	 * Feature Name : Mass Update Price Functionality : Verify Eating/Take
	 * Out/Other Price Fields Errors Scenario ID : PRC_0239 Author : Pooja Panse
	 */
	// -----------------------------------

	public boolean RFM_MUP_Eating_TO_Other_ErrCheck(String strEatingPrc, String strTakeOutPrc, String strOtherPrice,
			String strMessageBeforeSave, String strResultMessage) throws Exception {

		Boolean blnResult = false;
		Boolean test_AllStatus;
		String strAll_RadioValue, strRest_Value, strEating_Chkbx, strTO_Chkbx, strOther_Chkbx;

		// Navigate to Mass Update Price Page
		this.RFM_PRC_MUP_Prerquisite();

		// Selecting Today's date (Today Button)
		Thread.sleep(1000);
		actions.click("UpdtMultipleSet.TodayBtn");
		Thread.sleep(1000);

		// Check default values/status of All Prices Fields
		// All - default checked & enabled, Rest - disabled

		strAll_RadioValue = actions.getValue("VerifyFields.AllRadio");
		test_AllStatus = this.get_Field_Status("VerifyFields.AllRadio");
		strRest_Value = actions.getValue("VerifyFields.RestPrcRadio");

		strEating_Chkbx = actions.getValue("VerifyFields.EatingChkBx");
		strTO_Chkbx = actions.getValue("VerifyFields.TkOutChkBx");
		strOther_Chkbx = actions.getValue("VerifyFields.OtherChkBx");

		if ((strAll_RadioValue.equals("true")) && (test_AllStatus)) {
			actions.reportCreatePASS("Verify All Price radio button", "Should be enabled & selected by default",
					"Is enabled & selected by default", "PASS");
			// Reporter.log("All Radio enabled and checked by default - PASS");
		} else {
			actions.reportCreateFAIL("Verify All Price radio button", "Should be enabled & selected by default",
					"Is not enabled & selected by default", "FAIL");
			// Reporter.log("All Radio not enabled and checked by default -
			// FAIL");
		}

		if (strRest_Value.equals("false")) {
			actions.reportCreatePASS("Verify rest of the price radio button", "Should be unchecked by default",
					"Not selected by default", "PASS");
			// Reporter.log("Rest Prices radio button unchecked by default -
			// PASS");
		} else {
			actions.reportCreateFAIL("Verify rest of the price radio button", "Should be unchecked by default",
					"Selected by default", "FAIL");
			// Reporter.log("Rest Prices radio button are checked by default -
			// FAIL");
		}

		// Eating Prc/TO/Other radio button unchecked

		if ((strEating_Chkbx.equals("false")) && (strTO_Chkbx.equals("false")) && (strOther_Chkbx.equals("false"))) {
			actions.reportCreatePASS("Verify Eating Prc/TO/Other price radio button", "Should be unchecked by default",
					"Not selected by default", "PASS");
			// Reporter.log("CheckBox against Eating Prc/TO/Other unchecked -
			// PASS");
		} else {
			actions.reportCreateFAIL("Verify Eating Prc/TO/Other price radio button", "Should be unchecked by default",
					"Selected by default", "FAIL");
			// Reporter.log("CheckBox against Eating Prc/TO/Other checked -
			// FAIL");
		}

		// Eating Prc/TO/Other fields disabled
		if (!((this.get_Field_Status("VerifyFields.EatingPrc")) && this.get_Field_Status("VerifyFields.TkOutPrc")
				&& this.get_Field_Status("VerifyFields.OtherPrc"))) {
			actions.reportCreatePASS("Verify Eating Prc/TO/Other price fields", "Should be disabled by default",
					"Disabled by default", "PASS");
			// Reporter.log("Eating/TakeOut/Other prices fields are enabled -
			// FAIL");
		} else {
			actions.reportCreateFAIL("Verify Eating Prc/TO/Other price fields", "Should be disabled by default",
					"Enabled by default", "FAIL");
			// Reporter.log("Eating/TakeOut/Other prices fields are disabled -
			// PASS");
		}

		Thread.sleep(3000);
		// Check Rest Prices RAdio button
		// All Prices - disabled, Other Enabled

		actions.click("VerifyFields.RestPrcRadio");
		Thread.sleep(1000);

		strAll_RadioValue = actions.getValue("VerifyFields.AllRadio");
		test_AllStatus = this.get_Field_Status("VerifyFields.AllRadio");
		strRest_Value = actions.getValue("VerifyFields.RestPrcRadio");

		strEating_Chkbx = actions.getValue("VerifyFields.EatingChkBx");
		strTO_Chkbx = actions.getValue("VerifyFields.TkOutChkBx");
		strOther_Chkbx = actions.getValue("VerifyFields.OtherChkBx");

		if ((strAll_RadioValue.equals("true")) && (test_AllStatus)) {
			actions.reportCreateFAIL("Verify All radio button after, other price radio button is selected",
					"Should get unchecked & disabled", "Not unchecked or disabled", "FAIL");
			// Reporter.log("All Radio enabled and checked - FAIL");
		} else {
			actions.reportCreatePASS("Verify All radio button after, other price radio button is selected",
					"Should get unchecked & disabled", "Gets unchecked & disabled", "PASS");
			// Reporter.log("All Radio disabled and unchecked - PASS");
		}

		if (strRest_Value.equals("true")) {
			actions.reportCreatePASS("Verify Rest prices radio button after being selected",
					"Should get checked & enabled", "Gets checked & enabled", "PASS");
			// Reporter.log("Rest Prices radio button checked - PASS");
		} else {
			actions.reportCreateFAIL("Verify Rest prices radio button after being selected",
					"Should get checked & enabled", "Gets unchecked or is disabled", "FAIL");
			// Reporter.log("Rest Prices radio button unchecked - FAIL");
		}

		// Eating Prc/TO/Other radio button checked

		if ((strEating_Chkbx.equals("true")) && (strTO_Chkbx.equals("true")) && (strOther_Chkbx.equals("true"))) {
			actions.reportCreatePASS(
					"Verify Eating Prc/TO/Other price radio button after rest price check box is clicked",
					"Should remain unchecked", "Not yet selected", "PASS");
			// Reporter.log("CheckBox against Eating Prc/TO/Other unchecked -
			// FAIL");
		} else {
			actions.reportCreateFAIL(
					"Verify Eating Prc/TO/Other price radio button after rest price check box is clicked",
					"Should remain unchecked", "Get Checked", "FAIL");
			// Reporter.log("CheckBox against Eating Prc/TO/Other checked -
			// PASS");
		}

		// Eating Prc/TO/Other fields enabled
		if ((this.get_Field_Status("VerifyFields.EatingPrc")) && this.get_Field_Status("VerifyFields.TkOutPrc")
				&& this.get_Field_Status("VerifyFields.OtherPrc")) {
			actions.reportCreatePASS(
					"Verify Eating Prc/TO/Other price text fields after rest price check box is clicked",
					"Should get enabled", "Fields gets enabled", "PASS");
			// Reporter.log("Eating/TakeOut/Other prices fields are enabled -
			// PASS");
		} else {
			actions.reportCreateFAIL(
					"Verify Eating Prc/TO/Other price text fields after rest price check box is clicked",
					"Should get enabled", "Fields remain disabled", "FAIL");
			// Reporter.log("Eating/TakeOut/Other prices fields are disabled -
			// FAIL");
		}

		// Validating input in Eating/TO/Other Price fields
		actions.setValue("VerifyFields.EatingPrc", "test1");

		actions.setValue("VerifyFields.TkOutPrc", "test2");

		actions.setValue("VerifyFields.OtherPrc", "test3");

		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(4000);

		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", "Please enter a valid price.", true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify numeric validation for Eating/TO/Other Price fields",
					"Only Numeric values should be allowed", "Only numeric values are allowed", "PASS");
			// Reporter.log("Non-numeric Input Validations for Eating/TO/Other
			// Price fields - PASS");
			blnResult = true;
		} else {
			actions.reportCreateFAIL("Verify numeric validation for Eating/TO/Other Price fields",
					"Only Numeric values should be allowed", "Non-numeric values are allowed", "FAIL");
			// Reporter.log("Non-numeric Input Validations for Eating/TO/Other
			// Price fields - FAIL");
			blnResult = false;
		}
		// Clearing all the test values
		actions.clear("VerifyFields.EatingPrc");
		actions.clear("VerifyFields.EatingPrc");
		actions.clear("VerifyFields.TkOutPrc");
		actions.clear("VerifyFields.TkOutPrc");
		actions.clear("VerifyFields.OtherPrc");
		actions.clear("VerifyFields.OtherPrc");
		// Enter valid input in Eating/TO/Other Price fields

		actions.setValue("VerifyFields.EatingPrc", strEatingPrc);

		actions.setValue("VerifyFields.TkOutPrc", strTakeOutPrc);

		actions.setValue("VerifyFields.OtherPrc", strOtherPrice);

		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(2000);

		// ------------------------------------------------------------------------------------

		// Save & Apply Changes

		this.RFM_PRC_MUP_SaveAndApply(strMessageBeforeSave, strResultMessage);

		// Verifying correct prices are saved

		// Thread.sleep(1000);
		// actions.click("UpdtMultipleSet.ExpandImg");
		// Thread.sleep(1000);

		String Eating_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewEatingPrc")))
				.getAttribute("value");
		String TakeOut_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewTkOutPrc")))
				.getAttribute("value");
		String Other_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewOtherPrc")))
				.getAttribute("value");

		if ((Eating_Price.equals(strEatingPrc)) && (TakeOut_Price.equals(strTakeOutPrc))
				&& (Other_Price.equals(strOtherPrice))) {
			actions.reportCreatePASS("Verify Price Update",
					"All Prices/Eating/Take out/Other Prices should be saved correctly", "Updated Correctly", "PASS");
			// Reporter.log("All Prices/Eating/Take out/Other Prices saved
			// correctly - PASS");
		} else {
			actions.reportCreateFAIL("Verify Price Update",
					"All Prices/Eating/Take out/Other Prices should be saved correctly", "Not Updated Correctly",
					"FAIL");
			// Reporter.log("All Prices/Eating/Take out/Other Prices not saved
			// correctly - FAIL");
		}
		Thread.sleep(1000);

		return blnResult;
	}

	public boolean get_Field_Status(String strLocator) {
		Boolean Field_Status;
		Field_Status = driver.findElement(By.xpath(actions.getLocator(strLocator))).isEnabled();
		return Field_Status;
	}

	// ----------------------------------
	/*
	 * Feature Name : Mass Update Price Functionality : Mass Update Prices
	 * Scenario ID : PRC_0244 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_MUP_MassUpdtPrices(String strDate, String strNumOfDays, String strNewPrice, String strPriceSet,
			String app_date) throws InterruptedException {

		// Menu Item

		actions.click("UpdateSet.VwFullList");
		Thread.sleep(1000);
		actions.smartWait(120);
		mcd.select_row("UpdateSet.MenuItemTable", 0);
		actions.click("UpdateSet.AddRow");
		actions.click("UpdateSet.NextBtn");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		// Price Sets - Select a Price Set that is assigned to a restaurant
		actions.setValue("UpdatePrcSet.SearchBox", strPriceSet);
		Thread.sleep(500);
		actions.click("UpdatePrcSet.SearchButton");
		Thread.sleep(1000);
		actions.smartWait(120);
		mcd.select_row("UpdatePrcSet.PriceSetTable", 0);
		actions.click("UpdatePrcSet.AddRow");
		actions.click("UpdatePrcSet.NextBtn");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		// Updating Prices
		if (strDate.equals("Today")) {
			// Selecting Today's date (Today Button)
			Thread.sleep(1000);
			actions.click("UpdtMultipleSet.TodayBtn");
			Thread.sleep(2000);
			// Reporter.log("Today's date selected - PASS");

		} else if (strDate.equals("Future")) {

			// Calendar Icon check
			actions.verifyPresence("UpdtMultipleSet.CalenderIcon", true);
			actions.click("UpdtMultipleSet.CalenderIcon");
			mcd.Get_future_date(Integer.parseInt(strNumOfDays), "close", app_date);
			// mcd.Get_future_date(Integer.parseInt(strNumOfDays),
			// "UpdtMultipleSet.CalenderIcon", app_date);
			Thread.sleep(500);
			// Reporter.log("Future Date selected - PASS");
			actions.reportCreatePASS("Verify future date selection", "Date should be selected", "Date Selected",
					"PASS");

		} else {
			actions.reportCreateFAIL("Verify future date selection", "Date should be selected", "Date Selected",
					"FAIL");
			// Reporter.log("Date selection - FAIL");
		}

		// Mass Updating Prices

		actions.setValue("UpdtMultipleSet.AllPrc", strNewPrice);

		actions.click("UpdtMultipleSet.Apply");
		Thread.sleep(1000);
		actions.smartWait(120);

		// Verifying Date & Prices entered are updated correctly.
		String InputDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.StartDate")))
				.getAttribute("value");
		String AppliedDate = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewDate")))
				.getAttribute("value");

		String ALL_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewAllPrc")))
				.getAttribute("value");

		if (InputDate.equals(AppliedDate)) {
			// Reporter.log("Start Date entered is updated against for all
			// prices correctly - PASS");
			actions.reportCreatePASS("Verify Start Date displayed", "Start date should be correctly updated",
					"Start date correctly updated", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Start Date displayed", "Start date should be correctly updated",
					"Start date not correctly updated", "FAIL");
		}

		Thread.sleep(1000);
		try {
			driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.ExpandImg"))).click();
		} catch (Exception e4) {
			System.out.println("Already expanded");
		}
		Thread.sleep(1000);

		// Reading Eating/take out/other prices
		String Eating_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewEatingPrc")))
				.getAttribute("value");
		String TakeOut_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewTkOutPrc")))
				.getAttribute("value");
		String Other_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewOtherPrc")))
				.getAttribute("value");

		if ((ALL_Price.equals(strNewPrice)) && (Eating_Price.equals(strNewPrice)) && (TakeOut_Price.equals(strNewPrice))
				&& (Other_Price.equals(strNewPrice))) {
			// Reporter.log("All Prices/Eating/Take out/Other Prices updated
			// correctly - PASS");
			actions.reportCreatePASS("Verify Price fields",
					"All Prices/Eating/Take out/Other Prices should be updated correctly",
					"All Prices/Eating/Take out/Other Prices updated correctly", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Price fields",
					"All Prices/Eating/Take out/Other Prices should be updated correctly",
					"All Prices/Eating/Take out/Other Prices not updated correctly", "FAIL");
			// Reporter.log("All Prices/Eating/Take out/Other Prices not updated
			// correctly - FAIL");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Mass Update Price Functionality : Check Activate Menu Item
	 * Check Box Scenario ID : PRC_0244 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_MUP_ActivateMI(String strMessageBeforeSave, String strResultMessage, String strNewPrice)
			throws Exception {

		actions.waitForPageToLoad(120);

		if (actions.getValue("UpdtMultipleSet.ActivateMIChkBx").equals("false")) {
			// Reporter.log("Activate Menu Item Checkbox is unchecked by default
			// - PASS");
			actions.reportCreatePASS("Verify Activate Menu Item Checkbox",
					"Activate Menu Item Checkbox should be unchecked by default",
					"Activate Menu Item Checkbox is unchecked by default", "PASS");
			// Check Activate Menu Item CheckBox
			actions.click("UpdtMultipleSet.ActivateMIChkBx");
		} else {
			actions.reportCreateFAIL("Verify Activate Menu Item Checkbox",
					"Activate Menu Item Checkbox should be unchecked by default",
					"Activate Menu Item Checkbox is checked by default", "FAIL");
			// Reporter.log("Ativate Menu Item Checkbox is checked by default -
			// FAIL");
		}

		// Save & Apply Changes

		this.RFM_PRC_MUP_SaveAndApply(strMessageBeforeSave, strResultMessage);

		// Verifying correct prices are saved

		try {
			driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.ExpandImg"))).click();
			Thread.sleep(1000);
		} catch (Exception e4) {
			System.out.println("Already expanded");
		}

		String ALL_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewAllPrc")))
				.getAttribute("value");
		String Eating_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewEatingPrc")))
				.getAttribute("value");
		String TakeOut_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewTkOutPrc")))
				.getAttribute("value");
		String Other_Price = driver.findElement(By.xpath(actions.getLocator("UpdtMultipleSet.NewOtherPrc")))
				.getAttribute("value");

		if ((ALL_Price.equals(strNewPrice)) && (Eating_Price.equals(strNewPrice)) && (TakeOut_Price.equals(strNewPrice))
				&& (Other_Price.equals(strNewPrice))) {
			actions.reportCreatePASS("Verify Price fields",
					"All Prices/Eating/Take out/Other Prices should be saved correctly",
					"All Prices/Eating/Take out/Other Prices saved correctly", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Price fields",
					"All Prices/Eating/Take out/Other Prices should be saved correctly",
					"All Prices/Eating/Take out/Other Prices not saved correctly", "FAIL");
		}
		Thread.sleep(1000);
	}

	// ----------------------------------
	/*
	 * Feature Name : Mass Update Price Functionality : Get Price Set name
	 * assigned to a restaurant Scenario ID : PRC_0244 Author : Pooja Panse
	 */
	// -----------------------------------

	public String Get_PriceSet(String strNavigateTo) throws Exception {

		String Price_Set_Name = null;
		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateTo);
		actions.select_menu("RFMHome.Navigation", strNavigateTo);
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// To handle navigation issue :

//		driver.findElement(By.xpath("//*[@id='anchorTag2']/b")).click();
//		Thread.sleep(5000);
//		driver.findElement(By.xpath("//*[@id='pageNoId1']")).click();
//		Thread.sleep(1000);

		int rw_cnt = mcd.GetTableRowCount("Price.PriceSets");
		// System.out.println("Rows - "+rw_cnt);

		for (int i = 1; i < rw_cnt; i++) {
			try {
				if (driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/span/img"))
						.isDisplayed()) {
					Price_Set_Name = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a"))
							.getText();
					// System.out.println(Price_Set_Name);
					// Reporter.log("Selecting Price Set "+Price_Set_Name+" as
					// it assigned to restaurant. - PASS");
					break;
				}
			} catch (Exception e) {
				System.out.println("This price set is not attached to any restaurant");
			}

		}
		return Price_Set_Name;
	}

	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Verify Search & Add/Remove Menu
	 * Items Scenario ID : PRC_0170 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_SearchAddRemove_MenuItem(String strPriceSet, String strNewPrice, String strMessage,
			String strAddRemoveMsg) throws Exception {

		// Variable Declaration
		int iTemp = 0;
		String Searchd_PrcSet = null;
		String Search_Str = "";
		String ItemName;
		String[] MI_Arr;
		String[] Add_Arr = null;
		String Item_Name;
		Boolean VerifyPopUpMsg;
		Boolean StrCheck = false;
		String OutputMsg;

		// Enter Price Set name to search

		actions.setValue("PriceSet.SearchBox", strPriceSet);
		actions.keyboardEnter("PriceSet.SearchBtn");
		Thread.sleep(1000);
		actions.smartWait(180);
		// Get row count of number of price sets fetched
		int rw_cnt = mcd.GetTableRowCount("PriceSet.Table");

		List<WebElement> PrcSet_List = driver.findElements(By.xpath("//*[@id='currentLink']"));

		// Click on desired Price set
		for (int i = 0; i <= rw_cnt; i++) {
			try {

				String temp_str = PrcSet_List.get(i).getText();
				if (temp_str.equals(strPriceSet)) {
					PrcSet_List.get(i).sendKeys(Keys.ENTER);
					// PrcSet_List.get(i).click();
					iTemp = 0;
					break;
				} else {
					iTemp = iTemp + 1;
				}
			} catch (Exception e) {
				// System.out.println("This price set is not attached to any
				// restaurant");
			}
		}

		Thread.sleep(1000);
		actions.waitForPageToLoad(120);
		if (iTemp == 0) {
			actions.reportCreatePASS("Verify Price Set selection", "Price Set should be selected",
					strPriceSet + " fetched and clicked", "PASS");
			// Reporter.log(strPriceSet+" fetched and clicked - PASS");
		} else {
			actions.reportCreateFAIL("Verify Price Set selection", "Price Set should be selected",
					strPriceSet + " not found", "FAIL");
			// Reporter.log(strPriceSet+" not found - FAIL");
		}

		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		// Verify Page navigated to Manager Price Set window
		/** Verify Page Header */
	//	System.out.println("> Verify Page Heading");

		//String New_Heading = "Manage Price Set : " + strPriceSet + "\n" + "[ Base Price ]";
		// mcd.VerifyPageHeading(New_Heading, "SubHeading");
		//mcd.VerifyPageTitle(New_Heading);

		// Get count of number of Menu Items in selected price set
		int MIrw_cnt = mcd.GetTableRowCount("ManagePS.MITable");

		Thread.sleep(1000);

		// Get all the names of menu items present
		List<WebElement> MI_lists = driver
				.findElements(By.xpath("//table[@class = \"SmallHeading\"]/tbody/tr[1]/td[@class = \"padLeft5\"][1]"));

		// Get few menu items words to search. Create the search string
		if (MI_lists.size() == 1) {
			ItemName = MI_lists.get(0).getText();
			MI_Arr = ItemName.split("-");
			Item_Name = MI_Arr[1].trim();
			Search_Str = Item_Name.split(" ")[0];

		} else if (MI_lists.size() > 1) {
			for (int k = 0; k < MI_lists.size(); k++) {
				ItemName = MI_lists.get(k).getText();
				MI_Arr = ItemName.split("-");
				Item_Name = MI_Arr[1].trim();
				if (k == 5) {
					System.out.println("Search String created using 3 menu items");
					break;
				}
				Search_Str = Search_Str + Item_Name.split(" ")[0] + "+";
				System.out.println(Search_Str);
			}

		}

		Search_Str = Search_Str.substring(0, (Search_Str.length() - 1));

		actions.setValue("ManagePS.SearchBox", Search_Str);
		Thread.sleep(500);
		actions.keyboardEnter("ManagePS.SearchBtn");
		Thread.sleep(1000);
		actions.smartWait(180);
		// Verify Search Happened successfully
		// Get all the names of menu items present

		List<WebElement> Srch_lists = driver
				.findElements(By.xpath("//table[@class = 'SmallHeading']/tbody/tr[1]/td[@class = 'padLeft5'][1]"));

		String[] NewArr = Search_Str.split("\\W");
		for (int m = 0; m < Srch_lists.size(); m++) {
			ItemName = Srch_lists.get(m).getText();
			for (int n = 0; n < NewArr.length; n++) {
				System.out.println(NewArr[n]);
				System.out.println(ItemName);
				if ((ItemName.toLowerCase()).contains(NewArr[n].toLowerCase())) {
					StrCheck = true;
					break;
				} else {
					StrCheck = false;
				}
			}
		}

		if (StrCheck) {
			System.out.println("Search - PASS");
		} else {
			System.out.println("Search - FAIL");
		}

		// Get all elements of delete icon.
		List<WebElement> icons = driver.findElements(By.xpath(actions.getLocator("ManagePS.DeleteIcons")));

		// Click on delete icon against menu item 1
		icons.get(0).click();

		// Get all the names of menu items present
		List<WebElement> M_lists = driver
				.findElements(By.xpath("//table[@class = \"SmallHeading\"]/tbody/tr[1]/td[@class = \"padLeft5\"][1]"));

		// Get the name of menu item that is removed above
		String Modified_ItemName = M_lists.get(0).getText();
		String[] strArr = Modified_ItemName.split("-");
		String Item_Number = strArr[0].trim();
		String Name = strArr[1].trim();
		Modified_ItemName = Item_Number + "-" + Name;

		// Apply Changes
		actions.click("ManagePS.ApplyBtn");
		Thread.sleep(1000);
		actions.smartWait(120);

		// Verify warning message
		String New_Msg = "The below listed menu item(s) will be removed from the price set." + "\n" + "\n"
				+ Modified_ItemName;
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", New_Msg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify warning message for deletion", "Correct warning should be displayed",
					"Correct warning displayed", "PASS");
			// Reporter.log("Warning message for Delete Item occured - PASS");
		} else {
			actions.reportCreateFAIL("Verify warning message for deletion", "Correct warning should be displayed",
					"Correct warning not displayed", "FAIL");
			// Reporter.log("No warning message before deletion of item occured
			// - FAIL");
		}

		Thread.sleep(1000);
		actions.smartWait(120);

		// Verify Success message
		OutputMsg = driver.findElement(By.xpath(actions.getLocator("ManagePS.ResultMsg"))).getText();
		if (OutputMsg.equals(strMessage)) {
			actions.reportCreatePASS("Verify Menu Item deletion", "Menu Item should be deleted successfully",
					"Menu Item deleted successfully", "PASS");
			// Reporter.log("Delete menu item done successfully - PASS");
		} else {
			actions.reportCreatePASS("Verify Menu Item deletion", "Menu Item should be deleted successfully",
					"Menu Item not deleted successfully", "FAIL");
			// Reporter.log("Delete menu item not done successfully - FAIL");
		}

		Thread.sleep(2000);

		// Add/Remove Menu Item
		actions.click("ManagePS.AddRemoveMIBtn");
		Thread.sleep(1000);

		// Switch Window to //"Price Sets : Common Menu Item Selector"
		mcd.SwitchToWindow("Price Sets : Common Menu Item Selector");
//		String CurrHandle = driver.getWindowHandle();
//		actions.windowSwitch(CurrHandle, "Price Sets : Common Menu Item Selector");
//		Thread.sleep(5000);
//		String NewHandle = driver.getWindowHandle();

		// ADD

		// Click on View Full List

		actions.keyboardEnter("CommonSelector.ViewFullBtn");
		Thread.sleep(1000);
		actions.smartWait(180);
		// Select Available from Availability drop down
		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
		Thread.sleep(1000);
		actions.smartWait(180);

		// Get Row Count
		// int Item_Counts = mcd.GetTableRowCount("CommonSelector.Table");

		List<WebElement> Add_Chkbox = driver
				.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
		int Item_Counts = Add_Chkbox.size();
		List<String> MnuItem_Names = new ArrayList<String>();

		// Check items and add accordingly

		int i_temp = 0;
		for (int n = 0; n <= Item_Counts; n++) {
			// Check whether enabled for Add or not
			if ((Add_Chkbox.get(n).isEnabled())) {
				// Check box enabled - Add Item
				Add_Chkbox.get(n).sendKeys(Keys.SPACE);

				// Get Item Name
				String p = Integer.toString(n + 1);
				String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
				MnuItem_Names.add(e);

				i_temp++;
			} else {
				System.out.println("This MI is already added");
			}

			if (i_temp == 2) {
				System.out.println("Selected 3 items for Add MI");
				break;
			}
			Thread.sleep(1000);
		}

		actions.keyboardEnter("CommonSelector.Save");

		Thread.sleep(1000);


		// Switch back to Main Window- Title "Price Sets"
		mcd.SwitchToWindow("Price Sets");
		
//		actions.windowSwitch(NewHandle, "Price Sets");
//		Thread.sleep(5000);

		// Menu Items have been Added/Removed successfully from the Price Set.

		OutputMsg = driver.findElement(By.xpath(actions.getLocator("ManagePS.AddRemoveMsg"))).getText();
		if (OutputMsg.equals(strAddRemoveMsg)) {
			actions.reportCreatePASS("Verify addition of MI to Price set", "Menu Item should be added",
					"Menu Item added", "PASS");
			// Reporter.log("Add Menu Item to price set - PASS");
		} else {
			actions.reportCreateFAIL("Verify addition of MI to Price set", "Menu Item should be added",
					"Menu Item not added", "FAIL");
			// Reporter.log("Add Menu Item to price set - FAIL");
		}

		// Check only added menu items are displayed
		// Get the list of items displayed
		List<WebElement> Added_Items = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));
		// System.out.println(Added_Items.size());
		int AddItem_check = 0;

		for (int k = 0; k < Added_Items.size(); k++) {
			String Added_ItemName = Added_Items.get(k).getText().split("-")[1].trim();

			// Verify that the added items are same as displayed items
			if (Added_ItemName.equals(MnuItem_Names.get(k))) {
				AddItem_check++;
			} else {
				System.out.println("Check " + Added_ItemName);
				System.out.println("Check " + MnuItem_Names.get(k));
			}
		}

		if (AddItem_check == 3) {
			// Reporter.log("Only newly added menu items are displayed as
			// expected - PASS");
			actions.reportCreatePASS("Verify menu items displayed", "Only newly added items should be displayed",
					"Only newly added items are displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify menu items displayed", "Only newly added items should be displayed",
					"Items are incorrectly displayed", "FAIL");
			// Reporter.log("More menu items than newly added menu items are
			// displayed - FAIL");
		}
		
		actions.waitForPageToLoad(180);
		// REMOVE

		// Add/Remove Menu Item
		actions.click("ManagePS.AddRemoveMIBtn");
		Thread.sleep(1000);

		// Switch Window to //"Price Sets : Common Menu Item Selector"
//		CurrHandle = driver.getWindowHandle();
//		actions.windowSwitch(CurrHandle, "Price Sets : Common Menu Item Selector");
//		Thread.sleep(5000);
//		NewHandle = driver.getWindowHandle();

		mcd.SwitchToWindow("Price Sets : Common Menu Item Selector");
		
		// Select Assigned from Availability drop down
		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Assigned");
		Thread.sleep(1000);
		actions.smartWait(180);

		// Get elements of Remove chkbox
		List<WebElement> Remove_Chkbox = driver
				.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'removeMenuItem')]"));
		Thread.sleep(500);

		// Remove Check Box :
		Remove_Chkbox.get(0).sendKeys(Keys.SPACE);
		Thread.sleep(500);

		actions.keyboardEnter("CommonSelector.Save");
		Thread.sleep(3000);

		// One or more restaurant might lose the price information on removing
		// the menu item from this set. Do you want to continue?
		New_Msg = "One or more restaurant might lose the price information on removing the menu item from this set. Do you want to continue?";
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", New_Msg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify REMOVE warning message", "Correct warning should be displayed",
					"Correct message displayed", "PASS");

			// Reporter.log("Warning message for REMOVE Item occured - PASS");
		} else {
			actions.reportCreateFAIL("Verify REMOVE warning message", "Correct warning should be displayed",
					"Correct message not displayed", "FAIL");
			// Reporter.log("No warning message before REMOVE occured - FAIL");
		}

		Thread.sleep(2000);
		
		// Switch back to Main Window- Title "Price Sets"
		mcd.SwitchToWindow("Price Sets");
		//		actions.windowSwitch(NewHandle, "Price Sets");
//		Thread.sleep(5000);

		// Menu Items have been Added/Removed successfully from the Price Set.

		OutputMsg = driver.findElement(By.xpath(actions.getLocator("ManagePS.AddRemoveMsg"))).getText();
		if (OutputMsg.equals(strAddRemoveMsg)) {
			// Reporter.log("Remove Menu Item from price set - PASS");
			actions.reportCreatePASS("Verify menu item removal", "Menu item should be removed", "Menu Item removed",
					"PASS");
		} else {
			// Reporter.log("Remove Menu Item from price set - FAIL");
			actions.reportCreateFAIL("Verify menu item removal", "Menu item should be removed", "Menu Item not removed",
					"FAIL");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Verify Activate Selected Menu
	 * Items & Activate All Menu Items cannot be checked together Scenario ID :
	 * PRC_0169 Author : Pooja Panse
	 */
	// -----------------------------------

	public Boolean RFM_PRC_VerifyActivateCheckBox() throws InterruptedException {

		Boolean btnResult = false;
		String Price_Set_Name;
		int rw_cnt = mcd.GetTableRowCount("Price.PriceSets");
		// System.out.println("Rows - "+rw_cnt);

		for (int i = 1; i < rw_cnt; i++) {
			try {
				Boolean temp = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/span/img"))
						.isDisplayed();
				if (temp) {
					Price_Set_Name = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a"))
							.getText();
					// Click on Price Set link
					driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a")).click();
					Thread.sleep(5000);
					// Reporter.log("Selecting a Price Set "+Price_Set_Name+"
					// assigned to restaurant. - PASS");
					break;
				}
			} catch (Exception e) {
				System.out.println("This price set is not attached to any restaurant");
			}
		}

		actions.setValue("ManagePS.SearchBox", "B");
		Thread.sleep(500);
		actions.keyboardEnter("ManagePS.SearchBtn");
		Thread.sleep(3000);

		WebElement CheckBox1 = driver.findElement(By.xpath(actions.getLocator("ManagePS.ActivateChkBox")));
		WebElement CheckBox2 = driver.findElement(By.xpath(actions.getLocator("ManagePS.ActivateSelectChkBox")));

		// Both Unchecked
		System.out.println(CheckBox1.isSelected());
		System.out.println(CheckBox2.isSelected());
		if (!CheckBox1.isSelected() && !CheckBox2.isSelected()) {
			// Reporter.log("Activate All Menu Items AND Activate Selected Menu
			// Items both unchecked by default - PASS");
			actions.reportCreatePASS("Verify Activate/Selected Activate",
					"Activate All Menu Items AND Activate Selected Menu Items both should be unchecked by default",
					"Activate All Menu Items AND Activate Selected Menu Items both unchecked by default", "PASS");
			btnResult = true;
		} else {
			// Reporter.log("Activate All Menu Items AND Activate Selected Menu
			// Items are not unchecked by default - FAIL");
			actions.reportCreateFAIL("Verify Activate/Selected Activate",
					"Activate All Menu Items AND Activate Selected Menu Items both should be unchecked by default",
					"Activate All Menu Items AND Activate Selected Menu Items both checked by default", "FAIL");
			btnResult = false;
		}

		// Check CheckBox 1

		CheckBox1.sendKeys(Keys.SPACE);
		if (CheckBox1.isSelected()) {
			actions.reportCreatePASS("Verify Activate All Items", "Activate All Menu Items should be checked",
					"Activate All Menu Items checked", "PASS");
			// Reporter.log("Activate All Menu Items checked - PASS");
			btnResult = true;
		} else {
			actions.reportCreateFAIL("Verify Activate All Items", "Activate All Menu Items should be checked",
					"Activate All Menu Items not getting checked", "FAIL");
			// Reporter.log("Activate All Menu Items not checked - FAIL");
			btnResult = false;
		}

		// Check CheckBox 2

		CheckBox2.sendKeys(Keys.SPACE);
		if (CheckBox2.isSelected() && !CheckBox1.isSelected()) {
			actions.reportCreatePASS("Verify checkboxes",
					"Activate Selected Menu Items - Checked ; Activate All Menu Items unchecked",
					"Activate Selected Menu Items - Checked ; Activate All Menu Items unchecked", "PASS");
			// Reporter.log("Activate Selected Menu Items - Checked ; Activate
			// All Menu Items unchecked - PASS");
			btnResult = true;
		} else {
			actions.reportCreateFAIL("Verify checkboxes",
					"Activate Selected Menu Items - Checked ; Activate All Menu Items unchecked",
					"Activate Selected Menu Items/Activate All Menu Items not correctly checked/unchecked", "FAIL");
			// Reporter.log("Activate Selected Menu Items - Checked ; Activate
			// All Menu Items unchecked - FAIL");
			btnResult = false;
		}

		// Check CheckBox 1

		CheckBox1.sendKeys(Keys.SPACE);
		if (CheckBox1.isSelected() && !CheckBox2.isSelected()) {
			actions.reportCreatePASS("Verify checkboxes",
					"Activate Selected Menu Items - UnChecked ; Activate All Menu Items Checked",
					"Activate Selected Menu Items - UnChecked ; Activate All Menu Items Checked", "PASS");
			// Reporter.log("Activate Selected Menu Items - UnChecked ; Activate
			// All Menu Items Checked - PASS");
			btnResult = true;
		} else {
			actions.reportCreateFAIL("Verify checkboxes",
					"Activate Selected Menu Items - UnChecked ; Activate All Menu Items Checked",
					"Activate Selected Menu Items/Activate All Menu Items not correctly checked/unchecked", "FAIL");
			// Reporter.log("Activate Selected Menu Items - UnChecked ; Activate
			// All Menu Items Checked - FAIL");
			btnResult = false;
		}

		return btnResult;

	}

	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Verify that only newly added
	 * menu item is displayed, when new Menu Items are added to Base Price Set
	 * (Future Settings) Scenario ID : PRC_0157 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_AddMIBasePrcSet_FutureSetting(String strAddRemoveMsg) throws InterruptedException {

		// //To handle navigation issue :
		//
		// driver.findElement(By.xpath("//*[@id='anchorTag2']/b")).click();
		// Thread.sleep(5000);
		// driver.findElement(By.xpath("//*[@id='pageNoId1']")).click();
		// Thread.sleep(1000);

		String Future_Date = null;
		String Price_Set_Name;

		// Get the row count of the price set list displayed
		int rw_cnt = mcd.GetTableRowCount("Price.PriceSets");
		// System.out.println("Rows - "+rw_cnt);

		// Check for assigned price set and select
		for (int i = 1; i < rw_cnt; i++) {
			try {
				Boolean temp = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/span/img"))
						.isDisplayed();
				if (temp) {
					Price_Set_Name = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a"))
							.getText();

					// Click on Price Set link
					driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a")).click();
					Thread.sleep(5000);
					// Reporter.log("Selecting a Price Set "+Price_Set_Name+"
					// assigned to restaurant. - PASS");
					break;
				}
			} catch (Exception e) {
				System.out.println("This price set is not attached to any restaurant");
			}
		}

		// Select future date link in the future price changes part
		try {

			WebElement FDate = driver.findElement(By.xpath("//*[@id='futureEffectiveDate']/option[2]"));
			Future_Date = FDate.getText();
			FDate.click();
			actions.smartWait(180);
			Thread.sleep(5000);
			System.out.println("Clicked on future date settings - PASS");

		} catch (Exception e) {
			System.out.println("Date selection failed");
		}

		actions.waitForPageToLoad(10000);

		// Verify that new tab displays the correct date
		String Date_displayed = driver.findElement(By.xpath(actions.getLocator("ManagePS.DateSelected"))).getText();

		if (Date_displayed.equals(Future_Date)) {
			actions.reportCreatePASS("Verify date in future tab", "Correct future date should be displayed",
					"Correct future date displayed", "PASS");
			// Reporter.log("Correct future date is displayed on future tab -
			// PASS");
		} else {
			actions.reportCreateFAIL("Verify date in future tab", "Correct future date should be displayed",
					"Correct future date not displayed", "FAIL");
			// Reporter.log("Incorrect future date is displayed on future tab -
			// FAIL");
		}

		// Add Menu Item to the price set in future date
		// Click on Add MI
		actions.click("ManagePS.FutureAddMI");
		Thread.sleep(5000);

		// Current window handle
		String MainWindow = driver.getWindowHandle();

		// Wait for New Window - Title : Price Sets : Common Menu Item Selector
		// actions.WaitForWindowToBe(2, 5000);

		// Switch to new window
		actions.windowSwitch(MainWindow, "Price Sets : Common Menu Item Selector");
		Thread.sleep(5000);
		// System.out.println("New Title : "+driver.getTitle());
		String NewHandle = driver.getWindowHandle();

		// Click View Full list
		actions.javaScriptClick("CommonSelector.ViewFullBtn");
		Thread.sleep(5000);

		// Select Available from Availability drop down
		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
		Thread.sleep(5000);

		// Get all the Add check box elements
		List<WebElement> Add_Chkbox = driver
				.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
		int Item_Counts = Add_Chkbox.size();

		// Check items and add accordingly
		int i_temp = 0;
		String TXpath = null;
		List<String> MnuItem_Names = new ArrayList<String>();

		for (int n = 0; n < Item_Counts; n++) {

			// Check whether enabled for Add or not
			if ((Add_Chkbox.get(n).isEnabled())) {

				// Check box enabled - Add Item
				Add_Chkbox.get(n).sendKeys(Keys.SPACE);

				// Get Item Name
				String p = Integer.toString(n + 1);
				String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
				MnuItem_Names.add(e);

				// System.out.println(MnuItem_Names.get(n));
				i_temp++;

			} else {
				System.out.println("This MI is already added");
			}

			if (i_temp == 3) {
				// Reporter.log("Selected 3 items for Addition to the price set
				// - PASS");
				break;
			}
			Thread.sleep(1000);
		}

		// Save the updates
		actions.keyboardEnter("CommonSelector.Save");
		Thread.sleep(3000);

		Thread.sleep(10000);

		// Switch back to Main Window- Title "Price Sets"
		actions.windowSwitch(NewHandle, "Price Sets");
		Thread.sleep(5000);

		// Menu Items have been Added/Removed successfully from the Price Set.
		String OutputMsg = driver.findElement(By.xpath(actions.getLocator("ManagePS.AddRemoveMsg"))).getText();
		if (OutputMsg.equals(strAddRemoveMsg)) {
			actions.reportCreatePASS("Verify Menu item addition", "Menu Items should be added", "Menu Items added",
					"PASS");
			// Reporter.log("Add Menu Item to price set - PASS");
		} else {
			actions.reportCreateFAIL("Verify Menu item addition", "Menu Items should be added", "Menu Items not added",
					"FAIL");
			// Reporter.log("Add Menu Item to price set - FAIL");
		}

		Thread.sleep(5000);

		// Get the list of items displayed
		List<WebElement> Added_Items = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));
		// System.out.println(Added_Items.size());
		int AddItem_check = 0;

		for (int k = 0; k < Added_Items.size(); k++) {
			String Added_ItemName = Added_Items.get(k).getText().split("-")[1].trim();

			// Verify that the added items are same as displayed items
			if (Added_ItemName.equals(MnuItem_Names.get(k))) {
				AddItem_check++;
			} else {
				System.out.println("Check " + Added_ItemName);
				System.out.println("Check " + MnuItem_Names.get(k));
			}
		}

		if (AddItem_check == 3) {
			actions.reportCreatePASS("Verify menu items displayed", "Only newly added items should be displayed",
					"Only newly added items are displayed", "PASS");
			// Reporter.log("Only newly added menu items are displayed as
			// expected - PASS");
		} else {
			actions.reportCreateFAIL("Verify menu items displayed", "Only newly added items should be displayed",
					"Items are incorrectly displayed", "FAIL");
			// Reporter.log("More menu items than newly added menu items are
			// displayed - FAIL");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Create New Promotional/Base
	 * Price Set by copying settings from an existing price set Decimal
	 * validations on the All Price/Eating/Take-out/Other prices - checked
	 * Scenario ID : PRC_0107/ 108 Author : Pooja Panse
	 */
	// -----------------------------------

	public String RFM_PRC_Create_PromotionalBase_PrcSet(String strNewPrcSet, String strPrcSet_copy,
			String strPrcSetType, String strResMessage, String strTestPrc, String strError_Eating, String strError_Msg2,
			String strFuturePrc, String strNodeNum, String strNavigateTo) throws Exception {

		actions.WaitForElementPresent("PriceSet.NewBtn", 180);
		/** Get application time */
		WebElement apptime = mcd.getdate();
		String strApplicationDate = apptime.getText();

		int iTemp = 0;

		actions.click("PriceSet.NewBtn");
		Thread.sleep(2000);

		// Switch to New Price Sets
		mcd.SwitchToWindow("New Price Sets");

		// Generate unique strNewPrcSet for Base/Promotion Price Set

		switch (strPrcSetType) {
		case "Base":
			// Base Price
			strNewPrcSet = mcd.fn_GetRndName("Base");
			break;
		case "Promotion":
			strNewPrcSet = mcd.fn_GetRndName("Prom");
			break;
		default:
			// System.out.println("Please enter correct Price Set Type
			// (Base/Promotion)");
			actions.reportCreateFAIL("Verfiy data", "Enter correct price set name", "Incorrect data", "FAIL");
			break;
		}

		// Enter new price set name :
		actions.setValue("NewPriceSet.Name", strNewPrcSet);
		Thread.sleep(500);

		actions.click("NewPriceSet.SelectNode");
		Thread.sleep(1000);
		
		// Switch to Select Node Window - Title - Select Node
		mcd.waitAndSwitch("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(500);
//		actions.setValue("SelectNode.SearchBox", strNodeNum);
		driver.findElement(By.xpath(actions.getLocator("SelectNode.SearchBox"))).sendKeys(strNodeNum);
		Thread.sleep(500);

		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		Boolean Node_chk = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);
		Thread.sleep(2000);

		mcd.SwitchToWindow("New Price Sets");

		switch (strPrcSetType) {
		case "Base":

			// Base Price
			actions.keyboardEnter("NewPriceSet.BaseRadioBtn");
			Thread.sleep(1000);

			break;
		case "Promotion":

			// Promotion Price
			// actions.keyboardEnter("NewPriceSet.PromRadioBtn");
			actions.javaScriptClick("NewPriceSet.PromRadioBtn");
			Thread.sleep(1000);

			driver.findElement(By.xpath(actions.getLocator("NewPriceSet.StartDate"))).click();
			// mcd.select_date("25", "current", "NewPriceSet.StartDate");
			mcd.sel_current_date("NewPriceSet.StartDate", strApplicationDate);

			// driver.findElement(By.xpath("//*[@id='endDateAnchor'][@src='/rfm2OnlineApp/images/cal.jpg'][@name='endDateAnchor']")).click();
			driver.findElement(By.xpath(actions.getLocator("NewPriceSet.EndDate"))).click();
			// mcd.select_date("30", "current", "NewPriceSet.EndDate");
			mcd.Get_future_date(3, "close", strApplicationDate);

			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		// actions.click("NewPriceSet.CopyYesRadioBtn");
		actions.javaScriptClick("NewPriceSet.CopyYesRadioBtn");

		Thread.sleep(1000);

		// Select Price Set to copy
		actions.keyboardEnter("NewPriceSet.SelectPrcSet");

		Thread.sleep(1000);

		// Switch to price sets
		mcd.waitAndSwitch("Price Sets");

		actions.keyboardEnter("PriceSetList.ViewFullList");
		Thread.sleep(1000);
		actions.smartWait(120);

		try {
			// Select the first price set
			mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a").click();
			Thread.sleep(1000);

			/// Switch back
			mcd.SwitchToWindow("New Price Sets");
		} catch (Exception err) {
			actions.reportCreateFAIL("No Price Sets present to copy", "No Price Sets present to copy",
					"No Price Sets present to copy", "FAIL");
		}

		// Click Next
		actions.keyboardEnter("NewPriceSet.Next");
		
		//Switch to updated window -
		//driver.switchTo().window("");
		
		
		
		//mcd.waitAndSwitch("@Price Sets");
		
		
		//Based on instance >> Switch to Manage Price set window. Applicable to US
		
//		if(mcd.GetGlobalData("Instance").trim().toLowerCase().contains("us")){
		try{
			
			mcd.SwitchToWindow("Manage Price Set");
			actions.keyboardEnter("RFM.Okbtn");
			
			mcd.SwitchToWindow("@Price Sets");
		}
//		}else{
			catch(Exception err){
//				try{
//					mcd.SwitchToWindow("Manage Price Set");
//				}catch(Exception err){
					System.out.println("No window - Manage Price Set");
			
			}
//		}
		
		actions.WaitForElementPresent("ManagePS.QuickToolApply", 180);

		//Verify result message
		actions.verifyTextPresence(strResMessage, true);

		//Verify Screen header
		String CreatedPS_msg = null;
		CreatedPS_msg = "Manage Price Set : " + strNewPrcSet;
		actions.verifyTextPresence(CreatedPS_msg, true);

		
		// Validations - Common to Base / Promotional

		//For all price field
		driver.findElement(By.xpath(actions.getLocator("ManagePS.AllPrice"))).clear();
		actions.clear("ManagePS.AllPrice");
		Thread.sleep(500);
		actions.setValue("ManagePS.AllPrice", strTestPrc);
		Thread.sleep(500);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(2000);

		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify price fields",
					"All Prices fields should accept values upto 2 decimal places only.",
					"All Prices fields accepts values upto 2 decimal places only.", "PASS");
		} else {
			actions.reportCreatePASS("Verify price fields",
					"All Prices fields should accept values upto 2 decimal places only.",
					"All Prices fields accepts values more than 2 decimal places.", "FAIL");
		}

		//For Eating/TO/Other price field
		actions.click("ManagePS.RestRadio");
		Thread.sleep(1000);

		actions.clear("ManagePS.EatPrice");
		actions.setValue("ManagePS.EatPrice", strTestPrc);

		actions.clear("ManagePS.TkOutPrice");
		actions.setValue("ManagePS.TkOutPrice", strTestPrc);

		actions.clear("ManagePS.OtherPrice");
		actions.setValue("ManagePS.OtherPrice", strTestPrc);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(3000);

		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify price fields",
					"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
					"All Eating/TO/Other fields accepts values upto 2 decimal places only.", "PASS");
		} else {
			actions.reportCreatePASS("Verify price fields",
					"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
					"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
		}
		
		
		//Handled the situation where in based on the price value >> the price fields can be displayed as expanded or collapsed.
		//So the validations are done accordingly
		try{
			WebElement eleItemExpand = driver.findElement(By.xpath(actions.getLocator("PriceSet.FrstMIExpandIcon")));
			System.out.println("Whether expand/collapse = "+ eleItemExpand.getAttribute("style").trim());
			//if style = "" , Price fields are expanded
			if(!(eleItemExpand.getAttribute("style").trim().equalsIgnoreCase(""))){
				actions.smartWait(180);
 
				actions.clear("ManagePS.ItemEatPrice");
				actions.setValue("ManagePS.ItemEatPrice", strTestPrc);

				actions.clear("ManagePS.ItemTOPrice");
				actions.setValue("ManagePS.ItemTOPrice", strTestPrc);

				actions.clear("ManagePS.ItemOtherPrice");
				actions.setValue("ManagePS.ItemOtherPrice", strTestPrc);
				
				actions.click("ManagePS.ALLApply");
				Thread.sleep(2000);
				
				VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
				if (VerifyPopUpMsg) {
					actions.reportCreatePASS("Verify price fields",
							"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
							"All Eating/TO/Other fields accepts values upto 2 decimal places only.", "PASS");
				} else {
					actions.reportCreatePASS("Verify price fields",
							"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
							"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
				}

			}else{
				//if style = "display:none" , Price fields are collapsed	
			actions.smartWait(180);
			actions.clear("ManagePS.ItemAllPriceTextBox");
			actions.clear("ManagePS.ItemAllPriceTextBox");
			actions.setValue("ManagePS.ItemAllPriceTextBox", strTestPrc);
			
			
			actions.click("ManagePS.ALLApply");
			Thread.sleep(2000);
			
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify price fields",
						"All Prices fields should accept values upto 2 decimal places only.",
						"All Prices fields accepts values upto 2 decimal places only.", "PASS");
			} else {
				actions.reportCreatePASS("Verify price fields",
						"All Prices fields should accept values upto 2 decimal places only.",
						"All Prices fields accepts values more than 2 decimal places.", "FAIL");
			}
			}
		}catch(Exception err){
			//if style = "display:none" , Price fields are collapsed
			actions.smartWait(180);

			actions.clear("ManagePS.ItemEatPrice");
			actions.setValue("ManagePS.ItemEatPrice", strTestPrc);

			actions.clear("ManagePS.ItemTOPrice");
			actions.setValue("ManagePS.ItemTOPrice", strTestPrc);

			actions.clear("ManagePS.ItemOtherPrice");
			actions.setValue("ManagePS.ItemOtherPrice", strTestPrc);
			
			actions.click("ManagePS.ALLApply");
			Thread.sleep(2000);
			
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify price fields",
						"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
						"All Eating/TO/Other fields accepts values upto 2 decimal places only.", "PASS");
			} else {
				actions.reportCreatePASS("Verify price fields",
						"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
						"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
			}

		}
		actions.smartWait(10);
		


		// Click on cancel to close the page
		actions.click("NewPriceSet.Cancel");
		Thread.sleep(3000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
				"Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.CANCEL_BUTTON);
		if (VerifyPopUpMsg) {
			// Reporter.log("Unsaved record message PASS");
			actions.reportCreatePASS("Verify Unsaved warning", "Unsaved warning should be displayed",
					"Unsaved warning is displayed", "PASS");
		} else {
			// Reporter.log("Unsaved record message FAILED");
			actions.reportCreateFAIL("Verify Unsaved warning", "Unsaved warning should be displayed",
					"Unsaved warning is not displayed", "FAIL");
		}

		//enter correct price and save
		actions.smartWait(180);
		actions.WaitForElementPresent("ManagePS.EatPrice", 180);
		actions.clear("ManagePS.EatPrice");
		actions.setValue("ManagePS.EatPrice", Integer.toString(Integer.parseInt(strFuturePrc)));

		actions.clear("ManagePS.TkOutPrice");
		actions.setValue("ManagePS.TkOutPrice", Integer.toString(Integer.parseInt(strFuturePrc)));

		actions.clear("ManagePS.OtherPrice");
		actions.setValue("ManagePS.OtherPrice", Integer.toString(Integer.parseInt(strFuturePrc)));
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(3000);
		actions.smartWait(120);
		actions.click("ManagePS.ALLApply");
		Thread.sleep(3000);
		actions.smartWait(120);
		
		// Click on cancel to close the page
		actions.click("NewPriceSet.Cancel");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);
		// Creating Future Settings for newly created price set		
		mcd.SwitchToWindow("#Title");
		actions.smartWait(180);

		// Enter Price Set name to search
		actions.setValue("PriceSet.SearchBox", strNewPrcSet);
		Thread.sleep(500);
		actions.keyboardEnter("PriceSet.SearchBtn");
		Thread.sleep(1000);
		actions.smartWait(120);

		// Click on fetched PS
		mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a").click();
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);
		//driver.switchTo().window("");	
		mcd.SwitchToWindow("#Title");

		if (strPrcSetType.equals("Base")) {
			mcd.SelectDate_OpenCalender("10", "next");
			Thread.sleep(1000);
			actions.smartWait(120);
		} else {
			int d = 10;

			mcd.SelectDate_OpenCalender(Integer.toString(d), "next");
			Thread.sleep(1000);
			actions.smartWait(120);
			mcd.SelectDate_OpenCalender(Integer.toString(d + 2), "current");
			Thread.sleep(1000);
			actions.smartWait(120);
		}

		//Enter future price setting
		actions.clear("ManagePS.AllPrice");
		Thread.sleep(500);
		actions.setValue("ManagePS.AllPrice", strFuturePrc);
		Thread.sleep(500);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(2000);

		actions.click("FutureSettings.Apply");
		
		try{
			String Alertvalue=driver.switchTo().alert().getText();
				if(Alertvalue.contains("You have specified incomplete tax information")){
					driver.switchTo().alert().accept();
				}
			  }catch(Exception e) {	                     
				System.out.println("Alert is not displaying");
		}
		Thread.sleep(1000);
		actions.smartWait(120);

		//Verify Success message
		actions.verifyTextPresence("Your changes have been saved.", false);
		actions.reportCreatePASS("Verify Future Settings",
				"Future settings for new price set should be done successfully",
				"Future settings for new price set done successfully", "PASS");

		return strNewPrcSet;
	}

	//We have created this new function to handle switch to window 
	public String RFM_PRC_Create_PromotionalBase_PrcSet_New(String strNewPrcSet, String strPrcSet_copy,
			String strPrcSetType, String strResMessage, String strTestPrc, String strError_Eating, String strError_Msg2,
			String strFuturePrc, String strNodeNum, String strNavigateTo) throws Exception {

		actions.WaitForElementPresent("PriceSet.NewBtn", 180);
		/** Get application time */
		WebElement apptime = mcd.getdate();
		String strApplicationDate = apptime.getText();

		int iTemp = 0;

		actions.click("PriceSet.NewBtn");
		Thread.sleep(2000);

		// Switch to New Price Sets
		mcd.SwitchToWindow("New Price Sets");

		// Generate unique strNewPrcSet for Base/Promotion Price Set

		switch (strPrcSetType) {
		case "Base":
			// Base Price
			strNewPrcSet = mcd.fn_GetRndName("Base");
			break;
		case "Promotion":
			strNewPrcSet = mcd.fn_GetRndName("Prom");
			break;
		default:
			// System.out.println("Please enter correct Price Set Type
			// (Base/Promotion)");
			actions.reportCreateFAIL("Verfiy data", "Enter correct price set name", "Incorrect data", "FAIL");
			break;
		}

		// Enter new price set name :
		actions.setValue("NewPriceSet.Name", strNewPrcSet);
		Thread.sleep(500);

		actions.click("NewPriceSet.SelectNode");
		Thread.sleep(1000);
		
		// Switch to Select Node Window - Title - Select Node
		mcd.waitAndSwitch("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(500);
//		actions.setValue("SelectNode.SearchBox", strNodeNum);
		driver.findElement(By.xpath(actions.getLocator("SelectNode.SearchBox"))).sendKeys(strNodeNum);
		Thread.sleep(500);

		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

//		Boolean Node_chk = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);
		if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {			
			Boolean Node_chk=mcd.Selectrestnode_JavaScriptClk("SelectNode.CPTable", strNodeNum);
		} else {
			Boolean Node_chk=mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);

		}
		Thread.sleep(2000);

		mcd.SwitchToWindow("New Price Sets");

		switch (strPrcSetType) {
		case "Base":

			// Base Price
			actions.keyboardEnter("NewPriceSet.BaseRadioBtn");
			Thread.sleep(1000);

			break;
		case "Promotion":

			// Promotion Price
			// actions.keyboardEnter("NewPriceSet.PromRadioBtn");
			actions.javaScriptClick("NewPriceSet.PromRadioBtn");
			Thread.sleep(1000);

			driver.findElement(By.xpath(actions.getLocator("NewPriceSet.StartDate"))).click();
			// mcd.select_date("25", "current", "NewPriceSet.StartDate");
			mcd.sel_current_date("NewPriceSet.StartDate", strApplicationDate);

			// driver.findElement(By.xpath("//*[@id='endDateAnchor'][@src='/rfm2OnlineApp/images/cal.jpg'][@name='endDateAnchor']")).click();
			driver.findElement(By.xpath(actions.getLocator("NewPriceSet.EndDate"))).click();
			// mcd.select_date("30", "current", "NewPriceSet.EndDate");
			mcd.Get_future_date(3, "close", strApplicationDate);

			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		// actions.click("NewPriceSet.CopyYesRadioBtn");
		actions.javaScriptClick("NewPriceSet.CopyYesRadioBtn");

		Thread.sleep(1000);

		// Select Price Set to copy
		actions.keyboardEnter("NewPriceSet.SelectPrcSet");

		Thread.sleep(1000);

		// Switch to price sets
		mcd.waitAndSwitch("Price Sets");

		actions.keyboardEnter("PriceSetList.ViewFullList");
		Thread.sleep(1000);
		actions.smartWait(120);

		try {
			// Select the first price set
			mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a").click();
			Thread.sleep(1000);

			/// Switch back
			mcd.SwitchToWindow("New Price Sets");
		} catch (Exception err) {
			actions.reportCreateFAIL("No Price Sets present to copy", "No Price Sets present to copy",
					"No Price Sets present to copy", "FAIL");
		}

		// Click Next
		actions.keyboardEnter("NewPriceSet.Next");
		
		//Switch to updated window -
		//driver.switchTo().window("");
		
		
		
		//mcd.waitAndSwitch("@Price Sets");
		
		
		//Based on instance >> Switch to Manage Price set window. Applicable to US
		
//		if(mcd.GetGlobalData("Instance").trim().toLowerCase().contains("us")){
		try{
			
			mcd.SwitchToWindow("Manage Price Set");
			actions.keyboardEnter("RFM.Okbtn");
			
			mcd.SwitchToWindow("@Price Sets");
		}
//		}else{
			catch(Exception err){
//				try{
//					mcd.SwitchToWindow("Manage Price Set");
//				}catch(Exception err){
					System.out.println("No window - Manage Price Set");
			
			}
//		}
		
		actions.WaitForElementPresent("ManagePS.QuickToolApply", 180);

		//Verify result message
		actions.verifyTextPresence(strResMessage, true);

		//Verify Screen header
		String CreatedPS_msg = null;
		CreatedPS_msg = "Manage Price Set : " + strNewPrcSet;
		actions.verifyTextPresence(CreatedPS_msg, true);

		
		// Validations - Common to Base / Promotional

		//For all price field
		driver.findElement(By.xpath(actions.getLocator("ManagePS.AllPrice"))).clear();
		actions.clear("ManagePS.AllPrice");
		Thread.sleep(500);
		actions.setValue("ManagePS.AllPrice", strTestPrc);
		Thread.sleep(500);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(2000);

		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify price fields",
					"All Prices fields should accept values upto 2 decimal places only.",
					"All Prices fields accepts values upto 2 decimal places only.", "PASS");
		} else {
			actions.reportCreatePASS("Verify price fields",
					"All Prices fields should accept values upto 2 decimal places only.",
					"All Prices fields accepts values more than 2 decimal places.", "FAIL");
		}

		//For Eating/TO/Other price field
		actions.click("ManagePS.RestRadio");
		Thread.sleep(1000);

		actions.clear("ManagePS.EatPrice");
		actions.setValue("ManagePS.EatPrice", strTestPrc);

		actions.clear("ManagePS.TkOutPrice");
		actions.setValue("ManagePS.TkOutPrice", strTestPrc);

		actions.clear("ManagePS.OtherPrice");
		actions.setValue("ManagePS.OtherPrice", strTestPrc);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(3000);

		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify price fields",
					"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
					"All Eating/TO/Other fields accepts values upto 2 decimal places only.", "PASS");
		} else {
			actions.reportCreatePASS("Verify price fields",
					"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
					"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
		}
		
		
		//Handled the situation where in based on the price value >> the price fields can be displayed as expanded or collapsed.
		//So the validations are done accordingly
		try{
			WebElement eleItemExpand = driver.findElement(By.xpath(actions.getLocator("PriceSet.FrstMIExpandIcon")));
			System.out.println("Whether expand/collapse = "+ eleItemExpand.getAttribute("style").trim());
			//if style = "" , Price fields are expanded
			if(!(eleItemExpand.getAttribute("style").trim().equalsIgnoreCase(""))){
				actions.smartWait(180);
 
				actions.clear("ManagePS.ItemEatPrice");
				actions.setValue("ManagePS.ItemEatPrice", strTestPrc);

				actions.clear("ManagePS.ItemTOPrice");
				actions.setValue("ManagePS.ItemTOPrice", strTestPrc);

				actions.clear("ManagePS.ItemOtherPrice");
				actions.setValue("ManagePS.ItemOtherPrice", strTestPrc);
				
				actions.click("ManagePS.ALLApply");
				Thread.sleep(2000);
				
				VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
				if (VerifyPopUpMsg) {
					actions.reportCreatePASS("Verify price fields",
							"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
							"All Eating/TO/Other fields accepts values upto 2 decimal places only.", "PASS");
				} else {
					actions.reportCreatePASS("Verify price fields",
							"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
							"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
				}

			}else{
				//if style = "display:none" , Price fields are collapsed	
			actions.smartWait(180);
			actions.clear("ManagePS.ItemAllPriceTextBox");
			actions.clear("ManagePS.ItemAllPriceTextBox");
			actions.setValue("ManagePS.ItemAllPriceTextBox", strTestPrc);
			
			
			actions.click("ManagePS.ALLApply");
			Thread.sleep(2000);
			
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify price fields",
						"All Prices fields should accept values upto 2 decimal places only.",
						"All Prices fields accepts values upto 2 decimal places only.", "PASS");
			} else {
				actions.reportCreatePASS("Verify price fields",
						"All Prices fields should accept values upto 2 decimal places only.",
						"All Prices fields accepts values more than 2 decimal places.", "FAIL");
			}
			}
		}catch(Exception err){
			//if style = "display:none" , Price fields are collapsed
			actions.smartWait(180);

			actions.clear("ManagePS.ItemEatPrice");
			actions.setValue("ManagePS.ItemEatPrice", strTestPrc);

			actions.clear("ManagePS.ItemTOPrice");
			actions.setValue("ManagePS.ItemTOPrice", strTestPrc);

			actions.clear("ManagePS.ItemOtherPrice");
			actions.setValue("ManagePS.ItemOtherPrice", strTestPrc);
			
			actions.click("ManagePS.ALLApply");
			Thread.sleep(2000);
			
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strError_Msg2, true, AlertPopupButton.OK_BUTTON);
			if (VerifyPopUpMsg) {
				actions.reportCreatePASS("Verify price fields",
						"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
						"All Eating/TO/Other fields accepts values upto 2 decimal places only.", "PASS");
			} else {
				actions.reportCreatePASS("Verify price fields",
						"All Eating/TO/Other fields should accept values upto 2 decimal places only.",
						"All Eating/TO/Other fields accepts values more than 2 decimal places.", "FAIL");
			}

		}
		actions.smartWait(10);
		


		// Click on cancel to close the page
		actions.click("NewPriceSet.Cancel");
		Thread.sleep(3000);
		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
				"Unsaved data will be lost. Are you sure you want to proceed?", true, AlertPopupButton.CANCEL_BUTTON);
		if (VerifyPopUpMsg) {
			// Reporter.log("Unsaved record message PASS");
			actions.reportCreatePASS("Verify Unsaved warning", "Unsaved warning should be displayed",
					"Unsaved warning is displayed", "PASS");
		} else {
			// Reporter.log("Unsaved record message FAILED");
			actions.reportCreateFAIL("Verify Unsaved warning", "Unsaved warning should be displayed",
					"Unsaved warning is not displayed", "FAIL");
		}

		//enter correct price and save
		actions.smartWait(180);
		actions.WaitForElementPresent("ManagePS.EatPrice", 180);
		actions.clear("ManagePS.EatPrice");
		actions.setValue("ManagePS.EatPrice", Integer.toString(Integer.parseInt(strFuturePrc)));

		actions.clear("ManagePS.TkOutPrice");
		actions.setValue("ManagePS.TkOutPrice", Integer.toString(Integer.parseInt(strFuturePrc)));

		actions.clear("ManagePS.OtherPrice");
		actions.setValue("ManagePS.OtherPrice", Integer.toString(Integer.parseInt(strFuturePrc)));
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(3000);
		actions.smartWait(120);
		actions.click("ManagePS.ALLApply");
		Thread.sleep(3000);
		actions.smartWait(120);
		
		// Click on cancel to close the page
		actions.click("NewPriceSet.Cancel");
		//Thread.sleep(2000);
		//actions.waitForPageToLoad(120);
		// Creating Future Settings for newly created price set
		//driver.switchTo().window("");		
		mcd.SwitchToWindow("@Manage Price Sets");
		actions.smartWait(180);

		// Enter Price Set name to search
		actions.setValue("PriceSet.SearchBox", strNewPrcSet);
		Thread.sleep(500);
		actions.keyboardEnter("PriceSet.SearchBtn");
		Thread.sleep(1000);
		actions.smartWait(120);

		// Click on fetched PS
		mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a").click();
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);
		//driver.switchTo().window("");	
		mcd.SwitchToWindow("@Price Sets");

		if (strPrcSetType.equals("Base")) {
			mcd.SelectDate_OpenCalender("10", "next");
			Thread.sleep(1000);
			actions.smartWait(120);
		} else {
			int d = 10;

			mcd.SelectDate_OpenCalender(Integer.toString(d), "next");
			Thread.sleep(1000);
			actions.smartWait(120);
			mcd.SelectDate_OpenCalender(Integer.toString(d + 2), "current");
			Thread.sleep(1000);
			actions.smartWait(120);
		}

		//Enter future price setting
		actions.clear("ManagePS.AllPrice");
		Thread.sleep(500);
		actions.setValue("ManagePS.AllPrice", strFuturePrc);
		Thread.sleep(500);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(2000);

		actions.click("FutureSettings.Apply");
		
		try{
			String Alertvalue=driver.switchTo().alert().getText();
				if(Alertvalue.contains("You have specified incomplete tax information")){
					driver.switchTo().alert().accept();
				}
			  }catch(Exception e) {	                     
				System.out.println("Alert is not displaying");
		}
		Thread.sleep(1000);
		actions.smartWait(120);

		//Verify Success message
		actions.verifyTextPresence("Your changes have been saved.", false);
		actions.reportCreatePASS("Verify Future Settings",
				"Future settings for new price set should be done successfully",
				"Future settings for new price set done successfully", "PASS");

		return strNewPrcSet;
	}

	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : A price set assigned to any
	 * restaurant can not be made inactive Scenario ID : PRC_0142 Author : Pooja
	 * Panse
	 */
	// -----------------------------------

	public void RFM_PRC_AssignedPriceSet_ActiveChk(String strError_Msg, String strResMessage)
			throws InterruptedException {

		// To handle navigation issue :

		driver.findElement(By.xpath("//*[@id='anchorTag2']/b")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='pageNoId1']")).click();

		Thread.sleep(500);

		String Assigned_PriceSet = null;
		String Unassigned_PrcSet = null;
		int set1 = 0;
		int set2 = 0;
		WebElement SetA = null;
		WebElement SetB = null;
		int rw_cnt = mcd.GetTableRowCount("Price.PriceSets");
		// System.out.println("Rows - "+rw_cnt);

		// Get one assigned & unassigned price set.
		for (int i = 1; i <= rw_cnt; i++) {
			try {
				if (driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/span/img"))
						.isDisplayed()) {
					Assigned_PriceSet = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a"))
							.getText();
					SetA = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a"));
					// Reporter.log("Selecting Assigned Price Set
					// "+Assigned_PriceSet);
					break;
				}
			} catch (Exception e) {

				// Reporter.log("Selecting Unassigned Price Set
				// "+Unassigned_PrcSet);

			}

		}

		// Check - An assigned price set can not be made inactive

		System.out.println(SetA.getText());
		// System.out.println(SetB.getText());
		// System.out.println("Unassigned_PrcSet");
		SetA.click();
		Thread.sleep(5000);

		actions.setValue("ManagePS.Status", "Inactive");
		Thread.sleep(1000);

		actions.click("ManagePS.ALLApply");
		Thread.sleep(5000);
		actions.verifyTextPresence(strError_Msg, true);
		// Reporter.log("A Price set assigned to any restaurant can not be made
		// inactive - PASS ");
		actions.reportCreatePASS("Verify assigned price set cannot be made inactive",
				"Assigned price set cannot be made inactive", "Assigned price set cannot be made inactive", "PASS");

		actions.click("ManagePS.CancelBtn");
		Thread.sleep(10000);

		actions.waitForPageToLoad(20);
		// Check - An unassigned price set can be made inactive

		// Get one unassigned price set.
		for (int i = 1; i <= rw_cnt; i++) {
			try {
				if (driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/span/img"))
						.isDisplayed()) {

				}
			} catch (Exception e) {

				System.out.println("This price set is not attached to any restaurant");
				Unassigned_PrcSet = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a"))
						.getText();
				driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a")).sendKeys(Keys.ENTER);
				// Reporter.log("Selecting Unassigned Price Set
				// "+Unassigned_PrcSet);
				break;
			}

		}

		Thread.sleep(5000);

		// Check whether active or not
		String currStatus = actions.getValue("ManagePS.Status");
		if (currStatus.equals("Inactive")) {
			actions.setValue("ManagePS.Status", "Active");
			Thread.sleep(1000);

			actions.click("ManagePS.ALLApply");
			Thread.sleep(5000);

		}

		actions.setValue("ManagePS.Status", "Inactive");
		Thread.sleep(1000);

		actions.click("ManagePS.ALLApply");
		Thread.sleep(5000);

		actions.verifyTextPresence(strResMessage, true);
		// Reporter.log("A Price set not assigned to any restaurant can be made
		// inactive - PASS ");
		actions.reportCreatePASS("Verify unassigned price set can be made inactive",
				"Unassigned price set can be made inactive", "Unassigned price set can be made inactive", "PASS");
	}

	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Updated Price set name is
	 * displayed in Mass update prices & restaurant profile Scenario ID :
	 * PRC_0150 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_UpdatePriceSetName(String strResMessage, String strNavigateMUP, String strNavigateRP)
			throws Exception {

		String Assigned_PriceSet = null;
		String updt_APriceSet = null;
		String strNode = null;

		int rw_cnt = mcd.GetTableRowCount("Price.PriceSets");
		// System.out.println("Rows - "+rw_cnt);

		// Get one assigned price set to update
		for (int i = 1; i <= rw_cnt; i++) {
			try {
				if (driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/span/img"))
						.isDisplayed()) {
					Assigned_PriceSet = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a"))
							.getText();

					// Get the node name to which this price set is assigned to.
					strNode = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[2]")).getText();

					// Click Price set link
					driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a")).sendKeys(Keys.ENTER);
					actions.WaitForElementPresent("ManagePS.PriceSetName", 10);

					// Update price set name
					actions.clear("ManagePS.PriceSetName");
					Thread.sleep(2000);

					// Appended Auto_updt to current price set name
					updt_APriceSet = "Auto_updt_" + Assigned_PriceSet;
					actions.setValue("ManagePS.PriceSetName", updt_APriceSet);

					// Apply chenges
					actions.click("ManagePS.ALLApply");
					Thread.sleep(5000);

					// Verify success message
					actions.verifyTextPresence(strResMessage, true);

					break;
				}
			} catch (Exception e) {
				System.out.println("This price set is not attached to any restaurant");
			}
		}

		// Verify updated Price Set name in - Mass update prices

		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateMUP);
		actions.select_menu("RFMHome.Pricing", strNavigateMUP);
		Thread.sleep(5000);
		actions.waitForPageToLoad(20000);

		// Menu Item

		actions.keyboardEnter("UpdateSet.VwFullList");
		Thread.sleep(10000);

		List<WebElement> MnuItm_List = driver.findElements(By.xpath("//tr[@onclick = 'SelectLeftRow(this)']"));
		// System.out.println(MnuItm_List.size());

		if (MnuItm_List != null) {
			MnuItm_List.get(0).click();
		}

		Thread.sleep(1000);
		actions.click("UpdateSet.AddRow");
		Thread.sleep(1000);
		actions.click("UpdateSet.NextBtn");
		Thread.sleep(10000);

		// Price Sets - Search for updated price set

		actions.setValue("UpdatePrcSet.SearchBox", updt_APriceSet);
		actions.keyboardEnter("UpdatePrcSet.SearchButton");
		Thread.sleep(10000);

		// Verify whether the updated name is displayed
		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator("UpdatePrcSet.PriceSetTable"));
		if (eleTable != null) {
			List<WebElement> eleRows = eleTable.findElements(By.xpath(".//tbody/tr/td[1]"));
			// System.out.println(eleRows.get(0).getText());
			if (eleRows.get(0).getText().equals(updt_APriceSet)) {
				actions.reportCreatePASS("Verify updated price set in Mass update prices",
						"Updated Price Set should be displayed correctly in Mass Update Prices",
						"Updated Price Set is displayed correctly in Mass Update Prices", "PASS");
				// Reporter.log("Updated Price Set is displayed correctly in
				// Mass Update Prices - PASS");
			} else {
				actions.reportCreateFAIL("Verify updated price set in Mass update prices",
						"Updated Price Set should be displayed correctly in Mass Update Prices",
						"Updated Price Set is not displayed correctly in Mass Update Prices", "FAIL");
				// Reporter.log("Updated Price Set is not displayed correctly in
				// Mass Update Prices - FAIL");
			}
		}

		Thread.sleep(1000);

		// Verify updated Price Set name in - Restaurant Profile

		// Navigate to Admin > Restaurant Profile
		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateRP);
		actions.select_menu("RFMHome.Pricing", strNavigateRP);
		Thread.sleep(5000);
		actions.waitForPageToLoad(20);

		// Search & Select node to which updated price set is assigned
		actions.setValue("RestaurantUpdt.SearchRestro", strNode);
		// actions.setValue("RestProfile.Status", "Active");
		actions.keyboardEnter("RestaurantUpdt.SearchRestroBtn");
		// actions.waitForPageToLoad(10);
		Thread.sleep(10000);
		driver.findElement(By.xpath("//*[@id='restData']/tr/td[1]/a")).sendKeys(Keys.ENTER);
		Thread.sleep(10000);

		// Select MenuItem/POS tab
		actions.keyboardEnter("RestaurantUpdt.MITab");
		Thread.sleep(10000);
		actions.setValue("RestaurantUpdt.SetType", "Pricing");
		Thread.sleep(20000);

		// Verify updated price set name is displayed
		// get row count of the table

		int srch_cnt = mcd.GetTableRowCount("RestaurantUpdt.SearchTable");
		// System.out.println(srch_cnt);
		String Srchd_Name = null;
		for (int k = 1; k <= srch_cnt; k++) {
			Srchd_Name = driver
					.findElement(By
							.xpath("//*[@id='rightsidelist']//tr[" + k + "][@onclick = 'SelectRightRow(this)']/td[1]"))
					.getText();
			Srchd_Name = Srchd_Name.split("\\(")[0].trim();

			if (Srchd_Name.equals(updt_APriceSet)) {
				// Reporter.log("Updated Price Set is displayed correctly in
				// Restaurant Profile - PASS");
				actions.reportCreatePASS("Verify updated price set in restaurant profile",
						"Updated Price Set should be displayed correctly in restaurant profile",
						"Updated Price Set is displayed correctly in restaurant profile", "PASS");
			} else {
				// Reporter.log("Updated Price Set is not displayed correctly in
				// Restaurant Profile - FAIL");
				actions.reportCreateFAIL("Verify updated price set in restaurant profile",
						"Updated Price Set should be displayed correctly in restaurant profile",
						"Updated Price Set is not displayed correctly in restaurant profile", "FAIL");
			}
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Verify that in price set price
	 * attributes are displayed as expanded by default & user cannot collapse it
	 * when <display-price-type-attribute-as-expanded-by-default> = true
	 * <restrict-price-type-attribute-from-expanding> = true Scenario ID :
	 * PRC_0152 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_VerifyPriceAttributes(String strNavigateTo, String strPriceSetName)
			throws InterruptedException {

		// Check for parameters :
		// General : Restrict price type attribute from expanding & Display
		// price type attribute as expanded by default

		int cnt = 3;
		List<WebElement> Parameter_Lists = driver.findElements(By.xpath("//*[@id='ApplicationParameters']/tr/td[2]/b"));

		for (int i = 0; i < Parameter_Lists.size(); i++) {
			String curr_parameter = Parameter_Lists.get(i).getText();

			// Check whether section name is "General"
			if (curr_parameter.equals("General")) {
				driver.findElement(By.xpath("//*[@id='ApplicationParameters']/tr[" + cnt + "]/td[1]")).click();
				Thread.sleep(1000);
				break;
			} else {
				cnt = cnt + 2;
			}
		}

		// Get row counts of parameters displayed
		int p_rows = mcd.GetTableRowCount("UpdateSettings.GeneralParamTbl");
		String tag = null;
		String curr_val = null;
		String new_val = null;
		int iTemp = 0;
		int tag_cnt = 0;

		// Check for the mentioned 2 tags & check whether they are set to
		// expected value
		for (int j = 1; j <= p_rows; j++) {
			tag = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[1]")).getText();

			if (tag.equals("Restrict price type attribute from expanding")) {
				curr_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input"))
						.getAttribute("value");

				if (curr_val.equalsIgnoreCase("False")) {
					driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[3]/input")).sendKeys("True");
					tag_cnt++;
				} else if (curr_val.equalsIgnoreCase("True")) {
					// Reporter.log(tag+" - Tag value is already true.");
					// System.out.println(tag+" - Tag value is already true.");
					actions.reportCreatePASS("Verify tag value", tag + " - Tag value is already true.",
							tag + " - Tag value is already true.", "PASS");
				}
			}

			if (tag.equals("Display price type attribute as expanded by default")) {

				curr_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input"))
						.getAttribute("value");

				if (curr_val.equalsIgnoreCase("False")) {
					driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[3]/input")).sendKeys("True");
					tag_cnt++;
				} else if (curr_val.equalsIgnoreCase("True")) {
					actions.reportCreatePASS("Verify tag value", tag + " - Tag value is already true.",
							tag + " - Tag value is already true.", "PASS");
				}
			}
		}

		// Save the changes
		if (tag_cnt > 0) {
			Thread.sleep(3000);
			actions.click("UpdateSettings.SaveBtn");

			Thread.sleep(5000);

			actions.verifyTextPresence("Your changes have been saved and cache is refreshed.", true);

			// Verify tag values - whether changes are reflected correctly

			for (int j = 1; j <= p_rows; j++) {
				tag = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[1]")).getText();

				if (tag.equals("Restrict price type attribute from expanding")) {
					new_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input"))
							.getAttribute("value");

					if (new_val.equalsIgnoreCase("True")) {
						// Reporter.log(tag+" - Tag value is correctly updated -
						// PASS");
						// System.out.println("Tag 1 value correctly updated");
						actions.reportCreatePASS("Verify tag value", tag + " - Tag value should be correctly updated.",
								tag + " - Tag value is correctly updated.", "PASS");
					} else {
						actions.reportCreateFAIL("Verify tag value", tag + " - Tag value should be correctly updated.",
								tag + " - Tag value is not correctly updated.", "FAIL");
						// Reporter.log(tag+" - Tag value is incorrectly updated
						// - FAIL");
					}
				}

				if (tag.equals("Display price type attribute as expanded by default")) {

					new_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input"))
							.getAttribute("value");

					if (new_val.equalsIgnoreCase("True")) {
						actions.reportCreatePASS("Verify tag value", tag + " - Tag value should be correctly updated.",
								tag + " - Tag value is correctly updated.", "PASS");
					} else {
						actions.reportCreateFAIL("Verify tag value", tag + " - Tag value should be correctly updated.",
								tag + " - Tag value is not correctly updated.", "FAIL");
					}
				}
			}
		}

		// Verify the change is reflecting in the modules
		// Navigate to Pricing > Price sets

		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateTo);
		actions.select_menu("RFMHome.Pricing", strNavigateTo);
		Thread.sleep(5000);
		actions.waitForPageToLoad(10000);

		// Enter Price Set name to search

		actions.setValue("PriceSet.SearchBox", strPriceSetName);
		Thread.sleep(500);
		actions.keyboardEnter("PriceSet.SearchBtn");
		Thread.sleep(7000);

		// Get row count of number of price sets fetched
		int rw_cnt = mcd.GetTableRowCount("PriceSet.Table");

		List<WebElement> PrcSet_List = driver.findElements(By.xpath("//*[@id='currentLink']"));

		// Click on desired Price set
		for (int i = 0; i <= rw_cnt; i++) {
			try {

				String temp_str = PrcSet_List.get(i).getText();
				if (temp_str.equals(strPriceSetName)) {
					PrcSet_List.get(i).sendKeys(Keys.ENTER);
					iTemp = 0;
					break;
				} else {
					iTemp = iTemp + 1;
				}
			} catch (Exception e) {
				// System.out.println("This price set is not attached to any
				// restaurant");
			}
		}

		Thread.sleep(15000);

		if (iTemp == 0) {
			// Reporter.log(strPriceSetName+" fetched and clicked - PASS");
		} else {
			// Reporter.log(strPriceSetName+" not found - FAIL");
		}

		Thread.sleep(10000);

		Boolean result = this.Verify_ImageNFields();

		if (result) {
			actions.reportCreatePASS("Verify price set details",
					"All three Price Type are expanded by default. And user is not allowed to collapse all prices",
					"All three Price Type are expanded by default. And user is not allowed to collapse all prices",
					"PASS");
			// Reporter.log("Price Set details : All three Price Type are
			// expanded by default. And user is not allowed to collapse all
			// prices - PASS");
		} else {
			actions.reportCreateFAIL("Verify price set details",
					"All three Price Type are expanded by default. And user is not allowed to collapse all prices",
					"All three Price Type are not expanded by default. OR user is allowed to collapse all prices",
					"FAIL");
			// Reporter.log("Price Set details : All three Price Type are not
			// expanded by default. - FAIL");
		}

		// Add New Menu Items & then verify changes

		// Add/Remove Menu Item

		String CurrHandle = driver.getWindowHandle();
		System.out.println(CurrHandle);
		Thread.sleep(1000);
		actions.click("ManagePS.AddRemoveMIBtn");
		Thread.sleep(20000);

		//// actions.WaitForWindowToBe(2, 10);
		// Switch Window to //"Price Sets : Common Menu Item Selector"

		//actions.windowSwitch(CurrHandle, "Price Sets : Common Menu Item Selector");
		//Thread.sleep(5000);
		//String NewHandle = driver.getWindowHandle();
		try{
		mcd.SwitchToWindow("Price Sets : Common Menu Item Selector");
		}catch(Exception e){
			
		}
		// ADD

		// Click on View Full List

		actions.keyboardEnter("CommonSelector.ViewFullBtn");
		Thread.sleep(10000);

		// Select Available from Availability drop down
		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
		Thread.sleep(5000);

		// Get Row Count
		// int Item_Counts = mcd.GetTableRowCount("CommonSelector.Table");

		List<WebElement> Add_Chkbox = driver
				.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
		int Item_Counts = Add_Chkbox.size();
		List<String> MnuItem_Names = new ArrayList<String>();
		// Check items and add accordingly

		int i_temp = 0;
		for (int n = 0; n <= Item_Counts; n++) {
			// Check whether enabled for Add or not
			if ((Add_Chkbox.get(n).isEnabled())) {
				// Check box enabled - Add Item
				Add_Chkbox.get(n).sendKeys(Keys.SPACE);

				// Get Item Name
				String p = Integer.toString(n + 1);
				String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
				MnuItem_Names.add(e);

				i_temp++;
			} else {
				System.out.println("This MI is already added");
			}

			if (i_temp == 1) {
				System.out.println("Selected 1 item for Add MI");
				break;
			}
			Thread.sleep(1000);
		}

		actions.keyboardEnter("CommonSelector.Save");
		Thread.sleep(3000);

		//Thread.sleep(20000);

		// Switch back to Main Window- Title "Price Sets"

		//actions.windowSwitch(NewHandle, "Price Sets");
		try{
		mcd.SwitchToWindow("Price Sets");
		}catch(Exception e){
		
		}
		//mcd.SwitchToWindow("Price Sets");
		Thread.sleep(7000);

		// Menu Items have been Added/Removed successfully from the Price Set.
		actions.verifyTextPresence("Menu Items have been Added/Removed successfully from the Price Set.", true);

		// Get the list of items displayed
		List<WebElement> Added_Items = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));
		// System.out.println(Added_Items.size());
		int AddItem_check = 0;

		for (int k = 0; k < Added_Items.size(); k++) {
			String Added_ItemName = Added_Items.get(k).getText().split("-")[1].trim();

			// Verify that the added items are same as displayed items
			if (Added_ItemName.equals(MnuItem_Names.get(k))) {
				AddItem_check++;
			} else {
				// System.out.println("Check "+Added_ItemName);
				// System.out.println("Check "+MnuItem_Names.get(k));
			}
		}

		if (AddItem_check == 1) {
			actions.reportCreatePASS("Verify menu items displayed", "Only newly added items should be displayed",
					"Only newly added items are displayed", "PASS");
			// Reporter.log("Only newly added menu items are displayed as
			// expected - PASS");
		} else {
			actions.reportCreateFAIL("Verify menu items displayed", "Only newly added items should be displayed",
					"Items are incorrectly displayed", "FAIL");
		}

		result = this.Verify_ImageNFields();

		if (result) {
			actions.reportCreatePASS("Verify Newly added items screen",
					"All three Price Type are expanded by default. And user is not allowed to collapse all prices",
					"All three Price Type are expanded by default. And user is not allowed to collapse all prices",
					"PASS");
			// Reporter.log("In Newly added items screen : All three Price Type
			// are expanded by default. And User is not allowed to collapse all
			// prices - PASS");
		} else {
			actions.reportCreateFAIL("Verify Newly added items screen",
					"All three Price Type are expanded by default. And user is not allowed to collapse all prices",
					"All three Price Type are not expanded by default. OR user is allowed to collapse all prices",
					"FAIL");
			// Reporter.log("In Newly added items screen : All three Price Type
			// are not expanded by default. - FAIL");
		}

		// Future settings :

		String Future_Date = null;

		// Select future date link in the future price changes part
		try {

			WebElement FDate = driver.findElement(By.xpath("//*[@id='futureEffectiveDate']/option[2]"));
			Future_Date = FDate.getText();
			FDate.click();
			actions.smartWait(180);
			// System.out.println("Clicked on future date settings - PASS");

		} catch (Exception e) {
			System.out.println("Date selection failed");
		}

		actions.waitForPageToLoad(120);

		// Verify that new tab displays the correct date
		String Date_displayed=null;
		try{
			Thread.sleep(9000);
		actions.WaitForElementPresent("ManagePS.DateSelected",180);
		Date_displayed = driver.findElement(By.xpath(actions.getLocator("ManagePS.DateSelected"))).getText();
		}catch(Exception E){
			
		}
		if (Date_displayed.equals(Future_Date)) {
			actions.reportCreatePASS("Verify date in future tab", "Correct future date should be displayed",
					"Correct future date displayed", "PASS");
			// Reporter.log("Correct future date is displayed on future tab -
			// PASS");
		} else {
			actions.reportCreateFAIL("Verify date in future tab", "Correct future date should be displayed",
					"Correct future date not displayed", "FAIL");
		}

		result = this.Verify_ImageNFields();

		if (result) {
			actions.reportCreatePASS("Verify Future Settings Screen screen",
					"All three Price Type are expanded by default. And user is not allowed to collapse all prices",
					"All three Price Type are expanded by default. And user is not allowed to collapse all prices",
					"PASS");
		} else {
			actions.reportCreateFAIL("Verify Future Settings Screen screen",
					"All three Price Type are expanded by default. And user is not allowed to collapse all prices",
					"All three Price Type are not expanded by default. OR user is allowed to collapse all prices",
					"FAIL");
			// Reporter.log("In Future Settings Screen : All three Price Type
			// are not expanded by default. - FAIL");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Verify fields displayed or not
	 * for Price Sets Scenario ID : Used for library for PRC_0152 Author : Pooja
	 * Panse
	 */
	// -----------------------------------

	public boolean Verify_ImageNFields() {
		Boolean check = false;
		Boolean check1 = false;
		Boolean check2 = false;
		Boolean check3 = false;
		try {

			List<WebElement> Collapse_img = driver.findElements(By.xpath("//img[contains(@onclick,'collapse')]"));

			// Check Collapse image exists by default
			if (Collapse_img != null) {
				check = true;
				// Reporter.log("Collapse image is displayed by default -
				// PASS");
				actions.reportCreatePASS("Verify Collapse icon", "Collapse image should be displayed by default",
						"Collapse image is displayed by default", "PASS");

				// Verify the fields Eating/TO/Other are displayed by default

				if ((mcd.fn_VerifyWebObjectsDisplayed("PriceTypes.Eating"))
						&& (mcd.fn_VerifyWebObjectsDisplayed("PriceTypes.TO"))
						&& (mcd.fn_VerifyWebObjectsDisplayed("PriceTypes.Other"))) {
					check = true;
					// System.out.println("All price attributes are displayed by
					// default - PASS");
					actions.reportCreatePASS("Verify all price attributes",
							"All price attributes should displayed by default",
							"All price attributes are displayed by default", "PASS");
				} else {
					check = false;
					actions.reportCreateFAIL("Verify all price attributes",
							"All price attributes should displayed by default",
							"All price attributes are not displayed by default", "FAIL");
					// System.out.println("All price attributes are not
					// displayed by default - FAIL");
				}

				// Try and collapse the items
				Collapse_img.get(0).click();

				// Again verify the fields

				Collapse_img = driver.findElements(By.xpath("//img[contains(@onclick,'collapse')]"));

				// Check Collapse image exists by default
				if (Collapse_img != null) {
					check = true;
					System.out.println("Collapse image displayed - PASS");

					// Verify the fields Eating/TO/Other are displayed by
					// default

					if ((mcd.fn_VerifyWebObjectsDisplayed("PriceTypes.Eating"))
							&& (mcd.fn_VerifyWebObjectsDisplayed("PriceTypes.TO"))
							&& (mcd.fn_VerifyWebObjectsDisplayed("PriceTypes.Other"))) {
						check = true;

						actions.reportCreatePASS("Verify collapse field", "Unable to collapse the fields",
								"Unable to collapse the fields", "PASS");
						// Reporter.log("Unable to collapse the fields as
						// expected - PASS");
					} else {
						check = false;
						actions.reportCreateFAIL("Verify collapse field", "Unable to collapse the fields",
								"Able to collapse the fields", "FAIL");
						// Reporter.log("Able to collapse the fields as expected
						// - FAIL");
					}
				}
			}

		} catch (Exception e) {
			System.out.println(e);
			actions.reportCreateFAIL("Verify collapse field", "Unable to collapse the fields",
					"Collapse icon not visible", "FAIL");
			// Reporter.log("Collapse image is not displayed by default -
			// FAIL");
			check = false;
		}

		return check;

	}

	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Verify that in price set price
	 * attributes are displayed as expanded by default & user cannot collapse it
	 * when <display-price-type-attribute-as-expanded-by-default> = false
	 * <restrict-price-type-attribute-from-expanding> = false Scenario ID :
	 * PRC_0154 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_VerifyPriceAttributes_False(String strNavigateTo, String strPriceSetName)
			throws Exception {

		// Check for parameters :
		// General : Restrict price type attribute from expanding & Display
		// price type attribute as expanded by default

		int cnt = 3;
		List<WebElement> Parameter_Lists = driver.findElements(By.xpath("//*[@id='ApplicationParameters']/tr/td[2]/b"));

		for (int i = 0; i < Parameter_Lists.size(); i++) {
			String curr_parameter = Parameter_Lists.get(i).getText();

			// Check whether section name is "General"
			if (curr_parameter.equals("General")) {
				driver.findElement(By.xpath("//*[@id='ApplicationParameters']/tr[" + cnt + "]/td[1]")).click();
				Thread.sleep(1000);
				break;
			} else {
				cnt = cnt + 2;
			}
		}

		// Get row counts of parameters displayed
		int p_rows = mcd.GetTableRowCount("UpdateSettings.GeneralParamTbl");
		String tag = null;
		String curr_val = null;
		String new_val = null;
		int iTemp = 0;
		int tag_cnt = 0;

		// Check for the mentioned 2 tags & check whether they are set to
		// expected value
		for (int j = 1; j <= p_rows; j++) {
			tag = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[1]")).getText();

			if (tag.equals("Restrict price type attribute from expanding")) {
				curr_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input"))
						.getAttribute("value");

				if (curr_val.equalsIgnoreCase("True")) {
					driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[3]/input")).sendKeys("False");
					tag_cnt++;
				} else if (curr_val.equalsIgnoreCase("False")) {
					// Reporter.log(tag+" - Tag value is already false.");
				}
			}

			if (tag.equals("Display price type attribute as expanded by default")) {

				curr_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input"))
						.getAttribute("value");

				if (curr_val.equalsIgnoreCase("True")) {
					driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[3]/input")).sendKeys("False");
					tag_cnt++;
				} else if (curr_val.equalsIgnoreCase("False")) {
					// Reporter.log(tag+" - Tag value is already false.");
				}
			}
		}

		// Save the changes
		if (tag_cnt > 0) {
			actions.WaitForElementPresent("UpdateSettings.SaveBtn", 180);
			actions.click("UpdateSettings.SaveBtn");

			Thread.sleep(1000);
			actions.smartWait(180);

			actions.verifyTextPresence("Your changes have been saved and cache is refreshed.", true);

			// Check for parameters :
			// General : Restrict price type attribute from expanding & Display
			// price type attribute as expanded by default

			cnt = 3;
			Parameter_Lists = driver.findElements(By.xpath("//*[@id='ApplicationParameters']/tr/td[2]/b"));

			for (int i = 0; i < Parameter_Lists.size(); i++) {
				String curr_parameter = Parameter_Lists.get(i).getText();

				// Check whether section name is "General"
				if (curr_parameter.equals("General")) {
					driver.findElement(By.xpath("//*[@id='ApplicationParameters']/tr[" + cnt + "]/td[1]")).click();
					Thread.sleep(1000);
					break;
				} else {
					cnt = cnt + 2;
				}
			}

			// Verify tag values - whether changes are reflected correctly

			for (int j = 1; j <= p_rows; j++) {
				tag = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[1]")).getText();

				if (tag.equals("Restrict price type attribute from expanding")) {
					new_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input"))
							.getAttribute("value");

					if (new_val.equalsIgnoreCase("True")) {
						actions.reportCreatePASS("Verify tag value", tag + " - Tag value should be correctly updated",
								tag + " - Tag value is correctly updated", "PASS");
						// Reporter.log(tag+" - Tag value is correctly updated -
						// PASS");
						// System.out.println("Tag 1 value correctly updated");
					} else {
						// Reporter.log(tag+" - Tag value is incorrectly updated
						// - FAIL");
						actions.reportCreateFAIL("Verify tag value", tag + " - Tag value should be correctly updated",
								tag + " - Tag value is incorrectly updated", "FAIL");
					}
				}

				if (tag.equals("Display price type attribute as expanded by default")) {

					new_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input"))
							.getAttribute("value");

					if (new_val.equalsIgnoreCase("True")) {
						actions.reportCreatePASS("Verify tag value", tag + " - Tag value should be correctly updated",
								tag + " - Tag value is correctly updated", "PASS");
						// Reporter.log(tag+" - Tag value is correctly updated -
						// PASS");
					} else {
						actions.reportCreateFAIL("Verify tag value", tag + " - Tag value should be correctly updated",
								tag + " - Tag value is incorrectly updated", "FAIL");
						// Reporter.log(tag+" - Tag value is incorrectly updated
						// - FAIL");
					}
				}
			}
		}

		// Verify the change is reflecting in the modules
		// Navigate to Pricing > Price sets

        /** Select Menu Option */
        System.out.println("> Navigate to :: " + strNavigateTo);
        actions.select_menu("RFMHome.Navigation",strNavigateTo);
        Thread.sleep(2000);
        actions.waitForPageToLoad(120);
        
        /** Update title of new Page  */
        mcd.SwitchToWindow("#Title");

		// Enter Price Set name to search
		actions.setValue("PriceSet.SearchBox", strPriceSetName);
		Thread.sleep(500);
		actions.keyboardEnter("PriceSet.SearchBtn");
		Thread.sleep(1000);
		actions.smartWait(180);

		// Get row count of number of price sets fetched
		int rw_cnt = mcd.GetTableRowCount("PriceSet.Table");

		List<WebElement> PrcSet_List = driver.findElements(By.xpath(actions.getLocator("RFMPriceSets.PriceSet1")));

		// Click on desired Price set
		for (int i = 0; i <= rw_cnt; i++) {
			try {

				String temp_str = PrcSet_List.get(i).getText();
				if (temp_str.equals(strPriceSetName)) {
					PrcSet_List.get(i).sendKeys(Keys.ENTER);
					iTemp = 0;
					break;
				} else {
					iTemp = iTemp + 1;
				}
			} catch (Exception e) {
				// System.out.println("This price set is not attached to any
				// restaurant");
			}
		}
		
		Thread.sleep(2000);
		mcd.SwitchToWindow("#Title");

		actions.WaitForElementPresent("ManagePS.AddRemoveMIBtn", 180);
		Boolean result = this.Verify_ImageNFields_PRC0154();

		if (result) {
			actions.reportCreatePASS("Verify price fields",
					"Fields should be expanded by default.User should be allowed to collapse all prices",
					"All three Price Type are expanded by default. And user is allowed to collapse all prices", "PASS");
			// Reporter.log("All three Price Type are expanded by default. And
			// user is allowed to collapse all prices - PASS");
		} else {
			actions.reportCreateFAIL("Verify price fields",
					"Fields should be expanded by default.User should be allowed to collapse all prices",
					"All three Price Type are collapsed by default. OR user is not able to collapse all prices",
					"FAIL");
			// Reporter.log("All three Price Type are not expanded by default. -
			// FAIL");
		}

		// Add New Menu Items & then verify changes

		// Add/Remove Menu Item

		actions.click("ManagePS.AddRemoveMIBtn");
		Thread.sleep(2000);

		//// actions.WaitForWindowToBe(2, 10);
		// Switch Window to //"Price Sets : Common Menu Item Selector"
		mcd.waitAndSwitch("Price Sets : Common Menu Item Selector");
//		actions.windowSwitch(CurrHandle, "Price Sets : Common Menu Item Selector");
//		Thread.sleep(5000);
//		String NewHandle = driver.getWindowHandle();

		// ADD

		// Click on View Full List

		actions.keyboardEnter("CommonSelector.ViewFullBtn");
		Thread.sleep(1000);
		actions.smartWait(180);

		// Select Available from Availability drop down
		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
		Thread.sleep(1000);
		actions.smartWait(180);

		// Get Row Count
		// int Item_Counts = mcd.GetTableRowCount("CommonSelector.Table");

		List<WebElement> Add_Chkbox = driver.findElements(By.xpath(actions.getLocator("PriceSet.AddMICheckBox")));
		int Item_Counts = Add_Chkbox.size();
		List<String> MnuItem_Names = new ArrayList<String>();
		// Check items and add accordingly

		int i_temp = 0;
		for (int n = 0; n <= Item_Counts; n++) {
			// Check whether enabled for Add or not
			if ((Add_Chkbox.get(n).isEnabled())) {
				// Check box enabled - Add Item
				Add_Chkbox.get(n).sendKeys(Keys.SPACE);

				// Get Item Name
				String p = Integer.toString(n + 1);
				String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
				MnuItem_Names.add(e);

				i_temp++;
			} else {
				System.out.println("This MI is already added");
			}

			if (i_temp == 1) {
				System.out.println("Selected 1 item for Add MI");
				break;
			}
			Thread.sleep(1000);
		}

		actions.keyboardEnter("CommonSelector.Save");
//		Thread.sleep(2000);
		actions.smartWait(180);
		mcd.SwitchToWindow("Price Sets");

		// Switch back to Main Window- Title "Price Sets"
//
//		actions.windowSwitch(NewHandle, "Price Sets");
//		Thread.sleep(7000);

		// Menu Items have been Added/Removed successfully from the Price Set.
		actions.verifyTextPresence("Menu Items have been Added/Removed successfully from the Price Set.", true);

		// Get the list of items displayed
		List<WebElement> Added_Items = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));
		// System.out.println(Added_Items.size());
		int AddItem_check = 0;

		for (int k = 0; k < Added_Items.size(); k++) {
			String Added_ItemName = Added_Items.get(k).getText().split("-")[1].trim();

			// Verify that the added items are same as displayed items
			if (Added_ItemName.equals(MnuItem_Names.get(k))) {
				AddItem_check++;
			} else {
				// System.out.println("Check "+Added_ItemName);
				// System.out.println("Check "+MnuItem_Names.get(k));
			}
		}

		if (AddItem_check == 1) {
			actions.reportCreatePASS("Verify menu items displayed", "Only newly added items should be displayed",
					"Only newly added items are displayed", "PASS");
			// Reporter.log("Only newly added menu items are displayed as
			// expected - PASS");
		} else {
			actions.reportCreateFAIL("Verify menu items displayed", "Only newly added items should be displayed",
					"Items are incorrectly displayed", "FAIL");
		}

		
		actions.WaitForElementPresent("RFM.CancelBtn", 180);
		result = this.Verify_ImageNFields_PRC0154();

		if (result) {
			actions.reportCreatePASS("Verify fields at New added items screen",
					"Fields should be expanded by default.User should be allowed to collapse all prices",
					"All three Price Type are expanded by default. And user is allowed to collapse all prices", "PASS");
			// Reporter.log("New added items screen : All three Price Type are
			// collasped by default. And User is allowed to expand and view all
			// prices - PASS");
		} else {
			actions.reportCreateFAIL("Verify fields at New added items screen",
					"Fields should be expanded by default.User should be allowed to collapse all prices",
					"All three Price Type are collapsed by default. OR user is not able to collapse all prices",
					"FAIL");
			// Reporter.log("Newly added items screen : All three Price Type are
			// expanded by default. - FAIL");
		}

		// Future settings :

		String Future_Date = null;

		// Select future date link in the future price changes part
		try {

			WebElement FDate = driver.findElement(By.xpath(actions.getLocator("ManagePS.FutureDate")));
			Future_Date = FDate.getText();
			FDate.click();
			Thread.sleep(3000);
			// System.out.println("Clicked on future date settings - PASS");

		} catch (Exception e) {
			System.out.println("Date selection failed");
		}

		actions.waitForPageToLoad(180);
		actions.smartWait(180);
		
		actions.WaitForElementPresent("RFM.CancelBtn", 180);

//		// Verify that new tab displays the correct date
//		String Date_displayed = driver.findElement(By.xpath(actions.getLocator("ManagePS.DateSelected"))).getText();
//
//		if (Date_displayed.equals(Future_Date)) {
//			// Reporter.log("Correct future date is displayed on future tab -
//			// PASS");
//			actions.reportCreatePASS("Verify future date", "Correct future date should be displayed on future tab",
//					"Correct future date is displayed on future tab", "PASS");
//		} else {
//			// Reporter.log("Incorrect future date is displayed on future tab -
//			// FAIL");
//			actions.reportCreateFAIL("Verify future date", "Correct future date should be displayed on future tab",
//					"Incorrect future date is displayed on future tab", "FAIL");
//		}
		
		actions.WaitForElementPresent("RFM.CancelBtn", 180);
		result = this.Verify_ImageNFields_PRC0154();

		if (result) {
			actions.reportCreatePASS("Verify fields at Future Settings Screen",
					"Fields should be expanded by default.User should be allowed to collapse all prices",
					"All three Price Type are expanded by default. And user is allowed to collapse all prices", "PASS");
			// Reporter.log("Future Settings Screen : All three Price Type are
			// collapsed by default. And User is allowed to expand and view all
			// prices - PASS");
		} else {
			actions.reportCreateFAIL("Verify fields at Future Settings Screen",
					"Fields should be expanded by default.User should be allowed to collapse all prices",
					"All three Price Type are collapsed by default. OR user is not able to collapse all prices",
					"FAIL");
			// Reporter.log("Future Settings Screen : All three Price Type are
			// expanded by default. - FAIL");
		}

	}

	// ----------------------------------
	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Verify fields displayed or not
	 * for Price Sets Scenario ID : Used for library for PRC_0154 Author : Pooja
	 * Panse
	 */
	// ----------------------------------

	// -----------------------------------

	public boolean Verify_ImageNFields_PRC0154() {
		Boolean check = false;
		Boolean check1 = false;
		Boolean check2 = false;
		Boolean check3 = false;
		try {

			List<WebElement> Expand_img = driver
					.findElements(By.xpath(actions.getLocator("PriceSet.ExpandImage")));

			// Check Expand image exists by default
			if (Expand_img != null) {
				check = true;
				// Reporter.log("Expand image is displayed by default - PASS");
				actions.reportCreatePASS("Verify expand icon", "Expand icon should be displayed",
						"Expand icon displayed", "PASS");
				Thread.sleep(3000);
				// Verify the fields Eating/TO/Other are not displayed by
				// default
				check1 = driver.findElement(By.xpath(actions.getLocator("PriceTypes.Eating"))).isDisplayed();
				check2 = driver.findElement(By.xpath(actions.getLocator("PriceTypes.TO"))).isDisplayed();
				check3 = driver.findElement(By.xpath(actions.getLocator("PriceTypes.Other"))).isDisplayed();
				if (check1 && check2 && check3) {
					check = false;
					System.out.println("All price attributes are displayed by default - FAIL");
					actions.reportCreateFAIL("Verify price attributes",
							"All price attributes should not be displayed by default",
							"All price attributes are displayed by default", "FAIL");
				} else {
					check = true;
					// System.out.println("All price attributes are not
					// displayed by default as expected - PASS");
					actions.reportCreatePASS("Verify price attributes",
							"All price attributes should not be displayed by default",
							"All price attributes are not displayed by default", "PASS");
				}

				Thread.sleep(500);
				// Try and collapse the items
				Expand_img.get(0).click();
				Thread.sleep(3000);

				// Again verify the fields

				List<WebElement> Collapse_img = driver.findElements(By.xpath(actions.getLocator("PriceSet.CollapseImage")));

				// Check Collapse image exists by default
				if (Collapse_img != null) {
					check = true;
					// System.out.println("User able to expand the price
					// attributes. Collapse image displayed - PASS");
					actions.reportCreatePASS("Verify user able to expand the fields",
							"User able to expand the price attributes. Collapse image displayed",
							"User able to expand the price attributes. Collapse image displayed", "PASS");
					// Verify the fields Eating/TO/Other are displayed by
					// default
					Thread.sleep(3000);
					check1 = driver.findElement(By.xpath(actions.getLocator("PriceTypes.Eating"))).isDisplayed();
					check2 = driver.findElement(By.xpath(actions.getLocator("PriceTypes.TO"))).isDisplayed();
					check3 = driver.findElement(By.xpath(actions.getLocator("PriceTypes.Other"))).isDisplayed();
					if (check1 && check2 && check3) {
						check = true;
						System.out.println("All price attributes are displayed. - PASS");
						actions.reportCreatePASS("Verify price attributes after expand icon is clicked",
								"All price attributes should be displayed",
								"All price attributes are displayed by default", "PASS");
					} else {
						check = false;
						System.out.println("All price attributes are not displayed after expanding - FAIL");
						actions.reportCreateFAIL("Verify price attributes after expand icon is clicked",
								"All price attributes should be displayed",
								"All price attributes are not displayed by default", "FAIL");
					}
				}
			}

		} catch (Exception e) {
			System.out.println(e);
			// Reporter.log("Expand image is not displayed by default - FAIL");
			actions.reportCreateFAIL("Verify expand icon", "Expand icon should be displayed",
					"Expand icon not displayed", "FAIL");
			check = false;
		}

		return check;

	}
	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Create New Promotional/Base
	 * Price Set by copying settings from an existing price set Decimal
	 * validations on the All Price/Eating/Take-out/Other prices - checked
	 * Scenario ID : PRC_0107/ 108 Author : Pooja Panse
	 */
	// -----------------------------------

	public String RFM_PRC_CreatePrcSetWOCpy(String strPrcSetType, String strResMessage, String strTestPrc,
			String strNodeNum, String strApplicationDate, String strMIAddMsg, String strStatus) throws Exception {
		String[] InfoMsg = strMIAddMsg.split("#");
		String strNamePrefix = "";
		boolean blnflag = true;
		
		actions.WaitForElementPresent("PriceSet.NewBtn", 180);
		actions.keyboardEnter("PriceSet.NewBtn");
		Thread.sleep(2000);

		// Switch to New Price Sets
		mcd.SwitchToWindow("New Price Sets");

		// Generate unique strNewPrcSet for Base/Promotion Price Set

		switch (strPrcSetType) {
		case "Base":
			// Base Price
			strNamePrefix = "BPS";
			break;
		case "Promotion":
			strNamePrefix = "PPS";
			break;
		default:
			// System.out.println("Please enter correct Price Set Type
			// (Base/Promotion)");
			actions.reportCreateFAIL("Verfiy data", "Enter correct price set name", "Incorrect data", "FAIL");
			break;
		}

		// Enter unique Price Set Name
		String strNewPrcSet = null;

		strNewPrcSet = mcd.fn_GetRndName(strNamePrefix);
		strNewPrcSet = strNewPrcSet.subSequence(0, 10).toString();

		// Enter new price set name :

		actions.click("NewPriceSet.SelectNode");
		Thread.sleep(1000);
		mcd.waitAndSwitch("Select Node");
		// Switch to Select Node Window - Title - Select Node
		// mcd.SwitchToWindow("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(500);
		actions.setValue("SelectNode.SearchBox", strNodeNum);
		Thread.sleep(500);

		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

//		mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);
		if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {			
			mcd.Selectrestnode_JavaScriptClk("SelectNode.CPTable", strNodeNum);
		} else {
			mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);

		}
		Thread.sleep(1000);

		mcd.SwitchToWindow("New Price Sets");

		do {
			strNewPrcSet = mcd.fn_GetRndName(strNamePrefix);
			strNewPrcSet = strNewPrcSet.subSequence(0, 10).toString();
			actions.WaitForElementPresent("NewPriceSet.Name", 180);
			actions.clear("NewPriceSet.Name");
			actions.setValue("NewPriceSet.Name", strNewPrcSet);
			Thread.sleep(500);

			switch (strPrcSetType) {
			case "Base":

				// Base Price
				actions.keyboardEnter("NewPriceSet.BaseRadioBtn");
				Thread.sleep(1000);

				break;
			case "Promotion":

				// Promotion Price
				// actions.keyboardEnter("NewPriceSet.PromRadioBtn");
				actions.javaScriptClick("NewPriceSet.PromRadioBtn");
				Thread.sleep(1000);
				actions.WaitForElementPresent("NewPriceSet.StartDate", 180);

				driver.findElement(By.xpath(actions.getLocator("NewPriceSet.StartDate"))).click();
				// mcd.select_date("25", "current", "NewPriceSet.StartDate");
				mcd.Get_future_date(0, "close", strApplicationDate);
//				mcd.sel_current_date("NewPriceSet.StartDate", strApplicationDate);
				
				// driver.findElement(By.xpath("//*[@id='endDateAnchor'][@src='/rfm2OnlineApp/images/cal.jpg'][@name='endDateAnchor']")).click();
				driver.findElement(By.xpath(actions.getLocator("NewPriceSet.EndDate"))).click();
				// mcd.select_date("30", "current", "NewPriceSet.EndDate");
				mcd.Get_future_date(3, "close", strApplicationDate);

				break;
			default:
				System.out.println("Please enter correct Price Set Type (Base/Promotion)");
				break;
			}

			// Click Next
			actions.keyboardEnter("NewPriceSet.Next");
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);
			boolean blnWindow = false;
			try {
				blnWindow = mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");
				if (blnWindow) {
					System.out.println("Set Name and number accepted successfully");
					blnflag = false;
				} else {
					mcd.SwitchToWindow("New Price Sets");
					if (actions.isTextPresence(InfoMsg[1].trim(), true)) {
						blnflag = true;
						System.out.println("Entered  number " + strNewPrcSet + " is already exist.");
						System.out.println(blnflag);
					}

				}
			} catch (Exception e) {
				if (actions.isTextPresence(InfoMsg[1].trim(), true)) {
					blnflag = true;
					System.out.println("Entered  number " + strNewPrcSet + " is already exist.");
					System.out.println(blnflag);
				}
			}

		} while (blnflag == true);
		// driver.switchTo().window("");

		// mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");

		// Validations - Common to Base / Promotional

		// Click View Full List
		actions.keyboardEnter("RFM.ViewFullListBtn");
		Thread.sleep(1000);
		actions.smartWait(180);

		// Check MI to add
		WebElement eleMIfrPrcSet = mcd.GetTableCellElement("Deposit.AddDepositTable", 1, "Add", "input");
		eleMIfrPrcSet.sendKeys(Keys.SPACE);
		// click Save

		actions.click("RFM.SaveBtn");

		// Swtich
		mcd.SwitchToWindow("#Title");

		actions.verifyTextPresence(InfoMsg[0], true);

		actions.clear("ManagePS.AllPrice");
		Thread.sleep(500);
		actions.setValue("ManagePS.AllPrice", strTestPrc);
		Thread.sleep(500);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(2000);
		actions.WaitForElementPresent("ManagePS.PPPrcSetFilter", 180);

		actions.setValue("ManagePS.PPPrcSetFilter", strStatus);

		actions.click("ManagePS.PPALLSave");
		Thread.sleep(1000);
		actions.smartWait(180);

		actions.verifyTextPresence(strResMessage, false);

		// Click on cancel to close the page
		actions.click("NewPriceSet.Cancel");
		mcd.SwitchToWindow("#Title");

		return strNewPrcSet;
	}

	// ----------------------------------
	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality :Create New Base/Promotion Price
	 * Set without copying existing price set Scenario ID : Author : Pooja Panse
	 */
	// ----------------------------------
	// -----------------------------------
	public String RFM_PRC_Create_PriceSet(String strNewPrcSet, String strPrcSetType, String strResMessage,
			String strNodeNum, String strNumOfMenuItem, String strStatus_Msg, String strNewPrice, String strStatus)
					throws Exception {
		/** Get application time */
		WebElement apptime = mcd.getdate();
		String strApplicationDate = apptime.getText();

		int iTemp = 0;

		actions.click("PriceSet.NewBtn");
		Thread.sleep(2000);

		// Switch to New Price Sets
		mcd.SwitchToWindow("New Price Sets");

		// Generate unique strNewPrcSet for Base/Promotion Price Set

		switch (strPrcSetType) {
		case "Base":
			// Base Price
			strNewPrcSet = mcd.fn_GetRndName("Base");
			break;
		case "Promotion":
			strNewPrcSet = mcd.fn_GetRndName("Prom");
			break;
		default:
			// System.out.println("Please enter correct Price Set Type
			// (Base/Promotion)");
			actions.reportCreateFAIL("Verfiy data", "Enter correct price set name", "Incorrect data", "FAIL");
			break;
		}

		// Enter new price set name :
		actions.WaitForElementPresent("NewPriceSet.Name", 180);
		actions.setValue("NewPriceSet.Name", strNewPrcSet);
		Thread.sleep(500);

		actions.click("NewPriceSet.SelectNode");
		// Thread.sleep(1000);

		// Switch to Select Node Window - Title - Select Node
		mcd.SwitchToWindow("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(500);
		actions.setValue("SelectNode.SearchBox", strNodeNum);
		Thread.sleep(500);

		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		Boolean Node_chk = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);
		Thread.sleep(2000);

		mcd.SwitchToWindow("New Price Sets");

		switch (strPrcSetType) {
		case "Base":

			// Base Price
			actions.keyboardEnter("NewPriceSet.BaseRadioBtn");
			Thread.sleep(1000);

			break;
		case "Promotion":

			// Promotion Price
			// actions.keyboardEnter("NewPriceSet.PromRadioBtn");
			actions.javaScriptClick("NewPriceSet.PromRadioBtn");
			Thread.sleep(1000);

			driver.findElement(By.id("startDateAnchor")).click();
			// mcd.select_date("25", "current", "NewPriceSet.StartDate");
			mcd.Get_future_date(0, "close", strApplicationDate);

			// driver.findElement(By.xpath("//*[@id='endDateAnchor'][@src='/rfm2OnlineApp/images/cal.jpg'][@name='endDateAnchor']")).click();
			driver.findElement(By.id("endDateAnchor")).click();
			// mcd.select_date("30", "current", "NewPriceSet.EndDate");
			mcd.Get_future_date(3, "close", strApplicationDate);

			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		// Click Next
		actions.keyboardEnter("NewPriceSet.Next");
		Thread.sleep(5000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("@Price Sets");

		actions.verifyTextPresence(strResMessage, true);

		String CreatedPS_msg = null;
		CreatedPS_msg = "Manage Price Set : " + strNewPrcSet;
		actions.verifyTextPresence(CreatedPS_msg, true);

		// bxdfhsdghghjtej

		driver.switchTo().window("");
		mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");

		// Switch to Price Sets : Common Menu Item Selector - to add new menu
		// items

		// View Full List
		actions.keyboardEnter("CommonSelector.ViewFullBtn");
		Thread.sleep(10000);

		// Select Available from Availability drop down
		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
		Thread.sleep(7000);

		// Get Row Count
		// int Item_Counts = mcd.GetTableRowCount("CommonSelector.Table");

		List<WebElement> Add_Chkbox = driver
				.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
		int Item_Counts = Add_Chkbox.size();
		List<String> MnuItem_Names = new ArrayList<String>();
		// Check items and add accordingly

		int i_temp = 0;
		for (int n = 0; n <= Item_Counts; n++) {
			// Check whether enabled for Add or not
			if ((Add_Chkbox.get(n).isEnabled())) {
				// Check box enabled - Add Item
				Add_Chkbox.get(n).sendKeys(Keys.SPACE);

				// Get Item Name
				String p = Integer.toString(n + 1);
				String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
				MnuItem_Names.add(e);

				i_temp++;
			} else {
				System.out.println("This MI is already added");
			}

			if (i_temp == Integer.parseInt(strNumOfMenuItem)) {
				System.out.println("Selected items for Add MI");
				break;
			}
			Thread.sleep(1000);
		}

		// Save Changes
		actions.keyboardEnter("CommonSelector.Save");
		Thread.sleep(3000);

		Thread.sleep(20000);

		// Verify success message
		actions.verifyTextPresence(strResMessage, true);

		// Verify success message - creation of price set
		// String CreatedPS_msg = "Manage Price Set : "+strNewPrcSet+"\n"+"[
		// Base Price ]";
		// actions.verifyTextPresence(CreatedPS_msg, true);

		// Check whether newly created price set is active or not
		// If Inactive > Change the status to active

		String currStatus = actions.getValue("ManagePS.Status");
		if (!currStatus.equals(strStatus)) {
			actions.setValue("ManagePS.Status", strStatus);
			Thread.sleep(1000);

			// Set price to all menu items
			actions.clear("UpdtMultipleSet.AllPrc");
			Thread.sleep(2000);
			actions.clear("UpdtMultipleSet.AllPrc");
			Thread.sleep(1000);
			actions.setValue("UpdtMultipleSet.AllPrc", strNewPrice);
			Thread.sleep(1000);
			actions.click("UpdtMultipleSet.Apply");
			Thread.sleep(20000);

			// Save changes
			actions.click("NewPriceSet.SaveBtn");
			Thread.sleep(5000);

		}

		Thread.sleep(5000);

		// Verify success message for status & price updates
		actions.verifyTextPresence(strStatus_Msg, true);
		// Reporter.log("Price Set made Active - PASS ");
		actions.reportCreatePASS("Verify price set set active", "Price set should be set as active",
				"Price set saved as active", "PASS");
		// Return price set name
		return strNewPrcSet;
	}

	// ----------------------------------
	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Replace Price Set
	 * (Base/Promotion); Check/Uncheck - Activate Menu Items; Select type -
	 * Price/Price & Taxes Scenario ID : PRC_0130 Author : Pooja Panse
	 */
	// ----------------------------------

	// -----------------------------------

	public void RFM_PRC_Replace_PriceSet(Object strpriceset1, Object strpriceset2, String strMethod,
			String strNavigateTo, String strPrcSetType, String strActivateFlag) throws Exception {

		// Look up first price set to verify replace later
		actions.WaitForElementPresent("RFMPriceSets.dropdownSearchList", 10);

		switch (strPrcSetType) {
		case "Base":

			// Base Price
			actions.setValue("RFMPriceSets.dropdownSearchList", "Base");
			break;
		case "Promotion":

			// Promotion Price
			actions.setValue("RFMPriceSets.dropdownSearchList", "Promotional");
			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		System.out.println("text: " + strpriceset1);
		actions.setValue("RFMPriceSets.MainSearchbox", strpriceset1);
		actions.click("RFMPriceSets.MainSearch");
		Thread.sleep(500);
		actions.smartWait(120);

		actions.keyboardEnter("RFMPriceSets.PriceSet2");

		Thread.sleep(500);
		actions.smartWait(120);

		// Store Menu items for price set 1
		List<WebElement> MenuItemList1 = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));

		Thread.sleep(2000);

		/** Navigate again to price sets */
		System.out.println("> Navigate to :: " + strNavigateTo);
		actions.select_menu("RFMHome.Pricing", strNavigateTo);
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

		// -------------------------------------------
		// REPLACE PS2 by PS1
		// -------------------------------------------
		// Wait for the replace button to display & Click
		// actions.WaitForElementPresent("RFMPriceSets.ReplaceBtn", 10);
		actions.click("RFMPriceSets.ReplaceBtn");

		// // Main window handle
		// String MainHandle = driver.getWindowHandle();
		// //actions.WaitForWindowToBe(2, 10);
		//
		// // Switch to Replace Price window
		// actions.windowSwitch(MainHandle, "Replace Price");
		// // Click on Cancel & Window should close
		// actions.WaitForElementPresent("RFMPriceSets.CancelBtn", 10);

		mcd.SwitchToWindow("Replace Price");

		actions.click("RFMPriceSets.CancelBtn");
		// actions.WaitForWindowToClose(1, 10);
		// // Switch back to main window
		// driver.switchTo().window(MainHandle);
		mcd.SwitchToWindow("Manage Price Sets");

		// -------------------------------------------------------

		// Again click Replace
		actions.click("RFMPriceSets.ReplaceBtn");
		// //actions.WaitForWindowToBe(2, 10);
		//
		// // Switch to Replace Price window
		// actions.windowSwitch(MainHandle, "Replace Price");
		// actions.WaitForElementPresent("RFMPriceSets.dropdown", 10);

		mcd.SwitchToWindow("Replace Price");

		// Select Price & Taxes
		actions.setValue("RFMPriceSets.dropdown", strMethod);
		actions.verifyTestStep(actions.getValue("RFMPriceSets.dropdown"), strMethod, true); // VP1

		// Click on Cancel. Warning message should display
		actions.click("RFMPriceSets.CancelBtn");

		// For method = Price, no changes will be made hence no pop up message
		// will occur
		if (strMethod.equals("Price And Tax")) {
			actions.acceptAlert();
		}

		mcd.SwitchToWindow("Manage Price Sets");

		// -------------------------------------------------------

		// Again click Replace
		actions.click("RFMPriceSets.ReplaceBtn");
		// //actions.WaitForWindowToBe(2, 10);

		// Switch to Replace Price window
		mcd.SwitchToWindow("Replace Price");

		// Select check box as per Base/Promotion

		switch (strPrcSetType) {
		case "Base":

			// Base Price
			actions.click("RFMPriceSets.BaseRadio");
			Thread.sleep(1000);
			break;
		case "Promotion":

			// Promotion Price
			actions.click("RFMPriceSets.PromotionRadio");
			Thread.sleep(1000);
			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		// Select first price set
		actions.click("RFMPriceSets.SelectFirst");
		// String ReplacePrcHandle = driver.getWindowHandle();
		// //actions.WaitForWindowToBe(3, 10);
		// // Switch to price sets window
		// actions.windowSwitch(ReplacePrcHandle, "Price Sets");
		// actions.WaitForElementPresent("RFMPriceSets.PriceSetSearchbox", 10);

		mcd.SwitchToWindow("Price Sets");

		// Search & Select desired price set
		actions.setValue("RFMPriceSets.PriceSetSearchbox", strpriceset1);
		actions.click("RFMPriceSets.PriceSetSearch");
		actions.waitForPageToLoad(10);
		actions.click("RFMPriceSets.PriceSet1");

		// Switch back to Replace price window
		// actions.WaitForWindowToClose(2, 10);
		// driver.switchTo().window(ReplacePrcHandle);
		// System.out.println("t:" + driver.getTitle());

		mcd.SwitchToWindow("Replace Price");

		// Select first price set
		// actions.WaitForElementPresent("RFMPriceSets.SelectSecond", 10);
		actions.click("RFMPriceSets.SelectSecond");
		// ReplacePrcHandle = driver.getWindowHandle();
		// //actions.WaitForWindowToBe(3, 10);
		// // Switch to price sets window
		// actions.windowSwitch(ReplacePrcHandle, "Price Sets");

		mcd.SwitchToWindow("Price Sets");

		// Search & Select desired price set
		// actions.WaitForElementPresent("RFMPriceSets.PriceSetSearchbox", 10);
		actions.setValue("RFMPriceSets.PriceSetSearchbox", strpriceset2);
		actions.click("RFMPriceSets.PriceSetSearch");
		actions.waitForPageToLoad(120);
		String priceset = actions.getValue("RFMPriceSets.PriceSet2");
		actions.click("RFMPriceSets.PriceSet2");

		// Switch back to Replace price window
		mcd.SwitchToWindow("Replace Price");

		// Select required type - Price/ Price & taxes
		// actions.WaitForElementPresent("RFMPriceSets.dropdown", 10);
		actions.setValue("RFMPriceSets.dropdown", strMethod);
		Thread.sleep(3000);

		// Check/Uncheck Activate Menu Items check box (Yes/No)
		actions.setValue("RFMPriceSets.Checkbox", strActivateFlag);
		Thread.sleep(3000);

		// Click on Replace button on Replace price window
		actions.click("RFMPriceSets.NewWinReplace");
		Thread.sleep(5000);

		mcd.SwitchToWindow("Price Sets");

		// Switch back to Main window (as second window is in load mode)
		// driver.switchTo().window(MainHandle);
		// Thread.sleep(3000);

		// Act on Activation Window only if Activation check box is selected
		if (strActivateFlag.equals("Yes")) {
			// Switch to Next Window, directly from main window (Skip 2nd i.e
			// Replace Price window)
			String sValue = "Activate Menu Items";
			String title = sValue.toString();
			// System.out.println(driver.getWindowHandles());
			//
			// System.out.println("Avoid - " + ReplacePrcHandle);
			// for (String handle : driver.getWindowHandles()) {
			// System.out.println("h = " + driver.getWindowHandle() + "t : " +
			// driver.getTitle());
			// if (!handle.equals(ReplacePrcHandle)) {
			// driver.switchTo().window(handle);
			// if (driver.getTitle().trim().equalsIgnoreCase(title)) {
			// System.out.println("curr : " + handle);
			// break;
			// } else {
			// System.out.println("in loop : " + driver.getTitle());
			// }
			// }
			// }

			mcd.SwitchToWindow("Activate Menu Items");

			Thread.sleep(200);

			// Verify Success Message
			// System.out.println("t:" + driver.getTitle());
			actions.verifyTextPresence("Activation process has been successfully completed.", true);

			// Click OK
			actions.keyboardEnter("ActivateMenuItem.OkBtn");
			Thread.sleep(2000);
			System.out.println(driver.getWindowHandles());

			// Switch to Main Window
			// driver.switchTo().window(MainHandle);

			mcd.SwitchToWindow("Price Sets");
		}

		// Search second Price Sets
		// And Verify whether 2nd Price set is replaced correctly by first price
		// set

		actions.WaitForElementPresent("RFMPriceSets.dropdownSearchList", 10);

		switch (strPrcSetType) {
		case "Base":

			// Base Price
			actions.setValue("RFMPriceSets.dropdownSearchList", "Base");
			Thread.sleep(1000);
			break;
		case "Promotion":

			// Promotion Price
			actions.setValue("RFMPriceSets.dropdownSearchList", "Promotional");
			Thread.sleep(1000);
			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		System.out.println("text: " + strpriceset2);
		actions.setValue("RFMPriceSets.MainSearchbox", strpriceset2);
		actions.click("RFMPriceSets.MainSearch");
		actions.waitForPageToLoad(120);
		actions.WaitForElementPresent("RFMPriceSets.PriceSet2", 10);
		actions.keyboardEnter("RFMPriceSets.PriceSet2");

		// Store Menu items for price set 2
		List<WebElement> MenuItemList2 = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));
		Boolean MenuItemCheck = false;

		// Verify whether both price sets have same menu items
		if (MenuItemList1.size() == MenuItemList2.size()) {
			MenuItemCheck = true;
			for (int f = 0; f < MenuItemList1.size(); f++) {
				if (MenuItemList1.get(f).getText().equals(MenuItemList1.get(f).getText())) {
					MenuItemCheck = true;
				} else {
					MenuItemCheck = false;
				}
			}
		}

		if (MenuItemCheck) {
			// Reporter.log("Replace functionality working correctly. Replaced
			// price set has same menu items as other price set - PASS");
			actions.reportCreatePASS("Verify Replace functionality",
					"Replace functionality working correctly. Replaced price set has same menu items as other price set",
					"Replace functionality working correctly. Replaced price set has same menu items as other price set",
					"PASS");
		} else {
			actions.reportCreateFAIL("Verify Replace functionality",
					"Replace functionality working correctly. Replaced price set has same menu items as other price set",
					"Replace functionality not working correctly.", "FAIL");
			// Reporter.log("Replace functionality working correctly. Replaced
			// price set has same menu items as other price set - FAIL");
		}
	}

	// ----------------------------------
	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Assign Base/Promotion Price set
	 * to Restaurant Scenario ID : Author : Pooja Panse
	 */
	// -----------------------------------

	// ----------------------------------

	public void RFM_PRC_AssignPrcSet_ToRest(String strNavigateRP, String strNodeNum, Object strpriceset1)
			throws Exception {

		// Navigate to Admin > Restaurant Profile
		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateRP);
		actions.select_menu("RFMHome.Pricing", strNavigateRP);
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

		// Search & Select node to which new price set needs to be assigned
		actions.setValue("RestaurantUpdt.SearchRestro", strNodeNum);
		actions.keyboardEnter("RestaurantUpdt.SearchRestroBtn");
		Thread.sleep(1000);
		actions.smartWait(120);
		// driver.findElement(By.xpath("//*[@id='restData']/tr/td[1]/a")).sendKeys(Keys.ENTER);

		mcd.GetTableCellElement("RFM.WebTable", 1, "Number", "a").click();
		Thread.sleep(1000);

		actions.smartWait(120);

		// Select MenuItem/POS tab
		actions.keyboardEnter("RestaurantUpdt.MITab");
		Thread.sleep(500);
		actions.smartWait(120);
		actions.setValue("RestaurantUpdt.SetType", "Pricing");
		Thread.sleep(500);
		actions.smartWait(120);

		// Enter Price Set name & Search
		actions.setValue("RestaurantUpdt.SrchSetType", strpriceset1);
		// Thread.sleep(500);
		actions.click("RestaurantUpdt.SearchBtn");
		Thread.sleep(1000);
		actions.smartWait(120);

		// Check whether the price set is displayed in the left hand side table
		int t_count = 0;
		int srch_cnt = mcd.GetTableRowCount("RestaurantUpdt.SearchTableLeft");
		String Srchd_Name = null;
		for (int k = 1; k <= srch_cnt; k++) {
			Srchd_Name = driver
					.findElement(
							By.xpath("//*[@id='leftsidelist']//tr[" + k + "][@onclick = 'SelectLeftRow(this)']/td[1]"))
					.getText();
			Srchd_Name = Srchd_Name.split("\\(")[0].trim();

			if (Srchd_Name.trim().equals(strpriceset1)) {
				actions.click("RestaurantUpdt.SelectPSelement");
				Thread.sleep(1000);
				actions.click("RestaurantUpdt.SelectPSelement");
				Thread.sleep(1000);
				actions.click("RestaurantUpdt.SelectPSelement");
				Thread.sleep(1000);
				actions.click("RestaurantUpdt.addbtn");
				Thread.sleep(1000);
				t_count++;
				break;
			} else {
				t_count = 0;
			}
		}

		if (t_count > 0) {
			// Reporter.log("Updated Price Set is displayed - PASS");
		} else {
			// Reporter.log("Updated Price Set is not displayed - FAIL");
		}

		Thread.sleep(3000);

		// Verify whether price set got assigned or not. i.e displayed in right
		// hand side table
		t_count = 0;
		srch_cnt = mcd.GetTableRowCount("RestaurantUpdt.SearchTable");
		// System.out.println(srch_cnt);
		Srchd_Name = null;
		for (int k = 1; k <= srch_cnt; k++) {
			Srchd_Name = mcd.GetTableCellElement("RestaurantUpdt.SearchTable", k, "Set Name", "").getText().trim();
			Srchd_Name = Srchd_Name.split("\\(")[0].trim();

			if (Srchd_Name.trim().equals(strpriceset1)) {
				t_count++;
			} else {
				t_count = 0;
			}
		}

		if (t_count > 0) {
			actions.reportCreatePASS("Verify Price set assignment", "Price set should be assigned to restaurant",
					"Price Set assigned to restaurant", "PASS");
			// Reporter.log("Price Set is assigned correctly to Restaurant
			// Profile - PASS");
		} else {
			actions.reportCreateFAIL("Verify Price set assignment", "Price set should be assigned to restaurant",
					"Price Set not assigned to restaurant", "FAIL");
			// Reporter.log("Price Set is not assigned to Restaurant Profile -
			// FAIL");
		}

		// Apply Changes
		actions.click("RestaurantUpdt.Apply");
		Thread.sleep(2000);

		// Switch to Apply Changes Details and Click on Save
		try {
			mcd.SwitchToWindow("Apply Changes Details");
			Thread.sleep(3000);

			// If - to check whether Apply Changes Details window is displayed
			// or
			// directly Run Validation Report window is displayed

			driver.findElement(By
					.xpath("//*[@id='restaurantProfile_displayEffectiveDatePopup']//a[@class = 'button'][contains(text(), 'Save')]"))
					.sendKeys(Keys.ENTER);
			Thread.sleep(5000);
		} catch (Exception e2) {
			actions.waitForPageToLoad(120);
		}

		try {
			// Switch back to Restaurant Profile window (Main Window)
			mcd.SwitchToWindow("Restaurant Profile");
			Thread.sleep(5000);

			// Switch to window Run Validation Report directly from Main window
			mcd.SwitchToWindow("Run Validation Report");
			Thread.sleep(2000);
			actions.click("RestaurantUpdtFuture.Cancel");
			Thread.sleep(3000);
			mcd.SwitchToWindow("Restaurant Profile");

			// Verify Success message
			actions.verifyTextPresence("Your changes have been saved.", true);
			Thread.sleep(1000);
		} catch (Exception e) {
			System.out.println(e);
		}

		// // Switch to Apply Changes Details and Click on Save
		// String RPHandle = driver.getWindowHandle();
		// //actions.WaitForWindowToBe(2, 10);
		// actions.windowSwitch(RPHandle, "Apply Changes Details");
		// Thread.sleep(3000);
		// System.out.println(driver.getTitle());
		// String ApplyWin = driver.getWindowHandle();
		//
		// // If - to check whether Apply Changes Details window is displayed or
		// // directly Run Validation Report window is displayed
		// if (driver.getTitle().trim().equals("Apply Changes Details")) {
		// driver.findElement(By.xpath("//*[@id='restaurantProfile_displayEffectiveDatePopup']//a[@class
		// = 'button'][contains(text(), 'Save')]")).sendKeys(Keys.ENTER);
		// Thread.sleep(10000);
		// }
		//
		// // Switch back to Restaurant Profile window (Main Window)
		// driver.switchTo().window(RPHandle);
		// Thread.sleep(3000);
		// System.out.println(driver.getTitle());
		//
		// // Switch to window Run Validation Report directly from Main window
		// for (String handle : driver.getWindowHandles()) {
		// System.out.println("h = " + driver.getWindowHandle() + "t : " +
		// driver.getTitle());
		// if (!handle.equals(ApplyWin) && !handle.equals(RPHandle)) {
		// driver.switchTo().window(handle);
		// if (driver.getTitle().trim().equalsIgnoreCase("Run Validation
		// Report")) {
		// System.out.println("curr : " + handle);
		// break;
		// } else {
		// System.out.println("in loop : " + driver.getTitle());
		// }
		// }
		// }
		//
		// Thread.sleep(2000);
		// System.out.println(driver.getTitle());
		// try {
		// // Click on Cancel button on the validation report window
		// System.out.println("In last window for prom");
		// actions.click("RestaurantUpdtFuture.Cancel");
		// Thread.sleep(5000);
		// } catch (Exception e) {
		// System.out.println(e);
		// }
		//
		// System.out.println(driver.getWindowHandles());
		// // Check if any extra drivers (other than Main window driver) are
		// open
		// // even though windows are closed.
		// // If yes > Close the drivers (except Main window driver)
		// if (driver.getWindowHandles().size() > 1) {
		// driver.close();
		// }
		//
		// // Switch back to Main Window
		// driver.switchTo().window(RPHandle);
		//
		// // Verify Success message
		// actions.verifyTextPresence("Your changes have been saved.", true);
		// Thread.sleep(1000);

	}

	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Verify Update Price Set - Copy
	 * Tax Function Scenario ID : PRC_0120 Author : Pooja Panse
	 */
	// ----------------------------------

	public void RFM_PRC_UpdatePriceSet_CopyTax(String strNewPrice, String strTaxCode, String strTaxRule,
			String strAlertMsg) throws InterruptedException {

		String Future_Date = null;
		String Price_Set_Name;

		// Get the row count of the price set list displayed
		int rw_cnt = mcd.GetTableRowCount("Price.PriceSets");

		// Check for assigned price set and select
		for (int i = 1; i < rw_cnt; i++) {
			try {
				Boolean temp = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/span/img"))
						.isDisplayed();
				if (temp) {
					Price_Set_Name = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a"))
							.getText();

					// Click on Price Set link
					driver.findElement(By.xpath("//*[@id='priceSetData']/tr[" + i + "]/td[1]/a")).click();
					Thread.sleep(5000);
					break;
				}
			} catch (Exception e) {
				System.out.println("This price set is not attached to any restaurant");
			}
		}

		// Verify that Copy Tax button is disabled
		try {
			if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.CpyTaxBtn"))).isEnabled())) {
				actions.reportCreateFAIL("Verify Copy Tax button", "Copy Tax button should be disabled by default",
						"Copy Tax button is enabled by default", "FAIL");

			}
		} catch (Exception e) {
			if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.CpyTaxStatus"))).isEnabled())) {
				actions.reportCreatePASS("Verify Copy Tax button", "Copy Tax button should be disabled by default",
						"Copy Tax button is disabled by default", "PASS");
			}
		}

		// Click on View Tax Details button
		actions.click("ManagePS.ViewTxDetails");
		actions.smartWait(180);

		// Verify that Copy Tax button is disabled
		try {
			if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.CpyTaxBtn"))).isEnabled())) {
				actions.reportCreateFAIL("Verify Copy Tax button after view full list",
						"Copy Tax button should be disabled by default", "Copy Tax button is enabled by default",
						"FAIL");

			}
		} catch (Exception e) {
			if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.CpyTaxStatus"))).isEnabled())) {
				actions.reportCreatePASS("Verify Copy Tax button after view full list",
						"Copy Tax button should be disabled by default", "Copy Tax button is disabled by default",
						"PASS");
			}
		}

		// Verify that Change date button does not exist
		try {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.ChngDtTaxBtn3"))).isDisplayed()) {
				actions.reportCreateFAIL("Verify change date button", "Change date button should not be displayed",
						"Change date button is displayed", "FAIL");
				// Reporter.log("Change date button is displayed - FAIL");

			}
		} catch (Exception e) {
			actions.reportCreatePASS("Verify change date button", "Change date button should not be displayed",
					"Change date button is not displayed", "PASS");
			// Reporter.log("Change date button is not displayed - PASS");
		}

		// Click on View Price Details button
		actions.click("ManagePS.ViewPrcDetails");
		actions.smartWait(180);

		// Select a future date from the calender
		mcd.SelectDate_OpenCalender("17", "next");
		actions.smartWait(180);

		// Note down the date selected for future reference
		String Date_displayed = driver.findElement(By.xpath(actions.getLocator("ManagePS.DateSelected"))).getText();

		// Click on View Tax Details button on Future Price settings
		actions.click("ManagePS.ViewTxDetails");
		Thread.sleep(15000);

		// Verify that Mass Update Tax Settings button is disabled
		try {
			if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.MassTaxUpdateBtn"))).isEnabled())) {
				actions.reportCreateFAIL("Verify mass update tax setting in future price changes",
						"Mass update tax setting should be disabled", "Mass update tax setting is enabled", "FAIL");

			}
		} catch (Exception e) {
			if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.UpdtTaxBtn2"))).isEnabled())) {
				actions.reportCreateFAIL("Verify mass update tax setting in future price changes",
						"Mass update tax setting should be disabled", "Mass update tax setting is disabled", "PASS");
			}
		}

		// Verify that Change Date-ManagePS.ChngDtTaxBtn3

		try {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.ChngeDateBtn"))).isDisplayed()) {
				if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.ChngeDateBtn"))).isEnabled())) {
					// Reporter.log("Future Price Changes : Change Date button
					// present & is enabled - FAIL");
					actions.reportCreateFAIL("Verfiy Change date in future price changes",
							"Change date button should not be present", "Change date button - present and enabled",
							"FAIL");
				} else {
					// Reporter.log("Future Price Changes : Change Date button
					// present & is disabled - FAIL");
					actions.reportCreateFAIL("Verfiy Change date in future price changes",
							"Change date button should not be present", "Change date button - present but disabled",
							"FAIL");
				}
			}
		} catch (Exception e) {
			actions.reportCreatePASS("Verfiy Change date in future price changes",
					"Change date button should not be present", "Change date button not present", "PASS");
			// Reporter.log("Future Price Changes : Change Date button not
			// present by default - PASS");

		}

		// Verification : Tax Code - Never ; Tax Rule & Tax Entry are
		// automatically set to None
		// Enter any valid price
		actions.setValue("PriceTypes.All", "5.00");
		
		// Set Tax Code as Never
		actions.setValue("PriceTypes.TaxCode", "Never");
		Thread.sleep(2000);

		Boolean VerifyPopUpMsg = false;
		// Pop Up message verification in case any
		try {
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
					"Tax cannot be applied to Menu Item as they are not priced.", true, AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			System.out.println(e);
		}

		if (VerifyPopUpMsg) {
			System.out.println("Warning msg before entering tax - PASS");
		} else {
			System.out.println("Warning msg before entering tax - FAIL");

		}

		// Set Tax Code = Never

		actions.setValue("PriceTypes.TaxCode", "Never");
		Thread.sleep(2000);

		Select select1 = new Select(driver.findElement(By.xpath(actions.getLocator("PriceTypes.TaxEntry"))));
		Select select2 = new Select(driver.findElement(By.xpath(actions.getLocator("PriceTypes.TaxRule"))));

		Thread.sleep(1000);

		// Verify rule & entry becomes none & disabled
		if (select1.getFirstSelectedOption().getText().equals("None")
				&& (select2.getFirstSelectedOption().getText().equals("None"))) {
			if (!(driver.findElement(By.xpath(actions.getLocator("PriceTypes.TaxEntry"))).isEnabled())
					&& !(driver.findElement(By.xpath(actions.getLocator("PriceTypes.TaxRule"))).isEnabled())) {
				// Reporter.log("For Tax Code \"Never\", Tax Entry & Tax Rule
				// are set as \"None\". - PASS");
				actions.reportCreatePASS("Verify Tax fields",
						"For tax code as Never, tax entry and tax rule should be set to None",
						"For tax code as Never, tax entry and tax rule is set to None", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Tax fields",
						"For tax code as Never, tax entry and tax rule should be set to None",
						"For tax code as Never, tax entry and tax rule is not set to None", "FAIL");
				// Reporter.log("For Tax Code \"Never\", Tax Entry & Tax Rule
				// not set as \"None\". - FAIL");

			}
		}

		// COPY TAX verification
		// Make some tax settings to verify copy tax
		actions.setValue("PriceTypes.TaxCode", strTaxCode);

		actions.setValue("PriceTypes.TaxRule", strTaxRule);

		Select select = new Select(driver.findElement(By.xpath(actions.getLocator("PriceTypes.TaxEntry"))));
		select.selectByIndex(2);
		Thread.sleep(2000);

		// Apply changes

		actions.click("FutureSettings.Apply");
		actions.smartWait(180);

		// Get Previous setting tax values for code/rule/entry
		String Curr_TaxCode = driver.findElement(By.xpath(actions.getLocator("ManagePS.PrevTaxCode"))).getText();
		if (Curr_TaxCode.equals("N/A")) {
			Curr_TaxCode = "Never";
		}

		String Curr_TaxRule = driver.findElement(By.xpath(actions.getLocator("ManagePS.PrevTaxRule"))).getText();
		if (Curr_TaxRule.equals("N/A")) {
			Curr_TaxRule = "None";
		}
		String Curr_TaxEntry = driver.findElement(By.xpath(actions.getLocator("ManagePS.PrevTaxEntry"))).getText();
		if (Curr_TaxEntry.equals("N/A")) {
			Curr_TaxEntry = "None";
		}

		System.out.println(Curr_TaxCode + ";" + Curr_TaxRule + ";" + Curr_TaxEntry);

		// Select future date link in the future price changes part
		List<WebElement> FutureDate_list = driver.findElements(By.xpath("//*[@id='futureEffectiveDate']/option"));
		int dt_row = FutureDate_list.size();
		int Temp_count = 0;

		for (int a = 1; a <= dt_row; a++) {

			try {

				WebElement FDate = driver.findElement(By.xpath("//*[@id='futureEffectiveDate']/option[" + a + "]"));
				Future_Date = FDate.getText();
				// FDate.click();
				Thread.sleep(1000);

				if (Date_displayed.equals(Future_Date)) {
					System.out.println("desired future date");
					Temp_count++;
					break;
				} else {
					System.out.println("not desired future date");
				}

			} catch (Exception e) {
				System.out.println("Not able to find date : " + e);
			}
		}

		if (Temp_count > 0) {
			actions.reportCreatePASS("Verify date",
					"Correct future date should be displayed on future price changes area",
					"Correct future date is displayed on future price changes area", "PASS");
			// Reporter.log("Correct future date is displayed on future price
			// changes area - PASS");
		} else {
			actions.reportCreateFAIL("Verify date",
					"Correct future date should be displayed on future price changes area",
					"Incorrect future date is displayed on future price changes area", "FAIL");
			// Reporter.log("Correct future date is not displayed on future
			// price changes area - FAIL");

		}

		// Verify that Mass Update Tax Settings button is displayed & enabled

		try {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.MassTaxUpdateBtn"))).isDisplayed()) {
				if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.MassTaxUpdateBtn"))).isEnabled())) {
					actions.reportCreatePASS("Verify Future Settings Applied : Mass Update Tax Settings button",
							"Mass Update Tax Settings button should be displayed & enabled",
							"Mass Update Tax Settings button is displayed & enabled", "PASS");
					// Reporter.log("Future Settings Applied : Mass Update Tax
					// Settings button is displayed & enabled - PASS");
				} else {
					actions.reportCreateFAIL("Verify Future Settings Applied : Mass Update Tax Settings button",
							"Mass Update Tax Settings button should be displayed & enabled",
							"Mass Update Tax Settings button is displayed but disabled", "FAIL");
					// Reporter.log("Future Settings Applied : Mass Update Tax
					// Settings button is disabled - FAIL");

				}
			}
		} catch (Exception e) {
			actions.reportCreateFAIL("Verify Future Settings Applied : Mass Update Tax Settings button",
					"Mass Update Tax Settings button should be displayed & enabled",
					"Mass Update Tax Settings button is not displayed", "FAIL");
			// Reporter.log("Future Settings Applied : Mass Update Tax Settings
			// button is not displayed - FAIL");

		}

		// Verify that Change Date button is displayed & enabled
		try {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.ChngeDateBtn"))).isDisplayed()) {
				if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.ChngeDateBtn"))).isEnabled())) {
					// Reporter.log("Future Settings Applied : Change Date
					// button is displayed & enabled - PASS");
					actions.reportCreatePASS("Verify Future Settings Applied : Change Date button",
							"Change Date button should be displayed & enabled",
							"Change Date button is displayed and enabled", "PASS");
				} else {
					// Reporter.log("Future Settings Applied : Change Date
					// button is disabled - FAIL");
					actions.reportCreateFAIL("Verify Future Settings Applied : Change Date button",
							"Change Date button should be displayed & enabled",
							"Change Date button is displayed but disabled", "FAIL");
				}
			}
		} catch (Exception e) {
			actions.reportCreateFAIL("Verify Future Settings Applied : Change Date button",
					"Change Date button should be displayed & enabled", "Change Date button is not displayed", "FAIL");
			// Reporter.log("Future Settings Applied : Change Date button is not
			// displayed - FAIL");
		}

		// Verify that Copy Tax button is displayed & enabled
		try {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.CpyTaxBtn"))).isDisplayed()) {
				if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.CpyTaxBtn"))).isEnabled())) {
					// Reporter.log("Future Settings Applied : Copy Tax button
					// is displayed & enabled - PASS");
					actions.reportCreatePASS("Verify Future Settings Applied : Copy Tax button",
							"Copy Tax button should be displayed & enabled", "Copy Tax button is displayed and enabled",
							"PASS");
				} else {
					// Reporter.log("Future Settings Applied : Copy Tax button
					// is disabled - FAIL");
					actions.reportCreateFAIL("Verify Future Settings Applied : Copy Tax button",
							"Copy Tax button should be displayed & enabled",
							"Copy Tax button is displayed but disabled", "FAIL");
				}
			}
		} catch (Exception e) {
			// Reporter.log("Future Settings Applied : Copy Tax button is not
			// displayed - FAIL");
			actions.reportCreateFAIL("Verify Future Settings Applied : Copy Tax button",
					"Copy Tax button should be displayed & enabled", "Copy Tax button is not displayed", "FAIL");

		}

		// Verify that Add Menu button is displayed & enabled

		try {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.FutureAddMI"))).isDisplayed()) {
				if ((driver.findElement(By.xpath(actions.getLocator("ManagePS.FutureAddMI"))).isEnabled())) {
					// Reporter.log("Future Settings Applied : Add Menu button
					// is displayed & enabled - PASS");
					actions.reportCreatePASS("Verify Future Settings Applied : Add Menu button",
							"Add Menu button should be displayed & enabled", "Add Menu button is displayed and enabled",
							"PASS");
				} else {
					// Reporter.log("Future Settings Applied : Add Menu button
					// is disabled - FAIL");
					actions.reportCreateFAIL("Verify Future Settings Applied : Add Menu button",
							"Add Menu button should be displayed & enabled",
							"Add Menu button is displayed but disabled", "FAIL");
				}
			}
		} catch (Exception e) {
			// Reporter.log("Future Settings Applied : Add Menu button is not
			// displayed - FAIL");
			actions.reportCreateFAIL("Verify Future Settings Applied : Add Menu button",
					"Add Menu button should be displayed & enabled", "Add Menu button is not displayed", "FAIL");
		}

		// Set a new price to the menu item, to verify that price changes remain
		// unchanged while performing copy tax

		actions.clear("PriceTypes.All");
		Thread.sleep(500);
		actions.clear("PriceTypes.All");
		Thread.sleep(1000);
		actions.setValue("PriceTypes.All", strNewPrice);
		Thread.sleep(2000);

		// Apply changes
		actions.click("FutureSettings.Apply");
		Thread.sleep(10000);
		actions.verifyTextPresence("Your changes have been saved.", false);
		// Reporter.log("Future settings for new price set done successfully -
		// PASS");
		actions.reportCreatePASS("Verify future setting for new price set",
				"Future settings for new price set should be done successfully",
				"Future settings for new price set done successfully", "PASS");

		// Click on Copy Tax & select Cancel
		actions.click("ManagePS.CpyTaxBtn");

		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
				"This will override existing tax setting for all the priced menu items on this page.", true,
				AlertPopupButton.CANCEL_BUTTON);
		if (VerifyPopUpMsg) {
			// Reporter.log("Warning msg b4 copy tax & Clicked Cancel - PASS");
			actions.reportCreatePASS("Verify warning message", "Warning message should be displayed, Click Cancel",
					"Warning message displayed, Click Cancel", "PASS");
		} else {
			// Reporter.log("Warning msg b4 copy tax & Clicked Cancel - FAIL");
			actions.reportCreateFAIL("Verify warning message", "Warning message should be displayed, Click Cancel",
					"Warning message not displayed, Click Cancel", "FAIL");
		}

		// Click on Copy Tax & select Ok
		actions.click("ManagePS.CpyTaxBtn");

		// Verify message - This will override existing tax setting for all the
		// priced menu items on this page.

		VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strAlertMsg, true, AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			// Reporter.log("Warning msg b4 copy tax & Clicked OK - PASS");
			actions.reportCreatePASS("Verify warning message", "Warning message should be displayed, Click OK",
					"Warning message displayed, Click OK", "PASS");
		} else {
			// Reporter.log("Warning msg b4 copy tax & Clicked OK - FAIL");
			actions.reportCreateFAIL("Verify warning message", "Warning message should be displayed, Click OK",
					"Warning message not displayed, Click OK", "FAIL");
		}

		Thread.sleep(5000);

		// Verify that - Immediate tax settings will be copied. Price will not
		// be copied

		String Copied_TaxCode = actions.getValue("PriceTypes.TaxCode");
		String Copied_TaxRule = actions.getValue("PriceTypes.TaxRule");
		String Copied_TaxEntry = actions.getValue("PriceTypes.TaxEntry");

		String Curr_Price = driver.findElement(By.xpath("//*[@name='priceSetList[0].futureAllPrice']"))
				.getAttribute("value");

		if ((Curr_TaxCode.equals(Copied_TaxCode)) && (Curr_TaxRule.equals(Copied_TaxRule))
				&& (Curr_TaxEntry.equals(Copied_TaxEntry)) && (Curr_Price.equals(strNewPrice))) {
			// Reporter.log("Copy Tax Functionality is working as expected for
			// Menu Items with previous settings - PASS");
			actions.reportCreatePASS("Verify Copy Tax Functionality",
					"Copy Tax Functionality should work as expected for Menu Items with previous settings",
					"Copy Tax Functionality is working as expected for Menu Items with previous settings", "PASS");
		} else {
			// Reporter.log("Copy Tax Functionality is not working as expected
			// for Menu Items with previous settings - FAIL");
			actions.reportCreateFAIL("Verify Copy Tax Functionality",
					"Copy Tax Functionality is working as expected for Menu Items with previous settings",
					"Copy Tax Functionality not working as expected for Menu Items with previous settings", "FAIL");

		}

		Boolean blnFlag = false;

		WebElement strActivateSelectedMI = driver
				.findElement(By.xpath(actions.getLocator("ManagePS.ActivateSelectChkBox")));
		if (strActivateSelectedMI.isSelected() && !(strActivateSelectedMI.isEnabled())) {
			actions.reportCreatePASS("", "Activate Selected Menu Item checkbox is unchecked & disabled",
					"Activate Selected Menu Item checkbox is unchecked & disabled", "PASS");
			// Reporter.log("Activate Selected Menu Item checkbox is unchecked &
			// disabled - PASS");
			blnFlag = true;
		} else {
			actions.reportCreateFAIL("", "Activate Selected Menu Item checkbox is unchecked & disabled",
					"Activate Selected Menu Item checkbox is checked or enabled", "FAIL");
			// Reporter.log("Activate Selected Menu Item checkbox is
			// checked/enabled - FALSE");

		}

		Thread.sleep(1000);

		// Verification for Menu Items with No previous settings
		// Add a menu item
		actions.click("ManagePS.FutureAddMI");
		Thread.sleep(2000);
//		String MainHandle = driver.getWindowHandle();
//
//		actions.windowSwitch(MainHandle, "Price Sets : Common Menu Item Selector");
//		Thread.sleep(2000);
//		System.out.println(driver.getTitle());
		mcd.waitAndSwitch("Price Sets : Common Menu Item Selector");

		// Click View Full list
		actions.click("CommonSelector.ViewFullBtn");
		actions.smartWait(180);

		// Select Available from Availability drop down
		actions.setValue("CommonSelector.AvailabilityDrpDwn", "Available");
		actions.smartWait(180);

		// Get all the Add check box elements
		List<WebElement> Add_Chkbox = driver
				.findElements(By.xpath(".//input[@type = 'checkbox'][contains(@onclick, 'addMenuItem')]"));
		int Item_Counts = Add_Chkbox.size();

		// Check items and add accordingly
		int i_temp = 0;
		String TXpath = null;
		List<String> MnuItem_Names = new ArrayList<String>();

		for (int n = 0; n < Item_Counts; n++) {

			// Check whether enabled for Add or not
			if ((Add_Chkbox.get(n).isEnabled())) {

				// Check box enabled - Add Item
				Add_Chkbox.get(n).sendKeys(Keys.SPACE);

				// Get Item Name
				String p = Integer.toString(n + 1);
				String e = driver.findElement(By.xpath("//*[@id='commonTableBody']/tr[" + p + "]/td[4]")).getText();
				MnuItem_Names.add(e);

				// System.out.println(MnuItem_Names.get(n));
				i_temp++;

			} else {
				System.out.println("This MI is already added");
			}

			if (i_temp == 1) {
				// Reporter.log("Selected Menu Item for Addition to the price
				// set - PASS");
				break;
			}
		}

		// Save the updates
		actions.click("CommonSelector.Save");
		Thread.sleep(3000);

		mcd.waitAndSwitch("Manage Price Sets");

		// Get the list of items displayed
		List<WebElement> Added_Items = driver.findElements(By.xpath(actions.getLocator("ManagePS.ListofAddedMI")));
		// System.out.println(Added_Items.size());
		int AddItem_check = 0;

		for (int k = 0; k < Added_Items.size(); k++) {
			String Added_ItemName = Added_Items.get(k).getText().split("-")[1].trim();

			// Verify that the added items are same as displayed items
			if (Added_ItemName.equals(MnuItem_Names.get(k))) {
				AddItem_check++;
			} else {
				System.out.println("Check " + Added_ItemName);
				System.out.println("Check " + MnuItem_Names.get(k));
			}
		}

		if (AddItem_check == 1) {
			actions.reportCreatePASS("Verify menu items displayed", "Only newly added items should be displayed",
					"Only newly added items are displayed", "PASS");
			// Reporter.log("Only newly added menu items are displayed as
			// expected - PASS");
		} else {
			actions.reportCreateFAIL("Verify menu items displayed", "Only newly added items should be displayed",
					"Items are incorrectly displayed", "FAIL");
		}

		// Verify Previous & Future tax setting values for newly added menu item

		String Prev_TaxCode = driver.findElement(By.xpath(actions.getLocator("ManagePS.PrevTaxCode"))).getText();
		String Prev_TaxRule = driver.findElement(By.xpath(actions.getLocator("ManagePS.PrevTaxRule"))).getText();
		String Prev_TaxEntry = driver.findElement(By.xpath(actions.getLocator("ManagePS.PrevTaxEntry"))).getText();

		String Future_TaxCode = actions.getValue("PriceTypes.TaxCode");
		String Future_TaxRule = actions.getValue("PriceTypes.TaxRule");
		String Future_TaxEntry = actions.getValue("PriceTypes.TaxEntry");

		if ((Prev_TaxCode.equals("N/A")) && (Prev_TaxRule.equals("N/A")) && (Prev_TaxEntry.equals("N/A"))) {
			blnFlag = true;
			actions.reportCreatePASS("Verify Previous Settings",
					"Previous Settings should be set as N/A for Menu Items without previous settings",
					"Previous Settings are set as N/A for Menu Items without previous settings", "PASS");
			// Reporter.log("Previous Settings are set as N/A for Menu Items
			// without previous settings - PASS");
		} else {
			blnFlag = false;
			actions.reportCreateFAIL("Verify Previous Settings",
					"Previous Settings should be set as N/A for Menu Items without previous settings",
					"Previous Settings are not set as N/A for Menu Items without previous settings", "FAIL");
			// Reporter.log("Previous Settings are not set as N/A for Menu Items
			// without previous settings - FAIL");

		}

		if ((Future_TaxCode.equals("Default")) && (Future_TaxRule.equals("Default"))
				&& (Future_TaxEntry.equals("Default"))) {
			blnFlag = true;
			actions.reportCreatePASS("Verify future settings",
					"Future Settings should be set as Default for Menu Items without previous settings",
					"Future Settings are set as Default for Menu Items without previous settings", "PASS");
			// Reporter.log("Future Settings are set as Default for Menu Items
			// without previous settings - PASS");
		} else {
			blnFlag = false;
			actions.reportCreateFAIL("Verify future settings",
					"Future Settings should be set as Default for Menu Items without previous settings",
					"Future Settings are not set as Default for Menu Items without previous settings", "FAIL");
			// Reporter.log("Future Settings are not set as Default for Menu
			// Items without previous settings - FAIL");

		}

		if (blnFlag) {
			actions.reportCreatePASS("Verify Previous & Future Settings",
					"Should be displayed correctly for Menu Items without previous settings",
					"Displayed correctly for Menu Items without previous settings", "PASS");
			// Reporter.log("Previous & Future Settings are displayed correctly
			// for Menu Items without previous settings - PASS");
		} else {
			actions.reportCreateFAIL("Verify Previous & Future Settings",
					"Should be displayed correctly for Menu Items without previous settings",
					"Displayed incorrectly for Menu Items without previous settings", "FAIL");
			// Reporter.log("Previous & Future Settings are not displayed
			// correctly for Menu Items without previous settings - FAIL");

		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Get 2 Base & 2 Promotional
	 * Price set for TC PRC_0139 Scenario ID : Output used in PRC_0139 Author :
	 * Pooja Panse
	 */
	// -----------------------------------

	public String[] RFM_PRC_GetPriceSetNameArray() throws InterruptedException {
		String PriceSets[] = new String[4];

		// Base Price
		// Get 2 Base Price Set names
		// Price Set Type set as Base
		actions.setValue("RFMPriceSets.dropdownSearchList", "Base");
		Thread.sleep(1000);

		// Type any letter to search price set & Click Search
		actions.setValue("RFMPriceSets.MainSearchbox", "a");
		actions.click("RFMPriceSets.MainSearch");

		// Get row count of number of price sets fetched
		int rw_cnt = mcd.GetTableRowCount("PriceSet.Table");

		List<WebElement> PrcSet_List = driver.findElements(By.xpath("//*[@id='currentLink']"));

		// The number of price sets must be greater than or equal to 2,
		// As we need 2 sets to perform replace
		if (rw_cnt >= 2) {
			PriceSets[0] = PrcSet_List.get(0).getText();
			PriceSets[1] = PrcSet_List.get(1).getText();
		} else {
			// Reporter.log("Two Base Price sets not available for Replace -
			// FAIL");

		}

		// Promotion Price
		// Get 2 Base Promotional Set names
		// Price Set Type set as promotional
		actions.setValue("RFMPriceSets.dropdownSearchList", "Promotional");
		Thread.sleep(1000);

		actions.clear("RFMPriceSets.MainSearchbox");
		Thread.sleep(500);
		// Type any letter to search price set & Click Search
		actions.setValue("RFMPriceSets.MainSearchbox", "a");
		actions.click("RFMPriceSets.MainSearch");

		// Get row count of number of price sets fetched
		rw_cnt = mcd.GetTableRowCount("PriceSet.Table");

		PrcSet_List = driver.findElements(By.xpath("//*[@id='currentLink']"));

		// The number of price sets must be greater than or equal to 2,
		// As we need 2 sets to perform replace
		if (rw_cnt >= 2) {
			PriceSets[2] = PrcSet_List.get(0).getText();
			PriceSets[3] = PrcSet_List.get(1).getText();
		} else {
			// Reporter.log("Two Promotional Price sets not available for
			// Replace - FAIL");

		}

		return PriceSets;
	}

	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Verify that Base Price set
	 * cannot be overwritten with Promotional Price set or vice-versa Scenario
	 * ID : PRC_0139 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_ReplacePriceSetValidation(String strPriceSetType, String PriceSet1, String PriceSet2,
			String PriceSet3) throws Exception {

		String strDiffSet = null;
		// Get Main Page Window Handle
		String MainHandle = driver.getWindowHandle();

		// Click Replace
		actions.click("RFMPriceSets.ReplaceBtn");
		// actions.WaitForWindowToBe(2, 10);

		// Switch to Replace Price window
		actions.windowSwitch(MainHandle, "Replace Price");
		actions.WaitForElementPresent("RFMPriceSets.SelectFirst", 10);

		// Select check box as per Base/Promotion

		switch (strPriceSetType) {
		case "Base":

			// Base Price
			actions.click("RFMPriceSets.BaseRadio");
			Thread.sleep(1000);
			strDiffSet = "Promotional";
			break;
		case "Promotional":

			// Promotion Price
			actions.click("RFMPriceSets.PromotionRadio");
			Thread.sleep(1000);
			strDiffSet = "Base";
			break;
		default:
			// Reporter.log("Please enter correct Price Set Type
			// (Base/Promotional)");
			actions.reportCreateFAIL("Verify test data", "Data should be correct",
					"enter correct Price Set Type (Base/Promotional)", "FAIL");

			break;
		}

		// Select first price set
		actions.click("RFMPriceSets.SelectFirst");
		String ReplacePrcHandle = driver.getWindowHandle();
		// actions.WaitForWindowToBe(3, 10);

		// Switch to price sets window
		actions.windowSwitch(ReplacePrcHandle, "Price Sets");
		//actions.WaitForElementPresent("RFMPriceSets.PriceSetSearchbox", 10);
		actions.WaitForElementPresent("RecipeReport.SearchTextbox", 10);

		// Search & Select desired price set
		System.out.println("Entering 1st " + strPriceSetType + " Price Set");
		//actions.setValue("RFMPriceSets.PriceSetSearchbox", PriceSet1);
		actions.setValue("RecipeReport.SearchTextbox", PriceSet1);
		actions.click("RFMPriceSets.PriceSetSearch");
		actions.waitForPageToLoad(10);
		actions.click("RFMPriceSets.PriceSet1");

		// Switch back to Replace price window
		actions.WaitForWindowToClose(2, 10);
		driver.switchTo().window(ReplacePrcHandle);
		System.out.println("t:" + driver.getTitle());

		// Select second price set

		actions.WaitForElementPresent("RFMPriceSets.SelectSecond", 10);
		actions.click("RFMPriceSets.SelectSecond");
		ReplacePrcHandle = driver.getWindowHandle();
		// actions.WaitForWindowToBe(3, 10);
		// Switch to price sets window
		actions.windowSwitch(ReplacePrcHandle, "Price Sets");

		// Search & Select desired 2nd price set
		System.out.println("Entering 2nd " + strPriceSetType + " Price Set");
		actions.WaitForElementPresent("RecipeReport.SearchTextbox", 10);
		actions.setValue("RecipeReport.SearchTextbox", PriceSet2);
		actions.click("RFMPriceSets.PriceSetSearch");
		actions.waitForPageToLoad(10);

		//driver.findElement(By.xpath(actions.getLocator("RFMPriceSets.PriceSetSearchbox")));
		int search_count = mcd.GetTableRowCount("RFMPriceSets.SearcResultTable");
		String SearchdSet = actions.getValue("RFMPriceSets.PriceSet2");
		if (SearchdSet.equals(PriceSet2)) {
			// Reporter.log("Only "+strPriceSetType+" price set is available to
			// be replaced by a "+strPriceSetType+" price set. - PASS");
			actions.reportCreatePASS("Verify price set for replace", "Only expected price set should be listed",
					"Only " + strPriceSetType + " price set is available to be replaced by a " + strPriceSetType
							+ " price set.",
					"PASS");
		} else {
			// Reporter.log("Searched "+strPriceSetType+" Price Set is not
			// displayed - FAIL");
			actions.reportCreatePASS("Verify price set for replace", "Only expected price set should be listed",
					"Searched " + strPriceSetType + " Price Set is not displayed", "FAIL");

		}

		// Search & Select different price set

		System.out
				.println("Entering " + strDiffSet + " Price Set to be replaced by a " + strPriceSetType + " Price Set");

		actions.WaitForElementPresent("RecipeReport.SearchTextbox", 10);
		actions.clear("RecipeReport.SearchTextbox");
		Thread.sleep(500);
		actions.setValue("RecipeReport.SearchTextbox", PriceSet3);
		Thread.sleep(2000);
		actions.click("RFMPriceSets.PriceSetSearch");
		actions.waitForPageToLoad(10);

		search_count = mcd.GetTableRowCount("RFMPriceSets.SearcResultTable");

		actions.verifyTextPresence("Search returned no matching results.", false);

		if (search_count == 0) {
			// Reporter.log("A "+strPriceSetType+" price set can not replace a
			// "+strDiffSet+" price set - PASS");
			actions.reportCreatePASS("Verify Replace functionality",
					"A " + strPriceSetType + " price set can not replace a " + strDiffSet + " price set",
					"A " + strPriceSetType + " price set can not replace a " + strDiffSet + " price set", "PASS");
		} else {
			SearchdSet = actions.getValue("RFMPriceSets.PriceSet2");
			if (SearchdSet.equals(PriceSet3)) {
				actions.reportCreateFAIL("Verify Replace functionality",
						"A " + strPriceSetType + " price set can not replace a " + strDiffSet + " price set",
						"A " + strPriceSetType + " price set can replace a " + strDiffSet + " price set", "FAIL");
				// Reporter.log("A "+strPriceSetType+" price set can replace a
				// "+strDiffSet+" price set - FAIL");

			} else {
				actions.reportCreateFAIL("Verify Replace functionality",
						"A " + strPriceSetType + " price set can not replace a " + strDiffSet + " price set",
						"Searched " + strPriceSetType + " Price Set is not displayed", "FAIL");
				// Reporter.log("Searched "+strPriceSetType+" Price Set is not
				// displayed - FAIL");

			}
		}

		driver.close();
		Thread.sleep(2000);

		driver.switchTo().window(ReplacePrcHandle);
		Thread.sleep(2000);
		System.out.println(driver.getTitle());

		// Click on Cancel. Warning message should display
		actions.click("RFMPriceSets.CancelBtn");
		Thread.sleep(3000);
		actions.acceptAlert();

		driver.close();
		Thread.sleep(2000);

		driver.switchTo().window(MainHandle);
		Thread.sleep(2000);
		System.out.println(driver.getTitle());

	}

	// ----------------------------------
	/*
	 * Feature Name : Admin Functionality : Update Settings Scenario ID : Used
	 * for pre-requisites in Pricing functions Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_Admin_Update_PricingTags(String strTagValue, String strTagName1, String strTagName2)
			throws InterruptedException {

		// Check for parameters :
		// General :
		// automatically-fill-price-type-attribute-option-price-value =
		// automatically-fill-price-type-attribute-option-tax-value =

		int cnt = 3;
		List<WebElement> Parameter_Lists = driver.findElements(By.xpath("//*[@id='ApplicationParameters']/tr/td[2]/b"));

		for (int i = 0; i < Parameter_Lists.size(); i++) {
			String curr_parameter = Parameter_Lists.get(i).getText();

			// Check whether section name is "General"
			if (curr_parameter.equals("General")) {
				driver.findElement(By.xpath("//*[@id='ApplicationParameters']/tr[" + cnt + "]/td[1]")).click();
				Thread.sleep(1000);
				break;
			} else {
				cnt = cnt + 2;
			}
		}

		// Get row counts of parameters displayed
		int p_rows = mcd.GetTableRowCount("UpdateSettings.GeneralParamTbl");
		String tag = null;
		String curr_val = null;
		String new_val = null;
		int iTemp = 0;
		int tag_cnt = 0;

		// Check for the mentioned 2 tags & check whether they are set to
		// expected value
		for (int j = 1; j <= p_rows; j++) {
			tag = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[1]")).getText();

			if (tag.equals(strTagName1)) {
				curr_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input"))
						.getAttribute("value");

				if (curr_val.equals(strTagValue)) {
					// Reporter.log(tag + " - Tag value is already set to " +
					// strTagValue);
				} else {
					driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[3]/input")).sendKeys(strTagValue);
					tag_cnt++;
				}
			}

			if (tag.equals(strTagName2)) {

				curr_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input"))
						.getAttribute("value");

				if (curr_val.equals(strTagValue)) {
					// Reporter.log(tag + " - Tag value is already set to " +
					// strTagValue);
				} else {
					driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[3]/input")).sendKeys(strTagValue);
					tag_cnt++;
				}
			}
		}

		// Save the changes
		if (tag_cnt > 0) {
			actions.click("UpdateSettings.SaveBtn");

			Thread.sleep(1000);
			actions.smartWait(180);

			actions.verifyTextPresence("Your changes have been saved and cache is refreshed.", false);

			// Verify tag values - whether changes are reflected correctly

			for (int j = 1; j <= p_rows; j++) {
				tag = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[1]")).getText();

				if (tag.equals(strTagName1)) {
					new_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input"))
							.getAttribute("value");

					if (new_val.equals(strTagValue)) {
						// Reporter.log(tag + " - Tag value is correctly updated
						// - PASS");
						actions.reportCreatePASS("Verify tag value", tag + " - Tag value should be correctly updated.",
								tag + " - Tag value is correctly updated.", "PASS");
						// System.out.println("Tag 1 value correctly updated");
					} else {
						actions.reportCreateFAIL("Verify tag value", tag + " - Tag value should be correctly updated.",
								tag + " - Tag value is not correctly updated.", "FAIL");
						// Reporter.log(tag + " - Tag value is incorrectly
						// updated - FAIL");
					}
				}

				if (tag.equals(strTagName2)) {

					new_val = driver.findElement(By.xpath("//*[@id='div5']//tr[" + j + "]/td[2]/input"))
							.getAttribute("value");

					if (new_val.equals(strTagValue)) {
						actions.reportCreatePASS("Verify tag value", tag + " - Tag value should be correctly updated.",
								tag + " - Tag value is correctly updated.", "PASS");
						// Reporter.log(tag + " - Tag value is correctly updated
						// - PASS");
					} else {
						actions.reportCreateFAIL("Verify tag value", tag + " - Tag value should be correctly updated.",
								tag + " - Tag value is not correctly updated.", "FAIL");
						// Reporter.log(tag + " - Tag value is incorrectly
						// updated - FAIL");
					}
				}
			}
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing Functionality : Price Sets - Verify price & tax
	 * attributes when admin settings for below tags are set to values
	 * (0/1/2/3/4) //Tag 1 -
	 * automatically-fill-price-type-attribute-option-price-value //Tag 2 -
	 * automatically-fill-price-type-attribute-option-tax-value Scenario ID :
	 * PRC_0158 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_PS_VerifyTaxSettingAttribute(String strPriceSetType, String strNewPrice, String strNavigateTo,
			String strsetPrice, String strTagValue, String strPrcNavigateTo, String strPopUpMsg1, String strPopUpMsg2,
			String strTagName1, String strTagName2) throws Exception {
		// String Future_Date = null;

		Boolean VerifyPopUpMsg = false;
		String strSetting = null;
		String strPriceSetName = null;
		// Base Price

		// Price Set Type set as Base
		actions.setValue("RFMPriceSets.dropdownSearchList", strPriceSetType);
		Thread.sleep(1000);

		// Type any letter to search price set & Click Search
		actions.setValue("RFMPriceSets.MainSearchbox", "a");
		Thread.sleep(1000);
		actions.keyboardEnter("RFMPriceSets.MainSearch");
		Thread.sleep(1000);
		actions.smartWait(120);

		// Get row count of number of price sets fetched
		int rw_cnt = mcd.GetTableRowCount("PriceSet.Table");

		if (rw_cnt > 0) {
			strPriceSetName = driver.findElement(By.xpath("//*[@id='priceSetData']/tr[1]/td[1]/a")).getText();

			// Click on Price Set link
			driver.findElement(By.xpath("//*[@id='priceSetData']/tr[1]/td[1]/a")).click();
			Thread.sleep(5000);
		} else {
			// Reporter.log("There are no "+strPriceSetType+" price sets in this
			// market");
			actions.reportCreateFAIL("Verify price set", "Price sets should be available",
					"There are no " + strPriceSetType + " price sets in this market", "FAIL");
		}

		Thread.sleep(3000);
		mcd.waitAndSwitch("#Title");

		// Execute same test for
		// d = 0 >> Current Settings; d = 1 >> Future Setting

		for (int d = 0; d <= 1; d++) {

			// Click on future setting date if d = 1
			// As we now want to run the TC for future settings

			if (d == 1) {

				// Check whether the price set has future settings.
				// If not, create future setting for the price set

				WebElement NewFutureDt = RFM_PRC_BasePS_CreateFutureSetting(strNewPrice, strPrcNavigateTo,
						strPriceSetName);
				System.out.println(NewFutureDt.getText());
				String temp = NewFutureDt.getText();
				strSetting = "Future Settings";

				NewFutureDt.click();
				actions.smartWait(120);
				//Thread.sleep(2000);
				actions.waitForPageToLoad(120);
			} else {
				strSetting = "Current Settings";
			}

			try {
				Thread.sleep(4000);
				if (driver.findElement(By.xpath(actions.getLocator("ManagePS.ViewTxDetails"))).isDisplayed()) {
					// Click on View Tax Details																															
					actions.click("ManagePS.ViewTxDetails");
					actions.waitForPageToLoad(120);
				}
			} catch (Exception e) {
				Thread.sleep(4000);
				if (driver.findElement(By.xpath(actions.getLocator("ManagePS.ViewPrcDetails"))).isDisplayed()) {
					// Reporter.log("Tax View is already in display mode");
					actions.waitForPageToLoad(120);
				}
			}

			try {
				String test = null;
				if (d == 0) {
					test = driver.findElement(By.xpath("//tr[3]//tr[2]")).getAttribute("style");
				} else if (d == 1) {
					test = driver.findElement(By.xpath("//tr[3]//tr[6]")).getAttribute("style");
				}
				if (test.equalsIgnoreCase("")) {
					// Reporter.log("Price & Tax settings are displayed in
					// collapsed mode");
					List<WebElement> ExpandIcons = driver
							.findElements(By.xpath("//img[contains(@id, 'priceTypeExpand')]/.."));
					ExpandIcons.get(0).click();
				} else if (test.substring(0, 8).equalsIgnoreCase("display")) {
					// Reporter.log("Price & Tax settings are displayed in
					// expanded mode");
				}
				actions.smartWait(180);
				Thread.sleep(500);

			} catch (Exception e) {
				System.out.println(e);
			}

			if(driver.findElement(By.xpath(actions.getLocator("PriceSets.SBExpandbtn"))).isDisplayed()){
				driver.findElement(By.xpath(actions.getLocator("PriceSets.SBExpandbtn"))).click();
			}
			// Clear Price Settings
			actions.clear("PriceTypes.Eating");
			actions.clear("PriceTypes.TO");
			actions.clear("PriceTypes.Other");
			// Set Tax settings for 1st menu item as default

			actions.setValue("ManagePS.EatingTaxCode", "Default");
			Thread.sleep(500);
			actions.setValue("ManagePS.TOTaxCode", "Default");
			Thread.sleep(500);
			actions.setValue("ManagePS.OtherTaxCode", "Default");
			Thread.sleep(500);
			actions.setValue("ManagePS.EatingTaxRule", "Default");
			Thread.sleep(500);
			actions.setValue("ManagePS.TOTaxRule", "Default");
			Thread.sleep(500);
			actions.setValue("ManagePS.OtherTaxRule", "Default");
			Thread.sleep(500);
			actions.setValue("ManagePS.EatingTaxEntry", "Default");
			Thread.sleep(500);
			actions.setValue("ManagePS.TOTaxEntry", "Default");
			Thread.sleep(500);
			actions.setValue("ManagePS.OtherTaxEntry", "Default");
			Thread.sleep(500);

			if (strTagValue.equals("4")) {

				// Set some value in Eating Price
				// Set Eating Tax settings as Never; None; None
				actions.setValue("PriceTypes.TO", strsetPrice);
				Thread.sleep(4000);

				actions.setValue("ManagePS.TOTaxCode", "Never");
				Thread.sleep(1000);
				Boolean blnResult = false;

				VerifyPopUpMsg = false;
				// Pop Up message verification in case any
				try {
					VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strPopUpMsg1, true,
							AlertPopupButton.OK_BUTTON);
				} catch (Exception e) {
					System.out.println(e);
				}

				if (VerifyPopUpMsg) {
					System.out.println("Warning msg before entering tax - PASS");
				} else {
					System.out.println("Warning msg before entering tax - FAIL");

				}

				actions.setValue("ManagePS.TOTaxCode", "Never");
				Thread.sleep(1000);

			} else {
				// Set some value in Eating Price
				// Set Eating Tax settings as Never; None; None
				actions.setValue("PriceTypes.Eating", strsetPrice);
				Thread.sleep(4000);

				actions.setValue("ManagePS.EatingTaxCode", "Never");
				Thread.sleep(1000);
				Boolean blnResult = false;

				VerifyPopUpMsg = false;
				// Pop Up message verification in case any
				try {
					VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strPopUpMsg1, true,
							AlertPopupButton.OK_BUTTON);
				} catch (Exception e) {
					System.out.println(e);
				}

				if (VerifyPopUpMsg) {
					System.out.println("Warning msg before entering tax - PASS");
				} else {
					System.out.println("Warning msg before entering tax - FAIL");

				}

				actions.setValue("ManagePS.EatingTaxCode", "Never");
				Thread.sleep(1000);
			}

			// blnResult = false;
			// Take all Field values

			// Price Settings
			String strEatPrice = driver.findElement(By.xpath(actions.getLocator("PriceTypes.Eating")))
					.getAttribute("value");
			String strTOPrice = driver.findElement(By.xpath(actions.getLocator("PriceTypes.TO"))).getAttribute("value");
			String strOtherPrice = driver.findElement(By.xpath(actions.getLocator("PriceTypes.Other")))
					.getAttribute("value");

			// Tax Values
			String strETaxCode = actions.getValue("ManagePS.EatingTaxCode");
			String strTOTaxCode = actions.getValue("ManagePS.TOTaxCode");
			String strOthTaxCode = actions.getValue("ManagePS.OtherTaxCode");
			String strETaxRule = actions.getValue("ManagePS.EatingTaxRule");
			String strTOTaxRule = actions.getValue("ManagePS.TOTaxRule");
			String strOThTaxRule = actions.getValue("ManagePS.OtherTaxRule");
			String strETaxEntry = actions.getValue("ManagePS.EatingTaxEntry");
			String strTOTaxEntry = actions.getValue("ManagePS.TOTaxEntry");
			String strOthTaxEntry = actions.getValue("ManagePS.OtherTaxEntry");

			boolean blnResult = false;
			int PassCnt = 0;
			switch (strTagValue) {
			case "0":

				// Price Settings
				if ((!(strTOPrice.equals(strEatPrice))) && (!(strOtherPrice.equals(strEatPrice)))) {
					if ((strTOPrice.isEmpty()) && (strOtherPrice.isEmpty())) {
						// Reporter.log(strSetting+" : Eating Price values not
						// copied to other & take out fields - PASS");
						actions.reportCreatePASS("Verify Take out & Other Fields",
								strSetting + " : Eating Price values should not be copied to other & take out fields",
								strSetting + " : Eating Price values not copied to other & take out fields", "PASS");
						blnResult = true;
					} else {
						// Reporter.log(strSetting+" : Eating Price copied to
						// other & take out fields - FAIL");
						actions.reportCreateFAIL("Verify Take out & Other Fields",
								strSetting + " : Eating Price values should not be copied to other & take out fields",
								strSetting + " : Eating Price values copied to other & take out fields", "FAIL");
						blnResult = false;
					}
				} else {
					actions.reportCreateFAIL("Verify Take out & Other Fields",
							strSetting + " : Eating Price values should not be copied to other & take out fields",
							strSetting + " : Eating Price values copied to other & take out fields", "FAIL");
					// Reporter.log(strSetting+" : Eating Price copied to other
					// & take out fields - FAIL");
					blnResult = false;
				}

				// Tax Settings
				// Tax Code
				if ((!(strTOTaxCode.equals(strETaxCode))) && (!(strOthTaxCode.equals(strETaxCode)))) {
					if ((strTOTaxCode.equals("Default")) && (strOthTaxCode.equals("Default"))) {
						PassCnt++;
					} else {
						actions.reportCreateFAIL("Verify Tax Code", "Tax Code should be displayed as expected",
								"Tax Code is not displayed as expected", "FAIL");
						// Reporter.log("Tax Code is not displayed as expected -
						// FAIL");
					}
				} else {
					actions.reportCreateFAIL("Verify Tax Code", "Tax Code should be displayed as expected",
							"Tax Code is not displayed as expected", "FAIL");
					// Reporter.log("Tax Code is not displayed as expected -
					// FAIL");
				}

				// Tax Rule
				if ((!(strTOTaxRule.equals(strETaxRule))) && (!(strOThTaxRule.equals(strETaxRule)))) {
					if ((strTOTaxRule.equals("Default")) && (strOThTaxRule.equals("Default"))) {
						PassCnt++;
					} else {
						actions.reportCreateFAIL("Verify Tax Rule", "Tax Rule should be displayed as expected",
								"Tax Rule is not displayed as expected", "FAIL");
						// Reporter.log("Tax Rule is not displayed as expected -
						// FAIL");
					}
				} else {
					// Reporter.log("Tax Rule is not displayed as expected -
					// FAIL");
					actions.reportCreateFAIL("Verify Tax Rule", "Tax Rule should be displayed as expected",
							"Tax Rule is not displayed as expected", "FAIL");
				}

				// Tax Entry
				if ((!(strTOTaxEntry.equals(strETaxCode))) && (!(strOthTaxEntry.equals(strETaxEntry)))) {
					if ((strTOTaxEntry.equals("Default")) && (strOthTaxEntry.equals("Default"))) {
						PassCnt++;
					} else {
						actions.reportCreateFAIL("Verify Tax Entry", "Tax Entry should be displayed as expected",
								"Tax Entry is not displayed as expected", "FAIL");
					}
				} else {
					actions.reportCreateFAIL("Verify Tax Entry", "Tax Entry should be displayed as expected",
							"Tax Entry is not displayed as expected", "FAIL");
				}

				break;

			case "1":
				// Price Settings
				if (((strTOPrice.equals(strEatPrice))) && ((strOtherPrice.equals(strEatPrice)))) {
					actions.reportCreatePASS("Verify Take out & other price setting",
							strSetting + " : Eating Price should be copied to take out & other fields",
							strSetting + " : Eating Price copied to take out & other fields", "PASS");
					// Reporter.log(strSetting+" : Eating Price copied to take
					// out & other fields - PASS");
					blnResult = true;
				} else {
					actions.reportCreateFAIL("Verify Take out & other price setting",
							strSetting + " : Eating Price should be copied to take out & other fields",
							strSetting + " : Eating Price not copied to take out & other fields", "FAIL");
					// Reporter.log(strSetting+" : Eating Price not copied to
					// take out & other fields - FAIL");
				}

				// Tax Settings
				// Tax Code
				if (((strTOTaxCode.equals(strETaxCode))) && ((strOthTaxCode.equals(strETaxCode)))) {
					PassCnt++;
				} else {
					actions.reportCreateFAIL("Verify Tax Code", "Tax Code should be displayed as expected",
							"Tax Code is not displayed as expected", "FAIL");
				}

				// Tax Rule
				if (((strTOTaxRule.equals(strETaxRule))) && ((strOThTaxRule.equals(strETaxRule)))) {
					PassCnt++;
				} else {
					actions.reportCreateFAIL("Verify Tax Rule", "Tax Rule should be displayed as expected",
							"Tax Rule is not displayed as expected", "FAIL");
				}

				// Tax Entry
				if (((strTOTaxEntry.equals(strETaxEntry))) && ((strOthTaxEntry.equals(strETaxEntry)))) {
					PassCnt++;
				} else {
					actions.reportCreateFAIL("Verify Tax Entry", "Tax Entry should be displayed as expected",
							"Tax Entry is not displayed as expected", "FAIL");
				}

				break;
			case "2":

				// Price Settings
				if (((strTOPrice.equals(strEatPrice))) && (!(strOtherPrice.equals(strEatPrice)))
						&& (strOtherPrice.isEmpty())) {
					actions.reportCreatePASS("Verify 'other' price setting",
							strSetting + " : Eating Price should be copied to other fields",
							strSetting + " : Eating Price copied to other fields", "PASS");
					// Reporter.log(strSetting+" : Eating Price copied to take
					// out field only, not to other field - PASS");
					blnResult = true;
				} else {
					actions.reportCreateFAIL("Verify 'other' price setting",
							strSetting + " : Eating Price should be copied to other fields",
							strSetting + " : Eating Price not copied to other fields", "FAIL");
					// Reporter.log(strSetting+" : Eating Price copy to other
					// fields - FAIL");
					blnResult = false;
				}

				// Tax Settings
				// Tax Code
				if (((strTOTaxCode.equals(strETaxCode))) && (!(strOthTaxCode.equals(strETaxCode)))
						&& (strOthTaxCode.equals("Default"))) {
					PassCnt++;
				} else {
					actions.reportCreateFAIL("Verify Tax Code", "Tax Code should be displayed as expected",
							"Tax Code is not displayed as expected", "FAIL");
				}

				// Tax Rule
				if (((strTOTaxRule.equals(strETaxRule))) && (!(strOThTaxRule.equals(strETaxRule)))
						&& (strOThTaxRule.equals("Default"))) {
					PassCnt++;
				} else {
					actions.reportCreateFAIL("Verify Tax Rule", "Tax Rule should be displayed as expected",
							"Tax Rule is not displayed as expected", "FAIL");
				}

				// Tax Entry
				if (((strTOTaxEntry.equals(strETaxEntry))) && (!(strOthTaxEntry.equals(strETaxEntry)))
						&& (strOthTaxEntry.equals("Default"))) {
					PassCnt++;
				} else {
					actions.reportCreateFAIL("Verify Tax Entry", "Tax Entry should be displayed as expected",
							"Tax Entry is not displayed as expected", "FAIL");
				}
				break;

			case "3":

				// Price Settings
				if ((!(strTOPrice.equals(strEatPrice))) && ((strOtherPrice.equals(strEatPrice)))
						&& (strTOPrice.isEmpty())) {
					// Reporter.log(strSetting+" : Eating price copied to other
					// price only, not to take out setting - PASS");
					actions.reportCreatePASS("Verify take out & 'other' price setting",
							strSetting + " : Eating Price should be copied to other price only, not take out",
							strSetting + " : Eating Price copied to other fields, not take out price", "PASS");
					blnResult = true;
				} else {
					// Reporter.log(strSetting+" : Eating Price copy to take out
					// fields - FAIL");
					actions.reportCreateFAIL("Verify take out & 'other' price setting",
							strSetting + " : Eating Price should be copied to other price only, not take out",
							strSetting + " : Eating Price copied to other fields and take out price", "FAIL");
					blnResult = false;
				}

				// Tax Settings
				// Tax Code
				if ((!(strTOTaxCode.equals(strETaxCode))) && ((strOthTaxCode.equals(strETaxCode)))
						&& (strTOTaxCode.equals("Default"))) {
					PassCnt++;
				} else {
					actions.reportCreateFAIL("Verify Tax Code", "Tax Code should be displayed as expected",
							"Tax Code is not displayed as expected", "FAIL");
				}

				// Tax Rule
				if ((!(strTOTaxRule.equals(strETaxRule))) && ((strOThTaxRule.equals(strETaxRule)))
						&& (strTOTaxRule.equals("Default"))) {
					PassCnt++;
				} else {
					actions.reportCreateFAIL("Verify Tax Rule", "Tax Rule should be displayed as expected",
							"Tax Rule is not displayed as expected", "FAIL");
				}

				// Tax Entry
				if ((!(strTOTaxEntry.equals(strETaxEntry))) && ((strOthTaxEntry.equals(strETaxEntry)))
						&& (strTOTaxEntry.equals("Default"))) {
					PassCnt++;
				} else {
					actions.reportCreateFAIL("Verify Tax Entry", "Tax Entry should be displayed as expected",
							"Tax Entry is not displayed as expected", "FAIL");
				}
				break;
			case "4":

				// Price Settings
				if ((!(strTOPrice.equals(strEatPrice))) && ((strOtherPrice.equals(strTOPrice)))
						&& (strEatPrice.isEmpty())) {
					actions.reportCreatePASS("Verify eating & 'other' price setting",
							strSetting
									+ " : Take out price should be copied to other price only, not to eating setting",
							strSetting + " : Take out price copied to other price only, not to eating setting", "PASS");
					// Reporter.log(strSetting+" : Take out price copied to
					// other price only, not to eating setting - PASS");
					blnResult = true;
				} else {
					actions.reportCreateFAIL("Verify eating & 'other' price setting",
							strSetting
									+ " : Take out price should be copied to other price only, not to eating setting",
							strSetting + " : Take out price copied incorrectly to other fields", "FAIL");
					blnResult = false;
				}

				// Tax Settings
				// Tax Code
				if ((!(strTOTaxCode.equals(strETaxCode))) && ((strOthTaxCode.equals(strTOTaxCode)))
						&& (strETaxCode.equals("Default"))) {
					PassCnt++;
				} else {
					actions.reportCreateFAIL("Verify Tax Code", "Tax Code should be displayed as expected",
							"Tax Code is not displayed as expected", "FAIL");
				}

				// Tax Rule
				if ((!(strTOTaxRule.equals(strETaxRule))) && ((strOThTaxRule.equals(strTOTaxRule)))
						&& (strETaxRule.equals("Default"))) {
					PassCnt++;
				} else {
					actions.reportCreateFAIL("Verify Tax Rule", "Tax Rule should be displayed as expected",
							"Tax Rule is not displayed as expected", "FAIL");
				}

				// Tax Entry
				if ((!(strTOTaxEntry.equals(strETaxEntry))) && ((strOthTaxEntry.equals(strTOTaxEntry)))
						&& (strETaxEntry.equals("Default"))) {
					PassCnt++;
				} else {
					actions.reportCreateFAIL("Verify Tax Entry", "Tax Entry should be displayed as expected",
							"Tax Entry is not displayed as expected", "FAIL");
				}
				break;

			default:
				// Reporter.log("Please enter correct tag value - FAIL");
				actions.reportCreateFAIL("Verify Price Settings", "Tag value in update settings should be correct",
						"Please enter correct tag value", "FAIL");
				break;
			}

			if ((blnResult) && (PassCnt == 3)) {
				actions.reportCreatePASS("Verify Price & Tax attributes",
						strSetting + "Price & Tax attributes are working as expected for " + strTagName1 + " & "
								+ strTagName2 + " both set to " + strTagValue,
						strSetting + "Price & Tax attributes are working as expected for " + strTagName1 + " & "
								+ strTagName2 + " both set to " + strTagValue,
						"PASS");
				// Reporter.log(strSetting+"Price & Tax attributes are working
				// as expected for " + strTagName1 + " & " + strTagName2 + "
				// both set to "+strTagValue+" : PASS");
			} else {
				actions.reportCreateFAIL("Verify Price & Tax attributes",
						strSetting + "Price & Tax attributes are working as expected for " + strTagName1 + " & "
								+ strTagName2 + " both set to " + strTagValue,
						strSetting + "Price & Tax attributes are not working as expected for " + strTagName1 + " & "
								+ strTagName2 + " both set to " + strTagValue,
						"FAIL");
				// Reporter.log(strSetting+"Price & Tax attributes are not
				// working as expected for " + strTagName1 + " & " + strTagName2
				// + " both set to "+strTagValue+" : FAIL");
			}

			actions.click("ManagePS.CancelBtn");
			Thread.sleep(5000);

			try {
				// Pop Up message verification in case any
				VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strPopUpMsg2, true,
						AlertPopupButton.OK_BUTTON);
				if (VerifyPopUpMsg) {
					actions.reportCreatePASS("Verify Alert Message", "Alert Message should be present",
							"Unsaved record message displayed & clicked OK", "PASS");
					// Reporter.log("Unsaved record message displayed & clicked
					// OK - PASS");
				} else {
					actions.reportCreateFAIL("Verify Alert Message", "Alert Message should be present",
							"Alert verification failed", "FAIL");
				}
			} catch (Exception err) {
				System.out.println("No alert active");
			}
			Thread.sleep(5000);
			actions.waitForPageToLoad(180);
			mcd.SwitchToWindow("#Title");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing Functionality :Create Future Settings to an
	 * existing price sets Scenario ID : Used for pre-requisites in Pricing
	 * functions Author : Pooja Panse
	 */
	// -----------------------------------

	public WebElement RFM_PRC_BasePS_CreateFutureSetting(String strNewPrice, String strPrcNavigateTo,
			String strPriceSetName) throws Exception {

		actions.clear("RFMPriceSets.MainSearchbox");

		// Type price set name & Click Search
		actions.setValue("RFMPriceSets.MainSearchbox", strPriceSetName);
		actions.click("RFMPriceSets.MainSearch");
		Thread.sleep(1000);
		actions.smartWait(180);
		
		actions.WaitForElementPresent("RFMPriceSets.PriceSet1", 180);

		// Click on Price Set link
		driver.findElement(By.xpath(actions.getLocator("RFMPriceSets.PriceSet1"))).click();
		Thread.sleep(3000);
		mcd.waitAndSwitch("#Title");

		// Check whether the Price set is having a future setting.
		// Also get the number of future settings in the price set
		String Current_date = driver.findElement(By.xpath(actions.getLocator("ManagePS.DateSelected"))).getText();
		String CurrDt = null;
		if(mcd.GetGlobalData("Instance").toLowerCase().contains("ap")){
			 CurrDt = Current_date.split("/")[0].trim();
		}else if(mcd.GetGlobalData("Instance").toLowerCase().contains("us") || mcd.GetGlobalData("Instance").toLowerCase().contains("eu")){
			CurrDt = Current_date.split(" ")[1].trim().replace(",", "").trim();
		}
		int TodaysDt = Integer.parseInt(CurrDt);

		List<WebElement> FDate = driver.findElements(By.xpath(actions.getLocator("PriceSet.PPFutureDateLink")));
		Boolean Future_Flag = false;
		int numOfSettings = 0;
		// String[] Future_dates = new String[FDate.size()];

		if (FDate.size() > 1) {
			System.out.println("PS has 1 future setting");
			Future_Flag = true;
			numOfSettings = 0;
		} else {
			System.out.println("PS does not have future setting");
			Future_Flag = false;
			numOfSettings = 1;
		}

		for (int num = 1; num <= numOfSettings; num++) {

			int Dt_toSelect = 0;
			if (TodaysDt <= 29) {
				Dt_toSelect = TodaysDt + num;
			} else {
				Dt_toSelect = TodaysDt - num;
			}
			// Select a future date from the calendar
			mcd.SelectDate_OpenCalender(Integer.toString(Dt_toSelect), "next");
			actions.smartWait(180);

			actions.clear("UpdtMultipleSet.AllPrc");
			actions.setValue("UpdtMultipleSet.AllPrc", strNewPrice);
			actions.click("UpdtMultipleSet.Apply");
			Thread.sleep(3000);
			actions.click("ManagePS.ApplyBtn");
			Thread.sleep(1000);
			actions.smartWait(180);
			// Navigate again to price sets
			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strPrcNavigateTo);
			actions.select_menu("RFMHome.Pricing", strPrcNavigateTo);
			Thread.sleep(5000);
			actions.waitForPageToLoad(180);

			mcd.SwitchToWindow("#Title");

			// Type price set name & Click Search
			actions.setValue("RFMPriceSets.MainSearchbox", strPriceSetName);
			actions.click("RFMPriceSets.MainSearch");
			Thread.sleep(10000);

			// Click on Price Set link
			driver.findElement(By.xpath(actions.getLocator("RFMPriceSets.PriceSet1"))).click();
			Thread.sleep(3000);
			mcd.waitAndSwitch("#Title");

			// Refresh FDate
			FDate = driver.findElements(By.xpath(actions.getLocator("PriceSet.PPFutureDateLink")));

		}
		return FDate.get(1);

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing Functionality : Verify that in the
	 * Roles->Pricing-> Master Tender Type -- All fields are displayed -- Field
	 * Permissions can be updated
	 * 
	 * Scenario ID : PRC_1046, PRC_1045 Author : Pooja Panse
	 */
	// -----------------------------------

	public void PRC_MTT_Roles_VerifyMTTFields(String strRoleName, String strAdvanceSettingColumn,
			String strRoleHierarchy, String strFieldHierarchy, String strOutputMessage, String strExpectedField)
					throws Exception {

		// Check whether the page is loaded & View Full list button is present
		actions.WaitForElementPresent("AdminRoles.VwFullListBtn", 120);

		// Click on View Full List
		actions.click("AdminRoles.VwFullListBtn");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);
		
		// clearing the existing role name field values if any
					actions.clear("COPYMI.searchtextbox");

					// setting the value as Role name
					actions.setValue("COPYMI.searchtextbox", strRoleName);

					// clicking the search button
					actions.click("COPYMI.searchbtn");

					// waiting for the result to get loaded
					actions.smartWait(240);


		// Get the desired role using column name : Role Name, "a" - tag name in
		// html
		WebElement eleRole = mcd.GetTableCellElement("AdminRoles.RoleListTable", "Role Name", strRoleName, "a", "",
				"Role Name", "a");

		// Verify whether desired role is selected or not
		if (eleRole != null) {
			actions.reportCreatePASS("Verify Desired Role selection", strRoleName + " role should be selected",
					strRoleName + " role selected", "PASS");
			eleRole.click();
		} else {
			actions.reportCreateFAIL("Verify Desired Role selection", strRoleName + " role should be selected",
					strRoleName + " role not selected", "FAIL");
		}

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		int reqdColmNum = mcd.GetTableColumnNumber("AdminRoles.RoleListTable", strAdvanceSettingColumn);
		// System.out.println("Advance Settings : "+reqdColmNum);
		WebElement eleData = rfm.Get_DataElement("AdminRoles.RoleCategoryTbl", strRoleHierarchy);

		// Get the element we want to work on
		WebElement ele2 = eleData.findElement(By.xpath(".//td[" + reqdColmNum + "]/a"));

		// Click on Advance Settings
		ele2.click();

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Switch to window Advance Setting
		mcd.SwitchToWindow("Advance Setting");
		Thread.sleep(1000);

		// Get data from FieldPermissions.Table

		eleData = rfm.Get_DataElement("FieldPermissions.TableData", strFieldHierarchy);

		int iNumOfCol = mcd.GetTableColumnCount("FieldPermissions.Table");
		int iNumOfRows = mcd.GetTableRowCount("FieldPermissions.MTTFieldsTable");
		int FieldColNumber = mcd.GetTableColumnNumber("FieldPermissions.Table", "Fields");
		int CurrCheckdCol = 0;
		int NewCheckdCol = 0;
		String strActualField = null;
		int FldCheckCount = 0;

		// Check all the fields under Master Tender Type
		for (int j = 0; j < iNumOfRows; j++) {
			strActualField = mcd.GetTableCellValue("FieldPermissions.MTTFieldsTable", j + 1, FieldColNumber - 1, "",
					"");
			strActualField = strActualField.split(":")[0].trim();
			System.out.println(strActualField);
			if (strExpectedField.contains(strActualField)) {
				FldCheckCount++;
			} else {
				FldCheckCount = 0;
			}
		}

		if (FldCheckCount == iNumOfRows) {
			actions.reportCreatePASS("Verify all Master tender type fields are displayed",
					"All fields should be displayed", "All fields are displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify all Master tender type fields are displayed",
					"All fields should be displayed", "All fields are not displayed", "FAIL");
		}

		// Get the column names i.e access rights currently given & not given
		for (int i = 1; i < iNumOfCol; i++) {
			ele2 = eleData.findElement(By.xpath("//td[" + (i + 1) + "]/input"));
			if (ele2.isSelected()) {
				CurrCheckdCol = i + 1;
			} else {
				NewCheckdCol = i + 1;
			}
			if ((CurrCheckdCol != 0) && (NewCheckdCol != 0)) {
				break;
			}
		}

		// Change the access right - Create/Update/Read only/None
		ele2 = eleData.findElement(By.xpath("//td[" + (NewCheckdCol) + "]/input"));
		ele2.click();

		// Save the changes
		actions.click("FieldPermissions.SaveBtn");
		actions.smartWait(120);

		// Verify success message
		actions.verifyTextPresence(strOutputMessage, false);
		actions.reportCreatePASS("Verify Update Field Permission",
				"Master Tender Type - Field Permissions should be updated successfully",
				"Master Tender Type - Field Permissions updated successfully", "PASS");

		// Reset the changes made to original
		// Expand the tree node
		eleData = rfm.Get_DataElement("FieldPermissions.TableData", "Master Tender Type > Tender Name");
		ele2 = eleData.findElement(By.xpath("//td[" + (CurrCheckdCol) + "]/input"));
		ele2.click();

		// Save the changes
		actions.keyboardEnter("FieldPermissions.SaveBtn");
		actions.smartWait(120);

		// Verify success message
		actions.verifyTextPresence(strOutputMessage, false);

		actions.reportCreatePASS("Verify Update Field Permission",
				"Master Tender Type - Field Permissions should be updated successfully",
				"Master Tender Type - Field Permissions updated successfully", "PASS");

		// Click Cancel to close the window
		actions.keyboardEnter("FieldPermissions.CancelBtn");

		// Switch to main window
		mcd.SwitchToWindow("Roles");

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing Functionality : Verify that in the Field
	 * Permissions ->Pricing-> Menu Item Tax Set -- Menu Item Tax Set Name field
	 * is displayed with right access fields (Create/Update/Read Only/None)
	 * Scenario ID : PRC_1055 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_VerifyFieldDisplayed(String strFieldName, String strFieldPath, String[] strAccessType) {

		// Get data from FieldPermissions.Table - required tr element

		WebElement eleData = rfm.Get_DataElement("FieldPermissions.TableData", strFieldPath);

		int reqdColNum = 0;
		WebElement ele2;
		for (int i = 0; i < strAccessType.length; i++) {

			// Get column numbers for coulmn names (Fields/Create/Update/Read
			// Only/None
			reqdColNum = mcd.GetTableColumnNumber("FieldPermissions.HeaderTbl", strAccessType[i].trim());

			// Check whether new field is displayed in the Fields column
			if (strAccessType[i].trim().equals("Fields")) {
				ele2 = eleData.findElement(By.xpath("./td[" + (reqdColNum - 1) + "]/b"));

				if (ele2.getText().split(":")[0].trim().equals(strFieldName)) {
					actions.reportCreatePASS("Verify " + strFieldName + " field", "Should be displayed", "Displayed",
							"PASS");
				} else {
					actions.reportCreateFAIL("Verify " + strFieldName + " field", "Should be displayed",
							"Not Displayed", "FAIL");
				}

			} else {

				// Check whether the radio buttons for Create/Update/Read
				// Only/None are displayed & enabled
				ele2 = eleData.findElement(By.xpath("./td[" + (reqdColNum - 1) + "]/input"));

				if (ele2.isDisplayed()) {
					if (ele2.isEnabled()) {
						actions.reportCreatePASS("Verify " + strAccessType[i].trim() + " radio field",
								"Should be displayed & enabled", "Displayed & Enabled", "PASS");
					} else {
						actions.reportCreateFAIL("Verify " + strAccessType[i].trim() + " radio field",
								"Should be displayed & enabled", "Displayed but disabled", "FAIL");
					}
				} else {
					actions.reportCreateFAIL("Verify " + strAccessType[i].trim() + " radio field",
							"Should be displayed & enabled", "Not Displayed", "FAIL");
				}
			}

		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing Functionality : To verify the Field Permission of
	 * Default attribute, Update Tax button Scenario ID : PRC_1016 Author :
	 * Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_Verify_MUP_FieldDisplayed(String[] strFieldName, String strFieldName2, String strFieldPath1,
			String strFieldPath2, String[] strAccessType, String strNavigateTo) throws Exception {

		Boolean blnFlag = false;
		int FieldPassCount = 0;
		// Verification for field 1 - Default Eatin
		WebElement eleData = rfm.Get_DataElement("FieldPermissions.TableData", strFieldPath1);

		// Get all the elements / fields
		List<WebElement> eleAllFields = eleData.findElements(By.xpath("../tr"));
		// System.out.println(eleAllFields.size());

		// Loop in all elements to search for desired field
		for (int k = 0; k < eleAllFields.size(); k++) {
			eleData = eleAllFields.get(k);
			int reqdColNum = 0;
			String CurrFieldName = null;
			WebElement ele2;

			// Check whether the field is Fields/Create/Update/Read Only/None
			for (int i = 0; i < strAccessType.length; i++) {

				// Get column numbers for column names
				// (Fields/Create/Update/Read Only/None
				reqdColNum = mcd.GetTableColumnNumber("FieldPermissions.HeaderTbl", strAccessType[i].trim());
				// System.out.println("i = "+i+" "+strAccessType[i].trim()+"
				// "+blnFlag);

				// Check whether new field is displayed in the Fields column
				if (strAccessType[i].trim().equals("Fields")) {
					ele2 = eleData.findElement(By.xpath("./td[" + (reqdColNum - 1) + "]/b"));
					CurrFieldName = ele2.getText().split(":")[0].trim();
					// System.out.println(ele2.getText().split(":")[0].trim());

					// Check with the list of input field names & stored field
					// names
					for (int j = 0; j < strFieldName.length; j++) {
						if (ele2.getText().split(":")[0].trim().equals(strFieldName[j])) {
							blnFlag = true;
							FieldPassCount++;
							actions.reportCreatePASS("Verify " + strFieldName[j] + " field", "Should be displayed",
									"Displayed", "PASS");
							break;
						} else {
							blnFlag = false;
						}
					}

					// Final check whether the any field fetched or not
					if ((strAccessType[i].trim().equals("Fields")) && ((blnFlag))) {
						System.out.println("Field Found");
					} else {
						System.out.println("Not desired field");
						blnFlag = false;
						// System.out.println("Not verifying radio btns");
						break;
					}
				}

				// Actions to take if field is Create/Update/Read Only/ None
				// radio buttons

				// System.out.println("i = "+i+" "+strAccessType[i].trim()+"
				// "+blnFlag);
				if (!(strAccessType[i].trim().equals("Fields")) && (blnFlag)) {
					// Check whether the radio buttons for Create/Update/Read
					// Only/None are displayed & enabled
					ele2 = eleData.findElement(By.xpath("./td[" + (reqdColNum - 1) + "]/input"));
					if (ele2.isDisplayed()) {
						if (ele2.isEnabled()) {
							actions.reportCreatePASS(
									"Verify " + strAccessType[i].trim() + " radio field for field " + CurrFieldName,
									"Should be displayed & enabled", "Displayed & Enabled", "PASS");
						} else {
							actions.reportCreateFAIL(
									"Verify " + strAccessType[i].trim() + " radio field for field " + CurrFieldName,
									"Should be displayed & enabled", "Displayed but disabled", "FAIL");
						}
					} else {
						actions.reportCreateFAIL(
								"Verify " + strAccessType[i].trim() + " radio field for field " + CurrFieldName,
								"Should be displayed & enabled", "Not Displayed", "FAIL");
					}
				}
				// System.out.println(i+" "+strAccessType.length);
			}
			// System.out.println(k+" "+eleAllFields.size());
		}

		// Report whether all the required fields were found & verified or not
		if (FieldPassCount == 3) {
		} else {
			actions.reportCreateFAIL("Verify Default Eatin, Takeout, Other Price field", "Should be displayed",
					"Not Displayed", "FAIL");
		}

		// Navigate again to Verify Update Tax field is displayed or not
		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateTo);
		actions.select_menu("RFMHome.Navigate", strNavigateTo);
		Thread.sleep(10000);
		actions.waitForPageToLoad(180);

		// Verify 4th Field : Update Tax
		eleData = rfm.Get_DataElement("FieldPermissions.TableData", strFieldPath2);
		String strDisplayed_fld = eleData.findElement(By.xpath(".//b[contains(text(), '" + strFieldName2 + "')]"))
				.getText().trim();
		if (strDisplayed_fld.equals(strFieldName2)) {
			actions.reportCreatePASS("Verify " + strFieldName2 + " field", "Should be displayed", "Displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify " + strFieldName2 + " field", "Should be displayed", "Not Displayed",
					"FAIL");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Menu Item > Restaurant menu item list Functionality :
	 * Verifying the Manage Restaurant Menu Item List -- Main screen view, View
	 * full list. Scenario ID : MNU_1282/MNU_1283/MNU_1284 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_Verify_RestMIList_ViewFullList(String strNodeNum, String strMessage1) throws Exception {
		String strXPath = "";
		String strSelectedRestaurant = null;
		WebElement eleMarketTree = null;
		boolean blnReturn = false;
		String strDisplayedRest = null;

		// Click on search before selecting a restaurant
		// Verify error message is displayed
		actions.keyboardEnter("RestMIList.SearchRestaurant");
		Thread.sleep(2000);

		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strMessage1, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify error message to select a restaurant before search",
					"Error message should be displayed", "Error message displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify error message to select a restaurant before search",
					"Error message should be displayed", "Error message not displayed", "FAIL");

		}

		Thread.sleep(1000);
		// Select a Restaurant
		actions.keyboardEnter("RestMIList.SelectRestBtn");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("Select a Restaurant");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);
		actions.setValue("SelectNode.SearchBox", strNodeNum);
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		eleMarketTree = actions.getwebDriverLocator(actions.getLocator("SelectNode.NodeTable"));
		strXPath = "//label[contains(text(),'" + strNodeNum + "')]";
		WebElement eleMarket = eleMarketTree.findElement(By.xpath(strXPath));
		if (eleMarket != null) {
			strSelectedRestaurant = eleMarket.getText().trim();
			eleMarket.click();
			blnReturn = true;
			System.out.println("Restaurant-" + strSelectedRestaurant + " selected successfully");
		} else {
			blnReturn = false;
			System.out.println("Failed to select restaurant-" + strSelectedRestaurant);
		}

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Switch back to Restaurant Menu Item List Window
		mcd.SwitchToWindow("Restaurant Menu Item List");

		// Verify whether same restaurant is displayed
		strDisplayedRest = driver.findElement(By.xpath(actions.getLocator("RestMIList.SelectedRestaurant"))).getText()
				.trim();
		if (strDisplayedRest.equals(strSelectedRestaurant)) {
			actions.reportCreatePASS("Verify selected restaurant is displayed",
					"Selected restaurant should be displayed ", "Selected restaurant is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify selected restaurant is displayed",
					"Selected restaurant should be displayed ", "Selected restaurant not displayed", "FAIL");
		}

		// View Full List
		int iMIRwCnt = 0;
		// Get the contents of Menu Item table - before View Full List

		iMIRwCnt = mcd.GetTableRowCount("RestMIList.MITable");
		if (iMIRwCnt > 0) {
			actions.reportCreateFAIL("Verify data before view full list", "No data should be displayed",
					"Data displayed", "FAIL");
		} else {
			actions.reportCreatePASS("Verify data before view full list", "No data should be displayed",
					"No data displayed", "PASS");
		}

		// Click Search (i.e View Full List) functionality
		actions.click("RestMIList.SearchRestaurant");
		actions.smartWait(120);

		iMIRwCnt = driver.findElements(By.xpath("//*[@id='Sess1']//tbody[@id='menuItemsData']/tr")).size();
		if (iMIRwCnt > 0) {
			actions.reportCreatePASS("Verify data after view full list", "Data should be displayed", "Data displayed",
					"PASS");
		} else {
			actions.reportCreateFAIL("Verify data before view full list", "Data should be displayed",
					"No data displayed", "FAIL");
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Menu Item > Restaurant menu item list Functionality :
	 * Verifying the Manage Restaurant Menu Item List -- Filter functionality.
	 * Scenario ID : MNU_1282/MNU_1283/MNU_1284 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_Verify_RestaurantMenuItemList_Filter(String strStatus, String strFamilyGrp,
			String strMenuItemCls) throws Exception {

		// Status DropDown & Filter Check
		// Get column number for : Status column
		int iStatusColNum = mcd.GetTableColumnNumber("RestMIList.MITable", "Status");
		int iFamilyColNum = mcd.GetTableColumnNumber("RestMIList.MITable", "Family Group");
		int iApproveColNum = 0;
		try {
			if (driver.findElement(By.xpath(actions.getLocator("RestMIList.MIApprovalDrpdwn"))).isDisplayed()) {
				iApproveColNum = mcd.GetTableColumnNumber("RestMIList.MITable", "Status");
			} else {
				System.out.println("Approved field not present");
			}
		} catch (Exception e) {
			System.out.println("Approved field not present");
		}
		String strStatusVal = null;
		Boolean blnFilterResult = false;
		int iNewMIRwCnt = 0;
		List<WebElement> eleRws;
		String TableXpath = actions.getLocator("RestMIList.MITableRows");
		// Filter

		// Field : STATUS

		// Select Status - Active
		actions.setValue("RestMIList.MIStatusDrpdwn", strStatus);
		actions.smartWait(120);

		blnFilterResult = false;
		eleRws = driver.findElements(By.xpath(TableXpath));
		iNewMIRwCnt = eleRws.size();
		if (iNewMIRwCnt != 0) {
			blnFilterResult = RFM_Verify_Filter("RestMIList.MITable", iNewMIRwCnt, iStatusColNum, strStatus);
			// System.out.println(blnFilterResult);
		} else {
			System.out.println("No rows for active status");
			actions.reportCreatePASS("Verify filter on Status field",
					"Menu Item list should refresh as per filter option selected.", "Data is filtered as expected",
					"PASS");
		}

		if (!blnFilterResult) {
			actions.reportCreatePASS("Verify filter on Status field",
					"Menu Item list should refresh as per filter option selected.", "Data is filtered as expected",
					"PASS");
		} else {
			actions.reportCreateFAIL("Verify filter on Status field",
					"Menu Item list should refresh as per filter option selected.", "Data is not filtered as expected",
					"FAIL");
		}

		// Set Status back to - Active/Inactive
		actions.setValue("RestMIList.MIStatusDrpdwn", "Active/Inactive");
		actions.smartWait(120);

		// Field : Family Group :
		actions.setValue("RestMIList.MIFamilyGrpDrpdwn", strFamilyGrp);
		actions.smartWait(120);

		blnFilterResult = false;
		eleRws = driver.findElements(By.xpath(TableXpath));
		iNewMIRwCnt = eleRws.size();
		if (iNewMIRwCnt != 0) {
			blnFilterResult = RFM_Verify_Filter("RestMIList.MITable", iNewMIRwCnt, iFamilyColNum, strFamilyGrp);
			// System.out.println(blnFilterResult);
		} else {
			System.out.println("No rows for " + strFamilyGrp + " family group");
			actions.reportCreatePASS("Verify filter on Family Group field",
					"Menu Item list should refresh as per filter option selected.", "Data is filtered as expected",
					"PASS");
		}

		if (!blnFilterResult) {
			actions.reportCreatePASS("Verify filter on Family Group field",
					"Menu Item list should refresh as per filter option selected.", "Data is filtered as expected",
					"PASS");
		} else {
			actions.reportCreateFAIL("Verify filter on Family Group field",
					"Menu Item list should refresh as per filter option selected.", "Data is not filtered as expected",
					"FAIL");
		}

		// Set value back to - All
		actions.setValue("RestMIList.MIFamilyGrpDrpdwn", "All");
		actions.smartWait(120);

		// Field : MI Class :
		actions.setValue("RestMIList.MIClassDrpdwn", strMenuItemCls);
		Thread.sleep(3000);
		actions.waitForPageToLoad(120);
		actions.smartWait(180);

		blnFilterResult = false;
		eleRws = driver.findElements(By.xpath(TableXpath));
		iNewMIRwCnt = eleRws.size();
		if (iNewMIRwCnt != 0) {
//			eleRws.get(0).findElement(By.xpath("./td[1]")).click();
			actions.keyboardEnter(mcd.GetTableCellElement("RFM.WebTable", 1, "Number", "a"));
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.SwitchToWindow("#Title");

			String strDispMICls = driver.findElement(By.xpath(actions.getLocator("RestMIScreen.MIClassField")))
					.getText().trim();

			if (strDispMICls.equalsIgnoreCase(strMenuItemCls)) {
				actions.reportCreatePASS("Verify filter on Menu Item Class field",
						"Menu Item list should refresh as per filter option selected.", "Data is filtered as expected",
						"PASS");
			} else {
				actions.reportCreateFAIL("Verify filter on Menu Item Class field",
						"Menu Item list should refresh as per filter option selected.",
						"Data is not filtered as expected", "FAIL");
			}

		} else {
			actions.reportCreatePASS("Verify filter on Menu Item Class field",
					"Menu Item list should refresh as per filter option selected.", "Data is filtered as expected",
					"PASS");
			System.out.println("No rows for " + strMenuItemCls + " family group");
		}

		// Navigate back to main screen - Click Cancel
		//actions.click("RestMIScreen.CancelBtn");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);
		mcd.SwitchToWindow("#Title");

		// Set value back to - All
		actions.setValue("RestMIList.MIClassDrpdwn", "All");
		actions.smartWait(120);

	}

	// ----------------------------------
	/*
	 * Feature Name : Menu Item > Restaurant menu item list Functionality :
	 * Verifying the Manage Restaurant Menu Item List -- Sorting functionality.
	 * Scenario ID : MNU_1282/MNU_1283/MNU_1284 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_Verify_RestaurantMenuItemList_Sorting() throws InterruptedException {

		String TableXpath = actions.getLocator("RestMIList.MITableRows");
		// Verify SORTING
		// By Number

		// Click on Number link
		actions.click("RestMIList.MISortByNumber");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		List<WebElement> eleRws = driver.findElements(By.xpath(TableXpath));
		int iNewMIRwCnt = eleRws.size();
		int MI_Num1 = 0 ;
		int MI_Num2 = 0;
		
		if(iNewMIRwCnt >= 2){
			// Take 1st two elements for comparison by number
			MI_Num1 = Integer.parseInt(mcd.GetTableCellElement("RFM.WebTable", 1, "Number", "a").getText());
			MI_Num2 = Integer.parseInt(mcd.GetTableCellElement("RFM.WebTable", 2, "Number", "a").getText());
		}

		

		String strSortOrder = null;
		String strSortOrderValue = driver.findElement(By.xpath(actions.getLocator("RestMIList.MISortNumArrow")))
				.getAttribute("src");
		if (strSortOrderValue.contains("up")) {
			strSortOrder = "Ascending";
			if (MI_Num1 <= MI_Num2) {
				actions.reportCreatePASS("Verify Sorting according to Menu Item Number",
						"List should be sorted correctly", "List is sorted correctly", "PASS");
				// System.out.println("sorted ascending correct");
			} else {
				actions.reportCreateFAIL("Verify Sorting according to Menu Item Number",
						"List should be sorted correctly", "List is not sorted correctly", "FAIL");
				// System.out.println("sorted ascending incorrect");
			}
		} else if (strSortOrderValue.contains("down")) {
			strSortOrder = "Descending";
			if (MI_Num1 >= MI_Num2) {
				actions.reportCreatePASS("Verify Sorting according to Menu Item Number",
						"List should be sorted correctly", "List is sorted correctly", "PASS");
				// System.out.println("sorted descending correct");
			} else {
				actions.reportCreateFAIL("Verify Sorting according to Menu Item Number",
						"List should be sorted correctly", "List is not sorted correctly", "FAIL");
				// System.out.println("sorted descending incorrect");
			}
		}

		// Click on Name link
		/*actions.click("RestMIList.MISortByName");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		eleRws = driver.findElements(By.xpath(TableXpath));
		iNewMIRwCnt = eleRws.size();
		
		String MI_Name1 = null;
		String MI_Name2 = null;
		
		if(iNewMIRwCnt >= 2){
			MI_Name1 = mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "").getText().trim();
			MI_Name2 = mcd.GetTableCellElement("RFM.WebTable", 2, "Name", "").getText().trim();
		}

//		// Take 1st two elements for comparison by name
//		String MI_Name1 = eleRws.get(0).findElement(By.xpath("./td[2]")).getText();
//		String MI_Name2 = eleRws.get(1).findElement(By.xpath("./td[2]")).getText();

		strSortOrder = null;
		strSortOrderValue = driver.findElement(By.xpath(actions.getLocator("RestMIList.MISortNameArrow")))
				.getAttribute("src");
		if (strSortOrderValue.contains("up")) {
			strSortOrder = "Ascending";
			if ((MI_Name1.compareToIgnoreCase(MI_Name2)) <= 0) {
				actions.reportCreatePASS("Verify Sorting according to Menu Item Name",
						"List should be sorted correctly", "List is sorted correctly", "PASS");
				// System.out.println("sorted ascending correct");
			} else {
				actions.reportCreateFAIL("Verify Sorting according to Menu Item Name",
						"List should be sorted correctly", "List is not sorted correctly", "FAIL");
				// System.out.println("sorted ascending incorrect");
			}
		} else if (strSortOrderValue.contains("down")) {
			strSortOrder = "Descending";
			if ((MI_Name1.compareTo(MI_Name2)) >= 0) {
				actions.reportCreatePASS("Verify Sorting according to Menu Item Name",
						"List should be sorted correctly", "List is sorted correctly", "PASS");
				// System.out.println("sorted descending correct");
			} else {
				actions.reportCreateFAIL("Verify Sorting according to Menu Item Name",
						"List should be sorted correctly", "List is not sorted correctly", "FAIL");
				// System.out.println("sorted descending incorrect");
			}
		}
		*/
	}

	// ----------------------------------
	/*
	 * Feature Name : Menu Item > Restaurant menu item list Functionality :
	 * Verifying the Manage Restaurant Menu Item List -- Search functionality.
	 * Scenario ID : MNU_1282/MNU_1283/MNU_1284 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_Verify_RestaurantMenuItemList_Search(String strMessage2, String strStatus, String strFamilyGrp,
			String strMenuItemCls) throws InterruptedException {
		String strFilterDropDown = null;
		String strFilterVal = null;
		Boolean blnResult = false;
		for (int k = 0; k < 3; k++) {

			// Reset all filter values
			// Select Active/Inactive for Status
			actions.setValue("RestMIList.LevelUpStatusDrpdwn", "Active/Inactive");
			Thread.sleep(500);

			// Select All for MI class
			actions.setValue("RestMIList.LevelUpMIClassDrpdwn", "All");
			Thread.sleep(500);

			// Select all for family grp
			actions.setValue("RestMIList.LevelUpFamilyGrpDrpdwn", "All");
			Thread.sleep(500);

			if (k == 0) {
				strFilterDropDown = "RestMIList.LevelUpFamilyGrpDrpdwn";
				strFilterVal = strFamilyGrp;

			} else if (k == 1) {
				strFilterDropDown = "RestMIList.LevelUpMIClassDrpdwn";
				strFilterVal = strMenuItemCls;
			} else {
				strFilterDropDown = "RestMIList.LevelUpStatusDrpdwn";
				strFilterVal = strStatus;
			}

			String TableXpath = actions.getLocator("RestMIList.MITableRows");

			// Begins with radio button

			actions.click("RestMIList.BeginWithRadiobtn");
			actions.clear("RestMIList.SearchTextBox");
			actions.setValue("RestMIList.SearchTextBox", "b");
			Thread.sleep(500);

			// Select appropriate filter drop-down & value
			actions.setValue(strFilterDropDown, strFilterVal);
			Thread.sleep(500);

			actions.click("RestMIList.SearchRestaurant");
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);

			List<WebElement> eleRws = driver.findElements(By.xpath(TableXpath));
			int iNewMIRwCnt = eleRws.size();

			if (iNewMIRwCnt == 0) {
				System.out.println("No data record with this data & filter present");
				blnResult = true;
				//actions.verifyTextPresence(strMessage2, true);
			} else {

				blnResult = false;
				for (int i = 1; i <= iNewMIRwCnt; i++) {

					String MI_Name = mcd.GetTableCellElement("RFM.WebTable", i, "Name", "").getText().trim();
					Thread.sleep(1000);
					if (MI_Name.toLowerCase().startsWith("b")) {
						blnResult = true;
					} else {
						blnResult = false;
						break;
					}
				}

				if (blnResult) {
					actions.reportCreatePASS("Verify search with radio button Begins with selected",
							"Search should work as expected", "Search is working as expected", "PASS");
				} else {
					actions.reportCreateFAIL("Verify search with radio button Begins with selected",
							"Search should work as expected", "Search is not working as expected", "FAIL");
				}
			}

			// Ends with radio button
			Thread.sleep(2000);
			actions.click("RestMIList.EndsWithRadiobtn");
			actions.clear("RestMIList.SearchTextBox");
			actions.setValue("RestMIList.SearchTextBox", "a");
			Thread.sleep(500);
			actions.click("RestMIList.SearchRestaurant");
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);

			eleRws = driver.findElements(By.xpath(TableXpath));
			iNewMIRwCnt = eleRws.size();

			if (iNewMIRwCnt == 0) {
				System.out.println("No data record with this data & filter present");
				blnResult = true;
				//actions.verifyTextPresence(strMessage2, true);
			} else {
				blnResult = false;
				for (int i = 1; i <= iNewMIRwCnt; i++) {

					String MI_Name = mcd.GetTableCellElement("RFM.WebTable", i, "Name", "").getText().trim();
					Thread.sleep(1000);
					if (MI_Name.toLowerCase().endsWith("a")) {
						blnResult = true;
					} else {
						blnResult = false;
						break;
					}
				}
			}
			if (blnResult) {
				actions.reportCreatePASS("Verify search with radio button Ends with selected",
						"Search should work as expected", "Search is working as expected", "PASS");
			} else {
				actions.reportCreateFAIL("Verify search with radio button Ends with selected",
						"Search should work as expected", "Search is not working as expected", "FAIL");
			}

			// Contains radio button
			Thread.sleep(2000);
			actions.click("RestMIList.ContainsRadiobtn");
			actions.clear("RestMIList.SearchTextBox");
			actions.setValue("RestMIList.SearchTextBox", "b");
			Thread.sleep(500);
			actions.click("RestMIList.SearchRestaurant");
			Thread.sleep(2000);
			actions.waitForPageToLoad(180);

			eleRws = driver.findElements(By.xpath(TableXpath));
			iNewMIRwCnt = eleRws.size();

			if (iNewMIRwCnt == 0) {
				System.out.println("No data record with this data & filter present");
				blnResult = true;
				//actions.verifyTextPresence(strMessage2, true);
			} else {

				blnResult = false;
				for (int i = 1; i <= iNewMIRwCnt; i++) {

					String MI_Name = mcd.GetTableCellElement("RFM.WebTable", i, "Name", "").getText().trim();
					Thread.sleep(1000);
					if (MI_Name.toLowerCase().contains("b")) {
						blnResult = true;
					} else {
						blnResult = false;
						break;
					}
				}

				if (blnResult) {
					actions.reportCreatePASS("Verify search with radio button Contains selected",
							"Search should work as expected", "Search is working as expected", "PASS");
				} else {
					actions.reportCreateFAIL("Verify search with radio button Contains with selected",
							"Search should work as expected", "Search is not working as expected", "FAIL");
				}
			}
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Menu Item > Restaurant menu item list Functionality :
	 * Common function used in filter function. Scenario ID :
	 * MNU_1282/MNU_1283/MNU_1284 Author : Pooja Panse
	 */
	// -----------------------------------

	public Boolean RFM_Verify_Filter(String strTableElement, int iRwCnt, int iColNum, String strFilterValue) {
		Boolean blnResult = false;
		for (int i = 1; i <= iRwCnt; i++) {
			String strValue = mcd.GetTableCellValue("RestMIList.MITable", i, iColNum, "", "");
			// System.out.println(strValue);
			if (!(strValue.isEmpty())) {
				if (strValue.equals(strFilterValue)) {
					blnResult = true;
				} else {
					blnResult = false;
					break;
				}
			} else {
				// System.out.println("Rows for not-displayed block.");
			}
		}
		return blnResult;
	}

	// ----------------------------------
	/*
	 * Feature Name : Menu Item > Restaurant menu item list Functionality :
	 * Verify the SSP Classification in Menu Item Set Scenario ID : MNU_1294
	 * Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_RestMIList_SSPClassification(String strNavigateToRestList, String strLookUp,
			String strLookUpTableColumn, String strSSPTableCol1, String strSSPTableCol2, String strNodeNum)
					throws Exception {

		actions.setValue("LookUp.SearchBox", strLookUp);
		actions.click("LookUp.SearchBtn");
		actions.smartWait(180);

		int iRwCnt = mcd.GetTableRowCount("LookUp.Table");
		int iColNum = mcd.GetTableColumnNumber("LookUp.Table", strLookUpTableColumn);
		System.out.println(iColNum);

		for (int i = 1; i <= iRwCnt; i++) {
			WebElement eleLookUp = null;
			try {
				eleLookUp = mcd.GetTableCellElement("LookUp.Table", i, iColNum, "a/pre");
				if (eleLookUp.getText().trim().equalsIgnoreCase(strLookUp)) {
					eleLookUp.click();
					Thread.sleep(2000);
					actions.waitForPageToLoad(120);
					break;
				}
			} catch (Exception e) {
				System.out.println("Not the desired element");
			}

		}

		mcd.SwitchToWindow("#Title");

		int iSSPRwCnt = mcd.GetTableRowCount("SSPClassification.Table");
		int iSSPStatusColNum = mcd.GetTableColumnNumber("SSPClassification.Table", strSSPTableCol1);
		int iSSPNameColNum = mcd.GetTableColumnNumber("SSPClassification.Table", strSSPTableCol2);
		System.out.println(iSSPStatusColNum + " " + iSSPNameColNum);

		List<String> SSP_Names = new ArrayList<String>();

		for (int i = 1; i <= iSSPRwCnt; i++) {
			WebElement eleStatus = mcd.GetTableCellElement("SSPClassification.Table", i, iSSPStatusColNum, "select");
			eleStatus = eleStatus.findElement(By.xpath("./option[@selected='selected']"));
			String Status_Check = eleStatus.getText();
			System.out.println(Status_Check);
			if (Status_Check.equals("Active")) {
				String temp = mcd.GetTableCellValue("SSPClassification.Table", i, iSSPNameColNum, "input", "value");
				SSP_Names.add(temp);
				System.out.println(SSP_Names);
			}
		}

		// Navigate to MI > Restaurant Menu Item List
		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateToRestList);
		actions.select_menu("RFMHome.Navigate", strNavigateToRestList);
		Thread.sleep(5000);
		actions.waitForPageToLoad(120);

		// Switch to Same Window - Diff Title
		mcd.SwitchToWindow("#Title");

		// Select a Restaurant
		actions.keyboardEnter("RestMIList.SelectRestBtn");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("Select a Restaurant");

		// Select Exact Match Radio btn
		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);
		// Enter Restaurant number
		actions.setValue("SelectNode.SearchBox", strNodeNum);
		Thread.sleep(1000);

		// Search
		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Select Restaurant Node
		mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Switch back to Restaurant Menu Item List Window
		mcd.SwitchToWindow("Restaurant Menu Item List");

		// Click Search (i.e View Full List) functionality
		actions.setValue("RestMIList.SearchTextBox", "2");
	
		actions.click("RestMIList.SearchRestaurant");
		actions.smartWait(120);

		// Select any MenuItem
		//String TableXpath = actions.getLocator("RestMIList.MITableRows");

		List<WebElement> eleRws = driver.findElements(By.xpath("//*[@id='Sess1']//tbody[@id='menuItemsData']/tr/td[1]/a"));

		// Click on the first menu item displayed
		eleRws.get(0).click();
		//eleRws.get(0).findElement(By.xpath("./td[1]")).click();
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Switch to same window - different title
		mcd.SwitchToWindow("#Title");

		// Click on POS/KVS tab
		actions.click("RestMIList.POSKVStab");
		actions.smartWait(180);

		// Click on Customize button
		actions.click("RestMIList.CustomizeBtn");
		actions.smartWait(120);

		// Click on SSP Link
		actions.click("RestMIList.SSPLink");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Switch to new window
		mcd.SwitchToWindow("SSP Classification");

		// Get the list of SSP elements present & Verify
		Boolean blnResult = false;
		int newRwCnt = mcd.GetTableRowCount("RestMIList.SSPClassTable");
		int iCol = mcd.GetTableColumnNumber("RestMIList.SSPTableHeader", "SSP Classification Name");
		// Starting with m = 2 as for m=1 (tr[1]) - it is the header value )
		//for (int m = 2; m <= newRwCnt; m++) {
			String strCurrSSPElement = mcd.GetTableCellValue("RestMIList.SSPClassTable", 2, iCol, "input", "").trim();
			 System.out.println(strCurrSSPElement);
			 System.out.println(SSP_Names.get(7).trim());
			//if (strCurrSSPElement.equals(SSP_Names.get(m - 2).trim())) {
			 if (strCurrSSPElement.equals(SSP_Names.get(7).trim())) {
				blnResult = true;
			} else {
				blnResult = false;
				
			}
		

		if (blnResult) {
			actions.reportCreatePASS("Verify SSP SSP Classification in Menu Item Set",
					"SSP Classification should be displayed correctly", "SSP Classification is displayed correctly",
					"PASS");
		} else {
			actions.reportCreateFAIL("Verify SSP SSP Classification in Menu Item Set",
					"SSP Classification should be displayed correctly", "SSP Classification is not displayed correctly",
					"FAIL");
		}

		// Click on Cancel to close the window
		actions.click("RestMIList.SSPCancelBtn");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Switch back to main window
		mcd.SwitchToWindow("Manage Menu Items");
	}


	// ----------------------------------
	/*
	 * Feature Name : Promotion Management Functionality : Verify templates
	 * available for Price Change type market. Scenario ID : MNU_1229 Author :
	 * Pooja Panse
	 */
	// -----------------------------------

	public void RFM_MNU_PromotionMgmt_VerifyTemplateList(String[] strTemplateOptions) throws Exception {

		// Click on New Promotion button
		actions.keyboardEnter("PromotionMgmt.NewPromotionBtn");
		Thread.sleep(2000);
		actions.waitForPageToLoad(180);

		// Switch to New Window : Add New Promotion
		mcd.SwitchToWindow("Add New Promotion");

		Select select = new Select(driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.TemplateList"))));
		List<WebElement> DispTemplateOptions = select.getOptions();
		Boolean blnResult = false;
		// Subtracting the collected template list count by 1 - as 1st value is
		// Select
		// for array - i & for list i + 1 - as 1st value in list will be select

		for (int i = 0; i < (DispTemplateOptions.size() - 1); i++) {
			if (strTemplateOptions[i].equalsIgnoreCase(DispTemplateOptions.get(i + 1).getText().trim())) {
				blnResult = true;
			} else {
				blnResult = false;
				break;
			}
		}

		if (blnResult) {
			actions.reportCreatePASS("Verify template list in Promotion Management",
					"All template options should be displayed", "All template options are displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify template list in Promotion Management",
					"All template options should be displayed", "All template options are not displayed", "PASS");
		}

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Switch back to main window
		mcd.SwitchToWindow("Promotion");
	}

	// ----------------------------------
	/*
	 * Feature Name : PRICING > Price Set Functionality : Verify
	 * "Activate Selected Menu Items" & "Activate All Menu Items" fields On :
	 * Field Permissions, Roles & User Screen. Scenario ID : PRC_1074 Author :
	 * Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_ADMIN_VerifyActivateFields(String strPath, String[] strFieldNames, String strRoleName,
			String strNavigateToRoles, String strNavigateToUsers, Object strUserName, String strUserColName)
					throws Exception {

		WebElement eleData = null;
		String strNewPath = null;

		// Field Permissions Screen
		// Get Data Element for mentioned fields

		for (int i = 0; i < strFieldNames.length; i++) {
			strNewPath = strPath + strFieldNames[i];
			eleData = rfm.Get_DataElement("FieldPermissions.TableData", strNewPath);
			String strDisplayed_fld = eleData
					.findElement(By.xpath(".//b[contains(text(), '" + strFieldNames[i] + "')]")).getText().trim();
			if (strDisplayed_fld.equals(strFieldNames[i])) {
				actions.reportCreatePASS("Field Permission Screen : Verify " + strFieldNames[i] + " field",
						"Should be displayed", "Displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Field Permission Screen : Verify " + strFieldNames[i] + " field",
						"Should be displayed", "Not Displayed", "FAIL");
			}
		}

		// Roles Screen

		// Navigate to Admin > Roles
		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateToRoles);
		actions.select_menu("RFMHome.Navigate", strNavigateToRoles);
		Thread.sleep(5000);
		actions.waitForPageToLoad(180);

		/** Update title of new Page */
		mcd.SwitchToWindow("#Title");

		// Check whether the page is loaded & View Full list button is present
		actions.WaitForElementPresent("AdminRoles.VwFullListBtn", 50);

		// Click on View Full List
		actions.click("AdminRoles.VwFullListBtn");
		actions.smartWait(50);
		//Thread.sleep(2000);
		//actions.waitForPageToLoad(120);

		// Get the desired role using column name : Role Name, "a" - tag name in
		// html
		//WebElement eleRole = mcd.GetTableCellElement("AdminRoles.RoleListTable", "Role Name", strRoleName, "a", "", "Role Name", "a");
		WebElement eleRole = mcd.GetTableCellElement("AdminRoles.RoleListTable", 1, "Role Name", "a");
		// Verify whether desired role is selected or not
		if (eleRole != null) {
			actions.reportCreatePASS("Verify Desired Role selection", strRoleName + " role should be selected",
					strRoleName + " role selected", "PASS");
			eleRole.click();
		} else {
			actions.reportCreateFAIL("Verify Desired Role selection", strRoleName + " role should be selected",
					strRoleName + " role not selected", "FAIL");
		}

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Get Data Element for mentioned fields
		for (int i = 0; i < strFieldNames.length; i++) {
			strNewPath = strPath + strFieldNames[i];
			eleData = rfm.Get_DataElement("AdminRoles.RoleCategoryTbl", strNewPath);
			String strDisplayed_fld = eleData
					.findElement(By.xpath(".//b[contains(text(), '" + strFieldNames[i] + "')]")).getText().trim();
			if (strDisplayed_fld.equals(strFieldNames[i])) {
				actions.reportCreatePASS("Roles Screen: Verify " + strFieldNames[i] + " field", "Should be displayed",
						"Displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Roles Screen: Verify " + strFieldNames[i] + " field", "Should be displayed",
						"Not Displayed", "FAIL");
			}
		}

		// Users Screen

		// Navigate to Admin > Users
		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateToUsers);
		actions.select_menu("RFMHome.Navigate", strNavigateToUsers);
		Thread.sleep(5000);
		actions.waitForPageToLoad(180);

		/** Update title of new Page */
		mcd.SwitchToWindow("#Title");

		// Get User Id & convert it to string
		strUserName = strUserName.toString();

		// Search for user
		actions.setValue("AdminUsers.SearchBox", strUserName);
		actions.click("AdminUsers.SearchBtn");
		actions.smartWait(120);

		// Get row count for users fetched
		int intRow = mcd.GetTableRowCount("AdminUsers.UserTable");

		// Loop & get the desired user id
		for (int i = 1; i <= intRow; i++) {
			WebElement eleUser = mcd.GetTableCellElement("AdminUsers.UserTable", intRow, strUserColName, "a");
			if (eleUser.getText().trim().equals(strUserName)) {
				System.out.println(strUserName + " found & clicked");
				eleUser.click();
				Thread.sleep(2000);
				actions.waitForPageToLoad(180);
				break;
			}
		}

		// Switch to same window with different title
		mcd.SwitchToWindow("#Title");

		// AdminUsers.RolesTab
		actions.click("AdminUsers.RolesTab");
		actions.smartWait(180);

		// AdminUsers.AllPermissionChkBox
		actions.click("AdminUsers.AllPermissionChkBox");
		actions.smartWait(180);

		// Get Data Element for mentioned fields
		for (int i = 0; i < strFieldNames.length; i++) {
			strNewPath = strPath + strFieldNames[i];
			eleData = rfm.Get_DataElement("AdminUsers.AssigndPermissionTable", strNewPath);
			String strDisplayed_fld = eleData
					.findElement(By.xpath(".//b[contains(text(), '" + strFieldNames[i] + "')]")).getText().trim();
			if (strDisplayed_fld.equals(strFieldNames[i])) {
				actions.reportCreatePASS("Users Screen : Verify " + strFieldNames[i] + " field", "Should be displayed",
						"Displayed", "PASS");
			} else {
				actions.reportCreateFAIL("Users Screen : Verify " + strFieldNames[i] + " field", "Should be displayed",
						"Not Displayed", "FAIL");
			}
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Menu Item > Promotion Management Functionality : Verify
	 * GUI of Promotion Report Scenario ID : MNU_1270, MNU_1272 Author : Pooja
	 * Panse
	 */
	// -----------------------------------

	public void RFM_REPORT_VerifyPromotionDetailReport(String strMessage, String strNodeNum, String strMessage2,
			String strApplicationDate) throws Exception {

		// Verify Select Node button
		// Displayed & Enabled or not
		if (driver.findElement(By.xpath(actions.getLocator("PromotionReport.SelectNodeBtn"))).isDisplayed()) {
			if (driver.findElement(By.xpath(actions.getLocator("PromotionReport.SelectNodeBtn"))).isEnabled()) {
				actions.reportCreatePASS("Verify Select Node button", "Should be displayed & enabled",
						"Select Node button Is Displayed & Enabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Select Node button", "Select Node button Should be displayed & enabled",
						"Select Node button Is Displayed but disabled", "FAIL");
			}
		} else {
			actions.reportCreateFAIL("Verify Select Node button", "Select Node button Should be displayed & enabled", "Select Node button Is not displayed",
					"FAIL");
		}

		// Verify Generate Report button
		// Displayed & Enabled or not
		if (driver.findElement(By.xpath(actions.getLocator("PromotionReport.GenerateReportBtn"))).isDisplayed()) {
			if (driver.findElement(By.xpath(actions.getLocator("PromotionReport.GenerateReportBtn"))).isEnabled()) {
				actions.reportCreatePASS("Verify Generate Report button", "Generate Report button Should be displayed & enabled",
						"Generate Report button Is Displayed & Enabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Generate Report button", "Generate Report button Should be displayed & enabled",
						"Generate Report button Is Displayed but disabled", "FAIL");
			}
		} else {
			actions.reportCreateFAIL("Verify Generate Report button", "Generate Report button Should be displayed & enabled",
					"Generate Report button Is not displayed", "FAIL");
		}

		// Verify Select Node should be Mandatory
		// Click on Generate Report
		actions.click("PromotionReport.GenerateReportBtn");
		Thread.sleep(3000);

		Boolean blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Error", strMessage, true, AlertPopupButton.OK_BUTTON);
		if (blnVerifyPopUp) {
			actions.reportCreatePASS("Verify Select Node is Mandatory", "Selecting Node should be mandatory",
					"Selecting Node is mandatory", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Select Node is Mandatory", "Selecting Node should be mandatory",
					"Selecting Node is not mandatory", "FAIL");
		}

		// Select Node
		// Select a Restaurant
		actions.keyboardEnter("PromotionReport.SelectNodeBtn");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);
		actions.setValue("RFMSelectNode.SearchEditbox", strNodeNum);
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");

		Thread.sleep(3000);
		actions.waitForPageToLoad(120);

		Boolean blnSelectNode = mcd.Selectrestnode_JavaScriptClk("SelectNode.NodeTable", strNodeNum);
		if (blnSelectNode) {
			actions.reportCreatePASS("Verify Node Selection", "Node should be selected", "Node selected", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Node Selection", "Node should be selected", "Node not selected", "FAIL");
		}

		Thread.sleep(3000);
		// Switch back to main window
		mcd.SwitchToWindow("Promotion");

		// Verify date selection
		// Open calender
		actions.click("PromotionReport.Calender");
		Thread.sleep(1000);

		// Verify Past date
		WebElement elePastDate = driver.findElement(
				By.xpath("//td[contains(@class, 'datepickerSelectedToday')]/../preceding-sibling::tr[1]/td[1]"));

		// Get class attribute to verify past date is disabled
		String strAttributeVal = elePastDate.getAttribute("class");
		strAttributeVal = strAttributeVal.toLowerCase();

		// Verify whether disabled
		if (strAttributeVal.contains("disabled")) {
			actions.reportCreatePASS("Verify Select Past Date", "Past dates should be disabled",
					"Past dates are disabled", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Select Past Date", "Past dates should be disabled",
					"Past dates are not disabled", "FAIL");
		}

		// Verify Date is mandatory
		// Click on Generate Report
		actions.click("PromotionReport.GenerateReportBtn");
		Thread.sleep(3000);

		blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Error", strMessage2, true, AlertPopupButton.OK_BUTTON);
		if (blnVerifyPopUp) {
			actions.reportCreatePASS("Verify Effective Date is Mandatory", "Effective Date should be mandatory",
					"Effective Date is mandatory", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Effective Datee is Mandatory", "Effective Date should be mandatory",
					"Effective Date is not mandatory", "FAIL");
		}

		// Open calender
		actions.click("PromotionReport.Calender");
		Thread.sleep(1000);

		// Select today's date
		try {
			mcd.sel_current_date("PromotionReport.Calender");
			actions.reportCreatePASS("Verify Select Today's Date", "Today's date should be selected",
					"Today's date is selected", "PASS");
		} catch (Exception e) {
			actions.reportCreateFAIL("Verify Select Today's Date", "Today's date should be selected",
					"Today's date is not selected", "FAIL");
		}
		// System.out.println(actions.getValue("PromotionReport.EffectiveDate"));
		strApplicationDate = strApplicationDate.split(" ")[0].trim();

		// //System.out.println(strApplicationDate);
		// if(!(actions.getValue("PromotionReport.EffectiveDate").isEmpty())){
		// //if(actions.getValue("PromotionReport.EffectiveDate").equals("strApplicationDate")){
		// actions.reportCreatePASS("Verify Select Today's Date", "Today's date
		// should be selected", "Today's date is selected", "PASS");
		// }else{
		// actions.reportCreateFAIL("Verify Select Today's Date", "Today's date
		// should be selected", "Today's date is not selected", "FAIL");
		// }

		// Open calender
		actions.click("PromotionReport.Calender");
		Thread.sleep(1000);

		// Select future date
		try {
			mcd.Get_future_date(3, "close", strApplicationDate);
			actions.reportCreatePASS("Verify Select Future Date", "Future date should be selected",
					"Future date is selected", "PASS");
		} catch (Exception e) {
			actions.reportCreateFAIL("Verify Select Future Date", "Future date should be selected",
					"Future date is not selected", "FAIL");
		}
		// if(!(actions.getValue("PromotionReport.EffectiveDate").isEmpty())){
		// actions.reportCreatePASS("Verify Select Future Date", "Future date
		// should be selected", "Future date is selected", "PASS");
		// }else{
		// actions.reportCreateFAIL("Verify Select Future Date", "Future date
		// should be selected", "Future date is not selected", "FAIL");
		// }

		// Verify Status Field
		String strDefaultStatus = actions.getValue("PromotionReport.Status");
		if (strDefaultStatus.equalsIgnoreCase("Active/Inactive")) {
			actions.reportCreatePASS("Verify Status field",
					"Field should be present & default value should be Active/Inactive",
					"Present & default value is Active/Inactive", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Status field",
					"Field should be present & default value should be Active/Inactive",
					"Default value is not Active/Inactive", "FAIL");
		}

		// Verify Language Field

		Select select = new Select(driver.findElement(By.xpath(actions.getLocator("PromotionReport.Language"))));
		String[] strLanguageCollection = new String[select.getOptions().size()];
		String strLanguages = null;

		// Get 1st language in string
		strLanguages = actions.getValue("PromotionReport.Language");

		// Get rest of the languages, if any
		for (int j = 1; j < strLanguageCollection.length; j++) {
			strLanguages = strLanguages + ", " + select.getOptions().get(j).getText();
		}

		if (strLanguageCollection.length > 0) {
			actions.reportCreatePASS("Verify Language field", "Languages specific to the market should be available",
					"All the languages (" + strLanguages + ") are displayed", "PASS");
		} else {
			actions.reportCreatePASS("Verify Language field", "Languages specific to the market should be available",
					"No language us displayed", "FAIL");
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Menu Item > Promotion Management Functionality : Verify
	 * the funtionality of select node on Promotion Report screen Scenario ID :
	 * MNU_1271 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_REPORT_VerifySelectNode(String strMessage3, String strNodeNum, String strMessage4)
			throws Exception {
		// Select Node
		// Select a Restaurant
		actions.keyboardEnter("PromotionReport.SelectNodeBtn");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("Select Node");

		// Verify message for Search for no search data entered
		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(2000);

		Boolean blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Error", strMessage3, true,
				AlertPopupButton.OK_BUTTON);
		if (blnVerifyPopUp) {
			actions.reportCreatePASS("Verify Search with no data", "Error message should be displayed",
					"Error message displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Search with no data", "Error message should be displayed",
					"Error message displayed", "FAIL");
		}

		// Select Restaurant Name radio btn
		actions.click("SelectNode.RestNameRadioBtn");

		// Verify Search message for search text as special characters
		// Covers no search data found as well
		// Covers Contains radio btn as well

		actions.setValue("RFMSelectNode.SearchEditbox", "@#$#@");
		Thread.sleep(2000);

		actions.click("SelectNode.SKSearchButton");
		
		Thread.sleep(4000);
		
		/*blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Error", strMessage4, true, AlertPopupButton.OK_BUTTON);
		if (blnVerifyPopUp) {
			actions.reportCreatePASS("Verify Search with data that does not exist",
					"Correct output message pop-up should be displayed", "Correct message pop-up displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Search with data that does not exist",
					"Correct output message pop-up should be displayed", "Correct message pop-up displayed", "FAIL");
		}*/

		// report for contains
		/*if (blnVerifyPopUp) {
			actions.reportCreatePASS("Verify Search with Contains filter",
					"Data should be displayed on the basis of the Search criteria",
					"Data is displayed on the basis of the Search criteria", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Search with Contains filter",
					"Data should be displayed on the basis of the Search criteria",
					"Data is not displayed on the basis of the Search criteria", "FAIL");
		}*/

		// Search in restaurant name : Begins with

		// Clear the search box
		//actions.clear("SelectNode.SearchBox");
		// Select Begins with radio btn
		actions.click("SelectNode.BeginsWithRadiobtn");
		//actions.keyboardEnter("ManageMenuItemSet.BeginsWith");
		Thread.sleep(1000);
		actions.setValue("RFMSelectNode.SearchEditbox", "a");
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(2000);

		WebElement eleMarketTree;
		String strXPath = null;
		String strSelectedRestaurant = null;
		Boolean blnReturn = false;

		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strMessage4, true, AlertPopupButton.OK_BUTTON);
			actions.reportCreatePASS("Verify Search with Begins with filter",
					"Data should be displayed on the basis of the Search criteria",
					"Data is displayed on the basis of the Search criteria", "PASS");
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
			System.out.println("Data fetched. Verifying the data.");

			eleMarketTree = actions.getwebDriverLocator(actions.getLocator("SelectNode.NodeTable"));
			strXPath = "//label[contains(text(),'a')]";
			strSelectedRestaurant = null;
			blnReturn = false;

			List<WebElement> eleMarket = eleMarketTree.findElements(By.xpath(strXPath));

			for (int n = 0; n < eleMarket.size(); n++) {
				strSelectedRestaurant = eleMarket.get(n).getText().trim().split("-")[1].trim();
				//if (strSelectedRestaurant.toLowerCase().startsWith("a")) {
				if (strSelectedRestaurant.toLowerCase().contains("a")) {
					blnReturn = true;
				} else {
					blnReturn = false;
					break;
				}
			}

			if (blnReturn) {
				actions.reportCreatePASS("Verify Search with Begins with filter",
						"Data should be displayed on the basis of the Search criteria",
						"Data is displayed on the basis of the Search criteria", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Search with Begins with filter",
						"Data should be displayed on the basis of the Search criteria",
						"Data is not displayed on the basis of the Search criteria", "FAIL");
			}
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
		}

		// Search in restaurant name : Ends with

		// Clear the search box
		//actions.clear("SelectNode.SearchBox");
		// Select Ends with radio btn
		actions.click("SelectNode.EndsWithRadiobtn");
		Thread.sleep(1000);
		// Clear the search box
		actions.setValue("RFMSelectNode.SearchEditbox", "a");
		Thread.sleep(1000);
		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(2000);

		List<WebElement> eleMarket;

		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strMessage4, true, AlertPopupButton.OK_BUTTON);
			actions.reportCreatePASS("Verify Search with Ends with filter",
					"Data should be displayed on the basis of the Search criteria",
					"Data is displayed on the basis of the Search criteria", "PASS");
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
			System.out.println("Data fetched. Verifying the data.");

			eleMarketTree = actions.getwebDriverLocator(actions.getLocator("SelectNode.NodeTable"));
			strXPath = "//label[contains(text(),'a')]";
			strSelectedRestaurant = null;
			blnReturn = false;

			eleMarket = eleMarketTree.findElements(By.xpath(strXPath));

			for (int n = 0; n < eleMarket.size(); n++) {
				strSelectedRestaurant = eleMarket.get(n).getText().trim();
				//if (strSelectedRestaurant.toLowerCase().endsWith("a")) {
				if (strSelectedRestaurant.toLowerCase().contains("a")) {
					blnReturn = true;
				} else {
					blnReturn = false;
					break;
				}
			}

			if (blnReturn) {
				actions.reportCreatePASS("Verify Search with Ends with filter",
						"Data should be displayed on the basis of the Search criteria",
						"Data is displayed on the basis of the Search criteria", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Search with Ends with filter",
						"Data should be displayed on the basis of the Search criteria",
						"Data is not displayed on the basis of the Search criteria", "FAIL");
			}
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

		}

		// Verify Reset Button

		actions.click("SelectNode.ResetBtn");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Verify that the tree structure is reset
		Boolean blnReset = false;
		try {
			if (driver.findElements(By.xpath("//*[@style = 'display: none;']")).size() == 0) {
				blnReset = false;
			} else {
				blnReset = true;
			}
		} catch (Exception e) {
			blnReset = false;
		}

		// Get value of search box -- it should be cleared
		if ((blnReset) && (actions.getValue("RFMSelectNode.SearchEditbox").isEmpty())) {
			actions.reportCreatePASS("Verify Reset button", "Data should be reset", "Data is reset to default", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Reset button", "Data should be reset", "Data is not reset to default",
					"FAIL");
		}

		// Search in restaurant name : Exact Match

		// Select Exact Match with radio btn

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);
		actions.setValue("RFMSelectNode.SearchEditbox", strNodeNum);
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		//Boolean blnSelectNode = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);	
		Boolean blnSelectNode = mcd.Selectrestnode_JavaScriptClk("SelectNode.NodeTable", strNodeNum);

		if (blnSelectNode) {
			actions.reportCreatePASS("Verify Search with Exact match filter",
					"Data should be displayed on the basis of the Search criteria",
					"Data is displayed on the basis of the Search criteria", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Search with Exact match filter",
					"Data should be displayed on the basis of the Search criteria",
					"Data is not displayed on the basis of the Search criteria", "FAIL");
		}

		if (blnSelectNode) {
			actions.reportCreatePASS("Verify Node Selection", "Node should be selected", "Node selected", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Node Selection", "Node should be selected", "Node not selected", "FAIL");
		}

		Thread.sleep(3000);
		// Switch back to main window
		mcd.SwitchToWindow("Promotion");
	}


	// ----------------------------------
	/*
	 * Feature Name : PRICING > Price Sets Functionality : Associate a tax chain
	 * to a menu item (Pre-requisite for TC : PRC_1078 Scenario ID : Used in
	 * PRC_1078. Author : Pooja Panse
	 */
	// -----------------------------------

	public int RFM_PRC_AssociateMenuItemToTaxChain(String strNameOfCol, String strTaxCode, String strTaxRule)
			throws Exception {
		// String strTaxChainName = null;

		// Index to be selected
		int strTxChainIndex = 2;

		int iPSNameCol = mcd.GetTableColumnNumber("RFM.WebTable", strNameOfCol);

		WebElement eleTable = driver.findElement(By.xpath(actions.getLocator("RFM.WebTable")));
		List<WebElement> eleRws = eleTable.findElements(By.xpath("tbody/tr"));
		WebElement elePrcSet = null;
		String strPrcSetName = null;

		if (eleRws.size() > 0) {

			elePrcSet = eleRws.get(0).findElement(By.xpath("./td[" + iPSNameCol + "]/a"));
			strPrcSetName = elePrcSet.getText().trim();
			elePrcSet.sendKeys(Keys.ENTER);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
		} else {
			actions.reportCreateFAIL("Verify whether price set exist", "Atleast 1 price set should be present",
					"No price set should be present", "FAIL");
		}

		mcd.SwitchToWindow("#Title");

		// Enter Price in 1st Menu Item : (So that taxes can be applied)
		actions.setValue("PriceTypes.All", "1.00");
		Thread.sleep(3000);

		// Enter tax rule
		// Set Tax Code as Never
		actions.setValue("PriceTypes.TaxCode", strTaxCode);
		Thread.sleep(2000);

		Boolean VerifyPopUpMsg = false;
		// Pop Up message verification in case any
		try {
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
					"Tax cannot be applied to Menu Item as they are not priced.", true, AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			System.out.println(e);
		}

		if (VerifyPopUpMsg) {
			System.out.println("Warning msg before entering tax - PASS");
		} else {
			System.out.println("Warning msg before entering tax - FAIL");

		}

		int temp = 0;
		// Make some tax settings to verify copy tax
		// Tax Code
		String t = null;
		t = actions.getValue("PriceTypes.TaxCode");
		if (actions.getValue("PriceTypes.TaxCode").trim().equals(strTaxCode)) {
			temp++;
		} else {
			actions.setValue("PriceTypes.TaxCode", strTaxCode);
			Thread.sleep(1000);
		}
		Thread.sleep(3000);

		// Tax Rule

		if (actions.getValue("PriceTypes.TaxRule").trim().equals(strTaxCode)) {
			temp++;
		} else {
			actions.setValue("PriceTypes.TaxRule", strTaxRule);
			Thread.sleep(1000);
		}

		Thread.sleep(3000);
		actions.setValue("PriceTypes.TaxEntry", "TaxChain 1");

		// Select select =new Select
		// (driver.findElement(By.xpath(actions.getLocator("PriceTypes.TaxEntry"))));
		// select.selectByIndex(2);
		Thread.sleep(2000);

		// Apply changes

		actions.click("FutureSettings.Apply");
		actions.smartWait(180);

		// return strTaxChainName;
		return strTxChainIndex;
	}

	// ----------------------------------
	/*
	 * Feature Name : PRICING > Tax Chain Functionality : Verify that a Tax
	 * Chain may not be set to inactive if it is associated with menu item price
	 * information. Scenario ID : PRC_1078 Author : Pooja Panse
	 */
	// -----------------------------------
	public void RFM_PRC_VerifyDeactivateTaxChain(String strTaxChain, String strTaxCol, String strStatus,
			String strResultMsg) throws Exception {

		// Search required Tax chain name
		actions.setValue("PricingSets.SearchTextBox", strTaxChain);
		actions.keyboardEnter("RFM.SearchBtn");
		actions.smartWait(120);

		// Get Column Number for Tax chain name

		List<WebElement> eleHearderList = driver.findElements(By.xpath(actions.getLocator("RFM.WebTableHeaderTD")));
		int iTCNameCol = 0;

		// Compare the name of column
		for (int j = 0; j < eleHearderList.size(); j++) {
			if (eleHearderList.get(j).getText().trim().equalsIgnoreCase(strTaxCol)) {
				iTCNameCol = j + 1;
				break;
			}
		}

		// Search & Click Tax Chain name
		WebElement eleTaxChain = mcd.GetTableCellElement("RFM.WebTable", 1, iTCNameCol, "a");
		eleTaxChain.sendKeys(Keys.ENTER);

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

		// Change the status to Inactive
		actions.setValue("TaxChain.StatusDrpDwn", strStatus);
		Thread.sleep(500);

		// Click on apply
		actions.click("TaxChain.ApplyBtn");
		Thread.sleep(3000);

		actions.smartWait(180);

		// Verify error message
		actions.verifyTextPresence(strResultMsg, false);

	}

	// ----------------------------------
	/*
	 * Feature Name : MENU ITEM > Promotion Management Functionality : Verify
	 * functionality of Promotion Report Scenario ID : MNU_1274 Author : Pooja
	 * Panse
	 */
	// -----------------------------------l

	public void RFM_REPORT_GeneratePromotionDetailReport(String strNodeNum, String strApplicationDate,
			String strColNames, String strLanguage, String strStatus, String strCodeColumn, String strNameColumn,
			String strTempColumn, String strStrtDtColumn, String strEndDtColumn, String strUser) throws Exception {
		// Select Node
		// Select a Restaurant
		actions.keyboardEnter("PromotionReport.SelectNodeBtn");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);
		actions.setValue("RFMSelectNode.SearchEditbox", strNodeNum);
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");

		Thread.sleep(3000);
		actions.waitForPageToLoad(120);

		WebElement eleMarketTree = actions.getwebDriverLocator(actions.getLocator("SelectNode.NodeTable"));
		String strXPath = "//label[contains(text(),'" + strNodeNum + "')]";
		String strSelectedRestaurant = null;
		Boolean blnReturn = false;
		WebElement eleMarket = eleMarketTree.findElement(By.xpath(strXPath));
		if (eleMarket != null) {
			strSelectedRestaurant = eleMarket.getText().trim();
			eleMarket.click();
			blnReturn = true;
			System.out.println("Restaurant-" + strSelectedRestaurant + " selected successfully");
		} else {
			blnReturn = false;
			System.out.println("Failed to select restaurant-" + strSelectedRestaurant);
		}

		// Got strSelectedRestaurant as restaurant name for future use while
		// verifying report

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		Thread.sleep(3000);
		// Switch back to main window
		mcd.SwitchToWindow("Promotion");

		// Verify date selection
		// Open calender
		actions.click("PromotionReport.Calender");
		Thread.sleep(1000);

		// Select today's date
		try {
			mcd.sel_current_date("PromotionReport.Calender");
			actions.reportCreatePASS("Verify Select Today's Date", "Today's date should be selected",
					"Today's date is selected", "PASS");
		} catch (Exception e) {
			actions.reportCreateFAIL("Verify Select Today's Date", "Today's date should be selected",
					"Today's date is not selected", "FAIL");
		}

		// Select Status
		actions.setValue("PromotionReport.Status", strStatus);

		// Select Language
		actions.setValue("PromotionReport.Language", strLanguage);

		// Click on Generate Report
		actions.click("PromotionReport.GenerateReportBtn");
		Thread.sleep(3000);
		actions.waitForPageToLoad(180);

		// Verify Report generated

		// Get Column count
		int iPromColCnt = mcd.GetTableColumnCount("RFM.WebTable");
		System.out.println(iPromColCnt);

		String strCurrColumn = null;

		// Verify Column Names
		Boolean blnColmnChk = false;

		WebElement eleTable = actions.getwebDriverLocator(actions.getLocator("RFM.WebTable"));
		List<WebElement> eleCols = eleTable.findElements(By.xpath(".//thead/tr[@id='Sr']/td"));

		// Split Column Names string
		String[] columnNamesArr = strColNames.split("#");
		for (int i = 0; i < eleCols.size(); i++) {
			String strColName = eleCols.get(i).getText();
			for (String colName : columnNamesArr) {
				if (colName.toUpperCase().equals(strColName.toUpperCase())) {
					blnColmnChk = true;
				}
			}
		}

		if (blnColmnChk) {
			actions.reportCreatePASS("Verify Promotion Details Report Columns", "All columns should be displayed",
					"All columns is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Promotion Details Report Columns", "All columns should be displayed",
					"All columns are not displayed", "FAIL");
		}

		// Get Column numbers
		int iCodeCol = mcd.GetTableColumnNumber("RFM.WebTable", strCodeColumn);
		int iNameCol = mcd.GetTableColumnNumber("RFM.WebTable", strNameColumn);
		int iTemplateCol = mcd.GetTableColumnNumber("RFM.WebTable", strTempColumn);
		int iStrtDtCol = mcd.GetTableColumnNumber("RFM.WebTable", strStrtDtColumn);
		int iEndDtCol = mcd.GetTableColumnNumber("RFM.WebTable", strEndDtColumn);

		// Verify SORTING

		// Getting Header row (tr)
		WebElement eleHeader = driver.findElement(By.xpath(actions.getLocator("RFM.WebTableHeaderRw")));

		// SORTING - Based on Code

		WebElement eleCodeHD = eleHeader.findElement(By.xpath("td[" + iCodeCol + "]"));
		eleCodeHD.click();

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		eleTable = driver.findElement(By.xpath(actions.getLocator("RFM.WebTable")));
		List<WebElement> eleRws = eleTable.findElements(By.xpath("tbody/tr"));
		int iNewMIRwCnt = eleRws.size();

		// Take 1st two elements for comparison by number
		// Also Store Code element to future use - Verify report

		// WebElement eleCode =
		// eleRws.get(0).findElement(By.xpath("./td["+iCodeCol+"]/a"));

		String iData1 = eleRws.get(0).findElement(By.xpath("./td[" + iCodeCol + "]/a")).getText().trim();
		//String iData2 = eleRws.get(1).findElement(By.xpath("./td[" + iCodeCol + "]/a")).getText().trim();

		//RFM_Verify_Sorting(strCodeColumn, iCodeCol, iData1, iData2);

		// SORTING - Based on Name
		eleHeader = driver.findElement(By.xpath(actions.getLocator("RFM.WebTableHeaderRw")));
		eleCodeHD = eleHeader.findElement(By.xpath("td[" + iNameCol + "]"));
		eleCodeHD.click();

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		eleTable = driver.findElement(By.xpath(actions.getLocator("RFM.WebTable")));
		eleRws = eleTable.findElements(By.xpath("tbody/tr"));
		iNewMIRwCnt = eleRws.size();

		// Take 1st two elements for comparison by number
		iData1 = eleRws.get(0).findElement(By.xpath("./td[" + iNameCol + "]/span")).getText().trim();
		//iData2 = eleRws.get(1).findElement(By.xpath("./td[" + iNameCol + "]/span")).getText().trim();

		//RFM_Verify_Sorting(strNameColumn, iNameCol, iData1, iData2);

		// SORTING - Based on Template
		eleHeader = driver.findElement(By.xpath(actions.getLocator("RFM.WebTableHeaderRw")));
		eleCodeHD = eleHeader.findElement(By.xpath("td[" + iTemplateCol + "]"));
		eleCodeHD.click();

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		eleTable = driver.findElement(By.xpath(actions.getLocator("RFM.WebTable")));
		eleRws = eleTable.findElements(By.xpath("tbody/tr"));
		iNewMIRwCnt = eleRws.size();

		// Take 1st two elements for comparison by number
		iData1 = eleRws.get(0).findElement(By.xpath("./td[" + iTemplateCol + "]/span")).getText().trim();
		//iData2 = eleRws.get(1).findElement(By.xpath("./td[" + iTemplateCol + "]/span")).getText().trim();

		//RFM_Verify_Sorting(strTempColumn, iTemplateCol, iData1, iData2);

		// SORTING - Based on StartDate
		eleHeader = driver.findElement(By.xpath(actions.getLocator("RFM.WebTableHeaderRw")));
		eleCodeHD = eleHeader.findElement(By.xpath("td[" + iStrtDtCol + "]"));
		eleCodeHD.click();

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		eleTable = driver.findElement(By.xpath(actions.getLocator("RFM.WebTable")));
		eleRws = eleTable.findElements(By.xpath("tbody/tr"));
		iNewMIRwCnt = eleRws.size();

		// Take 1st two elements for comparison by number
		iData1 = eleRws.get(0).findElement(By.xpath("./td[" + iStrtDtCol + "]/span")).getText().trim();
		//iData2 = eleRws.get(1).findElement(By.xpath("./td[" + iStrtDtCol + "]/span")).getText().trim();

		//RFM_Verify_Sorting(strStrtDtColumn, iStrtDtCol, iData1, iData2);

		// SORTING - Based on EndDate
		eleHeader = driver.findElement(By.xpath(actions.getLocator("RFM.WebTableHeaderRw")));
		eleCodeHD = eleHeader.findElement(By.xpath("td[" + iEndDtCol + "]"));
		eleCodeHD.click();

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		eleTable = driver.findElement(By.xpath(actions.getLocator("RFM.WebTable")));
		eleRws = eleTable.findElements(By.xpath("tbody/tr"));
		iNewMIRwCnt = eleRws.size();

		// Take 1st two elements for comparison by number
		iData1 = eleRws.get(0).findElement(By.xpath("./td[" + iEndDtCol + "]/span")).getText().trim();
		//iData2 = eleRws.get(1).findElement(By.xpath("./td[" + iEndDtCol + "]/span")).getText().trim();

		//RFM_Verify_Sorting(strEndDtColumn, iEndDtCol, iData1, iData2);

		WebElement eleCode = eleRws.get(0).findElement(By.xpath("./td[" + iCodeCol + "]/a"));

		// Click on 1st code link : to verify the promotion report
		new Actions(driver).moveByOffset(10, 50).click().perform();
		eleCode.click();

		// User is navigated to

		Thread.sleep(2000);
		actions.waitForPageToLoad(180);

		mcd.SwitchToWindow("#Title");

		// Verify Heading displayed
		actions.verifyTextPresence("Promotion Report", false);

		// Verify Report generated at :
		actions.verifyTextPresence("Report generated at", false);

		// Verify Restaurant Name:
		actions.verifyTextPresence(strSelectedRestaurant, false);

		// Verify Report generated on :
		actions.verifyTextPresence("Report generated on", false);

		// Verify Date
		actions.verifyTextPresence(strApplicationDate.split(" ")[0].trim(), false);

		// Verify Report generated by :
		WebElement eleUser = driver.findElement(By.xpath("//td/strong[contains(text(), '" + strUser + "')]"));
		String strUserLabel = eleUser.getText().split("-")[1].trim();
		strUserLabel = strUserLabel.split(" ")[0].trim() + " " + strUserLabel.split(" ")[1].trim();
		actions.verifyTextPresence("Report generated by", false);

		String strDisplayedName = driver
				.findElement(By.xpath("//td/span[contains(text(), 'Report generated by')]/following-sibling::span"))
				.getText();
		System.out.println(strDisplayedName);
		System.out.println(strUserLabel);

		// Verify User Name
		if (strDisplayedName.toLowerCase().trim().equals(strUserLabel.toLowerCase().trim())) {
			actions.reportCreatePASS("Verify User Name in front of Report Create by",
					"Correct User Name should be displayed", "Correct User Name is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Verify User Name in front of Report Create by",
					"Correct User Name should be displayed", "Correct User Name is not displayed", "FAIL");
		}

		// Verify Print button is displayed twice
		int iPrintCnt = driver.findElements(By.xpath(actions.getLocator("PromotionReport.PrintBtn"))).size();
		int iOKCnt = driver.findElements(By.xpath(actions.getLocator("PromotionReport.OkBtn"))).size();

		if ((iPrintCnt == 2) && (iOKCnt == 2)) {
			actions.reportCreatePASS("Verify Print & OK Button",
					"Print and OK button should be displayed above and below of the report screen",
					"Print and OK button is displayed above and below of the report screen", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Print & OK Button",
					"Print and OK button should be displayed above and below of the report screen",
					"Print and OK button is not displayed above and below of the report screen", "FAIL");
		}

		// Click on OK
		// Page should navigate back to last page
		driver.findElements(By.xpath(actions.getLocator("PromotionReport.OkBtn"))).get(1).click();
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

		actions.verifyTextPresence("Promotion Detail Report", false);

	}

	// ----------------------------------
	/*
	 * Feature Name : MENU ITEM > Restaurant Menu Item List Functionality :
	 * Verify that NGABSVolume/ NGABSCode at Restaurant Menu Item List level.
	 * Scenario ID : MNU_1304, MNU_1307 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_RMIL_VerifyNGABSVolume_Code(String strNodeNum, String strStatus, String strFamilyGrp)
			throws Exception {

		String strXPath = "";
		String strSelectedRestaurant = null;
		WebElement eleMarketTree = null;
		boolean blnReturn = false;
		String strDisplayedRest = null;

		// Select a Restaurant
		actions.keyboardEnter("RestMIList.SelectRestBtn");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("Select a Restaurant");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);
		actions.setValue("SelectNode.SearchBox", strNodeNum);
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		Boolean blnSelectRest = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Switch back to Restaurant Menu Item List Window
		mcd.SwitchToWindow("Restaurant Menu Item List");

		// Field : STATUS

		// Select Status - Active
		actions.setValue("RestMIList.LevelUpStatusDrpdwn", strStatus);
		actions.smartWait(120);

		// Field : Family Group :
		actions.setValue("RestMIList.LevelUpFamilyGrpDrpdwn", strFamilyGrp);
		actions.smartWait(120);

		actions.click("RestMIList.SearchRestaurant");
		Thread.sleep(2000);
		actions.waitForPageToLoad(180);

		String TableXpath = actions.getLocator("RestMIList.MITableRows");

		List<WebElement> eleRws = driver.findElements(By.xpath(TableXpath));
		int iNewMIRwCnt = eleRws.size();

		// click on first menu item
		actions.keyboardEnter(mcd.GetTableCellElement("RFM.WebTable", 1, "Number", "a"));
//		eleRws.get(0).findElement(By.xpath("./td[1]")).click();
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

		actions.click("RestMIList.POSKVStab");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		try {
			if ((driver.findElement(By.xpath(actions.getLocator("RestMIList.CustomizeBtn"))).isDisplayed())
					&& (driver.findElement(By.xpath(actions.getLocator("RestMIList.CustomizeBtn"))).isEnabled())) {
				rfm.SelectCustOrResetButton("Are you sure you want to Reset to Default?", "RestMIList.CustomizeBtn","RestMIList.CustomizeBtn");
//				actions.click("RestMIList.CustomizeBtn");
			} else {
				actions.reportCreateFAIL("Click Customize Button", "Button should be present & enabled",
						"Not present or is disabled", "FAIL");
			}
		} catch (Exception e) {
			actions.reportCreateFAIL("Click Customize Button", "Button should be present & enabled",
					"Not present or is disabled", "FAIL");
		}

		if (!(driver.findElement(By.xpath(actions.getLocator("RestMIList.NGABSCodeTxtBox"))).isEnabled())) {
			actions.reportCreatePASS("Verify NGABSCode Field", "Should be present but disabled",
					"Is present but disabled", "PASS");
		} else {
			// Verify class name : (As for this fields disabled attribute might
			// not be present
			// for enable - class name is bdr, for disabled - disabledbdr
			String strClass = driver.findElement(By.xpath(actions.getLocator("RestMIList.NGABSCodeTxtBox")))
					.getAttribute("class");
			if (strClass.toLowerCase().trim().contains("disabled")) {
				actions.reportCreatePASS("Verify NGABSCode Field", "Should be present but disabled",
						"Is present but disabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify NGABSCode Field", "Should be present but disabled",
						"Is present but enabled", "FAIL");
			}
		}

		actions.click("RestMIList.ABSSettingStab");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		try {
			if ((driver.findElement(By.xpath(actions.getLocator("RestMIList.CustomizeBtn"))).isDisplayed())
					&& (driver.findElement(By.xpath(actions.getLocator("RestMIList.CustomizeBtn"))).isEnabled())) {
				actions.click("RestMIList.CustomizeBtn");
			} else {
				actions.reportCreateFAIL("Click Customize Button", "Button should be present & enabled",
						"Not present or is disabled", "FAIL");
			}
		} catch (Exception e) {
			actions.reportCreateFAIL("Click Customize Button", "Button should be present & enabled",
					"Not present or is disabled", "FAIL");
		}

		if (!(driver.findElement(By.xpath(actions.getLocator("RestMIList.NGABSVolumeTxtBox"))).isEnabled())) {
			actions.reportCreatePASS("Verify NGABSVolume Field", "Should be present but disabled",
					"Is present but disabled", "PASS");
		} else {
			actions.reportCreateFAIL("Verify NGABSVolume Field", "Should be present but disabled",
					"Is present but enabled", "FAIL");
		}

	}

	// ----------------------------------
	/*
	 * Feature Name : MENU ITEM > Restaurant Menu Item List Functionality
	 * :Verify that Deliver early field is enabled for Non-Cyt items and Non-Cyt
	 * ingredients with values at Restaurant menu item list. Scenario ID :
	 * MNU_1312 Author : Pooja Panse
	 */
	// -----------------------------------

    public void RFM_RMIL_VerifyDeliverEarlyForNonCYT(String strNodeNum, String strStatus, String strMenuItemCls,
            String strCYTItem) throws Exception {
     String strXPath = "";
     String strSelectedRestaurant = null;
     WebElement eleMarketTree = null;
     boolean blnReturn = false;
     String strDisplayedRest = null;

     // Select a Restaurant
     actions.keyboardEnter("RestMIList.SelectRestBtn");

     Thread.sleep(2000);
     actions.waitForPageToLoad(120);

     mcd.SwitchToWindow("Select a Restaurant");

     actions.click("SelectNode.ExactMtchRadiobtn");
     Thread.sleep(1000);
     actions.setValue("SelectNode.SearchBox", strNodeNum);
     Thread.sleep(1000);

     actions.keyboardEnter("SelectNode.SearchButton");

     Thread.sleep(2000);
     actions.waitForPageToLoad(120);

     //changed by smita(9/aug/2016)
     //Selectrestnode() replaced with Selectrestnode_JavaScriptClk
     Boolean blnSelectRest = mcd.Selectrestnode_JavaScriptClk("SelectNode.NodeTable", strNodeNum);

     Thread.sleep(2000);
     actions.waitForPageToLoad(120);

     // Switch back to Restaurant Menu Item List Window
     mcd.SwitchToWindow("Restaurant Menu Item List");

     actions.click("RestMIList.SearchRestaurant");
     Thread.sleep(2000);
     actions.waitForPageToLoad(180);

     // Get ACtive & Product Class Menu Items
     // Field : STATUS

     // Select Status - Active
     actions.setValue("RestMIList.MIStatusDrpdwn", strStatus);
     actions.smartWait(120);

     // Field : MI Class :
     actions.setValue("RestMIList.LevelUpMIClassDrpdwn", strMenuItemCls);
     actions.smartWait(120);

     actions.setValue("RestMIList.MIClassDrpdwn", strMenuItemCls);
     actions.smartWait(120);

     // Get the new table element
     //click on 1st record
     mcd.GetTableCellElement("RestMIList.MITable", 1, 1, "a").click();
     //actions.click(eleMI);
     mcd.SwitchToWindow("#Title");

     actions.click("RestMIList.RoutingTab");
     Thread.sleep(2000);
     actions.waitForPageToLoad(120);

     // Click on Customize btn
     // Click on Customize btn
		/*try {
			if ((driver.findElement(By.xpath(actions.getLocator("RestMIList.CustomizeBtn"))).isDisplayed())
					&& (driver.findElement(By.xpath(actions.getLocator("RestMIList.CustomizeBtn"))).isEnabled())) {
				actions.click("RestMIList.CustomizeBtn");
			} else {
				actions.reportCreateFAIL("Click Customize Button", "Button should be present & enabled",
						"Not present or is disabled", "FAIL");
			}
		} catch (Exception e) {
			actions.reportCreateFAIL("Click Customize Button", "Button should be present & enabled",
					"Not present or is disabled", "FAIL");
		}*/
		
		rfm.SelectCustOrResetButton("Are you sure you want to Reset to Default?", "RestMIList.CustomizeBtn","RestMIList.CustomizeBtn");
		

     // Verify Fields : CYT Item & CYT Early Delivery
     Boolean blnFieldStatus = false;
     // For CYT Item not selected any value (i.e equal to select)
     if (actions.getValue("RestMIList.CYTItemDrpDwn").trim().equalsIgnoreCase("Select")) {
            // Its a non-cyt product
            // Check whether early delivery is enable
            blnFieldStatus = mcd.ISAttributePresent("RestMIList.CYTEarlyDeliveryDrpDwn", "disabled");
            if (!(blnFieldStatus)) {
                  actions.reportCreatePASS("Verify Deliver early field for Non-Cyt items",
                                "Deliver early field should be enabled", "Deliver early field is enabled", "PASS");
            } else {
                  actions.reportCreateFAIL("Verify Deliver early field for Non-Cyt items",
                                "Deliver early field should be enabled", "Deliver early field is not enabled", "FAIL");
            }

            
     } else {
            // Its a cyt product
            // Check whether early delivery is disable
            blnFieldStatus = mcd.ISAttributePresent("RestMIList.CYTEarlyDeliveryDrpDwn", "disabled");
            if (blnFieldStatus) {
                  actions.reportCreatePASS("Verify Deliver early field for Cyt items",
                                "Deliver early field should be disabled", "Deliver early field is disabled", "PASS");
            } else {
                  actions.reportCreateFAIL("Verify Deliver early field for Cyt items",
                                "Deliver early field should be disabled", "Deliver early field is not disabled", "FAIL");
            }
     }
}


	// ----------------------------------
	/*
	 * Feature Name : MENU ITEM > Restaurant Menu Item List Functionality
	 * :Verify that CYT preview image and CYT preview bottom image cannot be
	 * customized at Restaurant menu item list. Scenario ID : MNU_1312 Author :
	 * Pooja Panse
	 */
	// -----------------------------------

	public void RFM_RMIL_VerifyCYTImageDisabled(String strNodeNum, String strStatus, String strMenuItemCls)
			throws Exception {
		String strXPath = "";
		String strSelectedRestaurant = null;
		WebElement eleMarketTree = null;
		boolean blnReturn = false;
		String strDisplayedRest = null;

		// Select a Restaurant
		actions.keyboardEnter("RestMIList.SelectRestBtn");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("Select a Restaurant");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);
		actions.setValue("SelectNode.SearchBox", strNodeNum);
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		Boolean blnSelectRest = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Switch back to Restaurant Menu Item List Window
		mcd.SwitchToWindow("Restaurant Menu Item List");

		actions.click("RestMIList.SearchRestaurant");
		Thread.sleep(2000);
		actions.waitForPageToLoad(180);

		// Get ACtive & Product Class Menu Items
		// Field : STATUS

		// Select Status - Active
		actions.setValue("RestMIList.MIStatusDrpdwn", strStatus);
		actions.smartWait(120);

		// Field : MI Class :
		actions.setValue("RestMIList.LevelUpMIClassDrpdwn", strMenuItemCls);
		actions.smartWait(120);

		actions.setValue("RestMIList.MIClassDrpdwn", strMenuItemCls);
		actions.smartWait(120);

		/*actions.setValue("RestaurantMenuItemList.SearchBox", "7");
		actions.keyboardEnter("RestaurantMenuItemList.SearchBox");
		actions.smartWait(180); */
		
		// Get the new table element

		//String TableXpath = actions.getLocator("RestMIList.MITableRows");

		List<WebElement> eleRws = driver.findElements(By.xpath("//*[@id='Sess1']//tbody[@id='menuItemsData']/tr/td[1]/a"));
		int iNewMIRwCnt = eleRws.size();
		
				
		// click on first menu item
		//eleRws.get(0).findElement(By.xpath("./td[1]")).click();
		eleRws.get(1).click();
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

		actions.click("RestMIList.PresentationTab");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Click on Customize btn

		try {
			if ((driver.findElement(By.xpath(actions.getLocator("RestMIList.CustomizeBtn"))).isDisplayed())
					&& (driver.findElement(By.xpath(actions.getLocator("RestMIList.CustomizeBtn"))).isEnabled())) {
				actions.click("RestMIList.CustomizeBtn");
			} else {
				actions.reportCreateFAIL("Click Customize Button", "Button should be present & enabled",
						"Not present or is disabled", "FAIL");
			}
		} catch (Exception e) {
			actions.reportCreateFAIL("Click Customize Button", "Button should be present & enabled",
					"Not present or is disabled", "FAIL");
		}

		// Verify Fields : CYT Preview Image & CYT bottom preview image
		Boolean blnImageStatus1 = false;
		Boolean blnImageStatus2 = false;

		blnImageStatus1 = mcd.ISAttributePresent("RestMIList.CYTPrvwImg", "disabled");
		blnImageStatus2 = mcd.ISAttributePresent("RestMIList.CYTPrvwBtnImg", "disabled");

		if ((blnImageStatus1) && (blnImageStatus2)) {
			actions.reportCreatePASS("Verify CYT Preview Image & CYT Preview Bottom Image",
					"CYT Preview Image & CYT Preview Bottom Image should be disabled",
					"CYT Preview Image & CYT Preview Bottom Image is disabled", "PASS");
		} else {
			actions.reportCreateFAIL("Verify CYT Preview Image & CYT Preview Bottom Image",
					"CYT Preview Image & CYT Preview Bottom Image should be disabled",
					"CYT Preview Image & CYT Preview Bottom Image is not disabled", "FAIL");
		}

	}


	// ----------------------------------
	/*
	 * Feature Name : PRICING > Tax Chain Functionality : Verify the error
	 * message displayed when user enters a duplicate Tax Chain Name. Scenario
	 * ID : PRC_1080 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_VerifyDuplicateTaxChainErrorMsg(String strTaxCol, String strNodeNum, String strResultMsg,
			String strWarningMsg) throws Exception {

		// Get Column Number for Tax chain name

		List<WebElement> eleHearderList = driver.findElements(By.xpath(actions.getLocator("RFM.WebTableHeaderTD")));
		int iTCNameCol = 0;

		// Compare the name of column
		for (int j = 0; j < eleHearderList.size(); j++) {
			if (eleHearderList.get(j).getText().trim().equalsIgnoreCase(strTaxCol)) {
				iTCNameCol = j + 1;
				break;
			}
		}

		// Search & Click Tax Chain name
		WebElement eleTaxChain = mcd.GetTableCellElement("RFM.WebTable", 1, iTCNameCol, "a");

		// Get the name of an existing tax chain name
		String strTaxChainName = eleTaxChain.getText();

		// Click on New Tax Chain button
		actions.click("TaxChain.NewTaxChainBtn");

		// Switch to window
		mcd.SwitchToWindow("Add New Tax Chain");

		// Enter Name of existing tax chain name
		actions.setValue("TaxChain.TxChnName", strTaxChainName);

		// Select Node
		// Select a Restaurant
		actions.keyboardEnter("TaxChain.SelectNodeBtn");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);
		actions.setValue("SelectNode.SearchBox", strNodeNum);
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");

		Thread.sleep(3000);
		actions.waitForPageToLoad(120);

//		Boolean Node_chk = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);
		Boolean Node_chk = mcd.Selectrestnode_JavaScriptClk("SelectNode.NodeTable", strNodeNum);
		Thread.sleep(3000);

		// Switch to New Tax chain window

		mcd.SwitchToWindow("Add New Tax Chain");

		// Click on next
		actions.click("TaxChain.NextBtn");

		// Try-catch block to handle new change in the 2.10.5 build
		// Earlier error was given on the new tax chn window itself.
		// But in this build it allows to go to next page n gives the duplicate
		// error there.
		try {
			// Verify error message
			actions.verifyTextPresence(strResultMsg, false);

			// Click on Cancel
			actions.click("RFM.CancelBtn");
			Thread.sleep(3000);

			Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strWarningMsg, true,
					AlertPopupButton.OK_BUTTON);

			actions.reportCreatePASS("Verify Error message for duplicate Tax chain name",
					"Error message should be given for duplicate tax chain name",
					"Error message given for duplicate tax chain name", "PASS");

			// Switch to old window
			mcd.SwitchToWindow("Tax Chain");
		}

		catch (Exception err) {

			driver.switchTo().window("");

			// Update new title : Add Tax Chain
			mcd.SwitchToWindow("@Add Tax Chain");

			actions.setValue("TaxChain.TaxCode", "1111");

			actions.click("TaxChain.TblRow");

			actions.click("TaxChain.AddRowBtn");

			actions.click("TaxChainVerify.SaveBtn");

			// Verify error message
			actions.verifyTextPresence(strResultMsg, true);

			actions.reportCreatePASS("Verify Error message for duplicate Tax chain name",
					"Error message should be given for duplicate tax chain name",
					"Error message given for duplicate tax chain name", "PASS");

		}

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Tax Chain Functionality : Create a new Tax
	 * chain, without copying existing Scenario ID : Pre-requisite for
	 * PRC_1082/PRC_1083/PRC_1084/PRC_1085 Author : Pooja Panse
	 */
	// -----------------------------------

	public String RFM_PRC_Create_NewTaxChain(String strMarket, String strResultMsg) throws Exception {
		String strTxChnName = null;
		strTxChnName = mcd.fn_GetRndName("Auto");
		strTxChnName = strTxChnName.subSequence(0, 10).toString();

		// Click on New Tax Chain button
		actions.WaitForElementPresent("TaxChain.NewTaxChainBtn");
		actions.keyboardEnter("TaxChain.NewTaxChainBtn");

		// Switch to window
		mcd.SwitchToWindow("Add New Tax Chain");

		// Enter Name of existing tax chain name
		actions.setValue("TaxChain.TxChnName", strTxChnName);

		// Select Node
		// Select a Restaurant
		actions.keyboardEnter("TaxChain.SelectNodeBtn");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("Select Node");

		String strXPath = "";
		WebElement eleMarketTree = null;
		boolean blnReturn = false;
		eleMarketTree = actions.getwebDriverLocator(actions.getLocator("SelectNode.NodeTable"));
		strXPath = "//span[contains(text(),'" + strMarket + "')]";
		WebElement eleMarket = eleMarketTree.findElement(By.xpath(strXPath));
		if (eleMarket != null) {
			eleMarket.click();
			blnReturn = true;
			System.out.println("Node" + strMarket + " selected successfully");
		} else {
			blnReturn = false;
			System.out.println("Failed to select restaurant-" + strMarket);
		}

		// Boolean Node_chk = mcd.Selectrestnode("SelectNode.NodeTable",
		// strMarket);

		// Switch to New Tax chain window

		mcd.SwitchToWindow("Add New Tax Chain");

		// Click on next
		actions.keyboardEnter("TaxChain.NextBtn");

		Thread.sleep(7000);

		// Switch to the "Add Tax Chain" window
		mcd.SwitchToWindow("@Add Tax Chain");

		Thread.sleep(3000);

		// Enter Tax Code
		// Generate a random code
		Random rand_num = new Random();
		int iTaxCode = rand_num.nextInt((500) + 50);
		System.out.println(iTaxCode);
		actions.setValue("TaxChain.TaxCode", Integer.toString(iTaxCode));

		// Set the Tax chain active

		actions.setValue("TaxChain.StatusDrpDwn", "Active");
		Thread.sleep(500);

		// Select 1st available tax type
		actions.click("TaxChain.TblRow");

		// Add the row
		actions.click("TaxChain.AddRowBtn");

		// Click on apply
		actions.click("TaxChain.ApplyBtn");
		Thread.sleep(3000);

		actions.smartWait(180);

		// Verify success message message
		actions.verifyTextPresence(strResultMsg, false);

		// Switch to window with diff name
		mcd.SwitchToWindow("#Title");

		return strTxChnName;

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Tax Chain Functionality : Create a new Tax
	 * chain, with/without copying existing Scenario ID : PRC_0066/PRC_0067
	 * Author : Pooja Panse
	 */
	// -----------------------------------

	public String RFM_PRC_Create_NewTaxChain(String strMarket, String strResultMsg, String strCpyFlag, String strStatus)
			throws Exception {
		String strTxChnName = null;
		strTxChnName = mcd.fn_GetRndName("Auto");
		strTxChnName = strTxChnName.subSequence(0, 10).toString();

		// Click on New Tax Chain button
		actions.keyboardEnter("TaxChain.NewTaxChainBtn");

		// Switch to window
		mcd.SwitchToWindow("Add New Tax Chain");

		// Enter Name of existing tax chain name
		actions.setValue("TaxChain.TxChnName", strTxChnName);

		// Select Node
		// Select a Restaurant
		actions.keyboardEnter("TaxChain.SelectNodeBtn");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.waitAndSwitch("Select Node");

		String strXPath = "";
		WebElement eleMarketTree = null;
		boolean blnReturn = false;
		eleMarketTree = actions.getwebDriverLocator(actions.getLocator("SelectNode.NodeTable"));
		strXPath = "//span[contains(text(),'" + strMarket + "')]";
		WebElement eleMarket = eleMarketTree.findElement(By.xpath(strXPath));
		if (eleMarket != null) {
			eleMarket.click();
			blnReturn = true;
			System.out.println("Node" + strMarket + " selected successfully");
		} else {
			blnReturn = false;
			System.out.println("Failed to select restaurant-" + strMarket);
		}

		// Boolean Node_chk = mcd.Selectrestnode("SelectNode.NodeTable",
		// strMarket);

		// Switch to New Tax chain window

		mcd.SwitchToWindow("Add New Tax Chain");

		switch (strCpyFlag.trim().toLowerCase()) {
		case "yes":

			actions.click("SelectNode.CopyRadioButtonYes");
			Thread.sleep(2000);

			actions.click("TaxChain.SelectTaxToCpy");
			Thread.sleep(2000);

			mcd.SwitchToWindow("Copy Settings From Existing Tax Type");

			actions.click("RFM.ViewFullListBtn");

			Thread.sleep(500);
			actions.smartWait(120);

			int iCol = mcd.GetTableColumnNumber("RFM.WebTable", "Tax Chain Name");

			mcd.GetTableCellElement("RFM.WebTable", 1, iCol, "a").click();
			Thread.sleep(1000);

			mcd.SwitchToWindow("Add New Tax Chain");

			break;
		case "no":
			actions.click("SelectNode.CopyRadioButtonNo");
			Thread.sleep(2000);
			break;
		default:
			System.out.println("Please enter correct copy existing flag");
			break;
		}

		// Click on next
		actions.keyboardEnter("TaxChain.NextBtn");

		Thread.sleep(7000);

		// Switch to the "Add Tax Chain" window
		mcd.SwitchToWindow("@Add Tax Chain");

		Thread.sleep(3000);

		// Enter Tax Code
		// Generate a random code
		Random rand_num = new Random();
		int iTaxCode = rand_num.nextInt((500) + 50);
		System.out.println(iTaxCode);
		actions.setValue("TaxChain.TaxCode", Integer.toString(iTaxCode));

		// Set the Tax chain active
		if (strStatus.trim().equalsIgnoreCase("Active")) {
			actions.setValue("TaxChain.StatusDrpDwn", "Active");
			Thread.sleep(500);
		}

		// Select 1st available tax type
		actions.click("TaxChain.TblRow");

		// Add the row
		actions.click("TaxChain.AddRowBtn");

		// Click on apply
		actions.click("TaxChain.ApplyBtn");
		Thread.sleep(3000);

		actions.smartWait(180);

		// Verify success message message
		actions.verifyTextPresence(strResultMsg, false);

		actions.reportCreatePASS("Verify tax chain creation",
				"New tax chain should be created with copy existing set to " + strCpyFlag + ".",
				strTxChnName + " tax chain created with copy existing set to " + strCpyFlag + ".", "PASS");

		// Switch to window with diff name
		mcd.SwitchToWindow("#Title");

		actions.click("RFM.CancelBtn");

		// Switch to window with diff name
		mcd.SwitchToWindow("#Title");

		return strTxChnName;

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Tax Chain Functionality : Verify Updating Tax
	 * Chain Name Scenario ID : Pre-requisite for
	 * PRC_1082/PRC_1083/PRC_1084/PRC_1085 Author : Pooja Panse
	 */
	// -----------------------------------

	public String RFM_PRC_VerifyTaxChainNameUpdate(String strTaxCol, String strNodeNum, String strResultMsg,
			String strWarningMsg1, String strWarningMsg2) throws Exception {

		// //Get Column Number for Tax chain name
		//
		// List <WebElement> eleHearderList =
		// driver.findElements(By.xpath(actions.getLocator("RFM.WebTableHeaderTD")));
		// int iTCNameCol = 0;
		//
		// //Compare the name of column
		// for(int j=0; j<eleHearderList.size(); j++){
		// if(eleHearderList.get(j).getText().trim().equalsIgnoreCase(strTaxCol)){
		// iTCNameCol = j+1;
		// break;
		// }
		// }
		//
		// //Search & Click Tax Chain name
		// WebElement eleTaxChain = mcd.GetTableCellElement("RFM.WebTable", 1,
		// iTCNameCol, "a");
		//
		// //Get the name of an existing tax chain name
		// String strTaxChainName = eleTaxChain.getText();
		// eleTaxChain.sendKeys(Keys.ENTER);
		//
		// Thread.sleep(2000);
		// //actions.waitForPageToLoad(120);
		//
		// mcd.SwitchToWindow("#Title");

		String strUpdtTCName = mcd.fn_GetRndName("TxChn");
		strUpdtTCName = strUpdtTCName.subSequence(0, 10).toString();
		System.out.println(strUpdtTCName);

		// Clear the name
		actions.clear("TaxChain.TaxChainName");
		Thread.sleep(2000);

		// Enter the updated name
		actions.setValue("TaxChain.TaxChainName", strUpdtTCName);

		// Click on apply
		actions.click("TaxChain.ApplyBtn");
		Thread.sleep(3000);

		// Switch to Apply changes details window
		mcd.SwitchToWindow("Apply Changes Details");

		// Click on Save
		actions.click("RFM.SaveBtn");
		Thread.sleep(3000);

		// Switch to 1st window (hanlde on which we logged in)
		// As on save button the window gets closed & driver though there.. in
		// application its not present
		driver.switchTo().window("");
		// driver.switchTo().alert().accept();

		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Warning", strWarningMsg1, true,
				AlertPopupButton.OK_BUTTON);
		Thread.sleep(5000);
		// Switch back to main window
		mcd.SwitchToWindow("Update Tax Chain");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);
		// Verify success message
		actions.verifyTextPresence(strResultMsg, false);

		return strUpdtTCName;
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Tax Chain Functionality : Verify that Updated
	 * Tax Chain Name must be reflected in Price Set for the Menu Item. Scenario
	 * ID : PRC_1082 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_PriceSet_VerifyTaxChainName(String strNewTxChainName, String strTaxCode, String strTaxRule,
			String strNavigateToPriceSets, String strWarningMsg2) throws Exception {

		// Navigate to PRICING > Fee > Master Fee & Verify

		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateToPriceSets);
		actions.select_menu("RFMHome.Navigate", strNavigateToPriceSets);
		Thread.sleep(5000);
		actions.waitForPageToLoad(120);

		/** Update title of new Page */
		mcd.SwitchToWindow("#Title");
		actions.smartWait(180);

		Actions builder = new Actions(driver);
		builder.moveByOffset(500, 0).click().perform();

		int iPSNameCol = mcd.GetTableColumnNumber("RFM.WebTable", "Name");

		WebElement eleTable = driver.findElement(By.xpath(actions.getLocator("RFM.WebTable")));
		List<WebElement> eleRws = eleTable.findElements(By.xpath("tbody/tr"));
		WebElement elePrcSet = null;
		String strPrcSetName = null;

		if (eleRws.size() > 0) {

			elePrcSet = eleRws.get(0).findElement(By.xpath("./td[" + iPSNameCol + "]/a"));
			strPrcSetName = elePrcSet.getText().trim();
			elePrcSet.sendKeys(Keys.ENTER);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
		} else {
			actions.reportCreateFAIL("Verify whether price set exist", "Atleast 1 price set should be present",
					"No price set should be present", "FAIL");
		}

		mcd.SwitchToWindow("#Title");

		try {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.ViewPrcDetails"))).isDisplayed()) {
				System.out.println("View already in Tax view");
			}
		} catch (Exception e) {
			if (driver.findElement(By.xpath(actions.getLocator("ManagePS.ViewTxDetails"))).isDisplayed()) {
				System.out.println("View already in Tax view");
				actions.click("ManagePS.ViewTxDetails");
				Thread.sleep(2000);
				actions.waitForPageToLoad(120);
			}
		}

		// Enter Price in 1st Menu Item : (So that taxes can be applied)
		actions.setValue("PriceTypes.All", "1.00");
		Thread.sleep(3000);

		// Enter tax rule
		// Set Tax Code as Always
		actions.setValue("PriceTypes.TaxCode", strTaxCode);
		Thread.sleep(2000);

		Boolean VerifyPopUpMsg = false;
		// Pop Up message verification in case any
		try {
			VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error",
					"Tax cannot be applied to Menu Item as they are not priced.", true, AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			System.out.println(e);
		}

		// Enter tax rule
		// Set Tax Code as Always
		actions.setValue("PriceTypes.TaxCode", strTaxCode);
		Thread.sleep(2000);

		// Enter tax rule
		// Set Tax Code as Always
		actions.setValue("PriceTypes.TaxRule", strTaxRule);
		Thread.sleep(2000);

		// Check Tax Entry
		Boolean blnResult = Verify_UpdatedTaxChain_InTaxEntry("PriceTypes.TaxChainEntry", strNewTxChainName);

		if (blnResult) {
			actions.reportCreatePASS("PRICING > Pricing > Price Sets : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("PRICING > Pricing > Price Sets : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is not displayed", "FAIL");
		}

		// Verify Mass Update Tax Setting
		actions.click("ManagePS.MassTaxUpdateBtn");

		Thread.sleep(2000);
		Boolean blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Warning", strWarningMsg2, true,
					AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		// Switch to Maas Update Tax window
		mcd.SwitchToWindow("Maas Update Tax");

		Thread.sleep(2000);

		// Enter Tax Code
		actions.setValue("UpdateTax.TaxCode", strTaxCode);
		Thread.sleep(3000);

		// Select Tax Rule
		actions.setValue("UpdateTax.TaxRule", strTaxRule);
		Thread.sleep(1000);

		// Check Tax Entry
		blnResult = Verify_UpdatedTaxChain_InTaxEntry("UpdateTax.TaxChainEntry", strNewTxChainName);

		if (blnResult) {
			actions.reportCreatePASS("PRICING > Pricing > Price Sets > Mass Update Tax : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("PRICING > Pricing > Price Sets > Mass Update Tax : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is not displayed", "FAIL");
		}

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);
		blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Warning", strWarningMsg2, true,
					AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		// Switch to window
		mcd.SwitchToWindow("Price Sets");

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Tax Chain Functionality : Verify that updated
	 * Tax Chain Name is reflected in Restaurant profile. Scenario ID : PRC_1083
	 * Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_ADM_RestProf_VerifyTaxChainName(String strNewTxChainName, String strRPColm, String strTaxCode,
			String strTaxRule, String strNavigateToRest, String strWarningMsg2) throws Exception {

		// Navigate to RP & Verify

		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateToRest);
		actions.select_menu("RFMHome.Navigate", strNavigateToRest);
		Thread.sleep(5000);
		actions.waitForPageToLoad(120);

		/** Update title of new Page */
		mcd.SwitchToWindow("#Title");

		// Get Column Number for Restaurant name

		List<WebElement> eleHearderList = driver.findElements(By.xpath(actions.getLocator("RFM.WebTableHeaderTD")));
		int iTCNameCol = 0;
		// Compare the name of column
		for (int j = 0; j < eleHearderList.size(); j++) {
			if (eleHearderList.get(j).getText().trim().equalsIgnoreCase(strRPColm)) {
				iTCNameCol = j + 1;
				break;
			}
		}

		// Search & Click Restaurant name
		WebElement eleTaxChain = mcd.GetTableCellElement("RFM.WebTable", 1, iTCNameCol, "a");
		eleTaxChain.sendKeys(Keys.ENTER);

		Thread.sleep(5000);
		actions.waitForPageToLoad(180);

		mcd.SwitchToWindow("#Title");

		// Click on Receipt, Tax & Routing Tab
		actions.keyboardEnter("RestMIList.RecieptTab");

		actions.smartWait(180);

		// Set Tax Code value to Always
		actions.setValue("RestProfile.TaxCode", strTaxCode);
		Thread.sleep(1000);

		// Set Tax Rule to TAx Chain
		actions.setValue("RestProfile.TaxRule", strTaxRule);
		Thread.sleep(1000);

		Boolean blnResult = Verify_UpdatedTaxChain_InTaxEntry("RestProfile.TaxEntry", strNewTxChainName);

		if (blnResult) {
			actions.reportCreatePASS("Restaurant profile > Receipt, Tax & Routing Tab : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Restaurant profile > Receipt, Tax & Routing Tab : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is not displayed", "FAIL");
		}

		// Set Tax Entry to the newly update field.
		actions.setValue("RestProfile.TaxEntry", strNewTxChainName);

		// Verify in Operations detail tab

		actions.keyboardEnter("RestMIList.OperationsTab");
		Thread.sleep(2000);
		Boolean blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg2, true,
					AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		actions.waitForPageToLoad(120);
		Thread.sleep(3000);

		// Fee Set
		Select select = new Select(driver.findElement(By.xpath(actions.getLocator("RestProfile.FeeSet"))));
		select.selectByIndex(1);

		// Click on customize icon
		actions.click("RestProfile.FeeSetCustomize");
		Thread.sleep(3000);

		// Switch to new window
		mcd.SwitchToWindow("Fee Set");

		// Click on the fee set displayed
		actions.click("FeeSet.NameLink");
		Thread.sleep(3000);

		// Switch to new window
		mcd.SwitchToWindow("Manage Fee");

		rfm.SelectCustOrResetButton("Are you sure you want to Reset to Default?", "TaxChainVerify.Customize",
				"TaxChainVerify.ResetToDefault");
		// actions.click("TaxChainVerify.Customize");

		actions.smartWait(120);

		// Set Tax Code value to Always
		actions.setValue("FeeSet.TaxCode", strTaxCode);
		Thread.sleep(1000);

		// Set Tax Rule to TAx Chain
		actions.setValue("FeeSet.TaxRule", strTaxRule);
		Thread.sleep(1000);

		blnResult = Verify_UpdatedTaxChain_InTaxEntry("FeeSet.TaxEntry", strNewTxChainName);

		if (blnResult) {
			actions.reportCreatePASS("Restaurant profile > Fee Set : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Restaurant profile > Fee Set : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is not displayed", "FAIL");
		}

		// Set Tax Entry to the newly update field.
		actions.setValue("FeeSet.TaxEntry", strNewTxChainName);
		Thread.sleep(1000);

		actions.click("RFM.CancelBtn");
		Thread.sleep(3000);

		blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg2, true,
					AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		Thread.sleep(3000);

		mcd.SwitchToWindow("Fee Set");

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);

		// Switch back to 1st window
		mcd.SwitchToWindow("Restaurant Profile");
		Thread.sleep(1000);

		// Deposit Set
		select = new Select(driver.findElement(By.xpath(actions.getLocator("RestProfile.DepositSet"))));
		select.selectByIndex(2);
		Thread.sleep(1000);

		// Click on customize icon
		actions.click("RestProfile.DepositSetCustomize");
		Thread.sleep(3000);

		// Switch to new window
		mcd.SwitchToWindow("Deposit Set");

		// Click on the fee set displayed
		actions.click("DepositSet.NameLink");
		Thread.sleep(3000);

		// Switch to new window
		mcd.SwitchToWindow("Manage Deposit");

		rfm.SelectCustOrResetButton("Are you sure you want to Reset to Default?", "TaxChainVerify.Customize",
				"TaxChainVerify.ResetToDefault");
		// actions.click("TaxChainVerify.Customize");
		Thread.sleep(1000);

		// Set Tax Code value to Always
		actions.setValue("DepositSet.TaxCode", strTaxCode);
		Thread.sleep(1000);

		// Set Tax Rule to TAx Chain
		actions.setValue("DepositSet.TaxRule", strTaxRule);
		Thread.sleep(1000);

		blnResult = Verify_UpdatedTaxChain_InTaxEntry("DepositSet.TaxEntry", strNewTxChainName);

		if (blnResult) {
			actions.reportCreatePASS("Restaurant profile > Deposit Set : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("Restaurant profile > Deposit Set : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is not displayed", "FAIL");
		}

		// Set Tax Entry to the newly update field.
		actions.setValue("DepositSet.TaxEntry", strNewTxChainName);

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);
		blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg2, true,
					AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		actions.waitForPageToLoad(120);
		mcd.SwitchToWindow("Deposit Set");

		actions.click("RFM.CancelBtn");
		Thread.sleep(5000);

		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg2, true,
					AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		// Switch back to 1st window
		mcd.SwitchToWindow("Restaurant Profile");

		actions.click("RFM.CancelBtn");
		Thread.sleep(5000);

		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg2, true,
					AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}
		// Switch back to 1st window
		mcd.SwitchToWindow("#Title");
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Tax Chain Functionality : Verify that updated
	 * Tax Chain Name is reflected in Master Fee. Scenario ID : PRC_1084 Author
	 * : Pooja Panse
	 */
	// -----------------------------------

	
	/*//
	 * Feature Name : Pricing > Tax Chain Functionality : Updated for 'Price type expand' and 'Price type collapse'
	 * Scenario ID : PRC_1084 Author : Purnima Chakladar
	*///
	public void RFM_PRC_MasterFee_VerifyTaxChainName(String strNewTxChainName, String strTaxCode, String strTaxRule,
			String strNavigateToMasterFee, String strWarningMsg2) throws Exception {

		// Navigate to PRICING > Fee > Master Fee & Verify

		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateToMasterFee);
		actions.select_menu("RFMHome.Navigate", strNavigateToMasterFee);
		Thread.sleep(5000);
		actions.waitForPageToLoad(120);

		/** Update title of new Page */
		mcd.SwitchToWindow("#Title");
		actions.smartWait(180);

		Actions builder = new Actions(driver);
		builder.moveByOffset(500, 0).click().perform();

		// Click on View Full List
		actions.click("RFM.ViewFullListBtn");

		int iFeeNameCol = mcd.GetTableColumnNumber("RFM.WebTable", "Fee Name");

		WebElement eleFeeNm = mcd.GetTableCellElement("RFM.WebTable", 1, iFeeNameCol, "a/pre");

		// Click on Element - Fee Name Link
		eleFeeNm.click();

		// Switch
		mcd.SwitchToWindow("#Title");
		
		boolean pricetypeexpand=driver.findElement(By.xpath(actions.getLocator("DepositSet.TaxPlusIcon"))).isDisplayed();
		System.out.println("Price Type Expand : "+pricetypeexpand);
		boolean pricetypecollapse=driver.findElement(By.xpath(actions.getLocator("DepositSet.TaxCollapseIcon"))).isDisplayed();
		System.out.println("Price Type collapse : "+pricetypecollapse);
		if(pricetypecollapse){
			actions.click("DepositSet.TaxCollapseIcon");
			Thread.sleep(1000);
		}
		
		actions.WaitForElementPresent("FeeSet.TaxCode");
		// Set Tax Code value to Always
		actions.setValue("FeeSet.TaxCode", strTaxCode);
		Thread.sleep(1000);

		// Set Tax Rule to TAx Chain
		actions.setValue("FeeSet.TaxRule", strTaxRule);
		Thread.sleep(1000);

		Boolean blnResult = Verify_UpdatedTaxChain_InTaxEntry("FeeSet.TaxEntry", strNewTxChainName);

		if (blnResult) {
			actions.reportCreatePASS("PRICING > Fee > Master Fee : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("PRICING > Fee > Master Fee : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is not displayed", "FAIL");
		}

		// Set Tax Entry to the newly update field.
		actions.setValue("FeeSet.TaxEntry", strNewTxChainName);

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);
		Boolean blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg2, true,
					AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		// Switch to window
		mcd.SwitchToWindow("#Title");

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Tax Chain Functionality : Verify that updated
	 * Tax Chain Name is reflected in Fee Set. Scenario ID : PRC_1084 Author :
	 * Pooja Panse
	 */
	// -----------------------------------
	
	/*//
	 * Feature Name : Pricing > Tax Chain Functionality : Updated for 'Price type expand' and 'Price type collapse'
	 * Scenario ID : PRC_1084 Author : Purnima Chakladar
	*///

	public void RFM_PRC_FeeSet_VerifyTaxChainName(String strNewTxChainName, String strTaxCode, String strTaxRule,
			String strNavigateToFeeSet, String strWarningMsg2) throws Exception {

		// Navigate to PRICING > Fee > Fee Sets & Verify

		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateToFeeSet);
		actions.select_menu("RFMHome.Navigate", strNavigateToFeeSet);
		Thread.sleep(5000);
		actions.waitForPageToLoad(120);

		/** Update title of new Page */
		mcd.SwitchToWindow("#Title");

		Actions builder = new Actions(driver);
		builder.moveByOffset(500, 0).click().perform();

		// Click on View Full List
		actions.click("RFM.ViewFullListBtn");
		actions.smartWait(180);

		int iFeeNameCol = mcd.GetTableColumnNumber("RFM.WebTable", "Name");

		WebElement eleFeeSetNm = mcd.GetTableCellElement("RFM.WebTable", 1, iFeeNameCol, "a");

		// Click on Element - Fee Name Link
		eleFeeSetNm.click();
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Switch
		mcd.SwitchToWindow("#Title");

		// Check out the Fee Set Table
		// Get Column number for View/Edit Settings
		int iViewCol = mcd.GetTableColumnNumber("FeeSet.Table", "View/Edit Settings");
		WebElement eleViewIcon;

		List<WebElement> eleViewIcons = driver.findElements(By.xpath(actions.getLocator("FeeSet.CustIcon")));
		// mcd.GetTableCellElement("FeeSet.Table", 1, iViewCol, "a");
		// Click on View/Edit Settings icon

		// eleViewIcon.click();
		eleViewIcons.get(0).click();
		Thread.sleep(3000);

		// Switch to Window : Manage Fee
		mcd.SwitchToWindow("Manage Fee");

		rfm.SelectCustOrResetButton("Are you sure you want to Reset to Default?", "TaxChainVerify.Customize",
				"TaxChainVerify.ResetToDefault");

		// Verify Tax fields
		
		boolean pricetypeexpand=driver.findElement(By.xpath(actions.getLocator("DepositSet.TaxPlusIcon"))).isDisplayed();
		System.out.println("Price Type Expand : "+pricetypeexpand);
		boolean pricetypecollapse=driver.findElement(By.xpath(actions.getLocator("DepositSet.TaxCollapseIcon"))).isDisplayed();
		System.out.println("Price Type collapse : "+pricetypecollapse);
		if(pricetypecollapse){
			actions.click("DepositSet.TaxCollapseIcon");
			Thread.sleep(1000);
		}

		// Set Tax Code value to Always
		actions.setValue("FeeSet.TaxCode", strTaxCode);
		Thread.sleep(1000);

		// Set Tax Rule to TAx Chain
		actions.setValue("FeeSet.TaxRule", strTaxRule);
		Thread.sleep(1000);

		Boolean blnResult = Verify_UpdatedTaxChain_InTaxEntry("FeeSet.TaxEntry", strNewTxChainName);

		if (blnResult) {
			actions.reportCreatePASS("PRICING > Fee > Fee Sets : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("PRICING > Fee > Fee Sets : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is not displayed", "FAIL");
		}

		// Set Tax Entry to the newly update field.
		actions.setValue("FeeSet.TaxEntry", strNewTxChainName);

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);
		Boolean blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg2, true,
					AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		// Switch to window
		mcd.SwitchToWindow("Fee Sets");

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Tax Chain Functionality : Verify that updated
	 * Tax Chain Name is reflected in Master Deposit. Scenario ID : PRC_1085
	 * Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_MasterDeposit_VerifyTaxChainName(String strNewTxChainName, String strTaxCode, String strTaxRule,
			String strNavigateToMasterDeposit, String strWarningMsg2) throws Exception {
		// Navigate to PRICING > Deposit > Master Deposit & Verify

		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateToMasterDeposit);
		actions.select_menu("RFMHome.Navigate", strNavigateToMasterDeposit);
		Thread.sleep(5000);
		actions.waitForPageToLoad(120);

		/** Update title of new Page */
		mcd.SwitchToWindow("#Title");

		Actions builder = new Actions(driver);
		builder.moveByOffset(500, 0).click().perform();

		// Click on View Full List
		actions.click("RFM.ViewFullListBtn");

		int iDepositNameCol = mcd.GetTableColumnNumber("RFM.WebTable", "Deposit Name");

		WebElement eleDepositNm = mcd.GetTableCellElement("RFM.WebTable", 1, iDepositNameCol, "a/pre");

		// Click on Element - Deposit Name Link
		eleDepositNm.click();

		// Switch
		mcd.SwitchToWindow("#Title");

		// Set Tax Code value to Always
		actions.setValue("DepositSet.TaxCode", strTaxCode);
		Thread.sleep(1000);

		// Set Tax Rule to TAx Chain
		actions.setValue("DepositSet.TaxRule", strTaxRule);
		Thread.sleep(1000);

		Boolean blnResult = Verify_UpdatedTaxChain_InTaxEntry("DepositSet.TaxEntry", strNewTxChainName);

		if (blnResult) {
			actions.reportCreatePASS("PRICING > Fee > Master Deposit : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("PRICING > Fee > Master Deposit : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is not displayed", "FAIL");
		}

		// Set Tax Entry to the newly update field.
		actions.setValue("DepositSet.TaxEntry", strNewTxChainName);

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);
		Boolean blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg2, true,
					AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		// Switch to window
		mcd.SwitchToWindow("#Title");
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Tax Chain Functionality : Verify that updated
	 * Tax Chain Name is reflected in Deposit Set. Scenario ID : PRC_1085 Author
	 * : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_DepositSet_VerifyTaxChainName(String strNewTxChainName, String strTaxCode, String strTaxRule,
			String strNavigateToDepositSet, String strWarningMsg2) throws Exception {

		// Navigate to PRICING > Deposit > Deposit Set & Verify

		/** Select Menu Option */
		System.out.println("> Navigate to :: " + strNavigateToDepositSet);
		actions.select_menu("RFMHome.Navigate", strNavigateToDepositSet);
		Thread.sleep(5000);
		actions.waitForPageToLoad(120);

		/** Update title of new Page */
		mcd.SwitchToWindow("#Title");

		Actions builder = new Actions(driver);
		builder.moveByOffset(500, 0).click().perform();

		// Click on View Full List
		actions.click("RFM.ViewFullListBtn");
		actions.smartWait(180);

		int iDepositSetNameCol = mcd.GetTableColumnNumber("RFM.WebTable", "Name");

		WebElement eleDepositSetNm = mcd.GetTableCellElement("RFM.WebTable", 1, iDepositSetNameCol, "a");

		// Click on Element - Fee Name Link
		eleDepositSetNm.click();
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Switch
		mcd.SwitchToWindow("#Title");

		// Check out the Fee Set Table
		// Get Column number for View/Edit Settings
		int iViewCol = mcd.GetTableColumnNumber("DepositSet.Table", "View/Edit Settings");
		WebElement eleViewIcon;

		List<WebElement> eleViewIcons = driver.findElements(By.xpath(actions.getLocator("DepositSet.CustIcon")));
		// mcd.GetTableCellElement("FeeSet.Table", 1, iViewCol, "a");
		// Click on View/Edit Settings icon

		// eleViewIcon.click();
		eleViewIcons.get(0).click();
		Thread.sleep(3000);

		// Switch to Window : Manage Fee
		mcd.SwitchToWindow("Manage Deposit");

		rfm.SelectCustOrResetButton("Are you sure you want to Reset to Default?", "TaxChainVerify.Customize",
				"TaxChainVerify.ResetToDefault");

		// Verify Tax fields

		// Set Tax Code value to Always
		actions.setValue("DepositSet.TaxCode", strTaxCode);
		Thread.sleep(1000);

		// Set Tax Rule to TAx Chain
		actions.setValue("DepositSet.TaxRule", strTaxRule);
		Thread.sleep(1000);

		Boolean blnResult = Verify_UpdatedTaxChain_InTaxEntry("DepositSet.TaxEntry", strNewTxChainName);

		if (blnResult) {
			actions.reportCreatePASS("PRICING > Fee > Deposit Sets : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is displayed", "PASS");
		} else {
			actions.reportCreateFAIL("PRICING > Fee > Deposit Sets : Verify updated tax chain name",
					"Updated Name should be displayed", "Updated Name is not displayed", "FAIL");
		}

		// Set Tax Entry to the newly update field.
		actions.setValue("DepositSet.TaxEntry", strNewTxChainName);

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);
		Boolean blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg2, true,
					AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		// Switch to window
		mcd.SwitchToWindow("Deposit Sets");
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Tax Chain Functionality : Common function used
	 * in Verifying updated tax chain name Scenario ID : Used in PRC_1082 Author
	 * : Pooja Panse
	 */
	// -----------------------------------

	public boolean Verify_UpdatedTaxChain_InTaxEntry(String strElementLocator, String strNewTxChainName) {
		// Verify whether new field is visible
		Select select = new Select(driver.findElement(By.xpath(actions.getLocator(strElementLocator))));
		String[] EntryOptions = new String[select.getOptions().size()];
		Boolean blnResult = false;

		for (int k = 0; k < EntryOptions.length; k++) {
			if (select.getOptions().get(k).getAttribute("innerText").trim().equalsIgnoreCase(strNewTxChainName)) {
				blnResult = true;
				break;
			} else {
				blnResult = false;
			}
		}

		return blnResult;
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Master Deposit Functionality : Create a Deposit
	 * in Master Deposit - With Current Settings/Future Settings Scenario ID :
	 * Used as a pre-requisite for TC : PRC_1024 & PRC_1025 Author : Pooja Panse
	 */
	// -----------------------------------

	public String RFM_PRC_CreateDepositSet(String strNamePrefix, String strDepositType, String strSuccessMsg,
			String strPriceVal, String strTaxCode, String strTaxRule, String strFutureSetFlag,
			String strApplicationDate, String strStatus) throws Exception {

		// Click New Deposit button
		actions.click("DepositSet.NewDepositBtn");
		Thread.sleep(2000);

		// Switch to same window - diff title
		mcd.SwitchToWindow("#Title");

		// Enter unique Deposit Id

		Random rand_num = new Random();
		int iDepositCode = rand_num.nextInt((99) + 5);
		System.out.println(iDepositCode);
		actions.setValue("DepositSet.DepositId", Integer.toString(iDepositCode));

		// Enter unique Deposit Name
		String strDepositName = null;
		strDepositName = mcd.fn_GetRndName(strNamePrefix);
		strDepositName = strDepositName.subSequence(0, 10).toString();
		actions.setValue("DepositSet.DepositName", strDepositName);

		// Select Deposit type
		actions.setValue("DepositSet.DepositType", strDepositType);

		actions.clear("DepositSet.AllPrices");
		Thread.sleep(500);

		actions.setValue("DepositSet.AllPrices", strPriceVal);

		// Set Tax Code value to Always
		actions.setValue("DepositSet.TaxCode", strTaxCode);
		Thread.sleep(1000);

		// Set Tax Rule to TAx Chain
		actions.setValue("DepositSet.TaxRule", strTaxRule);
		Thread.sleep(1000);

		// Set Tax Entry to the newly update field.
		Select select = new Select(driver.findElement(By.xpath(actions.getLocator("DepositSet.AllTaxEntry"))));
		select.selectByIndex(1);

		actions.click("RFM.SaveBtn");
		Thread.sleep(4000);

		Boolean blnUniqueID = false;

		// Verify success message

		if (driver.findElement(By.xpath(actions.getLocator("DepositSet.MessageHeader"))).getText().trim().toLowerCase()
				.contains("saved")) {
			actions.verifyTextPresence(strSuccessMsg, false);
		} else if (driver.findElement(By.xpath(actions.getLocator("DepositSet.MessageHeader"))).getText().trim()
				.toLowerCase().contains("unique")) {
			do {
				if (driver.findElement(By.xpath(actions.getLocator("DepositSet.MessageHeader"))).getText().trim()
						.toLowerCase().contains("unique")) {
					// actions.verifyTextPresence("Please enter a unique Deposit
					// ID.", false);
					blnUniqueID = true;

					// Clear existing id :
					actions.clear("DepositSet.DepositId");
					// Enter unique Deposit Id

					rand_num = new Random();
					iDepositCode = rand_num.nextInt((99) + 5);
					System.out.println(iDepositCode);
					actions.setValue("DepositSet.DepositId", Integer.toString(iDepositCode));

					actions.clear("DepositSet.DepositName");
					actions.setValue("DepositSet.DepositName", strDepositName + "1");

					// Click on Save
					actions.click("RFM.SaveBtn");
					Thread.sleep(3000);
				} else {
					blnUniqueID = false;
				}
			} while (blnUniqueID);

			// Verify success message
			actions.verifyTextPresence(strSuccessMsg, false);
		}

		actions.reportCreatePASS("Verify Creation of new deposit", "New Deposit set should be created",
				"New deposit set : " + strDepositName + " created", "PASS");

		// Select Status Active
		if (strStatus.equals("Active")) {
			actions.setValue("DepositSet.Status", strStatus);

			actions.click("RFM.Apply");
			Thread.sleep(4000);

			// Switch to Apply changes details window
			mcd.SwitchToWindow("Apply Changes Details");

			if (strFutureSetFlag.equalsIgnoreCase("yes")) {
				actions.click("DepositSet.FutureRadioBtn");
				Thread.sleep(500);

				actions.click("DepositSet.FutureCalender");

				mcd.Get_future_date(1, "close", strApplicationDate);

				Thread.sleep(1000);
			} else if (strFutureSetFlag.equalsIgnoreCase("no")) {
				System.out.println("Current Setting");
			} else {
				System.out.println("Enter correct future setting flag");
			}

			// Click on Save
			actions.click("RFM.SaveBtn");
			Thread.sleep(3000);

			// Switch to main window

			mcd.SwitchToWindow("Manage Deposit");
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			actions.verifyTextPresence(strSuccessMsg, false);

			actions.reportCreatePASS("Verify setting new deposit to active status",
					"New Deposit set should be made active", "New deposit set : " + strDepositName + " made active",
					"PASS");

		} else {
			actions.reportCreatePASS("Verify setting new deposit to inactive status",
					"New Deposit set should be saved as inactive",
					"New deposit set : " + strDepositName + " saved as inactive", "PASS");
		}
		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);

		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

		return strDepositName;
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Master Deposit Functionality : Verify that only
	 * 2 decimal places can be entered while updating already existing Deposit
	 * Set. - With Current Settings - With Future Settings Scenario ID :
	 * PRC_1024 & PRC_1025 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_VerifyPriceFieldsExistingDepositSet(String strNewDepositName, String strIncorrectPrcVal,
			String strCorrectPrcVal, String[] strFieldName, String strErrorMsg, String strFutureSetFlag, String strPath,
			String strApplicationDate, String strSuccessMsg) throws Exception {

		actions.WaitForElementPresent("DepositSet.SearchBox", 180);

		actions.clear("DepositSet.SearchBox");
		Thread.sleep(2000);
		// Enter newly created deposit set
		actions.setValue("DepositSet.SearchBox", strNewDepositName);

		// Click on Search
		actions.click("RFM.SearchBtn");

		// GEt the column number for column deposit name
		int iDepositNameCol = mcd.GetTableColumnNumber("RFM.WebTable", "Deposit Name");

		// Get the searched element
		WebElement eleDepositNm = mcd.GetTableCellElement("RFM.WebTable", 1, iDepositNameCol, "a/pre");

		// Click on Element - Deposit Name Link
		eleDepositNm.click();
		Thread.sleep(3000);

		// Switch to next window (same handle, diff title)
		mcd.SwitchToWindow("#Title");

		// PRICE VALIDATIONS
		// All Price

		// Update message for future or current setting
		if (strFutureSetFlag.equalsIgnoreCase("Yes")) {
			strPath = strPath + " (Future Setting)";
		} else if (strFutureSetFlag.equalsIgnoreCase("No")) {
			strPath = strPath + " (Current Setting)";
		}

		Verify_DecimalValidations_ExistingSet("DepositSet.AllPrices", strIncorrectPrcVal, strFieldName[0], strPath,
				strErrorMsg);

		// All Price is not expanded - Eating/Take Out/Other price fields
		// displayed

		boolean verPlusIcon = driver.findElement(By.xpath(actions.getLocator("DepositSet.PlusIcon"))).isDisplayed();
		if(verPlusIcon){
			actions.click("DepositSet.PlusIcon");
		}else{
			System.out.println("Plus icon already expanded");
		}
		
		// Clear & Enter Price upto correct decimal value
		actions.clear("DepositSet.EatingPrc");
		Thread.sleep(500);

		actions.clear("DepositSet.TakeOutPrc");
		Thread.sleep(500);

		actions.clear("DepositSet.OtherPrc");
		Thread.sleep(500);

		// Enter correct value in Take out & Other
		actions.setValue("DepositSet.TakeOutPrc", strCorrectPrcVal);
		Thread.sleep(500);

		actions.setValue("DepositSet.OtherPrc", strCorrectPrcVal);
		Thread.sleep(500);

		// Enter incorrect value in Eating

		Verify_DecimalValidations_ExistingSet("DepositSet.EatingPrc", strIncorrectPrcVal, strFieldName[1], strPath,
				strErrorMsg);

		// Clear & Enter correct value in eating
		actions.clear("DepositSet.EatingPrc");
		Thread.sleep(500);

		actions.setValue("DepositSet.EatingPrc", strCorrectPrcVal);

		// Enter incorrect value in TakeOut

		actions.clear("DepositSet.TakeOutPrc");
		Thread.sleep(500);
		Verify_DecimalValidations_ExistingSet("DepositSet.TakeOutPrc", strIncorrectPrcVal, strFieldName[2], strPath,
				strErrorMsg);

		// Clear & Enter correct value in TakeOut
		actions.clear("DepositSet.TakeOutPrc");
		Thread.sleep(500);

		actions.setValue("DepositSet.TakeOutPrc", strCorrectPrcVal);

		// Enter incorrect value in Other

		actions.clear("DepositSet.OtherPrc");
		Thread.sleep(500);
		Verify_DecimalValidations_ExistingSet("DepositSet.OtherPrc", strIncorrectPrcVal, strFieldName[3], strPath,
				strErrorMsg);

		// Clear & Enter correct value in Other
		actions.clear("DepositSet.OtherPrc");
		Thread.sleep(500);
		actions.clear("DepositSet.OtherPrc");
		Thread.sleep(500);

		actions.setValue("DepositSet.OtherPrc", strCorrectPrcVal);

		// Click Save - As correct values are present - success message should
		// be displayed
		actions.click("RFM.Apply");
		Thread.sleep(2000);
		actions.smartWait(120);

		try {
			// Switch to Apply changes details window
			mcd.SwitchToWindow("Apply Changes Details");

			if (strFutureSetFlag.equalsIgnoreCase("yes")) {
				actions.click("DepositSet.FutureRadioBtn");
				Thread.sleep(500);

				actions.click("DepositSet.FutureCalender");

				mcd.Get_future_date(1, "close", strApplicationDate);

				Thread.sleep(1000);
			} else if (strFutureSetFlag.equalsIgnoreCase("no")) {
				System.out.println("Current Setting");
			} else {
				System.out.println("Enter correct future setting flag");
			}

			// Click on Save
			actions.click("RFM.SaveBtn");
			Thread.sleep(3000);

			// Switch to main window

			mcd.SwitchToWindow("Manage Deposit");
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

		} catch (Exception e) {
			System.out.println("Window not encountered");
		}

		actions.verifyTextPresence(strSuccessMsg, false);

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);

		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Master Deposit Functionality : Verify that only
	 * 2 decimal places can be entered while creating Deposit Set. Scenario ID :
	 * PRC_1023 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_Deposit_VerifyPriceFields(String strNamePrefix, String strDepositType, String strErrorMsg,
			String strSuccessMsg, String strIncorrectPrcVal, String strCorrectPrcVal, String[] strFieldName,
			String strPath) throws Exception {

		// Click New Deposit button
		actions.click("DepositSet.NewDepositBtn");
		Thread.sleep(2000);

		// Switch to same window - diff title
		mcd.SwitchToWindow("#Title");

		// Enter unique Deposit Id

		actions.keyboardEnter("ApprovalStatusChanges.SaveBtn");
		mcd.VerifyAlertMessageDisplayed("Warning", "Please enter Deposit ID.", true, AlertPopupButton.OK_BUTTON);
		boolean flag = true;

		Random rand_num = new Random();
		int iDepositCode = rand_num.nextInt((99) + 5);
		System.out.println(iDepositCode);
		actions.setValue("DepositSet.DepositId", Integer.toString(iDepositCode));

		// Enter unique Deposit Name
		String strDepositName = null;
		strDepositName = mcd.fn_GetRndName(strNamePrefix);
		strDepositName = strDepositName.subSequence(0, 10).toString();
		actions.setValue("DepositSet.DepositName", strDepositName);

		// Select Deposit type
		actions.setValue("DepositSet.DepositType", strDepositType);

		// PRICE VALIDATIONS
		// All Price

		Verify_DecimalValidations_NewSet("DepositSet.AllPrices", strIncorrectPrcVal, strFieldName[0],
				strPath + " : New Deposit", strErrorMsg);

		// All Price is not expanded - Eating/Take Out/Other price fields
		// displayed

		boolean verPlusIcon = driver.findElement(By.xpath(actions.getLocator("DepositSet.PlusIcon"))).isDisplayed();
		if(verPlusIcon){
			actions.click("DepositSet.PlusIcon");
		}else{
			System.out.println("Plus icon already expanded");
		}
		
		// Clear & Enter Price upto correct decimal value
		actions.clear("DepositSet.EatingPrc");
		Thread.sleep(500);

		actions.clear("DepositSet.TakeOutPrc");
		Thread.sleep(500);

		actions.clear("DepositSet.OtherPrc");
		Thread.sleep(500);

		// Enter correct value in Take out & Other
		actions.setValue("DepositSet.TakeOutPrc", strCorrectPrcVal);
		Thread.sleep(500);

		actions.setValue("DepositSet.OtherPrc", strCorrectPrcVal);
		Thread.sleep(500);

		// Enter incorrect value in Eating

		Verify_DecimalValidations_NewSet("DepositSet.EatingPrc", strIncorrectPrcVal, strFieldName[1],
				strPath + " : New Deposit", strErrorMsg);

		// Clear & Enter correct value in eating
		actions.clear("DepositSet.EatingPrc");
		Thread.sleep(500);

		actions.setValue("DepositSet.EatingPrc", strCorrectPrcVal);

		// Enter incorrect value in TakeOut

		actions.clear("DepositSet.TakeOutPrc");
		Thread.sleep(500);
		Verify_DecimalValidations_NewSet("DepositSet.TakeOutPrc", strIncorrectPrcVal, strFieldName[2],
				strPath + " : New Deposit", strErrorMsg);

		// Clear & Enter correct value in TakeOut
		actions.clear("DepositSet.TakeOutPrc");
		Thread.sleep(500);

		actions.setValue("DepositSet.TakeOutPrc", strCorrectPrcVal);

		// Enter incorrect value in Other

		actions.clear("DepositSet.OtherPrc");
		Thread.sleep(500);
		Verify_DecimalValidations_NewSet("DepositSet.OtherPrc", strIncorrectPrcVal, strFieldName[3],
				strPath + " : New Deposit", strErrorMsg);

		// Clear & Enter correct value in Other
		actions.clear("DepositSet.OtherPrc");
		Thread.sleep(500);

		actions.setValue("DepositSet.OtherPrc", strCorrectPrcVal);

		// Click Save - As correct values are present - success message should
		// be displayed
		actions.click("RFM.SaveBtn");
		Thread.sleep(2000);
		actions.smartWait(120);
		do {
			// Handling pop up msg Discount Id already exists, please enter
			// another Discount Id.
			try {
				flag = mcd.VerifyOnscreenMessage("ManagePriceSet.InfoMsg", "Please enter a unique Deposit ID.", true);
				if (flag) {
					int iDepositCode1 = mcd.fn_GetRndNumInRange(0, 99);
					actions.clear("DepositSet.DepositId");
					Thread.sleep(2000);
					// Element1.clear();
					actions.setValue("DepositSet.DepositId", iDepositCode1);
					Thread.sleep(2000);
					// Element1.sendKeys(iDepositCode);
					actions.keyboardEnter("ApprovalStatusChanges.SaveBtn");
					actions.smartWait(100);
				}
			} catch (Exception e) {
				System.out.println("Discount Id already exists, please enter another Discount Id.");
			}
		} while (flag);

		Thread.sleep(2000);
		actions.verifyTextPresence(strSuccessMsg, false);

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Master Deposit Functionality : Verify that only
	 * 2 decimal places can be entered while updating any Fee & Deposit assigned
	 * to a restaurant through operation details tab in restaurant profile.
	 * Scenario ID : Fee - PRC_1044 , Deposit - PRC_1026 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_Rest_Prof_Deposit_VerifyPriceFields(String strIncorrectPrcVal, String strCorrectPrcVal,
			String[] strFieldName, String strErrorMsg, String strSuccessMsg, String strRPColm, String strWarningMsg,
			String strPath) throws Exception {
		// Get Column Number for Restaurant name

		List<WebElement> eleHearderList = driver.findElements(By.xpath(actions.getLocator("RFM.WebTableHeaderTD")));
		int iRestNameCol = 0;
		// Compare the name of column
		for (int j = 0; j < eleHearderList.size(); j++) {
			if (eleHearderList.get(j).getText().trim().equalsIgnoreCase(strRPColm)) {
				iRestNameCol = j + 1;
				break;
			}
		}

		// Search & Click Restaurant name
		WebElement eleTaxChain = mcd.GetTableCellElement("RFM.WebTable", 1, iRestNameCol, "a");
		eleTaxChain.sendKeys(Keys.ENTER);

		Thread.sleep(5000);
		actions.waitForPageToLoad(180);

		mcd.SwitchToWindow("#Title");

		// Verify in Operations detail tab

		actions.keyboardEnter("RestMIList.OperationsTab");
		Thread.sleep(2000);
		Boolean blnVerifyPopUp = false;
		actions.waitForPageToLoad(120);

		// Fee Set
		Select select = new Select(driver.findElement(By.xpath(actions.getLocator("RestProfile.FeeSet"))));
		select.selectByIndex(1);

		// Click on customize icon
		actions.click("RestProfile.FeeSetCustomize");
		Thread.sleep(3000);

		// Switch to new window
		mcd.SwitchToWindow("Fee Set");

		// Click on the fee set displayed
		actions.click("FeeSet.NameLink");
		Thread.sleep(3000);

		// Switch to new window
		mcd.SwitchToWindow("Manage Fee");

		rfm.SelectCustOrResetButton("Are you sure you want to Reset to Default?", "TaxChainVerify.Customize",
				"TaxChainVerify.ResetToDefault");
		// actions.click("TaxChainVerify.Customize");

		actions.smartWait(120);

		// VERIFY PRICES

		// -------------------------------------------------------------
		// Validations starts for fee set
		// -------------------------------------------------------------

		// All Price

		Verify_DecimalValidations_ExistingSet("FeeSet.AllPrc", strIncorrectPrcVal, strFieldName[0],
				strPath + " > Fee Set", strErrorMsg);

		// All Price is not expanded - Eating/Take Out/Other price fields
		// displayed

		boolean verPlusIcon = driver.findElement(By.xpath(actions.getLocator("DepositSet.PlusIcon"))).isDisplayed();
		if(verPlusIcon){
			actions.click("DepositSet.PlusIcon");
		}else{
			System.out.println("Plus icon already expanded");
		}
		
		// Clear & Enter Price upto correct decimal value
		actions.clear("FeeSet.EatingPrc");
		Thread.sleep(500);

		actions.clear("FeeSet.TkOutPrc");
		Thread.sleep(500);

		actions.clear("FeeSet.OthPrc");
		Thread.sleep(500);

		// Enter correct value in Take out & Other
		actions.setValue("FeeSet.TkOutPrc", strCorrectPrcVal);
		Thread.sleep(500);

		actions.setValue("FeeSet.OthPrc", strCorrectPrcVal);
		Thread.sleep(500);

		// Enter incorrect value in Eating

		Verify_DecimalValidations_ExistingSet("FeeSet.EatingPrc", strIncorrectPrcVal, strFieldName[1],
				strPath + " > Fee Set", strErrorMsg);

		// Clear & Enter correct value in eating
		actions.clear("FeeSet.EatingPrc");
		Thread.sleep(500);

		actions.setValue("FeeSet.EatingPrc", strCorrectPrcVal);

		// Enter incorrect value in TakeOut

		actions.clear("FeeSet.TkOutPrc");
		Thread.sleep(500);
		Verify_DecimalValidations_ExistingSet("FeeSet.TkOutPrc", strIncorrectPrcVal, strFieldName[2],
				strPath + " > Fee Set", strErrorMsg);

		// Clear & Enter correct value in TakeOut
		actions.clear("FeeSet.TkOutPrc");
		Thread.sleep(500);

		actions.setValue("FeeSet.TkOutPrc", strCorrectPrcVal);

		// Enter incorrect value in Other

		actions.clear("FeeSet.OthPrc");
		Thread.sleep(500);
		Verify_DecimalValidations_ExistingSet("FeeSet.OthPrc", strIncorrectPrcVal, strFieldName[3],
				strPath + " > Fee Set", strErrorMsg);

		// Clear & Enter correct value in Other
		actions.clear("FeeSet.OthPrc");
		Thread.sleep(500);
		actions.clear("FeeSet.OthPrc");
		Thread.sleep(500);

		actions.setValue("FeeSet.OthPrc", strCorrectPrcVal);

		// -------------------------------------------------------------
		// Validations ends for fee set
		// -------------------------------------------------------------

		actions.click("RFM.CancelBtn");
		Thread.sleep(3000);

		blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg, true, AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		Thread.sleep(3000);

		mcd.SwitchToWindow("Fee Set");

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);

		// Switch back to 1st window
		mcd.SwitchToWindow("Restaurant Profile");
		Thread.sleep(1000);

		// Deposit Set - TC 1026

		select = new Select(driver.findElement(By.xpath(actions.getLocator("RestProfile.DepositSet"))));
		select.selectByIndex(1);
		Thread.sleep(1000);

		// Click on customize icon
		actions.click("RestProfile.DepositSetCustomize");
		Thread.sleep(3000);

		// Switch to new window
		mcd.SwitchToWindow("Deposit Set");

		// Click on the fee set displayed
		actions.click("DepositSet.NameLink");
		Thread.sleep(3000);

		// Switch to new window
		mcd.SwitchToWindow("Manage Deposit");

		rfm.SelectCustOrResetButton("Are you sure you want to Reset to Default?", "TaxChainVerify.Customize",
				"TaxChainVerify.ResetToDefault");
		// actions.click("TaxChainVerify.Customize");
		Thread.sleep(1000);

		// -------------------------------------------------------------
		// Validations starts for deposit set
		// -------------------------------------------------------------

		// All Price

		Verify_DecimalValidations_ExistingSet("DepositSet.AllPrices", strIncorrectPrcVal, strFieldName[0],
				strPath + " > Deposit Set", strErrorMsg);

		// All Price is not expanded - Eating/Take Out/Other price fields
		// displayed

		boolean verPlusIcons = driver.findElement(By.xpath(actions.getLocator("DepositSet.PlusIcon"))).isDisplayed();
		if(verPlusIcons){
			actions.click("DepositSet.PlusIcon");
		}else{
			System.out.println("Plus icon already expanded");
		}
		
		// Clear & Enter Price upto correct decimal value
		actions.clear("DepositSet.EatingPrc");
		Thread.sleep(500);

		actions.clear("DepositSet.TakeOutPrc");
		Thread.sleep(500);

		actions.clear("DepositSet.OtherPrc");
		Thread.sleep(500);

		// Enter correct value in Take out & Other
		actions.setValue("DepositSet.TakeOutPrc", strCorrectPrcVal);
		Thread.sleep(500);

		actions.setValue("DepositSet.OtherPrc", strCorrectPrcVal);
		Thread.sleep(500);

		// Enter incorrect value in Eating

		Verify_DecimalValidations_ExistingSet("DepositSet.EatingPrc", strIncorrectPrcVal, strFieldName[1],
				strPath + " > Deposit Set", strErrorMsg);

		// Clear & Enter correct value in eating
		actions.clear("DepositSet.EatingPrc");
		Thread.sleep(500);

		actions.setValue("DepositSet.EatingPrc", strCorrectPrcVal);

		// Enter incorrect value in TakeOut

		actions.clear("DepositSet.TakeOutPrc");
		Thread.sleep(500);
		Verify_DecimalValidations_ExistingSet("DepositSet.TakeOutPrc", strIncorrectPrcVal, strFieldName[2],
				strPath + " > Deposit Set", strErrorMsg);

		// Clear & Enter correct value in TakeOut
		actions.clear("DepositSet.TakeOutPrc");
		Thread.sleep(500);

		actions.setValue("DepositSet.TakeOutPrc", strCorrectPrcVal);

		// Enter incorrect value in Other

		actions.clear("DepositSet.OtherPrc");
		Thread.sleep(500);
		Verify_DecimalValidations_ExistingSet("DepositSet.OtherPrc", strIncorrectPrcVal, strFieldName[3],
				strPath + " > Deposit Set", strErrorMsg);

		// Clear & Enter correct value in Other
		actions.clear("DepositSet.OtherPrc");
		Thread.sleep(500);
		actions.clear("DepositSet.OtherPrc");
		Thread.sleep(500);

		actions.setValue("DepositSet.OtherPrc", strCorrectPrcVal);

		// ------------------------------------------------------------------
		// Validations ends for deposit set
		// -----------------------------------------------------------------
		// Click Cancel

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);
		blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg, true, AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		actions.waitForPageToLoad(120);
		mcd.SwitchToWindow("Deposit Set");

		actions.click("RFM.CancelBtn");
		Thread.sleep(5000);

		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg, true, AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}

		// Switch back to 1st window
		mcd.SwitchToWindow("Restaurant Profile");

		actions.click("RFM.CancelBtn");
		Thread.sleep(5000);

		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Output", strWarningMsg, true, AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			actions.waitForPageToLoad(120);
		}
		// Switch back to 1st window
		mcd.SwitchToWindow("#Title");
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Master Fee Functionality : Create a Fee Set -
	 * With Current Settings/Future Settings Scenario ID : Used as a
	 * pre-requisite for TC : PRC_1042 & PRC_1043 Author : Pooja Panse
	 */
	// -----------------------------------

	public String RFM_PRC_CreateFeeSet(String strNamePrefix, String strFeeType, String strSuccessMsg,
			String strPriceVal, String strTaxCode, String strTaxRule, String strFutureSetFlag,
			String strApplicationDate, String strStatus) throws Exception {

		Actions builder = new Actions(driver);
		builder.moveByOffset(500, 0).click().perform();

		// Click New Fee button
		actions.click("MasterFee.NewFeeBtn");
		Thread.sleep(2000);

		// Switch to same window - diff title
		mcd.SwitchToWindow("#Title");

		// Enter unique Fee Id

		Random rand_num = new Random();
		int iFeeCode = rand_num.nextInt((99) + 5);
		System.out.println(iFeeCode);
		actions.setValue("MasterFee.FeeId", Integer.toString(iFeeCode));

		// Enter unique Fee Name
		String strFeeName = null;
		strFeeName = mcd.fn_GetRndName(strNamePrefix);
		strFeeName = strFeeName.subSequence(0, 10).toString();
		actions.setValue("MasterFee.FeeName", strFeeName);

		// Select Fee type
		actions.setValue("MasterFee.FeeType", strFeeType);

		actions.clear("FeeSet.AllPrc");
		Thread.sleep(500);

		actions.setValue("FeeSet.AllPrc", strPriceVal);

		// Set Tax Code value to Always
		actions.setValue("FeeSet.TaxCode", strTaxCode);
		Thread.sleep(1000);

		// Set Tax Rule to TAx Chain
		actions.setValue("FeeSet.TaxRule", strTaxRule);
		Thread.sleep(1000);

		// Set Tax Entry to the newly update field.
		Select select = new Select(driver.findElement(By.xpath(actions.getLocator("FeeSet.AllTaxEntry"))));
		select.selectByIndex(1);

		actions.click("RFM.SaveBtn");
		Thread.sleep(4000);

		// Verify success message
		actions.verifyTextPresence(strSuccessMsg, false);

		// Select Status Active
		actions.setValue("FeeSet.Status", strStatus);

		actions.click("RFM.Apply");
		Thread.sleep(4000);

		// Switch to Apply changes details window
		mcd.SwitchToWindow("Apply Changes Details");

		if (strFutureSetFlag.equalsIgnoreCase("yes")) {
			actions.click("FeeSet.FutureRadioBtn");
			Thread.sleep(500);

			actions.click("FeeSet.FutureCalender");

			mcd.Get_future_date(1, "close", strApplicationDate);

			Thread.sleep(1000);
		} else if (strFutureSetFlag.equalsIgnoreCase("no")) {
			System.out.println("Current Setting");
		} else {
			System.out.println("Enter correct future setting flag");
		}

		// Click on Save
		actions.click("RFM.SaveBtn");
		Thread.sleep(3000);

		// Switch to main window

		mcd.SwitchToWindow("Manage Fee");
		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		// Verify success message
		actions.verifyTextPresence(strSuccessMsg, false);

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);

		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

		return strFeeName;
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Master Fee Functionality : Create a Fee - With
	 * Current Settings/Future Settings Scenario ID : Used as a pre-requisite
	 * for TC : PRC_1042 & PRC_1043 Author : Pooja Panse
	 */
	// -----------------------------------

	public String RFM_PRC_CreateFee(String strNamePrefix, String strFeeType, String strSuccessMsg, String strPriceVal,
			String strTaxCode, String strTaxRule, String strFutureSetFlag, String strApplicationDate, String strStatus)
					throws Exception {

		// Click New Fee button
		actions.keyboardEnter("MasterFee.NewFeeBtn");
		Thread.sleep(2000);

		// Switch to same window - diff title
		mcd.SwitchToWindow("#Title");

		// Enter unique Fee Id

		Random rand_num = new Random();
		int iFeeCode = rand_num.nextInt((99) + 5);
		System.out.println(iFeeCode);
		actions.setValue("MasterFee.FeeId", Integer.toString(iFeeCode));

		// Enter unique Fee Name
		String strFeeName = null;
		strFeeName = mcd.fn_GetRndName(strNamePrefix);
		strFeeName = strFeeName.subSequence(0, 10).toString();
		actions.setValue("MasterFee.FeeName", strFeeName);

		// Select Fee type
		actions.setValue("MasterFee.FeeType", strFeeType);
		
		//Handling whether the fields are expanded or collapsed by default
		
		Boolean blnExpand = actions.isElementPresent("ManageFee.eatinValue");
		
		if(blnExpand){
			actions.clear("FeeSet.EatingPrc");
			Thread.sleep(500);

			actions.setValue("FeeSet.EatingPrc", strPriceVal);
			
			actions.clear("FeeSet.TkOutPrc");
			Thread.sleep(500);

			actions.setValue("FeeSet.TkOutPrc", strPriceVal);
			
			actions.clear("FeeSet.OthPrc");
			Thread.sleep(500);

			actions.setValue("FeeSet.OthPrc", strPriceVal);
			
			// Set Tax Code value to Always
			actions.setValue("DepositSet.EatinTaxCode", strTaxCode);
			Thread.sleep(1000);

			// Set Tax Rule to TAx Chain
			actions.setValue("DepositSet.EatinTaxRule", strTaxRule);
			Thread.sleep(1000);

			// Set Tax Entry to the newly update field.
			Select select = new Select(driver.findElement(By.xpath(actions.getLocator("DepositSet.EatinTaxEntry"))));
			select.selectByIndex(1);
			
			// Set Tax Code value to Always
			actions.setValue("DepositSet.TOTaxCode", strTaxCode);
			Thread.sleep(1000);

			// Set Tax Rule to TAx Chain
			actions.setValue("DepositSet.TOTaxRule", strTaxRule);
			Thread.sleep(1000);

			// Set Tax Entry to the newly update field.
			select = new Select(driver.findElement(By.xpath(actions.getLocator("DepositSet.TOTaxEntry"))));
			select.selectByIndex(1);
			
			// Set Tax Code value to Always
			actions.setValue("DepositSet.OtherTaxCode", strTaxCode);
			Thread.sleep(1000);

			// Set Tax Rule to TAx Chain
			actions.setValue("DepositSet.OtherTaxRule", strTaxRule);
			Thread.sleep(1000);

			// Set Tax Entry to the newly update field.
			select = new Select(driver.findElement(By.xpath(actions.getLocator("DepositSet.OtherTaxEntry"))));
			select.selectByIndex(1);

		}else{
			actions.clear("FeeSet.AllPrc");
			Thread.sleep(500);

			actions.setValue("FeeSet.AllPrc", strPriceVal);
			
			// Set Tax Code value to Always
			actions.setValue("FeeSet.TaxCode", strTaxCode);
			Thread.sleep(1000);

			// Set Tax Rule to TAx Chain
			actions.setValue("FeeSet.TaxRule", strTaxRule);
			Thread.sleep(1000);

			// Set Tax Entry to the newly update field.
			Select select = new Select(driver.findElement(By.xpath(actions.getLocator("FeeSet.AllTaxEntry"))));
			select.selectByIndex(1);

		}

		


		actions.click("RFM.SaveBtn");
		Thread.sleep(4000);
		actions.waitForPageToLoad(120);
		Boolean blnUnique = false;
		WebElement eleHeader;
		do {
			try {
				eleHeader = driver.findElement(By.xpath(actions.getLocator("MasterFee.Header")));
				if (eleHeader.getText().trim().contains("unique")) {
					blnUnique = true;
					actions.clear("MasterFee.FeeId");
					actions.clear("MasterFee.FeeName");
					iFeeCode = rand_num.nextInt((99) + 5);
					System.out.println(iFeeCode);
					actions.setValue("MasterFee.FeeId", Integer.toString(iFeeCode));
					strFeeName = strFeeName+"1";
					actions.setValue("MasterFee.FeeName", strFeeName);
					actions.click("RFM.SaveBtn");
					Thread.sleep(4000);

				} else {
					blnUnique = false;
				}
			} catch (Exception err) {
				blnUnique = false;
			}

		} while (blnUnique);

		// Verify success message
		actions.verifyTextPresence(strSuccessMsg, false);

		if (!(strStatus.equalsIgnoreCase("Inactive"))) {
			// Select Status Active/Suspended
			actions.setValue("FeeSet.Status", strStatus);

			actions.click("RFM.Apply");
			Thread.sleep(4000);

			// Switch to Apply changes details window
			mcd.SwitchToWindow("Apply Changes Details");

			if (strFutureSetFlag.equalsIgnoreCase("yes")) {
				actions.click("FeeSet.FutureRadioBtn");
				Thread.sleep(500);

				actions.click("FeeSet.FutureCalender");

				mcd.Get_future_date(3, "close", strApplicationDate);

				Thread.sleep(1000);
			} else if (strFutureSetFlag.equalsIgnoreCase("no")) {
				System.out.println("Current Setting");
			} else {
				System.out.println("Enter correct future setting flag");
			}

			// Click on Save
			actions.click("RFM.SaveBtn");
			Thread.sleep(3000);

			// Switch to main window

			mcd.SwitchToWindow("Manage Fee");
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			// Verify success message
			actions.verifyTextPresence(strSuccessMsg, false);

		}

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);

		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

		return strFeeName;
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Master Fee Functionality : Verify that only 2
	 * decimal places can be entered while updating already existing Fee Set. -
	 * With Current Settings - With Future Settings Scenario ID : PRC_1042 &
	 * PRC_1043 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_VerifyPriceFieldsExistingFeeSet(String strNewFeeName, String strIncorrectPrcVal,
			String strCorrectPrcVal, String[] strFieldName, String strErrorMsg, String strFutureSetFlag, String strPath,
			String strApplicationDate, String strSuccessMsg) throws Exception {

		actions.WaitForElementPresent("MasterFee.SearchBox", 180);

		actions.clear("MasterFee.SearchBox");
		Thread.sleep(5000);
		// Enter newly created Fee set
		actions.setValue("MasterFee.SearchBox", strNewFeeName);

		// Click on Search
		actions.click("RFM.SearchBtn");

		// GEt the column number for column fee name
		int iFeeNameCol = mcd.GetTableColumnNumber("RFM.WebTable", "Fee Name");

		// Get the searched element
		WebElement eleFeeNm = mcd.GetTableCellElement("RFM.WebTable", 1, iFeeNameCol, "a/pre");

		// Click on Element - Fee Name Link
		eleFeeNm.click();
		Thread.sleep(3000);

		// Switch to next window (same handle, diff title)
		mcd.SwitchToWindow("#Title");

		// PRICE VALIDATIONS
		// All Price

		// Update message for future or current setting
		if (strFutureSetFlag.equalsIgnoreCase("Yes")) {
			strPath = strPath + " (Future Setting)";
		} else if (strFutureSetFlag.equalsIgnoreCase("No")) {
			strPath = strPath + " (Current Setting)";
		}

		Verify_DecimalValidations_ExistingSet("FeeSet.AllPrc", strIncorrectPrcVal, strFieldName[0], strPath,
				strErrorMsg);

		// All Price is not expanded - Eating/Take Out/Other price fields
		// displayed

		// Clear & Enter Price upto correct decimal value
		actions.clear("FeeSet.EatingPrc");
		Thread.sleep(500);

		actions.clear("FeeSet.TkOutPrc");
		Thread.sleep(500);

		actions.clear("FeeSet.OthPrc");
		Thread.sleep(500);

		// Enter correct value in Take out & Other
		actions.setValue("FeeSet.TkOutPrc", strCorrectPrcVal);
		Thread.sleep(500);

		actions.setValue("FeeSet.OthPrc", strCorrectPrcVal);
		Thread.sleep(500);

		// Enter incorrect value in Eating

		Verify_DecimalValidations_ExistingSet("FeeSet.EatingPrc", strIncorrectPrcVal, strFieldName[1], strPath,
				strErrorMsg);

		// Clear & Enter correct value in eating
		actions.clear("FeeSet.EatingPrc");
		Thread.sleep(500);

		actions.setValue("FeeSet.EatingPrc", strCorrectPrcVal);

		// Enter incorrect value in TakeOut

		actions.clear("FeeSet.TkOutPrc");
		Thread.sleep(500);
		Verify_DecimalValidations_ExistingSet("FeeSet.TkOutPrc", strIncorrectPrcVal, strFieldName[2], strPath,
				strErrorMsg);

		// Clear & Enter correct value in TakeOut
		actions.clear("FeeSet.TkOutPrc");
		Thread.sleep(500);

		actions.setValue("FeeSet.TkOutPrc", strCorrectPrcVal);

		// Enter incorrect value in Other

		actions.clear("FeeSet.OthPrc");
		Thread.sleep(500);
		Verify_DecimalValidations_ExistingSet("FeeSet.OthPrc", strIncorrectPrcVal, strFieldName[3], strPath,
				strErrorMsg);

		// Clear & Enter correct value in Other
		actions.clear("FeeSet.OthPrc");
		Thread.sleep(500);
		actions.clear("FeeSet.OthPrc");
		Thread.sleep(500);

		actions.setValue("FeeSet.OthPrc", strCorrectPrcVal);

		// Click Save - As correct values are present - success message should
		// be displayed
		actions.click("RFM.Apply");
		Thread.sleep(2000);
		actions.smartWait(120);

		try {
			// Switch to Apply changes details window
			mcd.SwitchToWindow("Apply Changes Details");

			if (strFutureSetFlag.equalsIgnoreCase("yes")) {
				actions.click("FeeSet.FutureRadioBtn");
				Thread.sleep(500);

				actions.click("FeeSet.FutureCalender");

				mcd.Get_future_date(1, "close", strApplicationDate);

				Thread.sleep(1000);
			} else if (strFutureSetFlag.equalsIgnoreCase("no")) {
				System.out.println("Current Setting");
			} else {
				System.out.println("Enter correct future setting flag");
			}

			// Click on Save
			actions.click("RFM.SaveBtn");
			Thread.sleep(3000);

			// Switch to main window

			mcd.SwitchToWindow("Manage Fee");
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

		} catch (Exception e) {
			System.out.println("Window not encountered");
		}

		actions.verifyTextPresence(strSuccessMsg, false);

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);

		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing Functionality : Common function used in scenarios
	 * where we need to : Verify that only 2 decimal places can be entered in
	 * Price fields inexisting Fee or Deposit Set Scenario ID : Used in
	 * (DEPOSIT) PRC_1024/PRC_1025/PRC_1026 (FEE)PRC_1042/PRC_1043/PRC_1044
	 * Author : Pooja Panse
	 */
	// -----------------------------------

	public void Verify_DecimalValidations_ExistingSet(String strElementLocator, String strIncorrectPrcVal,
			String strFieldName, String strPath, String strErrorMsg) throws InterruptedException {

		// Clear the desired field
		actions.clear(strElementLocator);
		Thread.sleep(500);
		actions.clear(strElementLocator);
		Thread.sleep(500);

		// Dt - 15/01/2015
		try {

			Select select = new Select(driver.findElement(By.xpath(actions.getLocator("FeeSet.TaxCode"))));
			select.selectByVisibleText("Never");
			// actions.setValue("FeeSet.TaxCode", "Never");
			System.out.println("Test - here");
			Thread.sleep(2000);

		} catch (Exception err) {
			System.out.println("No alert present");
		}
		// --- End---

		// Set price value with more than 2 decimal places
		actions.setValue(strElementLocator, strIncorrectPrcVal);

		// Click Apply
		actions.click("RFM.Apply");
		Thread.sleep(2000);

		// update error message as per the field for Take Out & other
		if (strFieldName.equalsIgnoreCase("Take out")) {
			strErrorMsg = strErrorMsg.replaceAll("Eatin", "TakeOut");
		} else if (strFieldName.equalsIgnoreCase("Other")) {
			strErrorMsg = strErrorMsg.replaceAll("Eatin", strFieldName);
		}

		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strErrorMsg, false,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS(strPath + " : Verify field : " + strFieldName + " Price",
					"Error should be given for values more than 2 decimal places", "Error Given", "PASS");
		} else {
			actions.reportCreateFAIL(strPath + " : Verify field : " + strFieldName + " Price",
					"Error should be given for values more than 2 decimal places", "Error not given", "FAIL");
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing Functionality : Common function used in scenarios
	 * where we need to : Verify that only 2 decimal places can be entered in
	 * Price fields while creating new Fee or Deposit Set Scenario ID : Used in
	 * (DEPOSIT) PRC_1023; (FEE)PRC_1041 Author : Pooja Panse
	 */
	// -----------------------------------

	public void Verify_DecimalValidations_NewSet(String strElementLocator, String strIncorrectPrcVal,
			String strFieldName, String strPath, String strErrorMsg) throws InterruptedException {

		// Clear the desired field
		actions.clear(strElementLocator);
		Thread.sleep(500);
		actions.clear(strElementLocator);
		Thread.sleep(500);

		// Set price value with more than 2 decimal places
		actions.setValue(strElementLocator, strIncorrectPrcVal);
		Thread.sleep(2000);

		// Click Save
		actions.keyboardEnter("RFM.SaveBtn");
		Thread.sleep(2000);

		// update error message as per the field for Take Out & other
		if (strFieldName.equalsIgnoreCase("Take out")) {
			strErrorMsg = strErrorMsg.replaceAll("Eatin", "TakeOut");
		} else if (strFieldName.equalsIgnoreCase("Other")) {
			strErrorMsg = strErrorMsg.replaceAll("Eatin", strFieldName);
		}

		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strErrorMsg, true,
				AlertPopupButton.OK_BUTTON);
		if (VerifyPopUpMsg) {
			actions.reportCreatePASS(strPath + " : Verify field : " + strFieldName + " Price",
					"Error should be given for values more than 2 decimal places", "Error Given", "PASS");
		} else {
			actions.reportCreateFAIL(strPath + " : Verify field : " + strFieldName + " Price",
					"Error should be given for values more than 2 decimal places", "Error not given", "FAIL");
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Master Fee Functionality : Verify that only 2
	 * decimal places can be entered while creating Fee Set. Scenario ID :
	 * PRC_1041 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_Fee_VerifyPriceFields(String strNamePrefix, String strFeeType, String strErrorMsg,
			String strSuccessMsg, String strIncorrectPrcVal, String strCorrectPrcVal, String[] strFieldName,
			String strPath) throws Exception {

		Actions builder = new Actions(driver);
		builder.moveByOffset(500, 0).click().perform();

		// Click New Fee button
		actions.click("MasterFee.NewFeeBtn");
		Thread.sleep(2000);

		// Switch to same window - diff title
		mcd.SwitchToWindow("#Title");

		// Enter unique Fee Id

		Random rand_num = new Random();
		int iFeeId = rand_num.nextInt((99) + 5);
		System.out.println(iFeeId);
		actions.setValue("MasterFee.FeeId", Integer.toString(iFeeId));

		// Enter unique Fee Name
		String strFeeName = null;
		strFeeName = mcd.fn_GetRndName(strNamePrefix);
		strFeeName = strFeeName.subSequence(0, 10).toString();
		actions.setValue("MasterFee.FeeName", strFeeName);

		// Select Fee type
		actions.setValue("MasterFee.FeeType", strFeeType);

		// PRICE VALIDATIONS
		// All Price

		Verify_DecimalValidations_NewSet("FeeSet.AllPrc", strIncorrectPrcVal, strFieldName[0], strPath + " : New Fee",
				strErrorMsg);

		// All Price is not expanded - Eating/Take Out/Other price fields
		// displayed

		// Clear & Enter Price upto correct decimal value
		actions.clear("FeeSet.EatingPrc");
		Thread.sleep(500);

		actions.clear("FeeSet.TkOutPrc");
		Thread.sleep(500);

		actions.clear("FeeSet.OthPrc");
		Thread.sleep(500);
		actions.clear("FeeSet.TkOutPrc");
		// Enter correct value in Take out & Other
		actions.setValue("FeeSet.TkOutPrc", strCorrectPrcVal);
		Thread.sleep(500);

		actions.clear("FeeSet.OthPrc");
		actions.setValue("FeeSet.OthPrc", strCorrectPrcVal);
		Thread.sleep(500);

		// Enter incorrect value in Eating

		Verify_DecimalValidations_NewSet("FeeSet.EatingPrc", strIncorrectPrcVal, strFieldName[1],
				strPath + " : New Fee", strErrorMsg);

		// Clear & Enter correct value in eating
		actions.clear("FeeSet.EatingPrc");
		Thread.sleep(500);

		actions.setValue("FeeSet.EatingPrc", strCorrectPrcVal);

		// Enter incorrect value in TakeOut

		actions.clear("FeeSet.TkOutPrc");
		Thread.sleep(500);
		Verify_DecimalValidations_NewSet("FeeSet.TkOutPrc", strIncorrectPrcVal, strFieldName[2], strPath + " : New Fee",
				strErrorMsg);

		// Clear & Enter correct value in TakeOut
		actions.clear("FeeSet.TkOutPrc");
		Thread.sleep(500);

		actions.setValue("FeeSet.TkOutPrc", strCorrectPrcVal);

		// Enter incorrect value in Other

		actions.clear("FeeSet.OthPrc");
		Thread.sleep(500);
		Verify_DecimalValidations_NewSet("FeeSet.OthPrc", strIncorrectPrcVal, strFieldName[3], strPath + " : New Fee",
				strErrorMsg);

		// Clear & Enter correct value in Other
		actions.clear("FeeSet.OthPrc");
		Thread.sleep(500);

		actions.setValue("FeeSet.OthPrc", strCorrectPrcVal);

		// Click Save - As correct values are present - success message should
		// be displayed
		actions.click("RFM.SaveBtn");
		Thread.sleep(2000);
		actions.smartWait(180);

		boolean flag = false, flagFeeId = false;
		try {
			flag = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", "Your changes have been saved.", true);

		} catch (Exception e) {

			do {
				try {
					flagFeeId = mcd.VerifyOnscreenMessage("MasterFee.Header", "Please enter a unique Fee ID.", true);
					if (flagFeeId) {
						actions.clear("MasterFee.FeeId");
						// Entering unique Fee ID
						rand_num = new Random();
						int strNewFeeiD = rand_num.nextInt((99) + 5);
						System.out.println(strNewFeeiD);
						actions.setValue("MasterFee.FeeId", Integer.toString(strNewFeeiD));
						actions.keyboardEnter("ApplyChangesDetails.Save");
						actions.smartWait(180);
					}
				} catch (Exception ee) {
					actions.WaitForElementPresent("ManageFee.SSMsg", 180);
					flag = mcd.VerifyOnscreenMessage("ManageFee.SSMsg", "Your changes have been saved.", true);
					flagFeeId = false;
				}
			} while (flagFeeId);
		}
		
		actions.verifyTextPresence(strSuccessMsg, false);

	}

	// ----------------------------------
	/*
	 * Feature Name : MENU ITEM > Promotion Management Functionality : Verify
	 * the GUI of Dynamic Conditions tab in new promotion screen - for
	 * Suggestive Add-On Campaign - Two Conditional Product Sets template in
	 * SWAP market. Scenario ID : MNU_1253 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PRC_VerifyGUI_DynamicCond_Suggestive(String strNamePrefix, String strNodeNum,
			String strTemplateName, String strSuggestiveQues1, String strMessage1, String strErrorMsg,
			String[] strFields, String strWarningMsg, String strApplicationDate) throws Exception {

		// Click on New Promotion button
		actions.keyboardEnter("PromotionMgmt.NewPromotionBtn");
		Thread.sleep(2000);
		actions.waitForPageToLoad(180);

		// Switch to New Window : Add New Promotion
		mcd.SwitchToWindow("Add New Promotion");

		// Select Template
		actions.setValue("PromotionMgmt.TemplateList", strTemplateName);

		// Set Promotion Name
		String strNewPromName = mcd.fn_GetRndName(strNamePrefix).substring(0, 10);
		actions.setValue("PromotionMgmt.PromName", strNewPromName);

		// Select Node
		// Select a Restaurant
		actions.keyboardEnter("PromotionMgmt.SelectNode");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);
		actions.setValue("SelectNode.SearchBox", strNodeNum);
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");

		Thread.sleep(3000);
		actions.waitForPageToLoad(120);

		Boolean blnSelectNode = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);
		if (blnSelectNode) {
			actions.reportCreatePASS("Verify Node Selection", "Node should be selected", "Node selected", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Node Selection", "Node should be selected", "Node not selected", "FAIL");
		}

		// Switch back to Add new
		mcd.SwitchToWindow("Add New Promotion");

		// Click Next
		actions.click("RFM.NextBtn");
		Thread.sleep(3000);

		// Switch title
		mcd.SwitchToWindow("Promotion");

		// Enter Prom Code
		// Generate a random code
		Random rand_num = new Random();
		int iPromCode = rand_num.nextInt((500) + 50);

		driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.PromCode")))
				.sendKeys(Integer.toString(iPromCode));

		// Enter From date
		actions.click("PromotionMgmt.FromCalender");

		// Select Today's Date
		mcd.sel_current_date("PromotionMgmt.FromCalender");
		Thread.sleep(3000);

		// Enter To Date
		actions.click("PromotionMgmt.ToCalender");

		System.out.println(strApplicationDate.split(" ")[0].trim());
		// Select Future Date
		mcd.Get_future_date(3, "close", strApplicationDate.split(" ")[0].trim());
		Thread.sleep(3000);

		// Enter Suggestive Question 1 :
		actions.setValue("PromotionMgmt.SuggestiveQues1", strSuggestiveQues1);

		// Click Next
		actions.click("RFM.NextBtn");

		// Try if promo code is duplicate
		Boolean blnVerifyPopUp = false;
		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Error", strMessage1, true, AlertPopupButton.OK_BUTTON);
			Thread.sleep(2000);
			// Generate a random code
			rand_num = new Random();
			iPromCode = rand_num.nextInt((500) + 50);

			driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.PromCode")))
					.sendKeys(Integer.toString(iPromCode));
			Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println("No Errors");
		}

		// VERIFY DYNAMIC TAB

		// Verify Status field
		if (driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.Status"))).isDisplayed()) {
			if (driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.Status"))).isEnabled()) {
				actions.reportCreatePASS("Verify Status Field", "Should be present & enabled",
						"Field is present & enabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Status Field", "Should be present & enabled", "Field is disabled",
						"FAIL");
			}
		} else {
			actions.reportCreateFAIL("Verify Status Field", "Should be present & enabled", "Field is not present",
					"FAIL");
		}

		// Verify Image field
		if (driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.SelectImg"))).isDisplayed()) {
			if (driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.SelectImg"))).isEnabled()) {
				actions.reportCreatePASS("Verify Select Image Field", "Should be present & enabled",
						"Field is present & enabled", "PASS");
			} else {
				actions.reportCreateFAIL("Verify Select Image Field", "Should be present & enabled",
						"Field is disabled", "FAIL");
			}
		} else {
			actions.reportCreateFAIL("Verify Select Image Field", "Should be present & enabled", "Field is not present",
					"FAIL");
		}

		// Promo Code is mandatory
		// Clear Promo Code & Click Apply
		actions.clear("PromotionMgmt.PromCode");
		actions.click("RFM.NextBtn");

		String strErr = strErrorMsg + " " + strFields[0];
		Thread.sleep(2000);

		RFM_PM_Verify_ErrorMsg(strErr, strFields[0]);
		Thread.sleep(2000);

		driver.findElement(By.xpath(actions.getLocator("PromotionMgmt.PromCode")))
				.sendKeys(Integer.toString(iPromCode));

		// ----------------------------------
		// Verify Conditional Product 1
		// ----------------------------------

		actions.click("RFM.NextBtn");

		strErr = strErrorMsg + " " + strFields[1];
		Thread.sleep(2000);
		RFM_PM_Verify_ErrorMsg(strErr, strFields[1]);

		// Select Conditional Product 1
		actions.click("PromotionMgmt.CustProd1AddRem");
		Thread.sleep(3000);

		mcd.SwitchToWindow("Search Menu Item");

		// Click on View Full list
		actions.click("RFM.ViewFullListBtn");
		actions.smartWait(180);

		actions.click("AddItem.LftTableRow");
		actions.click("AddItem.AddRowRight");

		actions.click("RFM.Apply");
		Thread.sleep(2000);

		mcd.SwitchToWindow("Promotion");
		Thread.sleep(1000);

		// ---------------------------------------------------
		// Verify Conditional Product 1 - Quantity Needed
		// ---------------------------------------------------

		actions.clear("PromotionMgmt.QuantNeed1");

		actions.click("RFM.NextBtn");

		strErr = strErrorMsg + " " + strFields[2];
		Thread.sleep(2000);
		RFM_PM_Verify_ErrorMsg(strErr, strFields[2]);

		actions.setValue("PromotionMgmt.QuantNeed1", "1");
		Thread.sleep(1000);

		// ------------------------------------
		// Verify Conditional Product 2
		// ------------------------------------

		actions.click("RFM.NextBtn");

		strErr = strErrorMsg + " " + strFields[3];
		Thread.sleep(2000);
		RFM_PM_Verify_ErrorMsg(strErr, strFields[3]);

		// Select Conditional Product 2
		actions.click("PromotionMgmt.CustProd2AddRem");
		Thread.sleep(3000);

		mcd.SwitchToWindow("Search Menu Item");

		// Click on View Full list
		actions.click("RFM.ViewFullListBtn");
		actions.smartWait(180);

		actions.click("AddItem.LftTableRow");
		actions.click("AddItem.AddRowRight");

		actions.click("RFM.Apply");
		Thread.sleep(2000);

		mcd.SwitchToWindow("Promotion");
		Thread.sleep(1000);

		// ---------------------------------------------------
		// Verify Conditional Product 2 - Quantity Needed
		// ---------------------------------------------------

		actions.clear("PromotionMgmt.QuantNeed2");

		actions.click("RFM.NextBtn");

		strErr = strErrorMsg + " " + strFields[4];
		Thread.sleep(2000);
		RFM_PM_Verify_ErrorMsg(strErr, strFields[4]);

		actions.setValue("PromotionMgmt.QuantNeed2", "1");
		Thread.sleep(1000);

		// ------------------------------------
		// Verify Add-On Product
		// ------------------------------------

		actions.click("RFM.NextBtn");

		strErr = strErrorMsg + " " + strFields[5];
		Thread.sleep(2000);
		RFM_PM_Verify_ErrorMsg(strErr, strFields[5]);

		// Select Conditional Product 2
		actions.click("PromotionMgmt.AddOnAddRem");
		Thread.sleep(3000);

		mcd.SwitchToWindow("Search Menu Item");

		// Click on View Full list
		actions.click("RFM.ViewFullListBtn");
		actions.smartWait(180);

		actions.click("AddItem.LftTableRow");
		actions.click("AddItem.AddRowRight");

		actions.click("RFM.Apply");
		Thread.sleep(2000);

		mcd.SwitchToWindow("Promotion");
		Thread.sleep(1000);

		// ---------------------------------------------------
		// Verify Quantity Given
		// ---------------------------------------------------

		actions.clear("PromotionMgmt.QuantGiven");

		actions.click("RFM.NextBtn");

		strErr = strErrorMsg + " " + strFields[6];
		Thread.sleep(2000);
		RFM_PM_Verify_ErrorMsg(strErr, strFields[6]);

		actions.setValue("PromotionMgmt.QuantGiven", "1");
		Thread.sleep(1000);

		// ---------------------------------------------------
		// Verify New Price
		// ---------------------------------------------------

		actions.clear("PromotionMgmt.NewPrice");

		actions.click("RFM.NextBtn");

		strErr = strErrorMsg + " " + strFields[7];
		Thread.sleep(2000);
		RFM_PM_Verify_ErrorMsg(strErr, strFields[7]);

		actions.setValue("PromotionMgmt.NewPrice", "1.00");
		Thread.sleep(1000);

		// Click Cancel
		actions.click("RFM.CancelBtn");

		try {
			blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Error", strWarningMsg, true, AlertPopupButton.OK_BUTTON);
			Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println("No warning msg");
			actions.waitForPageToLoad(120);
		}

		mcd.SwitchToWindow("$Promotion");

	}

	// ----------------------------------
	/*
	 * Feature Name : MENU ITEM > Promotion Management Functionality : Common
	 * Function to Verify Error messages for GUI validations in MNU_1253
	 * Scenario ID : Used in MNU_1253 Author : Pooja Panse
	 */
	// -----------------------------------

	public void RFM_PM_Verify_ErrorMsg(String strErr, String strFieldName) throws InterruptedException {
		Boolean blnVerifyPopUp = mcd.VerifyAlertMessageDisplayed("Error", strErr, true, AlertPopupButton.OK_BUTTON);
		Thread.sleep(2000);

		if (blnVerifyPopUp) {
			actions.reportCreatePASS("Verify " + strFieldName, "Field should be mandatory", "Field is mandatory",
					"PASS");
		} else {
			actions.reportCreateFAIL("Verify " + strFieldName, "Field should be mandatory", "Field is not mandatory",
					"FAIL");
		}
	}

	// ----------------------------------
	/*
	 * Feature Name : PRICING > Tender Type Set Functionality : Create Tender
	 * Type Set Scenario ID : Used in PRC_1088/PRC_1089 Author : Pooja Panse
	 */
	// -----------------------------------

	public String RFM_PRC_CreateTenderTypeSet_CpyExisting(String strNewTenderSetName, String strNodeNum,
			String strNamePrefix, String strResultMsg) throws Exception {
		// Create Tender type set in Market 1
		actions.click("TenderTypeSet.NewTTSButton");
		Thread.sleep(2000);

		mcd.SwitchToWindow("Add New Tender Set");

		if (strNewTenderSetName.equals("")) {
			strNewTenderSetName = mcd.fn_GetRndName(strNamePrefix);
		}
		actions.setValue("NewMITaxSet.SetName", strNewTenderSetName);

		actions.click("TenderTypeSet.SelectNodeBtn");
		Thread.sleep(3000);

		mcd.SwitchToWindow("Select Node");

		actions.keyboardEnter("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);

		actions.click("SelectNode.HierarchyRB");
		Thread.sleep(1000);

		actions.setValue("SelectNode.SearchBox", strNodeNum);
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(7000);

		String strXPath = "";
		WebElement eleMarketTree = null;

		eleMarketTree = actions.getwebDriverLocator(actions.getLocator("SelectNode.NodeTable"));
		strXPath = "//label[contains(text(),'" + strNodeNum + "')]";
		WebElement eleMarket = eleMarketTree.findElement(By.xpath(strXPath));
		if (eleMarket != null) {
			eleMarket.click();
			System.out.println("Node-" + strNodeNum + " selected successfully");
		} else {
			System.out.println("Failed to select Node-" + strNodeNum);
		}

		mcd.SwitchToWindow("Add New Tender Set");

		actions.click("SelectNode.CopyRadioButtonYes");
		Thread.sleep(3000);

		actions.click("TenderTypeSet.SelectSettoCopy");
		Thread.sleep(2000);

		mcd.SwitchToWindow("tenderTypeSet.title.copyTenderTypeSet");
		Thread.sleep(2000);

		actions.click("RFM.ViewFullListBtn");
		actions.smartWait(120);

		// Select a Tender type set
		mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a").click();
		Thread.sleep(2000);

		mcd.SwitchToWindow("Add New Tender Set");

		// Click on Next
		actions.click("NewMITaxSet.Next");

		Thread.sleep(7000);
		mcd.SwitchToWindow("@Manage Tender Type Set");

		actions.click("RFM.SaveBtn");
		Thread.sleep(1000);
		actions.smartWait(120);

		try {
			actions.verifyTextPresence(strResultMsg, false);
			actions.reportCreatePASS("Verify Create New Tender Type Set", "New Tender Type should be created",
					"New Tender Type " + strNewTenderSetName + " is created", "PASS");
		} catch (Exception err) {
			actions.reportCreateFAIL("Verify Create New Tender Type Set", "New Tender Type should be created",
					"New Tender Type creation failed", "FAIL");
		}

		return strNewTenderSetName;
	}

	// ----------------------------------
	/*
	 * Feature Name : Pricing > Deposit Set Functionality : Create a Deposit Set
	 * in Deposits - With/Without copying existing set Scenario ID : PRC_20004/5
	 * Author : Pooja Panse
	 */
	// -----------------------------------

	public String RFM_PRC_CreateNewDepositSet(String strNamePrefix, String strMarket, String strSuccessMsg,
			String strStatus, String strCopyFlag, String strExistingSetMsg) throws Exception {
		actions.keyboardEnter("Deposit.NewBtn");
		Thread.sleep(2000);

		// Switch
		mcd.waitAndSwitch("Add New Deposit Set");

		// Set Name
		// Enter unique Deposit Name
		String strDepositSetName = null;
		strDepositSetName = mcd.fn_GetRndName(strNamePrefix);
		strDepositSetName = strDepositSetName.subSequence(0, 10).toString();
		actions.setValue("Deposit.DSName", strDepositSetName);

		// Select Node
		actions.click("Deposit.DSSelectNode");

		Thread.sleep(2000);

		mcd.waitAndSwitch("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);
		actions.setValue("SelectNode.SearchBox", strMarket);
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");

		Thread.sleep(3000);
		actions.waitForPageToLoad(120);

		Boolean blnSelectNode = mcd.Selectrestnode("SelectNode.NodeTable", strMarket);
		if (blnSelectNode) {
			actions.reportCreatePASS("Verify Node Selection", "Node should be selected", "Node selected", "PASS");
		} else {
			actions.reportCreateFAIL("Verify Node Selection", "Node should be selected", "Node not selected", "FAIL");
		}

		// Switch back to Add new
		mcd.waitAndSwitch("Add New Deposit Set");

		if (strCopyFlag.trim().equalsIgnoreCase("yes")) {
			actions.click("FeeSet.CopyExistingYes");
			Thread.sleep(1000);

			actions.click("NewPriceSet.SelectPrcSet");
			Thread.sleep(1000);
			mcd.waitAndSwitch("Select Deposit Set to Copy");

			actions.click("RFM.ViewFullListBtn");
			Thread.sleep(1000);
			actions.smartWait(120);

			actions.click("MasterDeposit.FirstData");
			Thread.sleep(1000);

			mcd.waitAndSwitch("Add New Deposit Set");

		}

		actions.click("RFM.NextBtn");
		
		Thread.sleep(3000);
		
		WebElement eleErrMsg;
		boolean blnExists = false;
		
		do{
			try{
				eleErrMsg = driver.findElement(By.xpath(actions.getLocator("AddNewFlavorSet.ErrorMessage")));
			
				if(eleErrMsg.getText().trim().equalsIgnoreCase(strExistingSetMsg)){
					blnExists = true;

					actions.clear("Deposit.DSName");
					strDepositSetName = mcd.fn_GetRndName(strNamePrefix);
					strDepositSetName = strDepositSetName.subSequence(0, 10).toString();
					actions.setValue("Deposit.DSName", strDepositSetName);
				
					actions.keyboardEnter("RFM.NextBtn");
					Thread.sleep(3000);
				}else{
					blnExists = false;
					System.out.println("Other msg appeared >>"+eleErrMsg.getText().trim());
				}
			}catch(Exception err){
				blnExists = false;
			}
		}while(blnExists);

		
		// Switch back to main window
		mcd.waitAndSwitch("Deposit Sets");

		if (strCopyFlag.trim().equalsIgnoreCase("no")) {
			actions.click("Deposit.AddDeposit");
			Thread.sleep(2000);
			// Switch back to main window
			mcd.waitAndSwitch("Add Deposit");

			WebElement eleChkDS = mcd.GetTableCellElement("Deposit.AddDepositTable", 1, 1, "input");

			eleChkDS.sendKeys(Keys.SPACE);

			actions.click("Deposit.AddDepositContinue");
			Thread.sleep(2000);

			// Switch back to main window
			mcd.waitAndSwitch("Deposit Sets");
		}

		actions.click("RFM.SaveBtn");
		Thread.sleep(4000);

		Boolean blnUniqueID = false;

		// Verify success message

		if (driver.findElement(By.xpath(actions.getLocator("DepositSet.MessageHeader"))).getText().trim().toLowerCase()
				.contains("saved")) {
			actions.verifyTextPresence(strSuccessMsg, false);
		} else if (driver.findElement(By.xpath(actions.getLocator("DepositSet.MessageHeader"))).getText().trim()
				.toLowerCase().contains("unique")) {
			do {
				if (driver.findElement(By.xpath(actions.getLocator("DepositSet.MessageHeader"))).getText().trim()
						.toLowerCase().contains("unique")) {
					// actions.verifyTextPresence("Please enter a unique Deposit
					// ID.", false);
					blnUniqueID = true;

					actions.clear("Deposit.DSName");
					strDepositSetName = strDepositSetName + "1";
					actions.setValue("Deposit.DSName", strDepositSetName);

					// Click on Save
					actions.click("RFM.SaveBtn");
					Thread.sleep(3000);
				} else {
					blnUniqueID = false;
				}
			} while (blnUniqueID);

			// Verify success message
			actions.verifyTextPresence(strSuccessMsg, false);
		}

		actions.reportCreatePASS("Verify Creation of new deposit set", "New Deposit set should be created",
				"New deposit set : " + strDepositSetName + " created", "PASS");

		// Select Status Active
		if (strStatus.equals("Inactive")) {
			actions.setValue("Deposit.DSStatus", strStatus);

			actions.click("RFM.Apply");
			Thread.sleep(4000);

		}

		actions.keyboardEnter("RFM.CancelBtn");
		Thread.sleep(2000);

		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

		return strDepositSetName;
	}

	// ----------------------------------
	/*
	 * Feature Name : Fee Sets Functionality :Create New Fee Set
	 * (Active/Inactive) Scenario ID : PRC_20214 Author : Pooja Panse
	 */
	// -----------------------------------

	public String RFM_PRC_CreateNewFeeSet(String strNamePrefix, String strMarket, String strSuccessMsg,
			String strStatus, String strCopyFlag, String strNodeNumber, String strFeeMsg, String strCancelMsg,
			int iNumOfFee, String strExistingSetMsg) throws Exception {
		// Click on New Fee Set button
		actions.keyboardEnter("FeeSet.NewFeeSetBtn");
		Thread.sleep(3000);

		// Switch to new window
		mcd.SwitchToWindow("Add New Fee Set");

		// Generate a unique Fee Set Name
		String strNewFeeSetName = mcd.fn_GetRndName(strNamePrefix);

		strNewFeeSetName = strNewFeeSetName.subSequence(0, 10).toString();

		// Enter Name
		actions.setValue("FeeSet.NewFeeSetName", strNewFeeSetName);

		// Select Node
		// Select a Restaurant
		actions.keyboardEnter("FeeSet.SelectBtn");

		Thread.sleep(2000);
		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(1000);
		actions.setValue("SelectNode.SearchBox", strNodeNumber);
		Thread.sleep(1000);

		actions.keyboardEnter("SelectNode.SearchButton");

		Thread.sleep(3000);
		actions.waitForPageToLoad(120);

		Boolean blnSelectNode = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNumber);

		// Switch back to Add new
		mcd.SwitchToWindow("Add New Fee Set");

		if (strCopyFlag.trim().equalsIgnoreCase("yes")) {
			// Select Yes for copy existing fee set
			actions.click("FeeSet.CopyExistingYes");
			Thread.sleep(1000);

			actions.click("NewPriceSet.SelectPrcSet");
			Thread.sleep(1000);
			mcd.SwitchToWindow("Select Fee Set to Copy");

			actions.click("RFM.ViewFullListBtn");
			Thread.sleep(1000);
			actions.smartWait(120);

			actions.click("MasterDeposit.FirstData");
			Thread.sleep(1000);

			mcd.SwitchToWindow("Add New Fee Set");

		}

		// Click on RFM Next
		actions.click("RFM.NextBtn");
		Thread.sleep(3000);
		
		WebElement eleErrMsg;
		boolean blnExists = false;
		
		do{
			try{
				eleErrMsg = driver.findElement(By.xpath(actions.getLocator("AddNewFlavorSet.ErrorMessage")));
			
				if(eleErrMsg.getText().trim().equalsIgnoreCase(strExistingSetMsg)){
					blnExists = true;

					actions.clear("FeeSet.NewFeeSetName");
					strNewFeeSetName = mcd.fn_GetRndName(strNamePrefix);
					strNewFeeSetName = strNewFeeSetName.subSequence(0, 10).toString();
					actions.setValue("FeeSet.NewFeeSetName", strNewFeeSetName);
				
					actions.click("RFM.NextBtn");
					Thread.sleep(3000);
				}else{
					blnExists = false;
					System.out.println("Other msg appeared >>"+eleErrMsg.getText().trim());
				}
			}catch(Exception err){
				blnExists = false;
			}
		}while(blnExists);
		
		// Switch title
		Boolean blnResult = mcd.waitAndSwitch("Fee Sets");

		if (blnResult) {
			actions.reportCreatePASS("Verify screen after Next button is clicked",
					"Window should navigate to Fee Sets Screen", "Window navigated to Fee Sets Screen.", "PASS");
		} else {

			actions.reportCreatePASS("Verify screen after Next button is clicked",
					"Window should navigate to Fee Sets Screen", "Window navigated to Fee Sets Screen.", "FAIL");
		}

		// Click Save Button without selecting any Fee
		actions.WaitForElementPresent("RFM.SaveBtn", 180);
		
		actions.click("RFM.SaveBtn");
		Thread.sleep(1000);

		Boolean VerifyPopUpMsg = mcd.VerifyAlertMessageDisplayed("Error", strFeeMsg, true, AlertPopupButton.OK_BUTTON);

		if (VerifyPopUpMsg) {
			actions.reportCreatePASS("Verify a fee should be mandatory in fee set", "Fee should be mandatory",
					"Fee is mandatory. Correct message displayed as expected, if left blank", "PASS");
		} else {
			actions.reportCreateFAIL("Verify a fee should be mandatory in fee set", "Fee should be mandatory",
					"Fee is not mandatory. No/Incorrect message displayed as expected, if left blank", "FAIL");
		}

		// Click on Add Fee Button
		if (strCopyFlag.trim().equalsIgnoreCase("no")) {
			actions.click("Fee.AddFee");
			Thread.sleep(2000);
			// Switch back to main window
			mcd.SwitchToWindow("Fee");

			// Verify Sort
			// get the row count first
			int FeeID1, FeeID2;
			int iTotalFeeRow = mcd.GetTableRowCount("Fee.AddFeeTable");
			if (iTotalFeeRow > 1) {
				FeeID1 = Integer.parseInt(mcd.GetTableCellElement("Fee.AddFeeTable", 1, "Fee ID", "").getText().trim());
				FeeID2 = Integer.parseInt(mcd.GetTableCellElement("Fee.AddFeeTable", 2, "Fee ID", "").getText().trim());

				if (FeeID1 < FeeID2) {
					actions.reportCreatePASS("Verify Fee Sort", "Fee should sorted in ascending order",
							"Fee sorted in ascending order", "PASS");
				} else {
					actions.reportCreateFAIL("Verify Fee Sort", "Fee should sorted in ascending order",
							"Fee not sorted in ascending order", "FAIL");
				}
			} else {
				actions.reportCreatePASS("Verify Fee Sort", "Fee should sorted in ascending order",
						"Fee sorted in ascending order", "PASS");
			}

			WebElement eleChkDS = mcd.GetTableCellElement("Fee.AddFeeTable", 1, 1, "input");

			eleChkDS.sendKeys(Keys.SPACE);

			// Verify Cancelling all changes

			actions.click("RFM.CancelBtn");
			Thread.sleep(2000);

			// Verify Pop Up - Click OK
			Boolean VerifyCancelPopUpMsg = mcd.VerifyAlertMessageDisplayed("Warning", strCancelMsg, true,
					AlertPopupButton.OK_BUTTON);
			mcd.SwitchToWindow("Fee Sets");

			if ((VerifyCancelPopUpMsg) && (driver.getTitle().trim().equalsIgnoreCase("Fee Sets"))) {
				actions.reportCreatePASS("Verify warning message when cancel is clicked",
						"Warning should be displayed & after selecting Ok, page should return to Fee Set screen",
						"Warning msg displayed & after selecting cancel page returns to Fee Set screen", "PASS");
			} else {
				actions.reportCreateFAIL("Verify warning message when cancel is clicked",
						"Warning should be displayed & after selecting cancel page should return to Fee Set screen",
						"Warning msg not displayed OR after selecting cancel page does not return to Fee Set screen",
						"FAIL");
			}

			// Click Add Fee Again

			actions.click("Fee.AddFee");
			Thread.sleep(2000);
			// Switch back to main window
			mcd.SwitchToWindow("Fee");

			eleChkDS = mcd.GetTableCellElement("Fee.AddFeeTable", 1, 1, "input");

			eleChkDS.sendKeys(Keys.SPACE);

			// Verify Cancelling all changes

			actions.click("RFM.CancelBtn");
			Thread.sleep(2000);

			// Verify Pop Up - Click OK
			VerifyCancelPopUpMsg = mcd.VerifyAlertMessageDisplayed("Warning", strCancelMsg, true,
					AlertPopupButton.CANCEL_BUTTON);

			if ((VerifyCancelPopUpMsg) && (driver.getTitle().trim().equalsIgnoreCase("Fee"))) {
				actions.reportCreatePASS("Verify warning message when cancel is clicked",
						"Warning should be displayed & after selecting cancel page should remain on Fee window",
						"Warning msg displayed & after selecting cancel page remains on Fee window", "PASS");
			} else {
				actions.reportCreateFAIL("Verify warning message when cancel is clicked",
						"Warning should be displayed & after selecting cancel page should remain on Fee window",
						"Warning msg not displayed OR after selecting cancel page does not remain on Fee window",
						"FAIL");
			}
			
			// Save the changes & Click Continue
			actions.click("Fee.AddFeeContinue");
			Thread.sleep(2000);

			// Switch back to main window
			mcd.SwitchToWindow("Fee Sets");

			// Check whether more Fee are required
			if (iNumOfFee != 0) {
				// Assign Few more Fee to Fee Set

				RFM_AddFeeToFeeSet(iNumOfFee, "yes");
			}
		}

		actions.click("RFM.SaveBtn");

		WebElement eleMessage = driver.findElement(By.xpath(actions.getLocator("DepositSet.PPActionMessage")));			
		
		boolean blnDynamicElement = (new WebDriverWait(driver, 18000))
				  .until(ExpectedConditions.textToBePresentInElement(eleMessage, strSuccessMsg));
		
		if(blnDynamicElement){
			actions.verifyTextPresence(strSuccessMsg, true);
		}
		
		//		Thread.sleep(4000);
//
//		// Verify success message
//		actions.verifyTextPresence(strSuccessMsg, false);

		actions.reportCreatePASS("Verify Creation of new fee set", "New fee set should be created",
				"New fee set : " + strNewFeeSetName + " created", "PASS");

		// Select Status Active
		if (strStatus.equals("Inactive")) {
			actions.setValue("Fee.FSStatus", strStatus);

			actions.click("RFM.Apply");
			Thread.sleep(4000);

		}

		actions.click("RFM.CancelBtn");
		Thread.sleep(2000);

		actions.waitForPageToLoad(120);

		mcd.SwitchToWindow("#Title");

		return strNewFeeSetName;
	}

	// ----------------------------------
	/*
	 * Feature Name : Fee Sets Functionality : Assign Fee to Fee Set
	 * (Active/Inactive) Scenario ID : Used in creating fee sets TCs Author :
	 * Pooja Panse
	 */
	// -----------------------------------

	public boolean RFM_AddFeeToFeeSet(int iNumOfFee, String strSelected) throws Exception {

		Boolean blnFeeAdded = false;
		int iStartCnt = 1;
		// Click Add Fee Again

		actions.keyboardEnter("Fee.AddFee");
		Thread.sleep(2000);
		// Switch back to main window
		mcd.SwitchToWindow("Fee");
		
		WebElement eleMessage = driver.findElement(By.xpath(actions.getLocator("DepositSet.PPActionMessage")));			
		
		if(eleMessage.getText().trim().equalsIgnoreCase("All Fee have already been added.")){
			actions.click("RFM.CancelBtn");
			blnFeeAdded = false;
		}else{
		
			if(strSelected.trim().equalsIgnoreCase("yes")){
				iStartCnt = 2;
			}else{
				iStartCnt = 1;
			}

			WebElement eleChkDS;

			for (int i = iStartCnt; i <= iNumOfFee; i++) {
				eleChkDS = mcd.GetTableCellElement("Fee.AddFeeTable", i, 1, "input");
				eleChkDS.sendKeys(Keys.SPACE);
			}

			// Save the changes & Click Continue
			actions.click("Fee.AddFeeContinue");
			
			blnFeeAdded = true;
		}
		
		Thread.sleep(2000);
			
		// Switch back to main window
		mcd.SwitchToWindow("Fee Sets");
		
		return blnFeeAdded;
	}
	
//	// ----------------------------------
//	/*
//	 * Feature Name : Fee Sets Functionality : Assign Fee to Fee Set
//	 * (Active/Inactive) Scenario ID : Used in creating fee sets TCs Author :
//	 * Pooja Panse
//	 */
//	// -----------------------------------
//
//	public void RFM_AddFeeToFeeSet(int iNumOfFee, String strSelected) throws Exception {
//
//		// Click Add Fee Again
//		actions.click("Fee.AddFee");
//		Thread.sleep(2000);
//		// Switch back to main window
//		mcd.SwitchToWindow("Fee");
//
//		WebElement eleChkDS;
//
//		for (int i = 1; i <= iNumOfFee; i++) {
//			eleChkDS = mcd.GetTableCellElement("Fee.AddFeeTable", i, 1, "input");
//			eleChkDS.sendKeys(Keys.SPACE);
//		}
//
//		// Save the changes & Click Continue
//		actions.click("Fee.AddFeeContinue");
//		Thread.sleep(2000);
//
//		// Switch back to main window
//		mcd.SwitchToWindow("Fee Sets");
//	}

	// ----------------------------------
	/*
	 * Feature Name : PRICING> Taxes> Tax Type Functionality : Create Tax Type
	 * by copying any existing Tax Type with future settings New Script Scenario
	 * ID : Used in PRC_20060 Author : Akanksha Rani
	 */
	// -----------------------------------
	public String RFM_PRC_CreateNewTaxTypeCopingExistingTT(String strNode, String strSearchBy, String AddTaxTypeValue,
			String strResultMsg) throws Exception {
		// Click on New Script Button
		boolean flag = false;
		String[] strErrMsg = strResultMsg.split("#");
		String[] strAddTaxTypeValue = AddTaxTypeValue.split("#");
		String strNewTaxName, NewTaxTypeActive1;
		Integer strRangId;
		// creating new tax type to use as existing Tax Type
		NewTaxTypeActive1 = RFM_PRC_CreateNewTaxType(strNode, strSearchBy, AddTaxTypeValue, strResultMsg);

		Thread.sleep(3000);
		driver.findElement(By.xpath(actions.getLocator("TaxType.NewTaxTypeButton"))).click();
		// actions.keyboardEnter("TaxType.NewTaxTypeButton");
		mcd.SwitchToWindow("Add New Tax Type");
		actions.keyboardEnter("NewTaxType.SelectButton");

		actions.smartWait(10);
		mcd.SwitchToWindow("Select Node");

		if (strSearchBy.equals("Restaurant Number")) {
			actions.click("SelectNode.RestaurantNumberRadioButton");
			/*
			 * int strNode1=Integer.parseInt(strNode); Integer strNode11 =
			 * Integer.valueOf(strNode);
			 * actions.setValue("SelectNode.SearchTextTreeTextBox", strNode1);
			 */
		} else if (strSearchBy.equals("Hierarchies")) {
			actions.click("SelectNode.HierarchiesRadioButton");

		}
		actions.setValue("SelectNode.SearchTextTreeTextBox", strNode);
		actions.click("SelectNode.ExactMatchRadioButton");
		driver.findElement(By.xpath(actions.getLocator("SelectNode.ARsearchButton"))).click();
		// actions.click("SelectNode.searchButton");
		mcd.Selectrestnode("SelectNode.Tree", strNode);
		mcd.SwitchToWindow("Add New Tax Type");

		// Selecting Copy Settings From Existing Tax Type
		actions.click("NewTaxType.YesRadioButton");
		actions.keyboardEnter("NewTaxType.SelectCopyTextTypeButton");

		mcd.SwitchToWindow("Copy Settings From Existing Tax Type");
		actions.setValue("ScriptManagement.SearchTextbox", NewTaxTypeActive1);
		actions.keyboardEnter("CopySettingsFromExistingTaxType.SearchButton");
		actions.smartWait(10);

		WebElement ElementTaxNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Tax Type Name", "a");
		ElementTaxNm.click();

		mcd.SwitchToWindow("Add New Tax Type");

		do {

			strNewTaxName = mcd.fn_GetRndName("Auto_NT");
			actions.clear("NewTaxType.TaxTypeNameField");
			actions.setValue("NewTaxType.TaxTypeNameField", strNewTaxName);
			System.out.println("NewTaxTypeName" + strNewTaxName);

			actions.keyboardEnter("NewTaxType.NextButton");
			actions.smartWait(10);
			try {
				flag = mcd.VerifyOnscreenMessage("NewScript.ResultMsg", strErrMsg[0], true);
			} catch (Exception e) {
				System.out.println("Tax Name accepted successfully");

				flag = false;
			}

		} while (flag);
		if (flag == false) {
			actions.smartWait(10);
			mcd.SwitchToWindow("@Add Tax Type");

			actions.setValue("AddTaxType.TaxRateIdTextbox", strAddTaxTypeValue[0]);
			actions.setValue("AddTaxType.TaxBasisIdDropdown", strAddTaxTypeValue[1]);
			actions.setValue("AddTaxType.TaxCalDropdown", strAddTaxTypeValue[2]);
			actions.setValue("AddTaxType.TaxRoundingDropdown", strAddTaxTypeValue[3]);
			actions.setValue("AddTaxType.TaxPrecisionDropdown", strAddTaxTypeValue[4]);
			try {
				if (!strAddTaxTypeValue[5].equals("")) {
					String statusId = strAddTaxTypeValue[5];
					switch (statusId) {
					case "Active":
						actions.setValue("AddTaxType.StatusIdDropdown", statusId);
						break;
					case "Inactive":
						actions.setValue("AddTaxType.StatusIdDropdown", statusId);
						break;
					case "Suspended":
						actions.setValue("AddTaxType.StatusIdDropdown", statusId);
						break;
					}
				}

			} catch (Exception err) {
				System.out.println("By Default your status will be Inactive");
			}
			do {
				strRangId = mcd.fn_GetRndNumInRange(1, 99999999);
				System.out.println("strRangId" + strRangId);
				actions.clear("AddTaxType.TaxTypeCodeTextbox");
				actions.setValue("AddTaxType.TaxTypeCodeTextbox", strRangId);
				System.out.println("AddTaxType.TaxTypeCodeTextbox" + strRangId);

				actions.keyboardEnter("AddTaxType.SaveButton");
				actions.smartWait(10);
				try {
					flag = mcd.VerifyOnscreenMessage("NewScript.ResultMsg", strErrMsg[1], true);
				} catch (Exception e) {
					System.out.println("Tax Type accepted successfully");
					// actions.keyboardEnter("AddTaxType.SaveButton");
					flag = false;
				}

				if (flag) {
					System.out.println("Tax Type already exists, trying another random name");
					System.out.println(flag);
				} else {
					try {
						System.out.println(flag);
						mcd.SwitchToWindow("#Title");

						actions.verifyTextPresence(strErrMsg[2], false);
						actions.keyboardEnter("AddTaxType.CancelButton");

						// Switching to Tax Type
						actions.smartWait(10);
						mcd.SwitchToWindow("#Title");
						actions.reportCreatePASS("Verify Create New Tax Type", "New Tax Type should be created",
								"New Tax Type " + strNewTaxName + " is created", "PASS");

					} catch (Exception err) {
						actions.reportCreateFAIL("Verify Create New Tax Type", "New Tax Type should be created",
								"New Tax Type creation failed", "FAIL");
					}
				}

			} while (flag);
		}
		return strNewTaxName;
	}

	// function to validate user is not able to change the status from Active to
	// Inactive for a Tax Types if it is associated with one or more
	// Fee/Deposit(s) or Tax Chain
	// New Script Scenario ID : Used in PRC_20049,PRC_20050,PRC_20051,PRC_20052
	// Author : Akanksha Rani
	public void verifyTaxTypeErrorAssOther(String strNavigateToTT, String TaxType, String strpopup, String ErrorMSG) {
		try {
			boolean flag = false;
			System.out.println("> Navigate to :: " + strNavigateToTT);
			actions.select_menu("RFMHome.Navigation", strNavigateToTT);
			actions.WaitForElementPresent("ScriptManagement.SearchTextbox");
			Thread.sleep(1000);
			mcd.smartsync(180);
//			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("ScriptManagement.SearchTextbox", 180);
			actions.setValue("ScriptManagement.SearchTextbox", TaxType);
			actions.keyboardEnter("TaxType.SearchButton");
			Thread.sleep(2000);
			actions.smartWait(10);

			WebElement ElementTaxTypNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Tax Type Name",
					"a");
			actions.keyboardEnter(ElementTaxTypNm);
			Thread.sleep(1000);
			mcd.smartsync(180);
//			mcd.SwitchToWindow("#Title");
			actions.setValue("AddTaxType.StatusIdDropdown", "Inactive");
			driver.findElement(By.xpath(actions.getLocator("UpdateTaxType.ApplyButton"))).click();
//			actions.click("UpdateTaxType.ApplyButton");
			Thread.sleep(2000);
			// actions.smartWait(100);
			if (!strpopup.equals("")) {
				mcd.VerifyAlertMessageDisplayed("Warning Message", strpopup, true, AlertPopupButton.OK_BUTTON);
				actions.smartWait(50);

			}
			
			Thread.sleep(4000);
			actions.smartWait(180);
			actions.verifyTextPresence(ErrorMSG, true);
//			flag = mcd.VerifyOnscreenMessage("NewScript.ResultMsg", ErrorMSG, true);
//
//			if (flag) {
//				System.out.println("Present");
//
//				actions.reportCreatePASS("Verify" + ErrorMSG + " is Displayed", ErrorMSG + "should displayed",
//						ErrorMSG + "is displayed", "Pass");
//
//			} else {
//
//				actions.reportCreateFAIL("Verify" + ErrorMSG + " is Displayed", ErrorMSG + "should displayed",
//						ErrorMSG + "is not displayed", "Fail");
//
//			}

		} catch (Exception e) {
			actions.reportCreateFAIL("Verify" + ErrorMSG + " is Displayed", ErrorMSG + "should displayed",
					ErrorMSG + "is not displayed", "Fail");
		}
	}

	/*
	 * Feature Name : PRICING> Tender Type> Master Tender Type Functionality :
	 * Applying Future Setting to existing Master Tender Type New Script
	 * Scenario ID : Used in PRC_20081 Author : Akanksha Rani
	 */
	public String RFM_PRC_TenderTypeFutureSettings(String TenderTypeName, String Data, String TenderFlagLocator,
			String strApplicationDate) throws Exception {
		String strDataSplit[], TenderFlagSplit[], FutureSettings;
		Integer strDataSplitln, TenderFlagSplitln;
		boolean flag;
		strDataSplit = Data.split("#");
		strDataSplitln = strDataSplit.length;

		try {
			actions.keyboardEnter("TenderTypeList.ViewFullListButton");
			Thread.sleep(2000);
			actions.smartWait(180);
			actions.WaitForElementPresent("TenderSet.StatusDropDown", 180);
			actions.setValue("TenderSet.StatusDropDown", "Active");
			Thread.sleep(2000);
			actions.smartWait(180);

			if (!TenderTypeName.equals("")) {
				actions.clear("TenderTypeList.SearchTextbox");
				actions.setValue("TenderTypeList.SearchTextbox", TenderTypeName);
				actions.keyboardEnter("TenderTypeList.SearchButton");
				Thread.sleep(1000);
				actions.smartWait(180);
				// Retrieving first value of table

				WebElement ElementTenderTypNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 3,
						"Tender Type Name", "a");
				ElementTenderTypNm.click();
			} else if (TenderTypeName.equals("")) {
				// Checking whether Future Settings is already present
				int rowcount = mcd.GetTableRowCount("ScriptManagement.TableNameValue");
				for (int i = 0; i < rowcount - 1; i++) {
					FutureSettings = mcd.GetTableCellValue("ScriptManagement.TableNameValue", i + 3, "Future Settings",
							"", "");
					if (FutureSettings.equals("")) {
						// Retrieving Tender Type Name of table
						TenderTypeName = mcd.GetTableCellValue("ScriptManagement.TableNameValue", i + 3,
								"Tender Type Name", "", "");
						WebElement ElementTenderTypNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue",
								i + 3, "Tender Type Name", "a");
						ElementTenderTypNm.click();
						break;
					}
				}

			} // Switching to manage Tender type
			mcd.SwitchToWindow("#Title");
			// Enter the Fiscal Index
			actions.clear("ManageTenderType.FiscalIndexTextbox");
			actions.setValue("ManageTenderType.FiscalIndexTextbox", strDataSplit[0]);

			// Enter the Currency Decimals
			if (strDataSplitln >= 2) {
				actions.clear("ManageTenderType.CurrencyDecimalsTextbox");
				actions.setValue("ManageTenderType.CurrencyDecimalsTextbox", strDataSplit[1]);
			}

			// Enter the Change Maximum Allowed
			if (strDataSplitln >= 3) {
				actions.clear("ManageTenderType.ChngMaxAllowedTextbox");
				actions.setValue("ManageTenderType.ChngMaxAllowedTextbox", strDataSplit[2]);
			}
			if (!TenderFlagLocator.equals("")) {
				TenderFlagSplit = TenderFlagLocator.split("#");
				TenderFlagSplitln = TenderFlagSplit.length;
				for (int i = 0; i <= TenderFlagSplitln - 1; i++) {
					flag = driver.findElement(By.xpath(actions.getLocator(TenderFlagSplit[i]))).isSelected();
					if (flag) {
						System.out.println("Already Selected");
					} else {
						driver.findElement(By.xpath(actions.getLocator(TenderFlagSplit[i]))).click();
					}
				}
			}
			actions.click("ManageTenderType.SaveIdButton");
			mcd.SwitchToWindow("Apply Changes Details");
			actions.click("ApplyChangesDetails.futureDateRadioButton");
			actions.click("ApplyChangesDetails.CalendarIcon");
			mcd.Get_future_date(2, "Close", strApplicationDate);
			actions.keyboardEnter("ManageTenderType.SaveButton");
			mcd.SwitchToWindow("Manage Tender Type");
			flag = mcd.VerifyOnscreenMessage("TaxType.ErrorMsg", "Your changes have been saved.", true);
			if (flag) {
				actions.reportCreatePASS("Verify Future Date applied on Tender Type" + TenderTypeName,
						"Future Date should applied on Tender Type" + TenderTypeName,
						"Future Date applied on Tender Type" + TenderTypeName, "Pass");
			} else {
				actions.reportCreateFAIL("Verify Future Date applied on Tender Type" + TenderTypeName,
						"Future Date should applied on Tender Type" + TenderTypeName,
						"Future Date not applied on Tender Type" + TenderTypeName, "Fail");
			}
			actions.keyboardEnter("ManageTenderType.CancelButton");
			// actions.smartWait(10);
			mcd.SwitchToWindow("#Title");

		} catch (Exception e) {
			System.out.println("Future Setting already applied to first TenderTypeName Values ");
		}
		System.out.println("TenderTypeName" + TenderTypeName);
		return TenderTypeName;
	}

	/*
	 * Feature Name : PRICING> Tender Type> Master Tender Type Functionality :
	 * Assigning Tender Type to TenderTypSet New Script Scenario ID : Used in
	 * PRC_0083,PRC_20082 Author : Akanksha Rani
	 */
	public String RFM_PRC_AssignMasterTenderTypeToTenderTypSet(String Status, String TenderTypeSet,
			String TenderTypeName, String ApplyChangesDetailsNowOrFutureSetting, String strApplicationDate)
					throws Exception {

		boolean flag = false;
		Integer strRowCount;
		String strStatus = null;

		actions.keyboardEnter("TenderTypeList.ViewFullListButton");
		actions.smartWait(10);

		if (Status.equals("")) {
			// actions.setValue("TenderSet.StatusDropDown","Active/Inactive");
		} else if (!Status.equals("")) {
			switch (Status) {
			case "Active":
				actions.setValue("TenderSet.StatusDropDown", "Active");
				break;
			case "Inactive":
				actions.setValue("TenderSet.StatusDropDown", "Inactive");
				break;
			case "Active/Inactive":
				actions.setValue("TenderSet.StatusDropDown", "Active/Inactive");
				break;

			}
			actions.smartWait(10);
		}

		// Selecting Tender Set
		if (TenderTypeSet.equals("")) {
			WebElement ElementTenderTypNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name", "a");
			actions.keyboardEnter(ElementTenderTypNm);
		}

		// Switching to Manage Tender Type Set
		mcd.SwitchToWindow("#Title");
		actions.WaitForElementPresent("ManageTenderTypeSet.AddTenderTypButton", 10);
		actions.click("ManageTenderTypeSet.AddTenderTypButton");

		// Switching to Manage Tender Type
		mcd.SwitchToWindow("Manage Tender Type");

		// Covering PRC_0082- Integration Scenario:-verify that for a Tender
		// Type set only active Tender types are visible
		strRowCount = mcd.GetTableRowCount("AddTenderType.Table");
		if (strRowCount == 1) {
			strStatus = mcd.GetTableCellValue("AddTenderType.Table", 1, "Status", "", "");
		} else if (strRowCount > 1) {
			strStatus = mcd.GetTableCellValue("AddTenderType.Table", strRowCount, "Status", "", "");
		}
		if (strStatus.equals("Active")) {
			actions.reportCreatePASS("verify that for a Tender Type set only active Tender types are visible",
					"For a Tender Type set only active Tender types should visible",
					"For a Tender Type set only active Tender types are visible", "Pass");
		} else {
			actions.reportCreateFAIL("verify that for a Tender Type set only active Tender types are visible",
					"For a Tender Type set only active Tender types should visible",
					"For a Tender Type set only active Tender types are not visible", "Fail");
		}

		if (TenderTypeName.equals("")) {
			TenderTypeName = mcd.GetTableCellValue("AddTenderType.Table", 1, "Tender Type Name", "", "");
			WebElement AddTenderType = mcd.GetTableCellElement("AddTenderType.Table", 1, "Add", "");
			AddTenderType.click();
		} else if (!TenderTypeName.equals("")) {

			for (int i = 1; i <= strRowCount; i++) {
				String TenderTypeNameAll = mcd.GetTableCellValue("AddTenderType.Table", i, "Tender Type Name", "", "");
				if (TenderTypeNameAll.equals(TenderTypeName)) {
					WebElement AddTenderType = mcd.GetTableCellElement("AddTenderType.Table", i, "Add", "input");
					AddTenderType.sendKeys(Keys.SPACE);
					break;
				}
			}
		}
		actions.click("AddTenderType.ContiueButton");

		// Switching to Manage Tender Type Set
		mcd.SwitchToWindow("Manage Tender Type Set");
		actions.click("AddTenderType.ApplyButton");
		Thread.sleep(2000);
		actions.smartWait(180);

		if (!ApplyChangesDetailsNowOrFutureSetting.equals("")) {
			
			try{
				// Switching to Apply Changes Details
				mcd.SwitchToWindow("Apply Changes Details");

				if (ApplyChangesDetailsNowOrFutureSetting.equals("Now")) {
					actions.click("ApplyChangesDetails.nowRadioButton");
				} else if (ApplyChangesDetailsNowOrFutureSetting.equals("FutureDate")) {
					actions.click("ApplyChangesDetails.futureDateRadioButton");
					actions.click("ApplyChangesDetails.CalendarIcon");
					mcd.Get_future_date(2, "Close", strApplicationDate);
				}
				actions.keyboardEnter("ApplyChangesDetails.TTSSaveButton");

				// Switching to Manage Tender Type Set
				mcd.SwitchToWindow("Manage Tender Type Set");
			}catch(Exception e2){
				System.out.println("No Apply changes details window appeared");
			}
		}
		// verify on screen msg
		flag = mcd.VerifyOnscreenMessage("ManageTenderTypeSet.ErrorMsg", "Your changes have been saved.", true);

		if (flag) {
			actions.reportCreatePASS("Verify that Tender Type assigned to a Tender Type Set",
					"Tender Type should assigned to a Tender Type Set", "Tender Type is assigned to a Tender Type Set",
					"Pass");
		} else {
			actions.reportCreateFAIL("Verify that Tender Type assigned to a Tender Type Set",
					"Tender Type should assigned to a Tender Type Set",
					"Tender Type is not assigned to a Tender Type Set", "Fail");
		}
		System.out.println("TenderTypeName" + TenderTypeName);
		return TenderTypeName;
	}

	// ----------------------------------
	/*
	 * Feature Name : PRICING> Tender Type> Tender Type Set Functionality :
	 * Creating new Tender Type Set and assigning Tender Type to Tender Type Set
	 * New Script Scenario ID : Used in PRC_20095 Author : Akanksha Rani
	 */
	// -----------------------------------
	public String RFM_PRC_CreateNewTenderSet(String strNode, String strSearchBy, String TenderTypeName, String Status)
			throws Exception {

		String strNewTenderTypeSetName, PaymentType, TenderTypeNamesplit[];
		boolean flag = false, flag1 = false;

		Integer strRowCount = 0;
		Thread.sleep(2000);
		actions.keyboardEnter("TenderSet.NewTenderSetButton");

		// Switching to "Add New Tender Set"
		mcd.SwitchToWindow("Add New Tender Set");

		actions.keyboardEnter("TenderTypeSet.SelectNodeBtn");

		Thread.sleep(5000);
		mcd.SwitchToWindow("Select Node");

		actions.setValue("RFMAuditLog.SearchBy", strNode);

		switch (strSearchBy) {
		case "BeginsWith":
			actions.click("SelectNode.BeginsWithRadioButton");
			break;
		case "EndsWith":
			actions.click("SelectNode.EndsWithRadioButton");
			break;
		case "ExactMatch":
			actions.click("SelectNode.ExactMatchRadioButton");
			break;
		}

		driver.findElement(By.xpath(actions.getLocator("SelectNode.ARsearchButton"))).click();
		// actions.smartWait(8);
		actions.WaitForElementPresent("SelectNode.ARTableFirstValue", 50);
		mcd.Selectrestnode("SelectNode.Tree", strNode);
		mcd.SwitchToWindow("Add New Tender Set");

		do {

			strNewTenderTypeSetName = mcd.fn_GetRndName("ATS");
			actions.clear("NewTaxType.TaxTypeNameField");
			actions.setValue("NewTaxType.TaxTypeNameField", strNewTenderTypeSetName);
			System.out.println("NewTenderTypeSetName" + strNewTenderTypeSetName);

			actions.keyboardEnter("AddNewTenderSet.NextButton");
			// actions.smartWait(10);
			try {
				Thread.sleep(5000);
				flag = mcd.VerifyOnscreenMessage("NewScript.ResultMsg", "Tender Type Set name already exists.", true);
			} catch (Exception e) {
				System.out.println("Tender Set Name accepted successfully");

				flag = false;
			}

		} while (flag);

		mcd.SwitchToWindow("@Manage Tender Type Set");

		actions.click("ManageTenderTypeSet.AddTenderTypButton");
		// Switching to Manage Tender Type
		mcd.waitAndSwitch("Manage Tender Type");
		
		//mcd.SwitchToWindow("Manage Tender Type");
		
		strRowCount = mcd.GetTableRowCount("AddTenderType.Table");
		if (TenderTypeName.equals("")) {
			for (int i = 1; i <= strRowCount; i++) {
				PaymentType = mcd.GetTableCellValue("AddTenderType.Table", i, "Payment Type", "", "");

				if (PaymentType.equals("TENDER_NATIVE")) {
					TenderTypeName = mcd.GetTableCellValue("AddTenderType.Table", i, "Tender Type Name", "", "");
					WebElement AddTenderType = mcd.GetTableCellElement("AddTenderType.Table", i, "Add", "input");
					AddTenderType.click();
					break;
				} else {
					System.out.println(
							"Please creat new Tender Type with PaymentType TENDER_NATIVE then only test case will get pass");
				}
			}

		} else if (!TenderTypeName.equals("")) {
			TenderTypeNamesplit = TenderTypeName.split("#");
			int TenderTypeNamesplitln = TenderTypeNamesplit.length;

			for (int j = 0; j <= TenderTypeNamesplitln - 1; j++) {
			/*	for (int i = 1; i <= strRowCount; i++) {
					String TenderTypeNameAll = mcd.GetTableCellValue("AddTenderType.Table", i, "Tender Type Name", "",
							"");
					if (TenderTypeNameAll.equals(TenderTypeNamesplit[j])) {
						WebElement AddTenderType = mcd.GetTableCellElement("AddTenderType.Table", i, "Add", "");
						AddTenderType.click();
						break;
					}
				}*/
				for (int i = 0; i <= strRowCount-1; i++) {
					String TenderTypeNameAll=driver.findElement(By.xpath("//*[@id='tenderNameLabel"+i+"']/pre")).getText();					
					if (TenderTypeNameAll.equals(TenderTypeNamesplit[j])) {						
						WebElement AddTenderType = mcd.GetTableCellElement("AddTenderType.Table", i+1, "Add", "input");
						AddTenderType.click();
						break;
					}
				}
			}
		}

		actions.click("AddTenderType.ContiueButton");

		driver.switchTo().window("");
		try {
			flag1 = mcd.VerifyAlertMessageDisplayed("Warning Message",
					"Tender ID must be unique in the tender type set.", true, AlertPopupButton.OK_BUTTON);
			actions.reportCreatePASS(
					"Verify Tender ID must be unique in the tender type set errror message is displaying.",
					"Tender ID must be unique in the tender type set errror message should displaying.",
					"Tender ID must be unique in the tender type set errror message is displaying.", "Pass");
		} catch (Exception e) {
			System.out.println("Tender Set Name accepted successfully");

			flag1 = false;
		}

		// Switching to Manage Tender Type Set
		// mcd.SwitchToWindow("Manage Tender Type Set");
		mcd.SwitchToWindow("@Manage Tender Type Set");

		switch (Status) {
		case "Active":
			actions.setValue("TenderTypeSet.Status", "Active");
			break;
		case "Inactive":
			actions.setValue("TenderTypeSet.Status", "Inactive");
			break;
		}
		if (flag1 == true) {
			System.out.println("Tender Set Name accepted successfully");
		} else {
			// actions.click("Tender ID must be unique in the tender type set");
			actions.keyboardEnter("AddTenderType.ApplyButton");
			// actions.smartWait(10);
		}

		try {
			flag = mcd.VerifyAlertMessageDisplayed("Warning Message",
					"At least one Active Native Tender Type should exist in the Tender Type Set.", true,
					AlertPopupButton.OK_BUTTON);
		} catch (Exception e) {
			System.out.println("Tender Set Name accepted successfully");

			flag = false;
		}

		if (flag == true) {
			// actions.smartWait(10);
			Thread.sleep(5000);
			actions.reportCreatePASS(
					"Verify At least one Active Native Tender Type should exist in the Tender Type Set. is displaying.",
					"At least one Active Native Tender Type should exist in the Tender Type Set. should display",
					"At least one Active Native Tender Type should exist in the Tender Type Set. is displaying",
					"Pass");
		} else if (flag == false && flag1 == false) {
			Thread.sleep(4000);
			actions.smartWait(180);
//			flag = mcd.VerifyOnscreenMessage("UpdateTaxType.SvMessage", "Your changes have been saved.", true);
			actions.verifyTextPresence("Your changes have been saved.", true);
			// flag =
			// mcd.VerifyOnscreenMessage("ManageTenderTypeSet.ErrorMsg","Your
			// changes have been saved.", true);
		}

		return strNewTenderTypeSetName;

	}

	// ----------------------------------
	/*
	 * Feature Name : PRICING> Tender Type> Tender Type Set Functionality :
	 * Creating new Coupon Type Set and assigning Tender Type of payment type
	 * "TENDER_GIFT_COUPON" to Coupon Type Set New Script Scenario ID : Used in
	 * PRC_20100 Author : Akanksha Rani
	 */
	// -----------------------------------
	public String RFM_PRC_CreateNewCouponSet(String strNode, String strSearchBy, String TenderTypeName, String Status)
			throws Exception {

		String strNewCouponSetName, PaymentType, TenderTypeNamesplit[];
		boolean flag = false, flag1 = false;

		Integer strRowCount = 0;

		actions.keyboardEnter("CouponSet.NewCouponSetButton");

		// Switching to "Add New Tender Set"
		mcd.waitAndSwitch("Add New Coupon Set");

		actions.keyboardEnter("AddCouponSet.SelectNodeButton");

		Thread.sleep(5000);
		// actions.smartWait(10);
		mcd.SwitchToWindow("Select Node");

		actions.setValue("SelectNode.SearchTextTreeTextBox", strNode);

		switch (strSearchBy) {
		case "BeginsWith":
			actions.click("SelectNode.BeginsWithRadioButton");
			break;
		case "EndsWith":
			actions.click("SelectNode.EndsWithRadioButton");
			break;
		case "ExactMatch":
			actions.click("SelectNode.ExactMatchRadioButton");
			break;
		}

		driver.findElement(By.xpath(actions.getLocator("RFMAuditLog.SearchRestaurant"))).click();
		actions.WaitForElementPresent("SelectNode.ARTableFirstValue", 5);
		// actions.click("SelectNode.searchButton");
		mcd.Selectrestnode("SelectNode.Tree", strNode);
		mcd.SwitchToWindow("Add New Coupon Set");

		do {

			strNewCouponSetName = mcd.fn_GetRndName("ACS");
			actions.clear("NewTaxType.TaxTypeNameField");
			actions.setValue("NewTaxType.TaxTypeNameField", strNewCouponSetName);
			System.out.println("NewCouponSetName" + strNewCouponSetName);

			actions.keyboardEnter("AddNewTenderSet.NextButton");
			// actions.smartWait(10);
			try {
				Thread.sleep(3000);
				flag = mcd.VerifyOnscreenMessage("NewScript.ResultMsg", "Coupon Set name already exists.", true);
			} catch (Exception e) {
				System.out.println("Coupon Set Name accepted successfully");
				flag = false;
			}

		} while (flag);

		mcd.SwitchToWindow("@Manage Coupon Set");

		actions.click("ManageTenderTypeSet.AddTenderTypButton");

		// Switching to Manage Tender Type
		mcd.SwitchToWindow("Manage Tender Type");
		// strRowCount=mcd.GetTableColumnCount("AddTenderType.Table");
		strRowCount = mcd.GetTableRowCount("AddTenderType.Table");
		if (TenderTypeName.equals("")) {
			TenderTypeName = mcd.GetTableCellValue("AddTenderType.Table", 1, "Coupon", "", "");
			WebElement AddTenderType = mcd.GetTableCellElement("AddTenderType.Table", 1, "Add", "");
			AddTenderType.click();

		} else if (!TenderTypeName.equals("")) {
			TenderTypeNamesplit = TenderTypeName.split("#");
			int TenderTypeNamesplitln = TenderTypeNamesplit.length;

			for (int j = 0; j <= TenderTypeNamesplitln - 1; j++) {
				for (int i = 1; i <= strRowCount; i++) {
					String TenderTypeNameAll = mcd.GetTableCellValue("AddTenderType.Table", i, "Coupon", "", "");
					if (TenderTypeNameAll.equals(TenderTypeNamesplit[j])) {
						WebElement AddTenderType = mcd.GetTableCellElement("AddTenderType.Table", i, "Add", "input");
						AddTenderType.sendKeys(Keys.SPACE);
						break;
					}
				}
			}
		}

		actions.click("AddTenderType.ContiueButton");

		driver.switchTo().window("");
		try {
			flag1 = mcd.VerifyAlertMessageDisplayed("Warning Message", "Tender ID must be unique in the coupon set.",
					true, AlertPopupButton.OK_BUTTON);

		} catch (Exception e) {
			System.out.println("Tender Set Name accepted successfully");

			flag1 = false;
		}

		// Switching to Manage Tender Type Set
		mcd.SwitchToWindow("@Manage Coupon Set");

		switch (Status) {
		case "Active":
			actions.setValue("ManageCouponSet.StatusDropdown", "Active");
			break;
		case "Inactive":
			actions.setValue("ManageCouponSet.StatusDropdown", "Inactive");
			break;
		}

		if (flag1 == true) {
			actions.smartWait(10);
			actions.reportCreatePASS(
					"Verify Tender ID must be unique in the tender type set errror message is displaying.",
					"Tender ID must be unique in the tender type set errror message should displaying.",
					"Tender ID must be unique in the tender type set errror message is displaying.", "Pass");
		} else if (flag1 == false) {
			actions.keyboardEnter("AddTenderType.ApplyButton");
			Thread.sleep(2000);
			actions.smartWait(100);
			flag = mcd.VerifyOnscreenMessage("UpdateTaxType.SvMessage", "Your changes have been saved.", true);
		}

		return strNewCouponSetName;

	}

	// ----------------------------------
	/*
	 * Feature Name : PRICING> Tender Type> Tender Type Set Functionality :
	 * Creating new Tender Type Set copying existing Tender Type New Script
	 * Scenario ID : Used in PRC_20294 Author : Akanksha Rani
	 */
	// -----------------------------------
	public String RFM_PRC_CreateNewTenderSetCopyingExisting(String strNode, String strSearchBy, String TenderTypeName,
			String Status) throws Exception {

		String strNewTenderTypeSetName, PaymentType, TenderTypeNamesplit[], NewTenderSet1 = null;
		boolean flag = false, flag1 = false;

		Integer strRowCount = 0;

		// creating new tax type to use as existing Tax Type
		NewTenderSet1 = RFM_PRC_CreateNewTenderSet(strNode, strSearchBy, TenderTypeName, Status);
		actions.keyboardEnter("UpdateTaxType.CancelButton");
		mcd.SwitchToWindow("#Title");

		actions.keyboardEnter("TenderSet.NewTenderSetButton");

		// Switching to "Add New Tender Set"
		mcd.SwitchToWindow("Add New Tender Set");

		actions.keyboardEnter("TenderTypeSet.SelectNodeBtn");

		// actions.smartWait(10);
		mcd.SwitchToWindow("Select Node");

		actions.setValue("RFMAuditLog.SearchBy", strNode);

		switch (strSearchBy) {
		case "BeginsWith":
			actions.click("SelectNode.BeginsWithRadioButton");
			break;
		case "EndsWith":
			actions.click("SelectNode.EndsWithRadioButton");
			break;
		case "ExactMatch":
			actions.click("SelectNode.ExactMatchRadioButton");
			break;
		}

		driver.findElement(By.xpath(actions.getLocator("SelectNode.ARsearchButton"))).click();
		actions.WaitForElementPresent("SelectNode.ARTableFirstValue", 5);
		mcd.Selectrestnode("SelectNode.Tree", strNode);
		mcd.SwitchToWindow("Add New Tender Set");

		// Selecting Copy Settings From Existing Tax Type
		actions.click("NewTaxType.YesRadioButton");
		actions.keyboardEnter("AddNewTenderSet.SelectCopyExistingButton");

		mcd.SwitchToWindow("tenderTypeSet.title.copyTenderTypeSet");
		actions.setValue("TenderSet.SearchTextBox", NewTenderSet1);
		actions.keyboardEnter("TenderTypeList.SearchButton");
		actions.smartWait(20);

		WebElement ElementTenderNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name", "a");
		ElementTenderNm.click();

		mcd.SwitchToWindow("Add New Tender Set");
		do {

			strNewTenderTypeSetName = mcd.fn_GetRndName("ATS");
			actions.clear("NewTaxType.TaxTypeNameField");
			actions.setValue("NewTaxType.TaxTypeNameField", strNewTenderTypeSetName);
			System.out.println("NewTaxTypeName" + strNewTenderTypeSetName);

			actions.keyboardEnter("AddNewTenderSet.NextButton");
			//actions.smartWait(10);
			try {
				//Explict wait condition
				try{
					new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(actions.getLocator("NewScript.ResultMsg"))));
				}catch(WebDriverException e){
					
				}				
				flag = mcd.VerifyOnscreenMessage("NewScript.ResultMsg", "Tender Type Set name already exists.", true);
			} catch (Exception e) {
				System.out.println("Tender Set Name accepted successfully");

				flag = false;
			}

		} while (flag);

		mcd.SwitchToWindow("Manage Tender Type Set");

		switch (Status) {
		case "Active":
			actions.setValue("TenderTypeSet.Status", "Active");
			break;
		case "Inactive":
			actions.setValue("TenderTypeSet.Status", "Inactive");
			break;
		}
		actions.keyboardEnter("AddTenderType.ApplyButton");
		Thread.sleep(2000);
		actions.smartWait(10);
		try {
			mcd.VerifyOnscreenMessage("UpdateTaxType.SvMessage", "Your changes have been saved.", true);
			actions.reportCreatePASS("Verify Tender Set Name created successfully",
					"Tender Set Name should created successfully", "Tender Set Name is created successfully", "Pass");
		} catch (Exception e) {
			actions.reportCreateFAIL("Verify Tender Set Name created successfully",
					"Tender Set Name should created successfully", "Tender Set Name is not created successfully",
					"Fail");
		}
		return strNewTenderTypeSetName;
	}

	// ---------------------------------------
	/*
	 * Feature Name : PRICING> Tender Type> Tender Type Set Functionality :
	 * Applying Future Setting to existing Tender Type Set New Script Scenario
	 * ID : Used in PRC_20299 Author : Akanksha Rani
	 */
	// ------------------------------------------------------
	public String RFM_PRC_TenderTypeSetFutureSettings(String TenderTypeSetName, String TenderTypeName,
			String TenderSetStatus, String strApplicationDate) throws Exception {
		String strDataSplit[], TenderFlagSplit[], FutureSettings, PaymentType, TenderTypeNamesplit[];
		Integer strDataSplitln, TenderFlagSplitln, strRowCount;
		boolean flag;

		try {
			actions.keyboardEnter("TenderTypeList.ViewFullListButton");
			actions.smartWait(10);
			actions.setValue("TenderSet.StatusDropDown", "Active");
			actions.smartWait(10);

			if (!TenderTypeSetName.equals("")) {
				actions.clear("TenderSet.SearchTextBox");
				actions.setValue("TenderSet.SearchTextBox", TenderTypeSetName);
				actions.keyboardEnter("TenderTypeList.SearchButton");
				actions.smartWait(20);
				// Retrieving first value of table

				WebElement ElementTenderTypNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", 1, "Name",
						"a");
				ElementTenderTypNm.click();
			} else if (TenderTypeSetName.equals("")) {
				// Checking whether Future Settings is already present
				int rowcount = mcd.GetTableRowCount("ScriptManagement.TableNameValue");
				for (int i = 1; i < rowcount; i++) {
					FutureSettings = mcd.GetTableCellValue("ScriptManagement.TableNameValue", i, "Future Settings", "",
							"");
					if (FutureSettings.equals("")) {
						// Retrieving Tender Type Name of table
						TenderTypeSetName = mcd.GetTableCellValue("ScriptManagement.TableNameValue", i, "Name", "", "");
						WebElement ElementTenderTypNm = mcd.GetTableCellElement("ScriptManagement.TableNameValue", i,
								"Name", "a");
						actions.keyboardEnter(ElementTenderTypNm);
						// ElementTenderTypNm.click();
						break;
					}
				}

			} // Switching to manage Tender type set
			mcd.SwitchToWindow("#Title");

			switch (TenderSetStatus) {
			case "Active":
				actions.setValue("TenderTypeSet.Status", "Active");
				break;
			case "Inactive":
				actions.setValue("TenderTypeSet.Status", "Inactive");
				break;
			}

			actions.click("ManageTenderTypeSet.AddTenderTypButton");

			// Switching to Manage Tender Type
			mcd.SwitchToWindow("Manage Tender Type");
			strRowCount = mcd.GetTableRowCount("AddTenderType.Table");
			if (TenderTypeName.equals("")) {
				for (int i = 1; i <= strRowCount; i++) {
					PaymentType = mcd.GetTableCellValue("AddTenderType.Table", i, "Payment Type", "", "");

					if (!PaymentType.equals("TENDER_NATIVE")) {
						TenderTypeName = mcd.GetTableCellValue("AddTenderType.Table", i, "Tender Type Name", "", "");
						WebElement AddTenderType = mcd.GetTableCellElement("AddTenderType.Table", i, "Add", "");
						AddTenderType.click();
						break;
					} else {
						System.out.println(
								"Please creat new Tender Type with PaymentType other than TENDER_NATIVE then only test case will get pass");
					}
				}

			} else if (!TenderTypeName.equals("")) {
				TenderTypeNamesplit = TenderTypeName.split("#");
				int TenderTypeNamesplitln = TenderTypeNamesplit.length;

				for (int j = 0; j <= TenderTypeNamesplitln - 1; j++) {
					for (int i = 1; i <= strRowCount; i++) {
						String TenderTypeNameAll = mcd.GetTableCellValue("AddTenderType.Table", i, "Tender Type Name",
								"", "");
						if (TenderTypeNameAll.equals(TenderTypeNamesplit[j])) {
							WebElement AddTenderType = mcd.GetTableCellElement("AddTenderType.Table", i, "Add", "");
							AddTenderType.click();
							break;
						}
					}
				}
			}
			actions.click("AddTenderType.ContiueButton");
			mcd.SwitchToWindow("Manage Tender Type Set");
			actions.click("AddTenderType.ApplyButton");

			mcd.SwitchToWindow("Apply Changes Details");
			actions.click("ApplyChangesDetails.futureDateRadioButton");
			actions.click("ApplyChangesDetails.CalendarIcon");
			mcd.Get_future_date(1, "Close", strApplicationDate);
			actions.keyboardEnter("ApplyChangesDetails.TTSSaveButton");
			// actions.smartWait(10);
			mcd.SwitchToWindow("Manage Tender Type Set");
			// flag = mcd.VerifyOnscreenMessage("ManageTenderTypeSet.ErrorMsg",
			// "Your changes have been saved.", true);
			flag = mcd.VerifyOnscreenMessage("UpdateTaxType.SvMessage", "Your changes have been saved.", true);
			if (flag) {
				actions.reportCreatePASS("Verify Future Date applied on Tender Type" + TenderTypeSetName,
						"Future Date should applied on Tender Type" + TenderTypeSetName,
						"Future Date applied on Tender Type" + TenderTypeSetName, "Pass");
			} else {
				actions.reportCreateFAIL("Verify Future Date applied on Tender Type" + TenderTypeSetName,
						"Future Date should applied on Tender Type" + TenderTypeSetName,
						"Future Date not applied on Tender Type" + TenderTypeSetName, "Fail");
			}

			actions.keyboardEnter("UpdateTaxType.CancelButton");
			actions.smartWait(10);
			mcd.SwitchToWindow("#Title");

		} catch (Exception e) {
			System.out.println("Future Setting already applied to TenderTypeNameSet Values");
		}
		System.out.println("TenderTypeName" + TenderTypeSetName);
		return TenderTypeSetName;
	}

	// ----------------------------------
	/*
	 * Feature Name : PRICING> Taxes>Menu Item Tax Set Functionality : Creating
	 * new Menu Item Tax Set and assigning Menu Item to Menu Item Tax Set New
	 * Script Scenario ID : Used in PRC_20269 Author : Akanksha Rani
	 */
	// -----------------------------------

	public String RFM_PRC_CreateNewMenuIteamTaxSet(String strNode, String strSearchBy, String MenuIteamSearchBy,
			String Data, String TaxCode, String TaxRule, String TaxEntry, String Status, String ErroMsg)
					throws Exception {

		String strNewMenuIteamTaxSetName, Datasplit[], ErroMsgSplit[];
		boolean flag = false;
		Datasplit = Data.split("#");
		ErroMsgSplit = ErroMsg.split("#");

		actions.keyboardEnter("MenuItemTaxSet.NewMenuItemTaxSetButton");

		// Switching to "Add New Menu Item Tax Set"
		mcd.SwitchToWindow("Add New Menu Item Tax Set");

		actions.keyboardEnter("AddNewMenuItemTaxSet.SelectButton");

		Thread.sleep(5000);
		// actions.smartWait(10);
		mcd.SwitchToWindow("Select Node");

		if (strSearchBy.equals("RestaurantNumber")) {
			// actions.click("SelectNode.RestaurantNumberRadioButton");
		} else if (strSearchBy.equals("Hierarchies")) {
			actions.click("SelectNode.HierarchiesRadioButton");
		}
		actions.setValue("SelectNode.SearchTextTreeTextBox", strNode);
		actions.click("SelectNode.ExactMatchRadioButton");

		// Clicking on Search button
		driver.findElement(By.xpath(actions.getLocator("RFMAuditLog.SearchRestaurant"))).click();
		// actions.smartWait(15);
		actions.WaitForElementPresent("SelectNode.ARTableFirstValue", 5);
//		mcd.Selectrestnode("SelectNode.MITSTree", strNode);
		if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {			
			mcd.Selectrestnode_JavaScriptClk("SelectNode.CPTable", strNode);
		} else {
			mcd.Selectrestnode("SelectNode.MITSTree", strNode);

		}
		mcd.SwitchToWindow("Add New Menu Item Tax Set");

		do {

			strNewMenuIteamTaxSetName = mcd.fn_GetRndName("AMITS");
			actions.clear("NewTaxType.TaxTypeNameField");
			actions.setValue("NewTaxType.TaxTypeNameField", strNewMenuIteamTaxSetName);
			System.out.println("strNewMenuIteamTaxSetName" + strNewMenuIteamTaxSetName);

			actions.keyboardEnter("AddNewTenderSet.NextButton");
			// actions.smartWait(15);
			try {
				Thread.sleep(4000);
				flag = mcd.VerifyOnscreenMessage("NewScript.ResultMsg", ErroMsgSplit[0], true);
			} catch (Exception e) {
				System.out.println("Menu Item Tax Set Name accepted successfully");

				flag = false;
			}

		} while (flag);

		mcd.SwitchToWindow("@Menu Item Tax Set : Common Menu Item Selector");
		Thread.sleep(2000);
		switch (MenuIteamSearchBy) {
		case "Search":
			actions.setValue("MenuItemTaxSet.SearchTextbox", Datasplit[0]);
			actions.click("SelectNode.ExactMatchRadioButton");
			actions.click("TaxType.SearchButton");
			break;
		case "ViewFullList":
			actions.click("TaxType.ViewFullListButton");
			break;
		default:
			actions.click("TaxType.ViewFullListButton");
			break;
		}

		actions.smartWait(100);
//		WebElement ElementMenuIteamNm = mcd.GetTableCellElement("AddTenderType.Table", 1, "Add", "checkbox");
		WebElement ElementMenuIteamNm = mcd.GetTableCellElement("AddTenderType.Table", 1, "Add", "input[1]");
		ElementMenuIteamNm.click();
		actions.click("AddTaxType.SaveButton");
		actions.smartWait(100);

		// Switching to Manage Menu Item Tax Set
		mcd.SwitchToWindow("#Title");

		switch (TaxCode) {
		case "Always":
			actions.setValue("ManageMenuItemTaxSet.TaxCodeDropDown", "Always");
			break;
		case "Never":
			actions.setValue("ManageMenuItemTaxSet.TaxCodeDropDown", "Never");
			break;
		case "Optional":
			actions.setValue("ManageMenuItemTaxSet.TaxCodeDropDown", "Optional");
			break;
		default:
			actions.setValue("ManageMenuItemTaxSet.TaxCodeDropDown", "Never");
		}

		switch (Status) {
		case "Active":
			actions.setValue("ManageMenuItemTaxSet.StatusDropDown", "Active");
			break;
		case "Inactive":
			actions.setValue("ManageMenuItemTaxSet.StatusDropDown", "Inactive");
			break;
		}

		actions.keyboardEnter("ManageMenuItemTaxSet.ApplyButton");
		actions.smartWait(10);
		flag = mcd.VerifyOnscreenMessage("UpdateTaxType.SvMessage", ErroMsgSplit[2], true);

		if (flag) {
			actions.reportCreatePASS("Verify Your changes have been saved. message is displaying",
					"Your changes have been saved. message should display",
					"Your changes have been saved. message is displaying", "Pass");
		} else {
			actions.reportCreateFAIL("Verify Your changes have been saved. message is displaying",
					"Your changes have been saved. message should display",
					"Your changes have been saved. message is not displaying", "Fail");
		}
		System.out.println("strNewMenuIteamTaxSetName" + strNewMenuIteamTaxSetName);
		return strNewMenuIteamTaxSetName;
	}

	// ----------------------------------
	/*
	 * Feature Name : PRICING> Taxes> Tax Type Functionality : Create Tax Type
	 * New Script Scenario ID : Used in PRC_20036 Author : Akanksha Rani
	 */
	// -----------------------------------

	public String RFM_PRC_CreateNewTaxType(String strNode, String strSearchBy, String AddTaxTypeValue,
			String strResultMsg) throws Exception {
		// Click on New Script Button
		boolean flag = false;
		String[] strErrMsg = strResultMsg.split("#");
		String[] strAddTaxTypeValue = AddTaxTypeValue.split("#");
		String strNewTaxName;
		Integer strRangId;

		// actions.smartWait(20);
		Thread.sleep(3000);
		actions.WaitForElementPresent("TaxType.NewTaxTypeButton", 180);
		driver.findElement(By.xpath(actions.getLocator("TaxType.NewTaxTypeButton"))).click();
		// actions.keyboardEnter("TaxType.NewTaxTypeButton");
		mcd.SwitchToWindow("Add New Tax Type");
		actions.keyboardEnter("NewTaxType.SelectButton");

		// Select Node window is taking time to load hence giving hard wait
		Thread.sleep(3000);
		mcd.waitAndSwitch("Select Node");

		if (strSearchBy.equals("Restaurant Number")) {
			actions.click("SelectNode.RestaurantNumberRadioButton");
		} else if (strSearchBy.equals("Hierarchies")) {
			actions.click("SelectNode.HierarchiesRadioButton");

		}
		actions.setValue("SelectNode.SearchTextTreeTextBox", strNode);
		actions.click("SelectNode.ExactMatchRadioButton");
		driver.findElement(By.xpath(actions.getLocator("SelectNode.ARsearchButton"))).click();
		// actions.click("SelectNode.searchButton");
		actions.WaitForElementPresent("SelectNode.ARTableFirstValue", 180);
		//mcd.Selectrestnode("SelectNode.Tree", strNode);
		mcd.Selectrestnode_JavaScriptClk("SelectNode.Tree", strNode);		
		mcd.SwitchToWindow("Add New Tax Type");

		do {

			strNewTaxName = mcd.fn_GetRndName("Auto_NT");
			actions.clear("NewTaxType.TaxTypeNameField");
			actions.setValue("NewTaxType.TaxTypeNameField", strNewTaxName);
			System.out.println("NewTaxTypeName" + strNewTaxName);

			actions.keyboardEnter("NewTaxType.NextButton");
			// actions.smartWait(10);
			try {
				Thread.sleep(3000);
				flag = mcd.VerifyOnscreenMessage("NewScript.ResultMsg", strErrMsg[0], true);
			} catch (Exception e) {
				System.out.println("Tax Name accepted successfully");

				flag = false;
			}

		} while (flag);
		if (flag == false) {
			// actions.smartWait(10);
			driver.switchTo().window("");
			mcd.SwitchToWindow("@Add Tax Type");

			actions.setValue("AddTaxType.TaxRateIdTextbox", strAddTaxTypeValue[0]);
			actions.setValue("AddTaxType.TaxBasisIdDropdown", strAddTaxTypeValue[1]);
			actions.setValue("AddTaxType.TaxCalDropdown", strAddTaxTypeValue[2]);
			actions.setValue("AddTaxType.TaxRoundingDropdown", strAddTaxTypeValue[3]);
			actions.setValue("AddTaxType.TaxPrecisionDropdown", strAddTaxTypeValue[4]);
			try {
				if (!strAddTaxTypeValue[5].equals("")) {
					String statusId = strAddTaxTypeValue[5];
					switch (statusId) {
					case "Active":
						actions.setValue("AddTaxType.StatusIdDropdown", statusId);
						break;
					case "Inactive":
						actions.setValue("AddTaxType.StatusIdDropdown", statusId);
						break;
					case "Suspended":
						actions.setValue("AddTaxType.StatusIdDropdown", statusId);
						break;
					}
				}

			} catch (Exception err) {
				System.out.println("By Default your status will be Inactive");
			}
			do {
				strRangId = mcd.fn_GetRndNumInRange(1, 99999999);
				System.out.println("strRangId" + strRangId);
				actions.clear("AddTaxType.TaxTypeCodeTextbox");
				actions.setValue("AddTaxType.TaxTypeCodeTextbox", strRangId);
				System.out.println("AddTaxType.TaxTypeCodeTextbox" + strRangId);

				actions.keyboardEnter("AddTaxType.SaveButton");
				actions.smartWait(180);
				try {
					flag = mcd.VerifyOnscreenMessage("NewScript.ResultMsg", strErrMsg[1], true);
				} catch (Exception e) {
					System.out.println("Tax Type accepted successfully");
					// actions.keyboardEnter("AddTaxType.SaveButton");
					flag = false;
				}

				if (flag) {
					System.out.println("Tax Type already exists, trying another random name");
					System.out.println(flag);
				} else {
					try {
						System.out.println(flag);
						mcd.SwitchToWindow("#Title");

						actions.verifyTextPresence(strErrMsg[2], false);
						actions.keyboardEnter("AddTaxType.CancelButton");

						// Switching to Tax Type
						// actions.smartWait(10);
						mcd.SwitchToWindow("#Title");
						actions.reportCreatePASS("Verify Create New Tax Type", "New Tax Type should be created",
								"New Tax Type " + strNewTaxName + " is created", "PASS");

					} catch (Exception err) {
						actions.reportCreateFAIL("Verify Create New Tax Type", "New Tax Type should be created",
								"New Tax Type creation failed", "FAIL");
					}

				}

			} while (flag);
		}
		return strNewTaxName;
	}

	// ----------------------------------
	/*
	 * Feature Name : PRICING> Taxes> Script Management Functionality : Create
	 * New Script New Script Scenario ID : Used in PRC_20023 Author : Akanksha
	 * Rani
	 */
	// -----------------------------------
	public String RFM_PRC_CreateNewScript(String strNode, String strCountryAndSearchByifNeeded, String strState,
			String strResultMsg) throws Exception {
		// Click on New Script Button
		boolean flag = false;
		Integer strCountrylen;
		String strNewScriptSetName;

		String[] strErrMsg = strResultMsg.split("#");
		String[] strCountry = strCountryAndSearchByifNeeded.split("#");
		strCountrylen = strCountry.length;

		actions.click("ScriptManagement.NewScriptButton");
		mcd.SwitchToWindow("New Script");
		actions.click("NewScript.SelectButton");
		actions.clickAndVerify("NewScript.SelectButton", "");
		// actions.smartWait(5);
		mcd.SwitchToWindow("Select Node");

		if (strCountrylen == 1) {
			actions.click("SelectNode.RestaurantNumberRadioButton");

		} else if (strCountrylen > 1 && strCountry[1].equals("Hierarchies")) {
			actions.click("SelectNode.HierarchiesRadioButton");
		}
		actions.setValue("SelectNode.SearchTextTreeTextBox", strNode);
		actions.click("SelectNode.ExactMatchRadioButton");
		driver.findElement(By.xpath(actions.getLocator("SelectNode.ARsearchButton"))).click();
		actions.WaitForElementPresent("SelectNode.ARTableFirstValue");
		// actions.click("SelectNode.searchButton");
		mcd.Selectrestnode("SelectNode.Tree", strNode);
		mcd.SwitchToWindow("New Script");
		actions.setValue("NewScript.CountryTextBox", strCountry[0]);
		actions.WaitForElementPresent("NewScript.StateDropdown", 100);
		actions.setValue("NewScript.StateDropdown", strState);

		do {

			strNewScriptSetName = mcd.fn_GetRndName("Auto_NS");
			actions.clear("NewScript.NameTextBox");
			actions.setValue("NewScript.NameTextBox", strNewScriptSetName);
			System.out.println("NewScriptSetName" + strNewScriptSetName);
			actions.clear("NewScript.ScriptNameTextBox");
			actions.setValue("NewScript.ScriptNameTextBox", strNewScriptSetName);

			actions.keyboardEnter("NewScript.SaveButton");
			Thread.sleep(7000);
			//actions.smartWait(10);
			try {
				flag = mcd.VerifyOnscreenMessage("NewScript.ResultMsg", strErrMsg[0], true);
			} catch (Exception e) {
				System.out.println("Name and Script Name accepted successfully");
				flag = false;
			}

			if (flag) {
				System.out.println("Name already exists, trying another random name");
				System.out.println(flag);
			} else {
				try {
					System.out.println(flag);
					mcd.SwitchToWindow("Script Management");

					actions.verifyTextPresence(strErrMsg[1], false);

					actions.reportCreatePASS("Verify Create New script", "New script should be created",
							"New script " + strNewScriptSetName + " is created", "PASS");

				} catch (Exception err) {
					actions.reportCreateFAIL("Verify Create New script", "New script should be created",
							"New script creation failed", "FAIL");
				}

			}

		} while (flag);
		return strNewScriptSetName;
	}

	/// ===

	public String priceset_addRemoveMI(String StrMIStatus, String strmsg) {

		String StrMI_name = null;

		try {

			// clicking on the add remove button
			actions.WaitForElementPresent("ManagePS.AddRemoveMIBtn", 20);

			// Clicking on the add remove button
			actions.click("ManagePS.AddRemoveMIBtn");

			// swtiching to new window
			mcd.SwitchToWindow(" Price Sets : Common Menu Item Selector");

			// selecting the view full list
			actions.click("RFM.ViewFullListBtn");

			// waiting for the page to load
			actions.smartWait(25);

			// setting the available in the search list
			actions.setValue("AddRemoveMenu.Availability", StrMIStatus);

			// waiting for the page to load
			actions.smartWait(25);

			// getting the webElement from the table
			String Item_name = null;
			try {
				// getting the element name
				Item_name = mcd.GetTableCellValue("PriceSetList.PSTable", 1, "Name", "", "");

				// getting the check box webelement and selecting it
				WebElement AddCheck_box = mcd.GetTableCellElement("PriceSetList.PSTable", 1, "Add", "input");
				AddCheck_box.sendKeys(Keys.SPACE);

				actions.reportCreatePASS("Verify selecting the Available menu Item",
						"Should select the available menu Item", "Selected menu item '" + Item_name + "successfuly",
						"Pass");
			} catch (Exception e) {

				actions.reportCreateFAIL("Verify selecting the Available menu Item",
						"Should select the available menu Item", "Not able to selected menu item", "Fail");
			}

			// clicking on the save button now
			actions.click("CommonSelector.Save");
			driver.switchTo().window("");

			// switching back to parent window
			mcd.SwitchToWindow("@Price Sets");

			// waiting for the page to load
			actions.smartWait(30);

			// verifying the success message
			actions.verifyTextPresence(strmsg, true);

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return StrMI_name;
	}

	// ================
	// =============
	public boolean Pricesetadd_MI(String validationmsg, int num_menuitem) {

		boolean strresult = false;
		try {

			// selecting the view full list
			actions.click("RFM.ViewFullListBtn");

			// waiting for the page to load
			actions.smartWait(125);

			// setting the available in the search list
			actions.setValue("AddRemoveMenu.Availability", "Available");

			// waiting for the page to load
			actions.smartWait(125);

			// getting the webElement from the table
			String Item_name = null;
			try {

				for (int i = 1; i <= num_menuitem; i++) {
					// getting the element name
					Item_name = mcd.GetTableCellValue("PriceSetList.PSTable", i, "Name", "", "");

					// getting the check box webelement and selecting it
					WebElement AddCheck_box = mcd.GetTableCellElement("PriceSetList.PSTable", i, "Add", "input");
					AddCheck_box.sendKeys(Keys.SPACE);

					actions.reportCreatePASS("Verify selecting the Available menu Item",
							"Should select the available menu Item", "Selected menu item '" + Item_name + "successfuly",
							"Pass");
				}
			} catch (Exception e) {

				actions.reportCreateFAIL("Verify selecting the Available menu Item",
						"Should select the available menu Item", "Not able to selected menu item", "Fail");
			}

			// clicking on the save button now
			actions.click("CommonSelector.Save");

			// waiting for the page to load
			actions.smartWait(120);

			// verifying the success message
			actions.verifyTextPresence(validationmsg, true);

			strresult = true;

		} catch (Exception e) {

			System.out.println(e.getMessage());
			strresult = false;

		}
		return strresult;
	}

	/*
	 * Feature Name : Price Sets Functionality : Create New Promotional/Base
	 * Price Set by copying settings from an existing price set Decimal
	 * validations on the All Price/Eating/Take-out/Other prices - checked
	 * Scenario ID : PRC_0107/ 108 Author : Santosh S Tangudu Here a parameter
	 * PriceSetName is provided to create a price set with the same name
	 */
	// -----------------------------------

	public String RFM_PRC_CreatePrcSetWOCpy(String strPrcSetType, String strResMessage, String strTestPrc,
			String strNodeNum, String strApplicationDate, String strMIAddMsg, String strStatus, String PriceSetName)
					throws Exception {
		String[] InfoMsg = strMIAddMsg.split("#");
		String strNamePrefix = "";
		boolean blnflag = true;
		actions.click("PriceSet.NewBtn");
		Thread.sleep(2000);

		// Switch to New Price Sets
		mcd.SwitchToWindow("New Price Sets");

		// Generate unique strNewPrcSet for Base/Promotion Price Set

		switch (strPrcSetType) {
		case "Base":
			// Base Price
			strNamePrefix = "AutoBPS";
			break;
		case "Promotion":
			strNamePrefix = "AutoPPS";
			break;
		default:
			// System.out.println("Please enter correct Price Set Type
			// (Base/Promotion)");
			actions.reportCreateFAIL("Verfiy data", "Enter correct price set name", "Incorrect data", "FAIL");
			break;
		}

		// Enter unique Price Set Name
		String strNewPrcSet = null;

		strNewPrcSet = mcd.fn_GetRndName(strNamePrefix);
		strNewPrcSet = strNewPrcSet.subSequence(0, 10).toString();

		// Enter new price set name :

		actions.click("NewPriceSet.SelectNode");
		Thread.sleep(1000);

		// Switch to Select Node Window - Title - Select Node
		mcd.SwitchToWindow("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(500);
		actions.setValue("SelectNode.SearchBox", strNodeNum);
		Thread.sleep(500);

		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

		mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);
		Thread.sleep(1000);

		mcd.SwitchToWindow("New Price Sets");

		do {
			strNewPrcSet = mcd.fn_GetRndName(strNamePrefix);
			strNewPrcSet = strNewPrcSet.subSequence(0, 10).toString();

			actions.clear("NewPriceSet.Name");
			strNewPrcSet = PriceSetName;
			actions.setValue("NewPriceSet.Name", strNewPrcSet);
			Thread.sleep(500);

			switch (strPrcSetType) {
			case "Base":

				// Base Price
				actions.keyboardEnter("NewPriceSet.BaseRadioBtn");
				Thread.sleep(1000);

				break;
			case "Promotion":

				// Promotion Price
				// actions.keyboardEnter("NewPriceSet.PromRadioBtn");
				actions.javaScriptClick("NewPriceSet.PromRadioBtn");
				Thread.sleep(1000);

				driver.findElement(By.id("startDateAnchor")).click();
				// mcd.select_date("25", "current", "NewPriceSet.StartDate");
				mcd.Get_future_date(0, "close", strApplicationDate);

				// driver.findElement(By.xpath("//*[@id='endDateAnchor'][@src='/rfm2OnlineApp/images/cal.jpg'][@name='endDateAnchor']")).click();
				driver.findElement(By.id("endDateAnchor")).click();
				// mcd.select_date("30", "current", "NewPriceSet.EndDate");
				mcd.Get_future_date(3, "close", strApplicationDate);

				break;
			default:
				System.out.println("Please enter correct Price Set Type (Base/Promotion)");
				break;
			}

			// Click Next
			actions.keyboardEnter("NewPriceSet.Next");
			Thread.sleep(2000);
			boolean blnWindow = false;
			try {
				blnWindow = mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");
				if (blnWindow) {
					System.out.println("Set Name and number accepted successfully");
					blnflag = false;
				} else {
					mcd.SwitchToWindow("New Price Sets");
					if (actions.isTextPresence(InfoMsg[1], true)) {
						blnflag = true;
						System.out.println("Entered  number " + strNewPrcSet + " is already exist.");
						System.out.println(blnflag);
					}

				}
			} catch (Exception e) {
				if (actions.isTextPresence(InfoMsg[1], true)) {
					blnflag = true;
					System.out.println("Entered  number " + strNewPrcSet + " is already exist.");
					System.out.println(blnflag);
				}
			}

		} while (blnflag == true);
		// driver.switchTo().window("");

		// mcd.SwitchToWindow("@Price Sets : Common Menu Item Selector");

		// Validations - Common to Base / Promotional

		// Click View Full List
		actions.keyboardEnter("RFM.ViewFullListBtn");
		Thread.sleep(1000);
		actions.smartWait(180);

		// Check MI to add
		WebElement eleMIfrPrcSet = mcd.GetTableCellElement("Deposit.AddDepositTable", 1, "Add", "input");
		eleMIfrPrcSet.sendKeys(Keys.SPACE);
		// click Save

		actions.click("RFM.SaveBtn");

		// Swtich
		mcd.SwitchToWindow("#Title");

		actions.verifyTextPresence(InfoMsg[0], true);

		actions.clear("ManagePS.AllPrice");
		Thread.sleep(500);
		actions.setValue("ManagePS.AllPrice", strTestPrc);
		Thread.sleep(500);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(2000);

		actions.setValue("ManagePS.PPPrcSetFilter", strStatus);

		actions.click("ManagePS.PPALLSave");
		Thread.sleep(1000);
		actions.smartWait(180);

		actions.verifyTextPresence(strResMessage, false);

		// Click on cancel to close the page
		actions.click("NewPriceSet.Cancel");
		mcd.SwitchToWindow("#Title");

		return strNewPrcSet;
	}
	
	
		/** TODO creating the set */
	public String fn_CreateSet(String strAddNewSetName, String strrestlocator, String strrest,String strCopyExisting,String WindowName,String PopWinName) {
		String strFeatureSetName = "";
		
		try {

			/** Click on New Set **/
			// Create Xpath
			String strXPath = "";
			strXPath = "//*[@class='button'][contains(text()," + "'" + strAddNewSetName + "')]";
			WebElement addNewSetButton = driver.findElement(By.xpath(strXPath));
			if (addNewSetButton != null) {
				actions.click(addNewSetButton);
			}

			/** -------Switch window to Add New Day Part Set---- **/
			mcd.SwitchToWindow(PopWinName);

			/** Set Value of Day part Set name and select name **/
			strFeatureSetName = mcd.GetTestData("DT_PREFIX")+"_" + RandomStringUtils.randomAlphabetic(5);
			actions.setValue("RFMAddNewSet.SetName", strFeatureSetName);
			actions.click("RFM.SBSelectNode");

			// Select Hierarchy from select window
			mcd.waitAndSwitch("Select Node");
		
			//(Integer.parseInt((mcd.GetGlobalData("StepTimeOut"))))*10000) : Here is to convert the step time out into milliseconds.
			(new WebDriverWait(driver, (Integer.parseInt((mcd.GetGlobalData("StepTimeOut"))))*10000)).
			until(ExpectedConditions.elementToBeClickable(By.xpath(actions.getLocator("SelectNode.SearchTextBox"))));
			
			// searching for the rest id
			actions.setValue("SelectNode.SearchTextBox", strrest);
			actions.click("SelectARestaurant.SearchRest");
			strXPath = "//*[contains(text(),'" + strrest + "')]";
			(new WebDriverWait(driver, (Integer.parseInt((mcd.GetGlobalData("StepTimeOut"))))*10000)).until(ExpectedConditions.visibilityOfAllElementsLocatedBy((By.xpath(strXPath))));
			mcd.Selectrestnode(strrestlocator, strrest);
			
			/** switching to new window */
			mcd.SwitchToWindow("$"+PopWinName);

			/** Select Copy Existing **/
			if (strCopyExisting.equalsIgnoreCase("No")) {
				/** Click on Next **/
				actions.click("SelectNode.Next");
				mcd.waitAndSwitch("@"+WindowName);
			}
		} catch (Exception e) {
			System.out.println("Failed Test" + e.getMessage());
		}
		return strFeatureSetName;
	}
	
	
	
	// ----------------------------------
	/*
	 * Feature Name : Price Sets Functionality : Overloaded a function to Create New Promotional/Base
	 * Price Set by copying settings from an existing price set without validations.
	 * Scenario ID : PRC_0109 : Pooja Panse
	 */
	// -----------------------------------

	public String RFM_PRC_Create_PromotionalBase_PrcSet(String strNewPrcSet, String strPrcSet_copy,
			String strPrcSetType, String strResMessage, String strFuturePrc, String strNodeNum, String strNavigateTo) throws Exception {

		actions.WaitForElementPresent("PriceSet.NewBtn", 180);
		/** Get application time */
		WebElement apptime = mcd.getdate();
		String strApplicationDate = apptime.getText();

		int iTemp = 0;

		actions.click("PriceSet.NewBtn");
		Thread.sleep(2000);

		// Switch to New Price Sets
		mcd.SwitchToWindow("New Price Sets");

		// Generate unique strNewPrcSet for Base/Promotion Price Set

		switch (strPrcSetType) {
		case "Base":
			// Base Price
			strNewPrcSet = mcd.fn_GetRndName("Base");
			break;
		case "Promotion":
			strNewPrcSet = mcd.fn_GetRndName("Prom");
			break;
		default:
			// System.out.println("Please enter correct Price Set Type
			// (Base/Promotion)");
			actions.reportCreateFAIL("Verfiy data", "Enter correct price set name", "Incorrect data", "FAIL");
			break;
		}

		// Enter new price set name :
		actions.setValue("NewPriceSet.Name", strNewPrcSet);
		Thread.sleep(500);

		actions.click("NewPriceSet.SelectNode");
		Thread.sleep(1000);
		
		// Switch to Select Node Window - Title - Select Node
		mcd.waitAndSwitch("Select Node");

		actions.click("SelectNode.ExactMtchRadiobtn");
		Thread.sleep(500);
//		actions.setValue("SelectNode.SearchBox", strNodeNum);
		driver.findElement(By.xpath(actions.getLocator("SelectNode.SearchBox"))).sendKeys(strNodeNum);
		Thread.sleep(500);

		actions.keyboardEnter("SelectNode.SearchButton");
		Thread.sleep(1000);
		actions.waitForPageToLoad(120);

//		Boolean Node_chk = mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);
		if (mcd.GetGlobalData("Instance").toLowerCase().contains("eu")) {			
			Boolean Node_chk = mcd.Selectrestnode_JavaScriptClk("SelectNode.CPTable", strNodeNum);
		} else {
			Boolean Node_chk =mcd.Selectrestnode("SelectNode.NodeTable", strNodeNum);

		}
		Thread.sleep(2000);
		

		mcd.SwitchToWindow("New Price Sets");

		switch (strPrcSetType) {
		case "Base":

			// Base Price
			actions.keyboardEnter("NewPriceSet.BaseRadioBtn");
			Thread.sleep(1000);

			break;
		case "Promotion":

			// Promotion Price
			// actions.keyboardEnter("NewPriceSet.PromRadioBtn");
			actions.javaScriptClick("NewPriceSet.PromRadioBtn");
			Thread.sleep(1000);

			driver.findElement(By.xpath(actions.getLocator("NewPriceSet.StartDate"))).click();
			// mcd.select_date("25", "current", "NewPriceSet.StartDate");
			mcd.sel_current_date("NewPriceSet.StartDate", strApplicationDate);

			// driver.findElement(By.xpath("//*[@id='endDateAnchor'][@src='/rfm2OnlineApp/images/cal.jpg'][@name='endDateAnchor']")).click();
			driver.findElement(By.xpath(actions.getLocator("NewPriceSet.EndDate"))).click();
			// mcd.select_date("30", "current", "NewPriceSet.EndDate");
			mcd.Get_future_date(3, "close", strApplicationDate);

			break;
		default:
			System.out.println("Please enter correct Price Set Type (Base/Promotion)");
			break;
		}

		// actions.click("NewPriceSet.CopyYesRadioBtn");
		actions.javaScriptClick("NewPriceSet.CopyYesRadioBtn");

		Thread.sleep(1000);

		// Select Price Set to copy
		actions.keyboardEnter("NewPriceSet.SelectPrcSet");

		Thread.sleep(1000);

		// Switch to price sets
		mcd.SwitchToWindow("Price Sets");

		actions.keyboardEnter("PriceSetList.ViewFullList");
		Thread.sleep(1000);
		actions.smartWait(120);

		try {
			// Select the first price set
			mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a").click();
			Thread.sleep(1000);

			/// Switch back
			mcd.SwitchToWindow("New Price Sets");
		} catch (Exception err) {
			actions.reportCreateFAIL("No Price Sets present to copy", "No Price Sets present to copy",
					"No Price Sets present to copy", "FAIL");
		}

		// Click Next
		actions.keyboardEnter("NewPriceSet.Next");
		
		//Switch to updated window -
		driver.switchTo().window("");
		actions.smartWait(180);
		//mcd.waitAndSwitch("@Price Sets");
		
		//Based on instance >> Switch to Manage Price set window. Applicable to US
		
//		if(mcd.GetGlobalData("Instance").trim().toLowerCase().contains("us")){
		try{
			actions.waitForPageToLoad(20);
			String windowTitle=driver.switchTo().window("").getTitle();
			if(windowTitle.equals("Manage Price Set")){
				mcd.SwitchToWindow("Manage Price Set");
				actions.keyboardEnter("RFM.Okbtn");			
				mcd.SwitchToWindow("@Price Sets");
			}
		}
//		}else{
			catch(Exception err){
//				try{
//					mcd.SwitchToWindow("Manage Price Set");
//				}catch(Exception err){
					System.out.println("No window - Manage Price Set");
					driver.switchTo().window("");
			
			}
//		}
		
		actions.WaitForElementPresent("ManagePS.QuickToolApply", 180);

		//Verify result message
		actions.verifyTextPresence(strResMessage, true);

		//Verify Screen header
		String CreatedPS_msg = null;
		CreatedPS_msg = "Manage Price Set : " + strNewPrcSet;
		actions.verifyTextPresence(CreatedPS_msg, true);

		
		// Validations - Common to Base / Promotional

		//For all price field
		driver.findElement(By.xpath(actions.getLocator("ManagePS.AllPrice"))).clear();
		actions.clear("ManagePS.AllPrice");
		Thread.sleep(500);
		actions.setValue("ManagePS.AllPrice", strFuturePrc);
		Thread.sleep(500);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(2000);
		actions.smartWait(120);
		
		//Handled the situation where in based on the price value >> the price fields can be displayed as expanded or collapsed.
		//So the validations are done accordingly
		actions.click("ManagePS.ALLApply");
		Thread.sleep(3000);
		actions.smartWait(120);
		
		// Click on cancel to close the page
		actions.click("NewPriceSet.Cancel");
		Thread.sleep(2000);
		
		// Creating Future Settings for newly created price set
		try{
		mcd.SwitchToWindow("#Title");
		}catch(Exception e){
			mcd.SwitchToWindow("@Manage Price Sets");
		}
		actions.smartWait(180);

		// Enter Price Set name to search
		actions.setValue("PriceSet.SearchBox", strNewPrcSet);
		Thread.sleep(500);
		actions.keyboardEnter("PriceSet.SearchBtn");
		Thread.sleep(1000);
		actions.smartWait(120);

		// Click on fetched PS
		mcd.GetTableCellElement("RFM.WebTable", 1, "Name", "a").click();

		Thread.sleep(1000);
		try{
			mcd.SwitchToWindow("#Title");
			}catch(Exception e){
				mcd.SwitchToWindow("Price Sets");
			}

		if (strPrcSetType.equals("Base")) {
			mcd.SelectDate_OpenCalender("10", "next");
			Thread.sleep(1000);
			actions.smartWait(120);
		} else {
			int d = 10;

			mcd.SelectDate_OpenCalender(Integer.toString(d), "next");
			Thread.sleep(1000);
			actions.smartWait(120);
			mcd.SelectDate_OpenCalender(Integer.toString(d + 2), "current");
			Thread.sleep(1000);
			actions.smartWait(120);
		}

		//Enter future price setting
		actions.clear("ManagePS.AllPrice");
		Thread.sleep(500);
		actions.setValue("ManagePS.AllPrice", strFuturePrc);
		Thread.sleep(500);
		actions.click("ManagePS.QuickToolApply");
		Thread.sleep(2000);

		actions.click("FutureSettings.Apply");
		Thread.sleep(1000);
		actions.smartWait(120);
		try{
			String Alertvalue=driver.switchTo().alert().getText();
				if(Alertvalue.contains("You have specified incomplete tax information")){
					driver.switchTo().alert().accept();
				}
			  }catch(Exception e) {	                     
				System.out.println("Alert is not displaying");
		}
		Thread.sleep(1000);
		actions.smartWait(120);
		//Verify Success message
		actions.verifyTextPresence("Your changes have been saved.", false);
		actions.reportCreatePASS("Verify Future Settings",
				"Future settings for new price set should be done successfully",
				"Future settings for new price set done successfully", "PASS");

		return strNewPrcSet;
	}
	public void fn_verifyTaxChainScreenGUI() throws Exception{
   	 actions.verifyTextPresence("Search Full List by Tax Chain Name", true);
        rfm.GUI_ObjectDisplayedValidation("RFM.Search", "Search Text Box");
        rfm.GUI_EnableDisableValidation("RFM.SearchButton", "Search Button", "Enable");
        rfm.GUI_EnableDisableValidation("RFMCouponSet.SearchWithinStatus", "Search Within Status Drop Down", "Enable");
        rfm.GUI_CheckDefaultDrpdownValue("RFMCouponSet.SearchWithinStatus", "All", "Search Within Status");
        rfm.GUI_EnableDisableValidation("RFM.ViewFullListBtn", "View Full List Button", "Enable");
        rfm.GUI_EnableDisableValidation("TaxChain.StatusDropDown", "Status Drop Down", "Enable");
        rfm.GUI_CheckDefaultDrpdownValue("TaxChain.StatusDropDown", "All", "Status");
        rfm.GUI_EnableDisableValidation("TaxChain.NewTaxChainBtn", "New Tax Chain Button", "Enable");
        rfm.GUI_EnableDisableValidation("RFMLookupUpdate.Save", "Import Button", "Enable");
     
        Boolean TaxChainCodeCol  = mcd.RFM_VerifyTableColumns("RFM.Table", "Tax Chain Code");
        if(TaxChainCodeCol){
       	 actions.reportCreatePASS(
						"Verify Tax Chain Code column in result grid",
						"Tax Chain Code column should be displayed in result grid",
						"Tax Chain Code column is displayed in result grid",
						"PASS");
        }else{
       	 actions.reportCreateFAIL(
       			"Verify Tax Chain Code column in result grid",
						"Tax Chain Code column should be displayed in result grid",
						"Tax Chain Code column is NOT displayed in result grid",
						"FAIL");
        }
        
        Boolean TaxChainNameCol  = mcd.RFM_VerifyTableColumns("RFM.Table", "Tax Chain Code");
        if(TaxChainNameCol){
       	 actions.reportCreatePASS(
						"Verify Tax Chain Name column in result grid",
						"Tax Chain Name column should be displayed in result grid",
						"Tax Chain Name column is displayed in result grid",
						"PASS");
        }else{
       	 actions.reportCreateFAIL(
       			"Verify Tax Chain Name column in result grid",
						"Tax Chain Name column should be displayed in result grid",
						"Tax Chain Name column is NOT displayed in result grid",
						"FAIL");
        }
        
        Boolean NodeCol  = mcd.RFM_VerifyTableColumns("RFM.Table", "Tax Chain Code");
        if(NodeCol){
       	 actions.reportCreatePASS(
						"Verify Node column in result grid",
						"Node column should be displayed in result grid",
						"Node column is displayed in result grid",
						"PASS");
        }else{
       	 actions.reportCreateFAIL(
       			"Verify Node column in result grid",
						"Node column should be displayed in result grid",
						"Node column is NOT displayed in result grid",
						"FAIL");
        }
        
        Boolean StatusCol  = mcd.RFM_VerifyTableColumns("RFM.Table", "Tax Chain Code");
        if(StatusCol){
       	 actions.reportCreatePASS(
						"Verify Status column in result grid",
						"Status column should be displayed in result grid",
						"Status column is displayed in result grid",
						"PASS");
        }else{
       	 actions.reportCreateFAIL(
       			"Verify Status column in result grid",
						"Status column should be displayed in result grid",
						"Status column is NOT displayed in result grid",
						"FAIL");
        }
        
        Boolean FutureSettingsCol  = mcd.RFM_VerifyTableColumns("RFM.Table", "Tax Chain Code");
        if(FutureSettingsCol){
       	 actions.reportCreatePASS(
						"Verify Future Settings column in result grid",
						"Future Settings column should be displayed in result grid",
						"Future Settings column is displayed in result grid",
						"PASS");
        }else{
       	 actions.reportCreateFAIL(
       			"Verify Future Settings column in result grid",
						"Future Settings column should be displayed in result grid",
						"Future Settings column is NOT displayed in result grid",
						"FAIL");
        }
        
        Boolean DeleteCol  = mcd.RFM_VerifyTableColumns("RFM.Table", "Tax Chain Code");
        if(DeleteCol){
       	 actions.reportCreatePASS(
						"Verify Delete column in result grid",
						"Delete column should be displayed in result grid",
						"Delete column is displayed in result grid",
						"PASS");
        }else{
       	 actions.reportCreateFAIL(
       			"Verify Delete column in result grid",
						"Delete column should be displayed in result grid",
						"Delete column is NOT displayed in result grid",
						"FAIL");
        }
        
        Boolean ExportCol  = mcd.RFM_VerifyTableColumns("RFM.Table", "Tax Chain Code");
        if(DeleteCol){
       	 actions.reportCreatePASS(
						"Verify Export column in result grid",
						"Export column should be displayed in result grid",
						"Export column is displayed in result grid",
						"PASS");
        }else{
       	 actions.reportCreateFAIL(
       			"Verify Export column in result grid",
						"Export column should be displayed in result grid",
						"Export column is NOT displayed in result grid",
						"FAIL");
        }
      }

}

package crossbrowser.library;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import crossbrowser.logger.FrameworkLogger;
import crossbrowser.logger.FrameworkLogger.LEVEL;
import crossbrowser.utils.FileUtil;
import crossbrowser.utils.XMLUtils;
import crossbrowser.utils.ZipUtils;

public class XMLValidations {
	
	public boolean isNodePresent(String fileName, String nodeName, boolean cleanupFolder){
		String xmlFolder=ZipUtils.unzipFile();
		String xmlfilePath=xmlFolder+"/"+fileName;
		if(!(xmlfilePath.endsWith(".xml") || xmlfilePath.endsWith(".XML"))){
			xmlfilePath=xmlfilePath+".xml";
		}
		boolean state = getNode(nodeName, xmlfilePath);
		if(cleanupFolder){
			FileUtil.recursiveDelete(xmlFolder);
		}
		if(state){
			return true;
		}else{
			return false;
		}
	}
	
	public boolean validateNodeValue(String fileName, String xpathStr, String expectedValue,boolean cleanupFolder){
		String xmlFolder=ZipUtils.unzipFile();
		String xmlfilePath=xmlFolder+"/"+fileName;
		if(!(xmlfilePath.endsWith(".xml") || xmlfilePath.endsWith(".XML"))){
			xmlfilePath=xmlfilePath+".xml";
		}
		String actNodeValue=getNodeValue(xpathStr, xmlfilePath);
		if(cleanupFolder){
			FileUtil.recursiveDelete(xmlFolder);
		}
		if(expectedValue.equals(actNodeValue)){
			return true;
		}else{
			return false;
		}
	}
	
	public boolean validateAttributeValue(String fileName, String xpathStr, String attribute, String expectedValue,boolean cleanupFolder){
		String xmlFolder=ZipUtils.unzipFile();
		String xmlfilePath=xmlFolder+"/"+fileName;
		if(!(xmlfilePath.endsWith(".xml") || xmlfilePath.endsWith(".XML"))){
			xmlfilePath=xmlfilePath+".xml";
		}
		String actNodeValue=getAttributeValue(xpathStr, attribute, xmlfilePath);
		if(cleanupFolder){
			FileUtil.recursiveDelete(xmlFolder);
		}
		if(expectedValue.equals(actNodeValue)){
			return true;
		}else{
			return false;
		}
	}
	
	private boolean getNode(String nodeName, String filePath) {
		Document doc=XMLUtils.docBuilder(filePath);
		int count = doc.getElementsByTagName(nodeName).getLength();
		if (count > 0) {
			doc = null;
			return true;
		} else {
			doc = null;
			FrameworkLogger.log("No Node found "+nodeName, LEVEL.error, this.getClass());
			return false;
		}
	}
	
	private String getNodeValue(String xpathStr, String filePath) {
		xpathStr=XMLUtils.tidyXpath(xpathStr);
		String value = null;
		Document doc=XMLUtils.docBuilder(filePath);
		System.out.println(doc);
		Node nl = XMLUtils.getNode(doc, xpathStr);
		System.out.println(nl);
		if (nl != null) {
			value = nl.getTextContent();
		} else {
			FrameworkLogger.log("No Node found. XPATH: "+xpathStr, LEVEL.error, this.getClass());
		}
		doc = null;
		return value;
	}
	
	
	private String getAttributeValue(String xpathStr, String attribute ,String filePath) {
		xpathStr=XMLUtils.tidyXpath(xpathStr);
		String value = null;
		Document doc=XMLUtils.docBuilder(filePath);
		Node nl = XMLUtils.getNode(doc, xpathStr);
		if (nl != null) {
			value = nl.getAttributes().getNamedItem(attribute).getNodeValue();
		} else {
			FrameworkLogger.log("No Node found. XPATH: "+xpathStr, LEVEL.error, this.getClass());
		}
		doc = null;
		return value;
	}
	  /****
     * 
     * 
     * @param fileName      : name of file in which value is to be searched
     * @param xpathStr 	    : xpath for the required node
     * @param cleanupFolder : boolean value for deleting downloaded file
     * @return 				: returns true if node is present in file else false
     * 
     */
    public boolean validateNodePresent(String fileName, String xpathStr,boolean cleanupFolder){
		boolean isNodePresent=false;
   		String xmlFolder=ZipUtils.unzipFile();
		String xmlfilePath=xmlFolder+"/"+fileName;
		if(!(xmlfilePath.endsWith(".xml") || xmlfilePath.endsWith(".XML"))){
			xmlfilePath=xmlfilePath+".xml";
		}
		
		xpathStr=XMLUtils.tidyXpath(xpathStr);
   		Document doc=XMLUtils.docBuilder(xmlfilePath);
   		Node nl = XMLUtils.getNode(doc, xpathStr);
   		if (nl != null) {
   			isNodePresent=true;
   			System.out.println("Name of node::"+nl.getNodeName());
   		} else {
   			isNodePresent =false;
   			
   		}
   		if(cleanupFolder){
			FileUtil.recursiveDelete(xmlFolder);
		}
   		return isNodePresent;
   	}
}

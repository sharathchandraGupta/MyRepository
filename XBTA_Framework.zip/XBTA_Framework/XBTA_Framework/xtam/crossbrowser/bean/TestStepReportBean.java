// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TestStepReportBean.java

package crossbrowser.bean;


public class TestStepReportBean
{

    public TestStepReportBean(String date, String stepName, String expected, String actual, String result, String screenShotPath)
    {
        this.date = date;
        this.stepName = stepName;
        this.expected = expected;
        this.actual = actual;
        this.result = result;
        this.screenShotPath = screenShotPath;
    }

    public TestStepReportBean()
    {
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    public String getStepName()
    {
        return stepName;
    }

    public void setStepName(String stepName)
    {
        this.stepName = stepName;
    }

    public String getExpected()
    {
        return expected;
    }

    public void setExpected(String expected)
    {
        this.expected = expected;
    }

    public String getActual()
    {
        return actual;
    }

    public void setActual(String actual)
    {
        this.actual = actual;
    }

    public String getResult()
    {
        return result;
    }

    public void setResult(String result)
    {
        this.result = result;
    }

    public String getScreenShotPath()
    {
        return screenShotPath;
    }

    public void setScreenShotPath(String screenShotPath)
    {
        this.screenShotPath = screenShotPath;
    }

    private String date;
    private String stepName;
    private String expected;
    private String actual;
    private String result;
    private String screenShotPath;
}

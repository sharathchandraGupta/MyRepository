// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ReportBean.java

package crossbrowser.bean;

import java.util.*;

public class ReportBean
{

    public ReportBean()
    {
    }

    public static Date startDate;
    public static Date endDate;
    public static List report = new ArrayList();

}

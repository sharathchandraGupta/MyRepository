// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TestCaseCreationBean.java

package crossbrowser.bean;

import java.util.ArrayList;
import java.util.List;

public class TestCaseCreationBean
{

    public TestCaseCreationBean()
    {
    }

    public static List testcasesInstanceCreated = new ArrayList();
    public static List testcasesReportFound = new ArrayList();
    public static List testcasesReportNotFound = new ArrayList();

}

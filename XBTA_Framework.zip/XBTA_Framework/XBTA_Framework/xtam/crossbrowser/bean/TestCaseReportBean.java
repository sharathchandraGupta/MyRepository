// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TestCaseReportBean.java

package crossbrowser.bean;

import java.util.List;

public class TestCaseReportBean
{

    public TestCaseReportBean()
    {
    }

    public TestCaseReportBean(String testCaseName, String description, String osBrowser, String status, String duration, List steps)
    {
        this.testCaseName = testCaseName;
        this.description = description;
        this.osBrowser = osBrowser;
        this.status = status;
        this.duration = duration;
        this.steps = steps;
    }

    public String getTestCaseName()
    {
        return testCaseName;
    }

    public void setTestCaseName(String testCaseName)
    {
        this.testCaseName = testCaseName;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String desc)
    {
        description = desc;
    }

    public String getOsBrowser()
    {
        return osBrowser;
    }

    public void setOsBrowser(String osBrowser)
    {
        this.osBrowser = osBrowser;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getDuration()
    {
        return duration;
    }

    public void setDuration(String duration)
    {
        this.duration = duration;
    }

    public List getSteps()
    {
        return steps;
    }

    public void setSteps(List steps)
    {
        this.steps = steps;
    }

    private String testCaseName;
    private String description;
    private String osBrowser;
    private String status;
    private String duration;
    private List steps;
}

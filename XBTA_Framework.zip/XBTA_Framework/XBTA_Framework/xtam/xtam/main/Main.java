package xtam.main;

import crossbrowser.harness.CrossBrowser;

public class Main {
	public static void main(String[] args) {
		
		CrossBrowser crossBrowser=new CrossBrowser();
		crossBrowser.runCrossBrowser();
	}
}

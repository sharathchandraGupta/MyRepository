package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.MasterMenuItem;
import crossbrowser.library.MenuItemSets;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;

public class MNU_0035_VerifyNGABSCode {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;
	private MasterMenuItem mmi;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateTo;

	// Declare test-data variables for other data-parameters
	private String MIrange, strmsg, pro_type, strmenutype, strNavigateToMMIL;
	private String strNavigateToRP, strRestNo;

	public MNU_0035_VerifyNGABSCode(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);
		mmi = new MasterMenuItem(driver, actions, uiActions, inputData, mcd, rfm);
		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateTo = mcd.GetTestData("DT_NAVIGATE_TO");

		// TODO: GetTestData for other data-parameters
		MIrange = mcd.GetTestData("DT_MIRANGE");
		strmenutype = mcd.GetTestData("DT_MenuItemParam");
		strmsg = mcd.GetTestData("DT_ERR_MSG");
		pro_type = mcd.GetTestData("DT_PROD_TYPE");
		strNavigateToMMIL = mcd.GetTestData("DT_NAVIGATE_TO_MMIL");
		strNavigateToRP = mcd.GetTestData("DT_NAVIGATE_TO_RP");
		strRestNo = mcd.GetTestData("DT_REST_NUM");
	}

	@Test
	public void test_MNU_0035_VerifyNGABSCode() throws InterruptedException {

		try {
			System.out.println(
					"********************************************************************** Test execution starts");
			actions.setTestcaseDescription(mcd.GetTestData("DT_DESCRIPTION"));

			/** Launch and Login RFM */
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);

			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Select Menu Option */
			System.out.println("> Navigate to :: " + strNavigateToMMIL);
			actions.select_menu("RFMHome.Navigation", strNavigateToMMIL);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");

			/*
			 * MNU_0035: Pre-requisite: Menu Item M1 having Category as
			 * "Drink Type/Cup Type/Pour Type/Addin" and having a value for
			 * NGABSCode is associated with Menu Item Set MIS1 Verify that
			 * NGABSCode is not customized at Menu Item Set level
			 */

			// Creating Menu Item of category Add-in without copying Existing
			// Menu Item
			int iMInum = mmi.RFM_MI_CreateMenuItem_updated(MIrange, pro_type, strmsg, strmenutype);

			// Navigate to Restaurant Profile and getting the name of MIS which
			// is already assigned to Restaurant
			System.out.println("> Navigate to :: " + strNavigateToRP);
			actions.select_menu("RFMHome.Navigation", strNavigateToRP);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("RestaurantProfile.SearchTextBox", 120);

			// Clear and enter Restaurant Number
			actions.clear("RestaurantProfile.SearchTextBox");
			actions.setValue("RestaurantProfile.SearchTextBox", strRestNo);
			actions.WaitForElementPresent("RestaurantProfile.searchbutton", 120);
			
			// Click on Search button
			actions.keyboardEnter("RestaurantProfile.searchbutton");
			mcd.smartsync(180);
			WebElement Tbl_EleNum = mcd.GetTableCellElement("RestaurantProfile.table", 1, "Number", "a");
			actions.click(Tbl_EleNum);
			mcd.smartsync(180);
			actions.click("RestaurantProfile.STMenuItemPosPricing");
			mcd.smartsync(180);
			actions.WaitForElementPresent("RestaurantUpdt.SetType", 120);
			actions.setValue("RestaurantUpdt.SetType", "Menu Items");
			mcd.smartsync(180);
			Thread.sleep(2000);
			actions.WaitForElementPresent("RFM.ViewFullListButton", 120);
			actions.keyboardEnter("RFM.ViewFullListButton");
			mcd.smartsync(180);
			Thread.sleep(2000);
			actions.WaitForElementPresent("LocalizationSet.Muapplybtn", 120);
			WebElement ExistingMISName = mcd.GetTableCellElement("OrderComponents.Table", 1, "Set Name", "tr");
			String ExistingMISNameRP = ExistingMISName.getText().trim();
			System.out.println(ExistingMISNameRP);
			Thread.sleep(5000);

			if (!ExistingMISNameRP.equals("")) {
				actions.reportCreatePASS("Verify Menu Item Set assigned", "Menu Item Set should be assigned",
						"Copied the Menu Item Set assigned", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Menu Item Set assigned", "Menu Item Set should be assigned",
						"Menu Item Set is not assigned", "Fail");
			}

			// Assigning the created Menu Item to MIS(Assigned to Restaurant) by
			// Navigating to Menu Item Sets
			System.out.println("> Navigate to :: " + strNavigateTo);
			actions.select_menu("RFMHome.Navigation", strNavigateTo);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			mcd.smartsync(180);
			/** Update title of new Page */
			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("RFMBuisnessLimitSet.SearchBLS", 120);
			actions.setValue("RFMBuisnessLimitSet.SearchBLS", ExistingMISNameRP);
			actions.keyboardEnter("RFM.SearchButton");
			mcd.smartsync(180);
			boolean b2 = mcd.fn_VerifyWebObjectsDisplayed("MenuItemSets.SearchedMenuLink");
			if (b2 == true) {
				actions.reportCreatePASS("Verify Search", ExistingMISNameRP + " - Menu Item Set should be displayed",
						ExistingMISNameRP + " - Menu Item Set is displayed", "Pass");
			} else {
				actions.reportCreateFAIL("Verify Search", ExistingMISNameRP + " - Menu Item Set should be displayed",
						ExistingMISNameRP + " - Menu Item Set is not displayed", "Fail");
			}

			WebElement Tbl_Element = mcd.GetTableCellElement("RestaurantProfile.table", 1, "Name", "a");
			actions.click(Tbl_Element);
			mcd.smartsync(180);
			// Switch to Manage Menu Item Set : Manage Menu Items
			mcd.SwitchToWindow("@Manage Menu Item Set : Manage Menu Items");
			mcd.smartsync(180);
			actions.WaitForElementPresent("ManageMenuItems.AddRemoveButton", 120);
			actions.keyboardEnter("ManageMenuItems.AddRemoveButton");
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("CopyComponents.SearchText", 120);
			actions.clear("CopyComponents.SearchText");
			actions.setValue("CopyComponents.SearchText", iMInum);
			actions.click("CopyComponent.ExactMatch");
			actions.keyboardEnter("CommonMenuItem.SearchBtn");
			mcd.smartsync(180);
			WebElement chkBox = mcd.GetTableCellElement("RFMCommonMenuItemSelector.ComoTbl", 1, 1, "input");
			actions.javaScriptClick(chkBox);
			actions.keyboardEnter("RFM.SaveButton");
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");
			actions.WaitForElementPresent("ManageMenuItems.SearchText", 120);
			// Set Search text and click Search
			actions.clear("ManageMenuItems.SearchText");
			actions.setValue("ManageMenuItems.SearchText", iMInum);
			actions.javaScriptClick("RestMIList.ExactRadiobtn");
			actions.keyboardEnter("ManageMenuItemSet.SearchBtn");
			mcd.smartsync(180);
			WebElement TableItem = mcd.GetTableCellElement("RestaurantProfile.table", 1, "Number", "a");
			boolean bfound2 = TableItem.isDisplayed();

			if (bfound2 == true) {
				String row_2 = TableItem.getText();
				System.out.println("Search Result row3 : " + row_2);
				actions.click(TableItem);
				mcd.smartsync(180);
				mcd.SwitchToWindow("#Title");
				actions.click("ManageMenuItem.POSTab");
				mcd.smartsync(180);
				actions.WaitForElementPresent("ManageMenuItems.POSKVSSettingNGABSCode", 180);
				if (actions.isElementPresent("ManageMenuItem.Customization")) {
					actions.keyboardEnter("ManageMenuItem.Customization");
					mcd.smartsync(180);
				}

				// Verify that NGABSCode is not customized at Menu Item Set
				// level and validate the same
				String sNGABSCode = driver
						.findElement(By.xpath(actions.getLocator("ManageMenuItems.POSKVSSettingNGABSCode")))
						.getAttribute("Class");
				mcd.smartsync(180);
				System.out.println("NGABSCode is: " + sNGABSCode);
				if (sNGABSCode.equals("disabledbdr "))
					actions.reportCreatePASS("Verify that NGABSCode is disabled",
							"NGABSCode input text field should be inactive",
							"NGABSCode input text field class is:" + sNGABSCode, "Pass");
				else
					actions.reportCreateFAIL("Verify that NGABSCode is disabled",
							"NGABSCode input text field should be inactive", "NGABSCode input text field is active",
							"Fail");
			} else {
				System.out.println("Search Result: row not found - " + iMInum);
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}

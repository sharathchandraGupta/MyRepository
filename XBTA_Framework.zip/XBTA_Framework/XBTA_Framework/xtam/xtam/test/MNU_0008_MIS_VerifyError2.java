package xtam.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import crossbrowser.library.Keywords;
import crossbrowser.library.UIValidations;
import crossbrowser.library.lib_MCD;
import crossbrowser.library.lib_RFM2;
import crossbrowser.library.Keywords.DialogType;
import crossbrowser.library.lib_MCD.AlertPopupButton;

public class MNU_0008_MIS_VerifyError2 {
	private Keywords actions;
	private WebDriver driver;
	private Map input;
	private UIValidations uiActions;
	private SoftAssert softAssert = new SoftAssert();

	private lib_MCD mcd;
	private lib_RFM2 rfm;

	// Test-Data Variables
	private Object strURL;
	private Object strUserName;
	private Object strPassword;
	private String strMarket;
	private String strNavigateToRMIL;
	private String strNavigateToMIS;
	// TODO: Declare test-data variables for other data-parameters
	private String strRestNum, strNavigateToAdmin;

	public MNU_0008_MIS_VerifyError2(WebDriver nodeDriver, Map inputData, Object or) {
		driver = nodeDriver;
		input = inputData;
		actions = new Keywords(driver, or);
		uiActions = new UIValidations();

		mcd = new lib_MCD(driver, actions, uiActions, inputData);
		rfm = new lib_RFM2(driver, actions, uiActions, inputData, mcd);

		// Read input Test-Data
		strURL = mcd.GetTestData("DT_URL");
		strUserName = mcd.GetTestData("DT_USER_NAME");
		strPassword = mcd.GetTestData("DT_PASSWORD");
		strMarket = mcd.GetTestData("DT_MARKET");
		strNavigateToRMIL = mcd.GetTestData("DT_NAVIGATE_TO_RMIL");

		// Additional data for menu;
		strNavigateToAdmin = mcd.GetTestData("DT_NAVIGATE_TO_ADMIN");
		strNavigateToMIS = mcd.GetTestData("DT_NAVIGATE_TO_MIS");
		strRestNum = mcd.GetTestData("DT_RestNum");
	}

	@Test
	public void test_MNU_0008_MIS_VerifyError2() throws InterruptedException {

		try {
			System.out.println("********************* Test execution starts *********************");
			actions.setTestcaseDescription(mcd.GetTestData("DT_DESCRIPTION"));

			/** Launch and Login RFM */
	
			System.out.println("> Launch and Login RFM");
			rfm.LaunchAndLogin(strURL, strUserName, strPassword);
			
			actions.waitForPageToLoad(120);
			/** Select Market (Node) */
			System.out.println("> Select Market (Node)");
			rfm.SelectMarket(strMarket);

			/** Navigating to Restaurant Menu Item List */
			System.out.println("> Navigate to :: " + strNavigateToRMIL);
			actions.select_menu("RFMHome.Navigation", strNavigateToRMIL);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.waitAndSwitch("#Title");

			actions.WaitForElementPresent("");
			actions.WaitForElementPresent("",10);


			// Getting 'Active' 'VALUE_MEAL' name or number
			actions.keyboardEnter("RestaurantMenuItemList.selectRest");
			mcd.waitAndSwitch("Select a Restaurant");
			mcd.Selectrestnode_JavaScriptClk("AddLocalizationSet.dataTable", strRestNum);
			mcd.SwitchToWindow("Restaurant Menu Item List");
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);
			actions.WaitForElementPresent("RestMIList.MIClassDrpdwn", 120);
			actions.setValue("RestMIList.MIClassDrpdwn", "VALUE_MEAL");
			mcd.smartsync(180);
			actions.WaitForElementPresent("RestMIList.MIStatusDrpdwn", 120);
			actions.setValue("RestMIList.MIStatusDrpdwn", "Active");
			mcd.smartsync(180);
			String CVM_MI = "";
			if(actions.isSafari()){
				WebElement element = mcd.GetTableCellElement("PackageSchedule.Table", 2, 1, "");
				CVM_MI =((JavascriptExecutor)driver).executeScript("return arguments[0].innerHTML", element).toString().trim();
				((JavascriptExecutor)driver).executeScript("arguments[0].style.border='3px solid red'", mcd.GetTableCellElement("PackageSchedule.Table", 2, 1, ""));
			}else{
				
				CVM_MI = mcd.GetTableCellValue("PackageSchedule.Table", 2, "Number", "a", "");	
			}
			

			// Navigating to Restaurant Profile to get the MIS Name which is
			// assigned to the particular Restaurant
			System.out.println("> Navigate to :: " + strNavigateToAdmin);
			actions.select_menu("RFMHome.Navigation", strNavigateToAdmin);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.waitAndSwitch("#Title");
			actions.setValue("RestaurantUpdt.SearchRestro", strRestNum);
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);
			actions.javaScriptClick(mcd.GetTableCellElement("PackageSchedule.Table", 1, 1, "a"));
			mcd.smartsync(180);
			actions.click("RestaurantProfile.STMenuItemPosPricing");
			mcd.smartsync(180);
			actions.WaitForElementPresent("RestaurantUpdt.SetType", 120);			

			actions.setValue("RestaurantUpdt.SetType", "Menu Items");
			mcd.smartsync(180);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);
			actions.keyboardEnter("RestaurantSet.ViewFulList");
			mcd.smartsync(180);
			Thread.sleep(2000);
			String MIS_Name = mcd.GetTableCellValue("OrderComponents.Table", 1, 1, "", "");

			// Navigating to Menu Item Sets to validate the error message
			System.out.println("> Navigate to :: " + strNavigateToMIS);
			actions.select_menu("RFMHome.Navigation", strNavigateToMIS);
			Thread.sleep(2000);
			actions.waitForPageToLoad(120);

			/** Update title of new Page */
			mcd.waitAndSwitch("#Title");

			// Search the MIS which is assigned to Restaurant
			actions.WaitForElementPresent("MenuItemSets.SearchTxtBox", 120);
			actions.setValue("MenuItemSets.SearchTxtBox", MIS_Name);
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);
			actions.javaScriptClick(mcd.GetTableCellElement("PackageSchedule.Table", 1, 1, "a"));
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");

			// Search for the 'VALUE_MEAL' and try to add Inactive/Not Approved
			// MI in Components tab
			actions.setValue("RFMMassUpdatePrice.SearchText", CVM_MI);
			actions.keyboardEnter("ManageMenuItemSet.SearchBtn");
			mcd.smartsync(180);
			mcd.GetTableCellElement("PackageSchedule.Table", 1, 1, "a").click();
			mcd.smartsync(180);
			mcd.SwitchToWindow("#Title");
			actions.keyboardEnter("MasterMenuItemList.Components");
			mcd.smartsync(180);

			if (actions.isElementPresent("RFM.CustomizeSettingsButton")) {
				actions.keyboardEnter("RFM.CustomizeSettingsButton");
			} else {
				actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
				actions.keyboardEnter("DimensionNameSets.ResetToDefault");
				if(!actions.isSafari()){									
					driver.switchTo().alert().accept();
					}
				mcd.smartsync(180);
				actions.WaitForElementPresent("RFM.CustomizeSettingsButton", 120);
				actions.keyboardEnter("RFM.CustomizeSettingsButton");
			}
			actions.keyboardEnter("ManageMenuItems.AddRemoveButton");
			mcd.waitAndSwitch("Common Menu Item Selector");
			actions.keyboardEnter("RestaurantSet.Searchbtn");
			mcd.smartsync(180);

			actions.setValue("CMIS.Availabilitydrpdwn", "Available");
			mcd.smartsync(180);
			if (strMarket.equals("US Country Office")) {
				actions.setValue("MenuItemSets.Status", "Not Approved");
				mcd.smartsync(180);
			} else {
				actions.setValue("MenuItemSets.Status", "Inactive");
				mcd.smartsync(180);
			}
			try {
				boolean bAddMenu = mcd.GetTableCellElement("AddTenderType.Table", 1, 1, "input").isEnabled();

				if (bAddMenu == true) {
					System.out.println("Add check box enabled: " + bAddMenu);
					mcd.GetTableCellElement("AddTenderType.Table", 1, 1, "input").click();
					actions.reportCreatePASS("Click Add Check box", "Add check box should be enabled and selected",
							"Add check box is enabled and selected", "Pass");
				} else {
					System.out.println("Add check box enabled: " + bAddMenu);
					actions.reportCreateFAIL("Click Add Check box", "Add check box should be enabled and selected",
							"Add check box is not enabled and selected", "Fail");
				}
				actions.keyboardEnter("RFM.ContinueButton");
			} catch (Exception err) {
				actions.reportCreateFAIL("Click Add Check box", "Add check box should be enabled and selected",
						"Add check box is not enabled and selected", "Fail");
			}

			mcd.SwitchToWindow("Manage Menu Items");
			actions.handleSafariAlertDialog(DialogType.CONFIRM, AlertPopupButton.OK_BUTTON);
			actions.keyboardEnter("LocalizationSet.Muapplybtn");

			try {
				if(!actions.isSafari()){									
				driver.switchTo().alert().accept();
				}
			} catch (Exception e) {
			}

			try {
				mcd.SwitchToWindow("Apply Changes Details");
				mcd.smartsync(180);
				actions.keyboardEnter("DimensionGroup.SaveButton");
				mcd.SwitchToWindow("Manage Menu Items");
				mcd.smartsync(180);
			} catch (Exception e) {
			}

			// Validating the expected error message
			try {
				boolean BlnVal = false;
				mcd.SwitchToWindow("Menu Item List");
				actions.waitForPageToLoad(120);
				Thread.sleep(5000);
				if (strMarket.equals("US Country Office")) {
					BlnVal = actions.isTextPresence(
							"The list of components which need to be Approved before they can be added to the EVM.",
							true);
				} else {
					BlnVal = actions.isTextPresence(
							"The list of components which need to be to Active before they can be added to the EVM/CONTAINER_VALUE_MEAL.",
							true);
				}
				if (BlnVal) {
					actions.reportCreatePASS("Verify the above mentiontioned Message",
							"Expected message should be displayed", "Expected message is displayed", "Pass");
				} else {
					actions.reportCreateFAIL("Verify the above mentiontioned Message",
							"Expected message should be displayed", "Expected message is not displayed", "Fail");
				}
				driver.close();
				mcd.SwitchToWindow("Manage Menu Items");
			} catch (Exception e) {
			}

			/** Logout the application */
			rfm.Logout();

		} catch (Exception e) {
			// reporting the Fail condition
			actions.catchException(e);
		} finally {
			actions.quitBrowser();
			actions.verifyTestCase(this.getClass());
		}
	}
}

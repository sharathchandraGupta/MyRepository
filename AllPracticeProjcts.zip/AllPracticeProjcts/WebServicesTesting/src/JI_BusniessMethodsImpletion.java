
public interface JI_BusniessMethodsImpletion {

}


public class B {
	
	
	private static void main(String[] args) {
		A oA = new A();
//		System.out.println(oA.strA);
		System.out.println("Finish");

	}

}

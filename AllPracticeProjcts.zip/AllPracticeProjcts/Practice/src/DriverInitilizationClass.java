import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Factory;
import org.testng.annotations.Parameters;

public class DriverInitilizationClass {
	
	WebDriver driver = null;
	
	@Parameters({ "myBrowser" })
	@BeforeTest
	public WebDriver creatingDriver(String myBrowser) {

		

		if (myBrowser.equalsIgnoreCase("chrome")) {
			System.out.println("in chrome");
			System.setProperty("webdriver.chrome.driver", "D://Hub_Node_Folder//Selenium_Grid_New//chromedriver.exe");
			driver = new ChromeDriver();
			
			Actions AO = new Actions(driver);
			AO.moveToElement(driver.findElement(By.id(""))).perform();
			AO.moveToElement(driver.findElement(By.id(""))).build();
			
			

		} else if (myBrowser.equalsIgnoreCase("IE")) {
			System.setProperty("webdriver.ie.driver", "D://Hub_Node_Folder//Selenium_Grid_New//IEDriverServer.exe");
			driver = new InternetExplorerDriver();

		} else if (myBrowser.equalsIgnoreCase("FireFox")) {

			driver = new FirefoxDriver();

		}

		return driver;

	}

}


public class Demo {
	
	
	public static void rec(String str){
		String strO =str;
		String[] temp = str.split(" ");
		int len= temp.length;
		String[] temp1;
		strO.replace(temp[0], "");
		temp1= strO.toLowerCase().replace(temp[0].toLowerCase(), "").trim().split(" ");
//		System.out.println(temp1[0]);
		if(len>1){
			System.out.println(temp[0]+ " : "+(len - temp1.length));	
		}else{
			System.out.println(temp[0]+ " : "+(len));
		}
		
		
		if(len-1>0){
			str = str.replace(temp[0], "").trim();
			rec(str);				
		}
		
		
	}

	
	public static void main(String[] args){
		String str = "#sharaht is at cap sharaht";
		
//		rec(str);
		System.out.println(str.substring(1));
		System.out.println(str.substring(2));
		
		
/*		for(char c :ch){
			System.out.println(c);
			temp = String.valueOf(c); 
			rev = temp+rev;
		}
		int orlen = str.length();
		int letlen = 0;
	for(int i=0;i<str.length();i++){
//		System.out.println(str.substring(i, i+1));
		temp = str.split("");
		rev = temp[i];					
		letlen = str.replace(rev, "").length();		
		System.out.println(rev +":"+ (orlen-letlen));
		
		
	}
*/		
	
		
		
	}
	
	
	
}

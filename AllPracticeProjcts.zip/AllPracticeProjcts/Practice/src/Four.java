
public class Four {
	public static void main(String[] args){
		System.out.println("Am in class Four");
	}
}

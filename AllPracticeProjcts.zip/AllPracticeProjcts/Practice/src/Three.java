import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;


public class Three extends DriverInitilizationClass{
	
	WebDriver driver = creatingDriver("");
	
	@Test
	public void FirstMethod_Three(){	
		driver.get("http://www.gmail.com");		
	}

	public void SecondMethod_Three() {
		System.out.println("Am in class three and in method two");		
	}
}

import org.apache.bcel.generic.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class abc extends DriverInitilizationClass{

	private WebDriver driver;
	public abc(){};
	
	public abc(WebDriver driver){
		DriverInitilizationClass obj = new DriverInitilizationClass();
		this.driver = obj.creatingDriver("");
		
		
		
				
		
		
	}

	
}





public class DemoStatic {
	 int a=0;
	 {
	a++;
	System.out.println(a);
	}
	
	 {
		a++;
		Assert.assertEquals("fds", "");
		System.out.println(a);
		}
	
	public static void main(String[] args){
		DemoStatic ob = new DemoStatic();
		
	}
	

}

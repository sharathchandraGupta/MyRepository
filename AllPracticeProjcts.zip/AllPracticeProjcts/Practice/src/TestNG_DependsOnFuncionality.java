
import org.testng.annotations.Test;

import org.testng.*;


public class TestNG_DependsOnFuncionality {
 
  @Test (dependsOnMethods = { "OpenBrowser" })
  public void SignIn() {
	  System.out.println("This will execute second (SignIn)"); 
  }
 
  @Test 
  public void OpenBrowser() {
	  Assert.assertEquals("Sharath", "Sharath");
  }
 
  @Test (dependsOnMethods = { "SignIn" })
  public void LogOut() {
	  System.out.println("This will execute third (Log Out)");
  }
}
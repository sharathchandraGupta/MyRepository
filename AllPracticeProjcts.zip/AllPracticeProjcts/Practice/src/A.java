import java.util.Scanner;

class A {
    public static void main(String args[] ) throws Exception {

        Scanner in = new Scanner(System.in);
        
        int T = in.nextInt();
     
        for(int i=1;i<=T;i++){
        	   int N=0;
               int items=0;
               double per = 0;
               int temp=0;
            N = in.nextInt();
            for(int j=0;j<N;j++){
            	items = in.nextInt();
                temp = temp+items;
          
            }
            per =  (double) temp/N;
             System.out.println(per);
            System.out.println(String.format( "%.8f", per)); ; 
            
        }
        

       
    }
}

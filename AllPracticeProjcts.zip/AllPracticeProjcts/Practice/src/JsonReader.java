import java.io.FileReader;
import java.io.IOException;

import org.apache.bcel.generic.Select;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class JsonReader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 JSONParser parser = new JSONParser();
	
		try{	
			 JSONArray  obj = (JSONArray ) parser.parse(new FileReader("D://XBTA_Framework//Practice//browsters.json"));
//			JSONObject jsonObject =  (JSONObject) obj;
			 
			 JSONObject person = (JSONObject) obj.get(0);
	            System.out.println(person.get("port"));
		} catch (IOException | ParseException e) {
			
//			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		 
		 
	}

}

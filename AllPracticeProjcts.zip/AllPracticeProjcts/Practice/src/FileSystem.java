import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.nio.charset.Charset;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.stream.Stream;

import org.apache.xalan.transformer.Counter;

import com.google.common.io.Files;

public class FileSystem {
	
	
	
	public static int countLines(String filename) throws IOException {
	    LineNumberReader reader  = new LineNumberReader(new FileReader(filename));
	int cnt = 0;
	String lineRead = "";
	while ((lineRead = reader.readLine()) != null) {}

	cnt = reader.getLineNumber(); 
	System.out.println(reader.read());
	reader.close();
	return cnt;
	}

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		System.out.println("Started");
		String filename= "D://temp//cmd.txt";
		try {
			countLines(filename);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Started");
		/*File file = new File("D://temp//cmd.txt");
		BufferedReader in = new BufferedReader(new FileReader(file));*/
//		String fileIn = new Scanner(new File("D://temp//cmd.txt")).useDelimiter("\\Z").next();
		
//		Scanner fileIn = new Scanner(new File("D://temp//cmd.txt"));
		
//		Files.lines(Paths.get("D://temp//cmd.txt"));
		
	/*	try {
			System.out.println(Files.readLines(new File("D://temp//cmd.txt"), Charset.defaultCharset()).size());;
			
			Stream<String> lines = (Stream<String>) Files.readLines(new File("D://temp//cmd.txt"), Charset.defaultCharset());
			System.out.println(lines);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		*/
	
		
//	System.out.println(fileIn);
	
	/*int counter=0;
		while(fileIn.hasNext()){
			counter= counter+1;
			
			
		}
		
		
System.out.println(counter);*/
	
	
	
	/*if(fileIn.hasNext()){
		int counter=0;
	try{
				
		
			while(fileIn.hasNextLine()){
				fileIn.nextLine();
//				System.out.println(fileIn.nextLine());
			counter= counter+1;
			}
			}	
			catch(Exception e){
				System.out.println("Failed to read the from text file");
				
			}	
	System.out.println(counter);
	}
	*/
	}
	
}

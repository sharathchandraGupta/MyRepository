import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TNG_B {
	
	@DataProvider
	public Iterator<String> getData()
	{
	//Rows - Number of times your test has to be repeated.
	//Columns - Number of parameters in test data.
		
		
	Object[] data = new Object[3];
ArrayList<String> ob = new ArrayList<String>();
	// 1st row
data[0] ="sampleuser1";

//	ob.add(data[0][0].toString());	


	
	data[1]= "abcdef";

	// 2nd row
//	data[1][0] ="testuser2";
	data[2] = "zxcvb";
	Iterator<String> itr = ob.iterator();
	
	// 3rd row
/*	data[2][0] ="guestuser3";
	data[2][1] = "pass123";
*/
	return itr;
	}
	
	
	
	@Test(dataProvider="getData")
	public void test1(String username){
	System.out.println("UN:" + username.length());
	for(int i= 0; i<username.length();i++){
		System.out.println(username.);
	}
	
//	System.out.println("UN:" + password);
	}

}

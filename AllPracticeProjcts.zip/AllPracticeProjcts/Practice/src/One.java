
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import org.testng.annotations.Test;


public class One extends DriverInitilizationClass {
	
	

	
	@Test
	public void FirstMethod_One() {
			System.out.println("m one:"+new Date());
		driver.get("http://www.google.com");
			
		/*long id = Thread.currentThread().getId();
			System.out.println("Before Method: "+id);*/
			
		}
		
		
		public void SecondMethod_One() {
			
			long id = Thread.currentThread().getId();
			System.out.println("First Test Method: "+id);
			
		}
		
		
		public void ThirdMethod_One() {
			
			long id = Thread.currentThread().getId();
			System.out.println("Second Test Method: "+id);
			
		}
		
	public void FourthMethod_One() {
			
			long id = Thread.currentThread().getId();
			System.out.println("AfterMethod: "+id);
			
		}

}


package example;		

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;		
public class NewTest {		
//	    private WebDriver driver;		
		@Test				
		public void testEasy() {	
//			driver.get("http://demo.guru99.com/selenium/guru99home/");  
			String title = "Guru99";				 
			System.out.println(title);
			System.out.println("Sharath");
//			Assert.assertTrue(title.contains("Demo Guru99 Page")); 	
			DesiredCapabilities capability=null;
			try{
			capability = DesiredCapabilities.chrome();
				capability.setPlatform(Platform.XP);
				capability.setBrowserName("chrome");	
			}catch(Exception e){
				System.out.println("Failed to set capabilities");
			}
			
			
			WebDriver driver;
			try {
				System.setProperty("webdriver.chrome.driver", "D://Hub_Node_Folder//Selenium_Grid_New//chromedriver.exe");
				driver = new RemoteWebDriver(new URL("http://10.211.101.9:6464/wd/hub"), capability);
				driver.get("http://www.google.com");

		        Actions action = new Actions(driver);
		 WebElement element=null;
		        action.moveToElement(element).build().perform();
		        
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Failed to start the driver");
			}
		

			
		}	
		/*@BeforeTest
		public void beforeTest() {	
			System.out.println("Testing");
//			System.setProperty("webdriver.chrome.driver", "D://Hub_Node_Folder//Selenium_Grid_New//chromedriver.exe");
//		    driver = new ChromeDriver();  
			System.setProperty("webdriver.ie.driver", "D://Hub_Node_Folder//Selenium_Grid_New//IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}		
		@AfterTest
		public void afterTest() {
//			driver.quit();			
			System.out.println("After Test");
		}		*/
}
import org.openqa.selenium.WebDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AdminStepDef {
	

	@Given("^launch the RFM application$")
	public void launch_the_RFM_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^Enter the username & password$")
	public void enter_the_username_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^Select Market$")
	public void select_Market() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Navigate Restaurant Profile$")
	public void navigate_Restaurant_Profile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^click on restaurant number link$")
	public void click_on_restaurant_number_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^click on Operation Details Tab$")
	public void click_on_Operation_Details_Tab() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^select order total discount Set and click on View/Edit Settings$")
	public void select_order_total_discount_Set_and_click_on_View_Edit_Settings() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^click on Customize settings and Enter the new value for Amount percentage$")
	public void click_on_Customize_settings_and_Enter_the_new_value_for_Amount_percentage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user save the changes after click on Apply button$")
	public void user_save_the_changes_after_click_on_Apply_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^click on cancel button and go back to Operation Details page$")
	public void click_on_cancel_button_and_go_back_to_Operation_Details_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}

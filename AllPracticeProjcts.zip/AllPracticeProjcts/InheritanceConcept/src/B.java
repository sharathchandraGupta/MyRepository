
public class B extends A{

	public static void main(String[] args) {
		
		System.out.println("sharath");
		System.out.println(strA);

	}

}


public class A {
	
	int a=10;
	public String strA=null;
	
	public void methodA(){
		strA = "SharathA";
		
	}

}

import java.util.Iterator;
import java.util.LinkedList;

import org.testng.Assert;
import org.testng.annotations.Test;


public class E {
	@Test
	public void nameE() {
		System.out.println("AM in E");
		Assert.assertEquals("Sharath", "Sharath");
	
		
	
	}
	
	
	
	
 	
}

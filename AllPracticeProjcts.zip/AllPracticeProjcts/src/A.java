import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;


public class A{
	@Test
	public void nameA() {
		System.out.println("Am in A");
//		Assert.assertEquals("Bharath", "Sharath");
	}
	@BeforeTest
	public void nameBT() {
		System.out.println("Am in BT");
		Assert.assertEquals("Bharath", "Sharath");
		Assert.assertEquals("sgar", "etst");
		
	}
	
	@AfterTest
	public void nameAT() {
		System.out.println("Am in AT");
//		Assert.assertEquals("Bharath", "Sharath");
	}
	
	@BeforeSuite
	public void nameBS() {
		System.out.println("Am in BS");
//		Assert.assertEquals("Bharath", "Sharath");
	}
	
}

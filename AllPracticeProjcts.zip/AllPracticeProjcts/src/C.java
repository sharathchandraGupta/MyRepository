import org.testng.Assert;
import org.testng.annotations.Test;

//(retryAnalyzer = RetryAnalyzer.class)
public class C {
	@Test
	public void nameC() {
		System.out.println("Am in C");
		Assert.assertEquals("Sharath", "Sharath");
	
	
	}

}

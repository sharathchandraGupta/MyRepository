package Listener;

import java.util.List;

import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.xml.XmlSuite;

public class IReporter_Class implements IReporter{

	@Override
	public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {
		int i = 0;
		System.out.println(xmlSuites.size() +": xmlSuiteSize");
		System.out.println(xmlSuites.get(i).getName() +": xmlSuiteNamed");
		
	
		System.out.println(suites.get(i).getName());
		
	}

}

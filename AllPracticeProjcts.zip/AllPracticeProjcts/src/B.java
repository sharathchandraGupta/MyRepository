
import org.testng.annotations.Test;

import junit.framework.Assert;

public class B {
 
  @Test (dependsOnMethods = { "OpenBrowser" })
 
  public void SignIn() {
 
	  System.out.println("This will execute second (SignIn)");
 
  }
 
  @Test
 
  public void OpenBrowser() {
 
	  Assert.assertEquals("Bharath", "Sharath");
 
  }
 
  @Test (dependsOnMethods = { "SignIn" })
 
  public void LogOut() {
 
	  System.out.println("This will execute third (Log Out)");
 
  }

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class ReadingValuesFormExcel {
	public static void main(String[] args) {
		try {
			String path = "D://Users//shagade//Desktop//MyPersonalDocs//TestCase.xlsx";
			FileInputStream inputstream = new FileInputStream(new File(path));
			
			
			
			XSSFWorkbook workbook = new XSSFWorkbook(inputstream);
//			XSSFSheet sheet_WithIndex = workbook.getSheetAt(0);
			// or
			XSSFSheet sheet_WithIndex = workbook.getSheet("Sheet1");
			int no_Sheets = workbook.getNumberOfSheets();
			
				

			int rowCount = sheet_WithIndex.getLastRowNum();
			
			System.out.println(rowCount);
			
		
			int columnCount = sheet_WithIndex.getRow(0).getLastCellNum();
			System.out.println(columnCount);
			
			for (int i = 0; i <=rowCount; i++) {
				for (int j = 0; j <=columnCount; j++) {
					try {
//						System.out.println(sheet_WithIndex.getRow(i).getCell(j).getStringCellValue());
						
						sheet_WithIndex.getRow(i).getCell(j).getStringCellValue();
						
						
						
					} catch (Exception e) {
						try{
							System.out.println(sheet_WithIndex.getRow(i).getCell(j).getNumericCellValue());
							
						}catch(Exception ea){
							
						}
						
					}
				}
			}
		} catch (Exception e) {
		}
	}
}

package Reporting;

public class GenerateReports {
//	ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("extent.html");
}

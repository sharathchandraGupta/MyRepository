import org.testng.Assert;
import org.testng.annotations.Test;

//(retryAnalyzer = RetryAnalyzer.class)
public class D {
	@Test
	public void nameD() {
		System.out.println("Am in D");
		Assert.assertEquals("Sharath", "Bharath");
	
	}
	
}

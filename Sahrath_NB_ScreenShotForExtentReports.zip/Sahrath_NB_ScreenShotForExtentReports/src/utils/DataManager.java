package utils;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.apache.poi.openxml4j.opc.OPCPackage;

import net.sourceforge.htmlunit.corejs.javascript.ast.SwitchCase;

public class DataManager {
	static XSSFWorkbook wb = null;
	static XSSFWorkbook wbR = null;
	static XSSFWorkbook rb = null;
	static Sheet sh = null;
	static Sheet shR = null;
	static Sheet rs = null;
	static FileOutputStream out = null;
	public static int rowNumber;

	public DataManager(String fileName, String sheet) {

		try {
			wb = (XSSFWorkbook) WorkbookFactory.create(new FileInputStream(fileName));
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
		}
		sh = wb.getSheet(sheet);
		rowNumber = sh.getPhysicalNumberOfRows();

	}
	
	public static void RaterWorkBook(String fileName, String sheet) {

		try {
//			rb = (XSSFWorkbook) WorkbookFactory.create(new FileInputStream(fileName));
//			Workbook rb = WorkbookFactory.create(new FileInputStream(fileName));
			Workbook rb = WorkbookFactory.create(new FileInputStream(fileName));
//			Sheet sh = wb.getSheet("Rater");
			rs = rb.getSheet(sheet);
//			rb = new XSSFWorkbook(OPCPackage.open(fileName));
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			e.printStackTrace();
		}
	  
		//rowNumber = sh.getPhysicalNumberOfRows();

	}

	public static void writeData(int i, double RaterWorkbookPremium) {
		sh.getRow(i).getCell(3).setCellValue(RaterWorkbookPremium);
		try {
//			out = new FileOutputStream(path);
		} catch (Exception e) {

			e.printStackTrace();
		}
		try {
			wb.write(out);
		} catch (IOException e) {

			e.printStackTrace();
		}
		
	}
	public static void readData(int i) {

		Parameters.TestCaseName = sh.getRow(i).getCell(0).getStringCellValue();
		try{
			Parameters.flag = sh.getRow(i).getCell(1).getStringCellValue();	
		}catch(Exception e){
			Parameters.flag = "N";
			System.out.println("Caught null while retriving the flag value");
		}
		
		
		
//		Parameters.AppPremium = sh.getRow(i).getCell(2).getStringCellValue();
		//Parameters.RaterWorkbookPremium = sh.getRow(i).getCell(3).getStringCellValue();
		//Parameters.Status = sh.getRow(i).getCell(4).getStringCellValue();
//		Parameters.PolicyNumber = sh.getRow(i).getCell(5).getStringCellValue();
		Parameters.TCID = sh.getRow(i).getCell(0).getStringCellValue();
		Parameters.coverage = sh.getRow(i).getCell(6).getStringCellValue();
		Parameters.userName = sh.getRow(i).getCell(7).getStringCellValue();
		Parameters.password = sh.getRow(i).getCell(8).getStringCellValue();
//		Parameters.BuildingPremium = sh.getRow(i).getCell(9).getNumericCellValue();
//		Parameters.ContentsPremium = sh.getRow(i).getCell(10).getNumericCellValue();
//		Parameters.CoverageLimit = sh.getRow(i).getCell(11).getStringCellValue();
		
		Parameters.IndustryCode = sh.getRow(i).getCell(12).getStringCellValue();
		Parameters.customerName = sh.getRow(i).getCell(13).getStringCellValue();
		Parameters.leagalName = sh.getRow(i).getCell(14).getStringCellValue();
		Parameters.isdCode = sh.getRow(i).getCell(15).getStringCellValue();
		Parameters.phoneNumber = sh.getRow(i).getCell(16).getNumericCellValue();
		Parameters.postalCode = sh.getRow(i).getCell(17).getStringCellValue();
		Parameters.ibcCode = sh.getRow(i).getCell(18).getStringCellValue();
		Parameters.revenue = (int) sh.getRow(i).getCell(19).getNumericCellValue();
		Parameters.YearsCurrentInsurer = sh.getRow(i).getCell(119).getStringCellValue();
		try{
			Parameters.brokerName = sh.getRow(i).getCell(20).getStringCellValue();	
		}catch(Exception e){
			Parameters.brokerName = "";	
		}
		Parameters.currentInsurer = sh.getRow(i).getCell(21).getStringCellValue();
		Parameters.yearBusinessEstablished = (int) sh.getRow(i).getCell(22).getNumericCellValue();
		Parameters.fullTimeEmploys = (int) sh.getRow(i).getCell(23).getNumericCellValue();
		Parameters.NewVenture = sh.getRow(i).getCell(35).getStringCellValue();
		Parameters.commercialProperty = sh.getRow(i).getCell(24).getStringCellValue();
		Parameters.inlandMarineInput = sh.getRow(i).getCell(25).getStringCellValue();
		Parameters.businessInterruptionInput = sh.getRow(i).getCell(26).getStringCellValue();
		Parameters.liability = sh.getRow(i).getCell(27).getStringCellValue();		
		Parameters.propertyLiabilityClaims = sh.getRow(i).getCell(28).getStringCellValue();
		Parameters.typeOfConstruction = sh.getRow(i).getCell(29).getStringCellValue();
		Parameters.noOfStoreys = (int) sh.getRow(i).getCell(30).getNumericCellValue();
		Parameters.yearBuilt = (int) sh.getRow(i).getCell(31).getNumericCellValue();
		Parameters.area = (int) sh.getRow(i).getCell(32).getNumericCellValue();
		
		try {
			Parameters.BuildingLimit = (int) sh.getRow(i).getCell(33).getNumericCellValue();
		} catch (Exception e1) {
			Parameters.BuildingLimit = 0;
		}
		
		Parameters.MultiLinePolicy = sh.getRow(i).getCell(97).getStringCellValue();
		try{
			Parameters.BusinessPersonalProperty = (int) sh.getRow(i).getCell(34).getNumericCellValue();	
		}catch(Exception e){
			Parameters.BusinessPersonalProperty = 0;
		}
		 
		try {					
			Parameters.CommercialAutoCurrentInsurer = sh.getRow(i).getCell(36).getStringCellValue();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		try {
			Parameters.PowerUnits = sh.getRow(i).getCell(37).getStringCellValue();			
		} catch (Exception e) {

		}
		
		/*Parameters.Vehicle_CV_Count = (int) sh.getRow(i).getCell(38).getNumericCellValue();
		Parameters.Vehicle_NonOwned_Count = (int) sh.getRow(i).getCell(39).getNumericCellValue();		
		Parameters.CV_Year = sh.getRow(i).getCell(41).getStringCellValue();
		Parameters.CV_Make = sh.getRow(i).getCell(42).getStringCellValue();
		Parameters.CV_Model = sh.getRow(i).getCell(43).getStringCellValue();
		Parameters.CV_VehicleType = sh.getRow(i).getCell(44).getStringCellValue();
		Parameters.CV_TypeOfCommercialUse = sh.getRow(i).getCell(45).getStringCellValue();
		Parameters.CV_CommoditiesCarried = sh.getRow(i).getCell(46).getStringCellValue();
		Parameters.CV_ToolsAndEquipmentOnly = sh.getRow(i).getCell(47).getStringCellValue();
		Parameters.CV_RadiusOfOperation = sh.getRow(i).getCell(48).getStringCellValue();
		Parameters.CV_ListPriceNew = sh.getRow(i).getCell(49).getStringCellValue();
		Parameters.CV_Trailer_PulledBy = sh.getRow(i).getCell(85).getStringCellValue();
		Parameters.CV_Trailer_LocationOfUse = sh.getRow(i).getCell(86).getStringCellValue();*/
		Parameters.PurchaseDate = sh.getRow(i).getCell(118).getStringCellValue();
		
	/*	//Fetching NonOwned Details
		Parameters.Non_VehicleType = sh.getRow(i).getCell(81).getStringCellValue();
		Parameters.Non_TypeOfCommercialUse = sh.getRow(i).getCell(82).getStringCellValue();
		Parameters.Non_CommoditiesCarried = sh.getRow(i).getCell(83).getStringCellValue();
		Parameters.Non_RadiusOfOperation = sh.getRow(i).getCell(84).getStringCellValue();
		Parameters.Non_Trailer_PulledBy = sh.getRow(i).getCell(87).getStringCellValue();
		Parameters.Non_Trailer_LocationOfUse = sh.getRow(i).getCell(88).getStringCellValue();
		Parameters.Non_VehicleWeight = sh.getRow(i).getCell(89).getStringCellValue();
		*/
		
		//Fetching Driver Details form Excel
		Parameters.FirstName = sh.getRow(i).getCell(50).getStringCellValue();
		Parameters.LastName = sh.getRow(i).getCell(51).getStringCellValue();
		Parameters.MiddleName = sh.getRow(i).getCell(52).getStringCellValue();
		Parameters.Gender = sh.getRow(i).getCell(53).getStringCellValue();
		Parameters.DateOfBirth = sh.getRow(i).getCell(54).getStringCellValue();
		Parameters.MaritalStatus = sh.getRow(i).getCell(55).getStringCellValue();
		Parameters.Province = sh.getRow(i).getCell(56).getStringCellValue();
		try {
			Parameters.LicenseNumber = sh.getRow(i).getCell(57).getStringCellValue();
		} catch (Exception e) {
			// TODO: handle exception
		}
		Parameters.LicenseClass = sh.getRow(i).getCell(58).getStringCellValue();
		Parameters.DateAchieved = sh.getRow(i).getCell(59).getStringCellValue();
//		Parameters.DriverID = sh.getRow(i).getCell(60).getStringCellValue();
		Parameters.Assignment = sh.getRow(i).getCell(61).getStringCellValue();
		
		Parameters.AddConvention = sh.getRow(i).getCell(101).getStringCellValue();
		Parameters.AddConvention_Desc_Type = sh.getRow(i).getCell(102).getStringCellValue();
		Parameters.AddConvention_Date = sh.getRow(i).getCell(103).getStringCellValue();
		Parameters.Driver_ReTraining = sh.getRow(i).getCell(104).getStringCellValue();
		Parameters.StudentawayfromHome = sh.getRow(i).getCell(105).getStringCellValue();
		
		
		//PPV Vehicle parameters
		Parameters.Vehicle_PPV_Count = (int) sh.getRow(i).getCell(40).getNumericCellValue();
		Parameters.PPV_Year= sh.getRow(i).getCell(90).getStringCellValue();
		Parameters.PPV_Make= sh.getRow(i).getCell(91).getStringCellValue();
		Parameters.PPV_Model= sh.getRow(i).getCell(92).getStringCellValue();
		Parameters.WinterTires= sh.getRow(i).getCell(98).getStringCellValue();
		try{
			Parameters.MonthsInUS = sh.getRow(i).getCell(99).getStringCellValue();	
		}catch(Exception e){
			Parameters.MonthsInUS = "";
		}
		try{
			Parameters.RightHandDrive = sh.getRow(i).getCell(100).getStringCellValue();	
		}catch(Exception e){
			Parameters.RightHandDrive = "";
		}
		
		Parameters.PPV_RateByValue= sh.getRow(i).getCell(115).getStringCellValue();;
		Parameters.PPV_VehicleValue= sh.getRow(i).getCell(116).getStringCellValue();;		
		
		Parameters.HouseHold = sh.getRow(i).getCell(67).getStringCellValue();
		Parameters.OwnerShipType = sh.getRow(i).getCell(68).getStringCellValue();
		Parameters.LocationOfUse = sh.getRow(i).getCell(69).getStringCellValue();
		Parameters.AnnualKilometers = sh.getRow(i).getCell(70).getStringCellValue();
		Parameters.DrivingBusinessUse_Percentage = sh.getRow(i).getCell(71).getStringCellValue();
		Parameters.DailyKMOneWay = sh.getRow(i).getCell(72).getStringCellValue();
		Parameters.VehicleValue = sh.getRow(i).getCell(73).getStringCellValue();
		

		
		Parameters.NonOwnedInput_Type = sh.getRow(i).getCell(74).getStringCellValue();
		Parameters.SameUseClassAs = sh.getRow(i).getCell(75).getStringCellValue();
		Parameters.ExposureDays = sh.getRow(i).getCell(76).getStringCellValue();
		Parameters.Limit = sh.getRow(i).getCell(77).getStringCellValue();
		Parameters.DriversToBeAdded = (int) sh.getRow(i).getCell(78).getNumericCellValue();
		
		//For Driver Assignment
		Parameters.Vehicles_For_Driver_Assignment = sh.getRow(i).getCell(93).getStringCellValue();		
		Parameters.No_Driver_Assignment = sh.getRow(i).getCell(94).getStringCellValue();
		Parameters.Driver_Assignment = sh.getRow(i).getCell(95).getStringCellValue();		
		Parameters.Assignment_ForDriver = sh.getRow(i).getCell(96).getStringCellValue();
		
		
		/*//For Claims
		Parameters.No_of_Claims_ToBeAdded = (int)sh.getRow(i).getCell(106).getNumericCellValue();
		Parameters.Claim_Date= sh.getRow(i).getCell(107).getStringCellValue();
		Parameters.Claim_Desc_Of_Loss= sh.getRow(i).getCell(108).getStringCellValue();
		Parameters.Claim_Vehicle= sh.getRow(i).getCell(109).getStringCellValue();
		Parameters.Claim_AssignLoss= sh.getRow(i).getCell(110).getStringCellValue();
		Parameters.Claim_TotalPaid= sh.getRow(i).getCell(111).getStringCellValue();
		Parameters.Claim_Reserve= sh.getRow(i).getCell(112).getStringCellValue();
		Parameters.Claim_Reserve_Type= sh.getRow(i).getCell(113).getStringCellValue();
		Parameters.Claim_Driver=sh.getRow(i).getCell(114).getStringCellValue();*/
		
		//For Coverage
//		Parameters.Additional_Endorsment_Coverages = sh.getRow(i).getCell(117).getStringCellValue();
		
		//For Class Vehicle
		Parameters.Expected_Class = sh.getRow(i).getCell(3).getStringCellValue();
		
	}

	public static String readData(int rowNumber, int cellNumber) {
		String cellValue = null;
		try {
			cellValue = sh.getRow(rowNumber).getCell(cellNumber).getStringCellValue();

		} catch (Exception e) {
		}

		return cellValue;
	}
	
public static void writeRateBook(String path, int row, int cell, String value) {
		
	rs.getRow(row).createCell(cell).setCellValue(value);
		try {
			out = new FileOutputStream(path);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		try {
			rb.write(out);
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

public static void writeData_ResultSheet(String path, int row, int cell, String value, String SheetName){
	try {
		wbR = (XSSFWorkbook) WorkbookFactory.create(new FileInputStream(path));
	} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
		e.printStackTrace();
	}
	shR = wb.getSheet(SheetName);
//	rowNumber = sh.getPhysicalNumberOfRows();	
	shR.getRow(row).createCell(cell).setCellValue(value);		

	try {
		out = new FileOutputStream(path);
	} catch (FileNotFoundException e) {

		e.printStackTrace();
	}
	try {
		wbR.write(out);
	} catch (IOException e) {

		e.printStackTrace();
	}
	
}

	public static void writeData(String path, int row, int cell, String value) {
		
		sh.getRow(row).createCell(cell).setCellValue(value);		

		try {
			out = new FileOutputStream(path);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		try {
			wb.write(out);
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	public static void closeWorkBook() {
		try {
			wb.close();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void openFile(String path) {
		File file = new File(path);

		if (!Desktop.isDesktopSupported()) {
			System.out.println("Desktop is not supported");
			return;
		}

		Desktop desktop = Desktop.getDesktop();
		if (file.exists())
			try {
				desktop.open(file);
			} catch (IOException e) {

				e.printStackTrace();
			}

	}
	
	
	
	


}

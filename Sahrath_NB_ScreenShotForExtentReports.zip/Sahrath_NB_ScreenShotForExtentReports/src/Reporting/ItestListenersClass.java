
package Reporting;
import org.w3c.dom.events.Event;
import org.w3c.dom.events.EventListener;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class ItestListenersClass implements EventListener  {
	
	ListenersImplemention obj = new ListenersImplemention();
	ExtentReports extent;
	ExtentTest test;
	@Override
	public void handleEvent(Event arg0) {
		System.out.println("Sharath");
	}

	


}

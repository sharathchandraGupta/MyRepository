package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Coverage {
	WebDriver driver;
	public Coverage( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);		
	}

	@FindBy(how=How.XPATH,using="//a[contains(text(),'Coverage')]")
	public WebElement CoverageTab;
	
	@FindBy(how=How.XPATH,using="//*[@class='toggleHeaderInner'][contains(text(),'PROPERTY')]")
	public WebElement PROPERTYHeader;
	
	@FindBy(how=How.XPATH,using="//*[@class='toggleHeaderInner'][contains(text(),'Commercial Property')]")
	public WebElement CommercialPropertyHeader;
	
	@FindBy(how=How.XPATH,using="//*[@class='toggleHeaderInner'][contains(text(),'Extensions')]")
	public WebElement ExtensionsHeader;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAutomaticBlanketCoverageExtensionInput.Limit']")
	public WebElement  CoverageExtensionInput;	

	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.LiabilityIndicator']")
	public WebElement  LiabilityIndicator;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov4AExplosivePermissionInput.Indicator']")
	public WebElement  Cov4AExplosivePermission;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov4BRadioactiveMatPermissionInput.Indicator']")
	public WebElement  Cov4BRadioactiveMatPermission;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov13CLimitationGlassInput.Indicator']")
	public List<WebElement>  Cov13CLimitationGlass;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov16SuspensionInput.Indicator']")
	public List<WebElement>  Cov16Suspension;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov19LimitAmtIndemnityInput.Indicator']")
	public WebElement  Cov19LimitAmtIndemnity;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov19AAgreedValueInput.Indicator']")
	public WebElement  Cov19AAgreedValue;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov38AgrIncrLimitElectEqptInput.Indicator']")
	public WebElement  Cov38AgrIncrLimitElectEqpt;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov40FireTheftDedInput.Indicator']")
	public List<WebElement>  Cov40FireTheftDed;
	
	
}

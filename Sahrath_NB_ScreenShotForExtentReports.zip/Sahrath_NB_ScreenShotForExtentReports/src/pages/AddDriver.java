package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AddDriver {
	
	WebDriver driver;
	public AddDriver( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);	
	}

		
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Add Driver')]")
	public WebElement AddDriver;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='DriverInput.FirstName']")
	public WebElement FirstName;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='DriverInput.LastName']")
	public WebElement LastName;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='DriverInput.MiddleName']")
	public WebElement MiddleName;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='DriverInput.Gender']")
	public WebElement Gender;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='DriverInput.DateOfBirth']")
	public WebElement DateOfBirth;
	
	@FindBy(how=How.XPATH,using= "//*[@fieldref='LicenseDetailInput.Province']")
	public WebElement Province;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LicenseDetailInput.Number']")
	public WebElement LicenseNumber;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LicenseDetailInput.Class']")
	public WebElement LicenseClass;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='DriverInput.MaritalStatus']")
	public WebElement MaritalStatus;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='LicenseDetailInput.DateAchieved']")
	public WebElement DateAchieved;
	
	@FindBy(how=How.XPATH,using="//img[@class='g-btn-img-loneIcon'][@data-tip='Add Conviction']")
	public WebElement Add_Conviction;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='ConvictionInput.Code']")
	public List<WebElement> ConvictionInput_Code;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='ConvictionInput.ConvictionDate']")
	public List<WebElement> ConvictionInput_ConvictionDate;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='DriverInput.Retraining'][@value='1']")
	public WebElement DriverInput_Retraining_Yes;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='DriverInput.Retraining'][@value='0']")
	public WebElement DriverInput_Retraining_No;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='DriverInput.StudentAwayFromHome'][@value='1']")
	public WebElement DriverInput_StudentAwayFromHome_Yes;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='DriverInput.StudentAwayFromHome'][@value='0']")
	public WebElement DriverInput_StudentAwayFromHome_No;
			
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Save')]")
	public WebElement Save;
	
	
};

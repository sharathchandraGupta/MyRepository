package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Premium {
	
	WebDriver driver;
	public Premium( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}

	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.QuotePremium']")
	public WebElement quotePremium;
	
	@FindBy(how=How.XPATH,using="//*[contains(text(),'Approve')]")
	public WebElement getTownGrade;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAutomaticBlanketCoverageExtensionInput.Limit']")
	public WebElement CoverageLimit;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAutomaticBlanketCoverageExtensionOutput.CalculatedPremium']")
	public WebElement CoveragePremium;
	
	@FindBy(how=How.XPATH,using="//span[text()='Auto']")
	public WebElement Auto;
	
	@FindBy(how=How.XPATH,using="//div[text()='Auto']")
	public WebElement AutoPremium;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Back to Premium Summary')]")
	public WebElement Back_to_Premium_Summary;
	
	@FindBy(how=How.XPATH,using="//label[contains(text(),'Calculated Premium')]/parent::div/parent::div/div[2]/div/div")
	public WebElement Capture_CalculatedPremium;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Quote')]")
	public WebElement quote_Button;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Bind')]")
	public WebElement bind_Button;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Book')]")
	public WebElement book_Button;
	
	
	
	
	
	
	
	
};

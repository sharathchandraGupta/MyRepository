package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;



public class VehicleClass_Verification {

	WebDriver driver;
	public VehicleClass_Verification( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}

	@FindBy(how=How.XPATH,using="//*[text()='Vehicle']")
	public WebElement Vehicle_Button;
	
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Add Vehicle')]")
	public WebElement AddVehicle;
	
	@FindBy(how=How.XPATH,using="//table[@class='x-grid3-row-table']/tbody/tr/td[7]/div/a")
	public List<WebElement>  Vehicles_EditButtons;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.VehicleClassDisplay']")
	public WebElement  VehicleClass;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Save')]")
	public WebElement  SaveButton;
	

	
	
	
	
	
}
package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CustomerSearch {
	
	WebDriver driver;
	public CustomerSearch( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}

	@FindBy(how=How.XPATH,using="//*[@id='id_Search']/span")
	public WebElement advanceSearch;
		
	@FindBy(how=How.XPATH,using="//*[@id='pageTitle']")
	public WebElement advanceSearchPage;
		
	@FindBy(how=How.XPATH,using="//*[@id='_clientOption']")
	public WebElement customerSelect;
	
	@FindBy(how=How.XPATH,using="//*[@id='_keyvalueTextSearch1']")
	public WebElement customerName;
	
	@FindBy(how=How.XPATH,using="//*[@id='searchFilterActions']/a/div[2]/span")
	public WebElement search;
	
	@FindBy(how=How.XPATH,using="//*[@name='createClient']")
	public WebElement createNewClient;
	
	@FindBy(how=How.XPATH,using="//*[@id='policyEffectiveDate']")
	public WebElement enterDate;
	
	@FindBy(how=How.XPATH,using="//*[@id='saveButton']/tbody/tr[2]/td[2]")
	public WebElement ok;
	
	//Verify the customer page 
		@FindBy(how=How.XPATH,using="//*[@id='pageTitle']")
		public WebElement pageTitle;

	
};

package pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Additional_Interest {
	WebDriver driver ;

	public Additional_Interest(WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(webdriver, this);
		}

	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Next')]")
	public WebElement Next_Button;
	
	
	
	
	
	
	

	
}

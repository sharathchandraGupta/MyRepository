package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AddVehicle {
	
	WebDriver driver;
	public AddVehicle( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}

		
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Add Vehicle')]")
	public WebElement AddVehicle;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskCommercialAutoInput.CommercialUse']")
	public WebElement CommercialUse;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.VIN']")
	public WebElement VIN;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.VICC']")
	public WebElement VICC;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.Year']")
	public WebElement Year;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.Make']")
	public WebElement Make;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.Model']")
	public WebElement Model;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskCommercialVehicleInput.VehicleType']")
	public WebElement VehicleType;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.PurchaseDate']")
	public WebElement PurchaseDate;
	
	
	@FindBy(how=How.XPATH,using="//img[@class='g-btn-img-loneIcon'][3]")
	public WebElement search;
	
	
	@FindBy(how=How.XPATH,using="//input[@fieldref='RiskVehicleInput.Model']/parent::div/parent::div//parent::div/parent::div/..//img[@data-tip='Search']")
	public WebElement search_Vehicle;
	
	
	
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Select')]")
	public WebElement Select;	
	
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Add')]")
	public WebElement Add;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskCommercialVehicleInput.TypeOfCommercialUse']")
	public WebElement TypeOfCommercialUse;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskCommercialVehicleInput.CommoditiesCarried']")
	public WebElement CommoditiesCarried;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskCommercialVehicleInput.ToolsAndEquipmentOnly']")
	public WebElement ToolsAndEquipmentOnly;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskCommercialVehicleInput.RadiusOfOperation']")
	public WebElement RadiusOfOperation;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskCommercialVehicleInput.ListPriceNew']")
	public WebElement ListPriceNew;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskPPVInput.AnnualKM']")
	public WebElement AnnualKilometers;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskPPVInput.DrivingBusinessUse']")
	public WebElement DrivingBusinessUse_Percentage;
	
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskPPVInput.DailyKMOneWay']")
	public WebElement DailyKMOneWay;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.VehicleValue']")
	public WebElement VehicleValue;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.HouseHold']")
	public WebElement HouseHold;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.OwnershipType']")
	public WebElement OwnershipType;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.LeasedDate']")
	public WebElement LeasedDate;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.LocationOfUse']")
	public WebElement LocationOfUse;
	
	@FindBy(how=How.XPATH,using="//input[@value='NonOwned']")
	public WebElement LookupType_NonOwned;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskNonOwnedInput.Type']")
	public WebElement NonOwnedInput_Type;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskNonOwnedInput.SameUseClassAs']")
	public WebElement SameUseClassAs;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskNonOwnedInput.ExposureDays']")
	public WebElement ExposureDays;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskNonOwnedInput.Limit']")
	public WebElement Limit;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskPPVInput.WinterTire'][@value='1']")
	public WebElement RiskPPVInput_WinterTire_Yes;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskPPVInput.WinterTire'][@value='0']")
	public WebElement RiskPPVInput_WinterTire_No;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskPPVInput.RightHandDrive'][@value='0']")
	public WebElement RiskPPVInput_RightHandDrive_Yes;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskPPVInput.RightHandDrive'][@value='1']")
	public WebElement RiskPPVInput_RightHandDrive_No;
	
	@FindBy(how=How.XPATH,using="//div[contains(text(),'Additional Information')]")
	public WebElement Additional_Information;
	
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskVehicleInput.RateByValue']")
	public WebElement RateByValue;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='RiskPPVInput.MonthsInUS']")
	public WebElement RiskPPVInput_MonthsInUS;
	
	
	@FindBy(how=How.XPATH,using="//*[text()='Rate Groups']/../../following-sibling::div[1]/div/label[text()='AB']")
	public WebElement RateGroups;
	
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Save')]")
	public WebElement Save;
	
	
	
	
	
};

package modules;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import utils.DataManager;
import utils.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import Reporting.Reports;
import utils.Reusable_Methods;

public class Premium {
	WebDriver driver;
	pages.Premium p;
	ExtentTest test;
	String path;
	
	
	public Premium(WebDriver webdriver, ExtentTest test1) {
		driver=webdriver;
		
		p=new pages.Premium(driver);
		path = "\\\\NBFC.COM\\departments\\QA\\Northbridge_QA\\IRCA_Rate_Testing_PPV\\RateTesting\\TestData\\InputDataSheet.xlsx";
		test = test1;
		
	}
	String BuildingPremium=null;
	public void Premium(int row) throws InterruptedException{		
		try {
			
			Reusable_Methods RM = new Reusable_Methods(driver);						
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,1500)");

			try{
				if(driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Approve')]")).isDisplayed()){
					driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Approve')]")).click();
					Thread.sleep(2000);
					driver.findElement(By.xpath("//button[text()='Yes']")).click();
					Thread.sleep(6000);
				}
			}catch(Exception e){
				System.out.println("Approve button not displayed");
			}
									
			p.Auto.click();
			
			// VerfiySubmissionPage
			boolean flag = false;
			flag = RM.verify_PageTitle(driver, "Auto Premium");
			try {
				Assert.assertEquals(flag, true);
				test.pass("Sucessfully Navigated to Auto Premium Page");
				System.out.println("Sucessfully Navigated to Auto Premium Page");
			} catch (AssertionError e) {
				System.out.println("Failed to Navigate to Auto Premium page");
				e.printStackTrace();
				test.fail("Failed to Navigate Auto Premium Page");			
			}	
			
			p.AutoPremium.click();
			Thread.sleep(1000);;
			String calculated_Premeum = p.Capture_CalculatedPremium.getText();
			
			//call the write method to with write the capture premium to input sheet
			DataManager.writeData(path,row,2, calculated_Premeum);			
			p.Back_to_Premium_Summary.click();
			
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(p.quote_Button));
			Thread.sleep(1000);
			p.quote_Button.click();
			wait.until(ExpectedConditions.visibilityOf(p.bind_Button));
			Thread.sleep(1000);
			try{
				p.bind_Button.click();
				driver.findElement(By.xpath("//button[text()='Yes']")).click();
				wait.until(ExpectedConditions.visibilityOf(p.book_Button));
				Thread.sleep(1000);
				p.book_Button.click();
			}catch(Exception bind){
				System.out.println("Failed to Bind");
			}	
			
			js.executeScript("window.scrollBy(0,1500)");
			driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
			Thread.sleep(6000);
		} catch (Exception e) {
			System.out.println("Failed to Add Premium Details");
			e.printStackTrace();
		}
	}				
}

package modules;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.Parameters;

public class ClaimInfo {
	WebDriver driver;
	pages.ClaimInfo c;

	public ClaimInfo(WebDriver webdriver) {
		driver = webdriver;
		c = new pages.ClaimInfo(driver);

	}
	
	public void ClaimInfo() throws InterruptedException {
		try {
			for (int claims = 0; claims < Parameters.No_of_Claims_ToBeAdded; claims++) {

				WebDriverWait wait = new WebDriverWait(driver, 20);
				wait.until(ExpectedConditions.visibilityOf(c.AddClaim));
				Thread.sleep(2000);
				c.AddClaim.click();
				try {
					driver.switchTo().frame(0);
				} catch (Exception e) {

				}
				c.Next.click();

				c.DateofLoss.sendKeys(Parameters.Claim_Date.split("#")[claims]);
				Thread.sleep(1000);
				c.DateofLoss.sendKeys(Keys.TAB);

				c.DescriptionofLoss.sendKeys(Parameters.Claim_Desc_Of_Loss.split("#")[claims]);
				c.DescriptionofLoss.sendKeys(Keys.TAB);

				c.ClaimInputVehicle.sendKeys(Parameters.Claim_Vehicle.split("#")[claims]);
				c.ClaimInputVehicle.sendKeys(Keys.TAB);

				try {
					if (c.ClaimInputDriver.isDisplayed()) {
						c.ClaimInputDriver.sendKeys(Parameters.Claim_Driver);
					}
				} catch (Exception e) {

				}

				c.AssignLoss.sendKeys(Parameters.Claim_AssignLoss.split("#")[claims]);
				c.AssignLoss.sendKeys(Keys.TAB);

				c.TotalPaid.clear();
				c.TotalPaid.sendKeys(Parameters.Claim_AssignLoss.split("#")[claims]);
				c.TotalPaid.sendKeys(Keys.TAB);

				c.Reserve.clear();
				c.Reserve.sendKeys(Parameters.Claim_Reserve.split("#")[claims]);
				c.Reserve.sendKeys(Keys.TAB);

				c.RatingType.sendKeys(Parameters.Claim_Reserve_Type.split("#")[claims]);
				c.RatingType.sendKeys(Keys.TAB);

				c.OK.click();
				Thread.sleep(4000);
				try {
					driver.switchTo().defaultContent();
				} catch (Exception e) {

				}

			}
		} catch (Exception e) {
			System.out.println("Failed to create claim");
			e.printStackTrace();
		}
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1500)");
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
		Thread.sleep(8000);
	
	}

}

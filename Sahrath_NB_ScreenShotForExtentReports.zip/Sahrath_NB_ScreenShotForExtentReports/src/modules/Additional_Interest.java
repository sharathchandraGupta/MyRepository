package modules;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import utils.Parameters;

public class Additional_Interest {
	
	Parameters parameter = new Parameters();
	WebDriver driver;
	pages.Additional_Interest Add_Int;
	ExtentReports extent;
	ExtentTest test;
	
	public Additional_Interest(WebDriver webdriver) {
		driver=webdriver;
		Add_Int=new pages.Additional_Interest(driver);
	}
	
	
	public void Additional_Interest() throws InterruptedException
	{	
		Add_Int.Next_Button.click();
		
	}
}



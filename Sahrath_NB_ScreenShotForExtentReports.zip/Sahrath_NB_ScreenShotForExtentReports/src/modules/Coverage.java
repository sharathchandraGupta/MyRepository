package modules;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import utils.Parameters;
import utils.Reusable_Methods;

public class Coverage {
	WebDriver driver;
	pages.Coverage cov;
	Reusable_Methods RM = new Reusable_Methods(driver);

	public Coverage(WebDriver webdriver) {
		driver = webdriver;
		cov = new pages.Coverage(driver);

	}

	public void Coverage() throws InterruptedException {
		/*
		 * cov.CoverageTab.click(); Thread.sleep(3000); boolean flag =
		 * RM.verify_PageTitle(driver, "Coverage"); Assert.assertEquals(flag,
		 * true);
		 * 
		 * JavascriptExecutor js = (JavascriptExecutor) driver;
		 * cov.PROPERTYHeader.click(); // driver.findElement(By.xpath(
		 * "//*[@class='toggleHeaderInner'][contains(text(),'PROPERTY')]")).
		 * click(); Thread.sleep(1000); cov.CommercialPropertyHeader.click();
		 * Thread.sleep(1000);
		 * 
		 * cov.ExtensionsHeader.click(); Thread.sleep(1000);
		 * 
		 * js.executeScript("window.scrollBy(0,800)");
		 * js.executeScript("arguments[0].scrollIntoView(true);",
		 * cov.CoverageExtensionInput); cov.CoverageExtensionInput.clear();
		 * cov.CoverageExtensionInput.sendKeys(Parameters.CoverageLimit.toString
		 * ()); Thread.sleep(1000);
		 * cov.CoverageExtensionInput.sendKeys(Keys.TAB); Thread.sleep(2000);
		 * js.executeScript("window.scrollBy(0,1500)"); Thread.sleep(2000);
		 * if(!cov.LiabilityIndicator.isSelected())
		 * cov.LiabilityIndicator.click();
		 * 
		 * driver.findElement(By.xpath(
		 * "//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
		 * Thread.sleep(7000);
		 */
	}

	public void Coverage_New() throws InterruptedException {
		try{
			try {
				cov.CoverageTab.click();
				Thread.sleep(5000); 
				boolean flag = RM.verify_PageTitle(driver, "Coverage"); Assert.assertEquals(flag, true);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			WebElement ele = driver.findElement(By.xpath("//*[text()='AUTO']"));
			ele.click();
						
		}catch(Exception e1){
			e1.printStackTrace();
		}
		
		try {
			List<WebElement> ele_Vechicle = driver.findElements(
					By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/div[13]/table/tbody/tr/td[2]"));
			for (int i = 0; i < ele_Vechicle.size(); i++) {
				
				List<WebElement> ele = driver.findElements(By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/div[13]/table/tbody/tr/td[2]/div[1]"));
				try{
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", ele.get(i));	
					ele.get(i).click();
					driver.findElements(By.xpath("//*[@fieldref='CovTPLDirectCompensationInput.Deductible']")).get(i).sendKeys("500");
					driver.findElements(By.xpath("//*[@fieldref='CovTPLDirectCompensationInput.Deductible']")).get(i).sendKeys(Keys.TAB);
				}catch(Exception e4){
					
				}
				
				Thread.sleep(2000);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", driver.findElements(By.xpath("//*[text()='Additional Endorsements']")).get(i));
				driver.findElements(By.xpath("//*[text()='Additional Endorsements']")).get(i).click();				
				Thread.sleep(1000);
				
				//Call method to select the check boxes
				for(int a=0;a<Parameters.Additional_Endorsment_Coverages.split("#").length;a++){
					select_Checkbox_AdditionEndorsement(Parameters.Additional_Endorsment_Coverages.split("#")[a], i);
					Thread.sleep(2000);
				}				
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getClass());
		}	
		try{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1500)");
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
		Thread.sleep(6000);
	} catch (Exception e) {
		System.out.println("Failed to Add Premium Details");
		e.printStackTrace();
	}
	}
	
	public void select_Checkbox_AdditionEndorsement(String str, int ind){
		try{
			switch (str) {
			case "4A":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov4AExplosivePermission);
				cov.Cov4AExplosivePermission.click();
				Thread.sleep(1000);
				break;
			case "4B":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov4BRadioactiveMatPermission);
				cov.Cov4BRadioactiveMatPermission.click();
				Thread.sleep(1000);
				break;
			case "13C":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov13CLimitationGlass.get(ind));
				cov.Cov13CLimitationGlass.get(ind).click();
				Thread.sleep(1000);
				break;
			case "16":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov13CLimitationGlass.get(ind));
				cov.Cov16Suspension.get(ind).click();
				Thread.sleep(1000);
				break;
			case "19":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov13CLimitationGlass);
				cov.Cov19LimitAmtIndemnity.click();
				Thread.sleep(1000);
				break;
			case "19A":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov13CLimitationGlass);
				cov.Cov19AAgreedValue.click();
				Thread.sleep(1000);
				break;
			case "38":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov13CLimitationGlass);
				cov.Cov38AgrIncrLimitElectEqpt.click();
				Thread.sleep(1000);
				break;
			case "40":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov13CLimitationGlass.get(ind));
				cov.Cov40FireTheftDed.get(ind).click();
				Thread.sleep(1000);
				break;
			}
		}catch(Exception e){
						
		}
		
	}

}

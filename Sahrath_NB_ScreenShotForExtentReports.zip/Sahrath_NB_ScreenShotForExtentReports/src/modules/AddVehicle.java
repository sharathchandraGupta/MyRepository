package modules;

import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;

import utils.Parameters;
import utils.Reusable_Methods;

public class AddVehicle {
	WebDriver driver;
	pages.AddVehicle v;
	Reusable_Methods RM = new Reusable_Methods(driver);
	String Added_Vehicles="";	
	JavascriptExecutor js = (JavascriptExecutor) driver;
	ExtentTest test;
	public AddVehicle(WebDriver webdriver) {
		driver = webdriver;
		v = new pages.AddVehicle(driver);
	}

	public void AddVehicle(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws Exception {
		
		for(int cv =0;cv<Parameters.Vehicle_CV_Count;cv++){
			add_Commercial_Vehicle(cv,docx,run,out);	
			Added_Vehicles = Added_Vehicles +retrive_ValueName();
			
		}
		
		for(int ppv =0;ppv<Parameters.Vehicle_PPV_Count;ppv++){
			add_Private_Passenger_Vehicle(ppv,docx,run,out);	
			Added_Vehicles = Added_Vehicles +retrive_ValueName();
			
		}
		
		for(int NonOwned =0;NonOwned<Parameters.Vehicle_NonOwned_Count;NonOwned++){
			add_NonOwned_Vehicle(NonOwned,docx,run,out);	
			Added_Vehicles = Added_Vehicles +retrive_ValueName();
		}
		System.out.println("All Vehicels that are added so far :"+Added_Vehicles);
		
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView", driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")));	
		RM.captureScreenShot(docx,run,out);	
		
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
		Thread.sleep(8000);
		//*[@class='g-btn-text'][contains(text(),'Add Driver')]
	}
	
	public void add_Commercial_Vehicle(int k, XWPFDocument docx,XWPFRun run,FileOutputStream out) throws InterruptedException {
		try {
			Thread.sleep(3000);
			v.AddVehicle.click();
			Thread.sleep(2000);
			try {
				driver.switchTo().frame(0);
			} catch (Exception e) {

			}
			boolean flag = RM.verify_PageTitle(driver, "Vehicle Lookup Screen");
			try {
				Assert.assertEquals(flag, true);
			} catch (AssertionError e) {
				e.printStackTrace();
				System.out.println("Failed to Navigate to Vehicle Lookup Screen");
			}

			v.CommercialUse.clear();			
			v.CommercialUse.sendKeys("Commercial Vehicle");
			v.CommercialUse.sendKeys(Keys.TAB);
			Thread.sleep(2000);
		
			v.VehicleType.sendKeys(Parameters.CV_VehicleType.split("#")[k]);
			v.VehicleType.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			v.Year.sendKeys(Parameters.CV_Year.split("#")[k]);
			Thread.sleep(1000);	
			v.Make.sendKeys(Parameters.CV_Make.split("#")[k]);
			Thread.sleep(1000);	
			v.Make.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			v.Model.sendKeys(Parameters.CV_Model.split("#")[k]);
			Thread.sleep(1000);	
			v.Model.sendKeys(Keys.TAB);
			Thread.sleep(1000);	
			v.search_Vehicle.click();
			Thread.sleep(3000);
			try {
				driver.switchTo().frame(0);
				driver.findElements(By.className("g-btn-text")).get(0).click();
				Thread.sleep(2000);
				try {
					driver.switchTo().window(" ");
					driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
				} catch (Exception e) {
					driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
				}
				Thread.sleep(3000);
				RM.captureScreenShot(docx,run,out);	
				js.executeScript("window.scrollBy(0,1500)");
				v.Add.click();
			} catch (Exception e) {
				try {
					v.Add.click();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Thread.sleep(3000);

				boolean flag1 = RM.verify_PageTitle(driver, "Commercial Vehicle Details");
				try {
					Assert.assertEquals(flag1, true);
				} catch (AssertionError f) {
					f.printStackTrace();
					System.out.println("Failed to Navigate to Commercial Vehicle Details Screen");
					js.executeScript("window.scrollBy(0,1500)");
				}
				
				if(Parameters.CV_VehicleType.split("#")[k].toUpperCase().contains("TRAILER")){
					driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).clear();
					driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).sendKeys(Parameters.CV_Trailer_PulledBy.trim());
					Thread.sleep(1000);
					driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).sendKeys(Keys.TAB);
					Thread.sleep(2000);
					if(Parameters.CV_Trailer_PulledBy.toUpperCase().contains("OTHER")){
						driver.findElement(By.xpath("//*[@fieldref='RiskCommercialAutoInput.LocationSearch']")).sendKeys(Parameters.CV_Trailer_LocationOfUse);
						
						try {
							driver.findElement(By.xpath("//img[@class='g-btn-img-loneIcon']")).click();							
							Thread.sleep(8000);
						} catch (Exception e1) {
						}
						try {
							driver.switchTo().frame(0);
							driver.findElements(By.className("g-btn-text")).get(0).click();
							Thread.sleep(2000);
							
							try {
								driver.switchTo().window(" ");
								driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
							} catch (Exception es) {
								driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
							}												
							
						} catch (Exception e2) {

						}
					}
				}
				
				v.TypeOfCommercialUse.sendKeys(Parameters.CV_TypeOfCommercialUse.split("#")[k]);
				v.TypeOfCommercialUse.sendKeys(Keys.TAB);
				Thread.sleep(4000);
				try{
					if(v.CommoditiesCarried.isDisplayed()){
					v.CommoditiesCarried.sendKeys(Parameters.CV_CommoditiesCarried.split("#")[k]);
					v.CommoditiesCarried.sendKeys(Keys.TAB);	
					Thread.sleep(3000);
					}
				}catch(Exception e3){
					
				}
				
				
				v.RadiusOfOperation.sendKeys(Parameters.CV_RadiusOfOperation.split("#")[k]);
				v.ListPriceNew.sendKeys(Parameters.CV_ListPriceNew.split("#")[k]);
				RM.captureScreenShot(docx,run,out);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", v.Save);
				v.Save.click();
				driver.switchTo().defaultContent();
				boolean flag2 = RM.verify_PageTitle(driver, "Vehicle");
				try {
					Assert.assertEquals(flag2, true);
				} catch (AssertionError g) {
					g.printStackTrace();
					System.out.println("Failed to Navigate to Vehicle Screen");
				}
			}
		} catch (Exception e) {
			System.out.println("Failed to Add add_Commercial_Vehicle");
			e.printStackTrace();
		}
	}
	
	public void add_Private_Passenger_Vehicle(int ppv, XWPFDocument docx,XWPFRun run,FileOutputStream out) throws InterruptedException{
	
		try {
			Thread.sleep(5000);
			v.AddVehicle.click();
			Thread.sleep(5000);
			try{
				driver.switchTo().frame(0);
			}catch(Exception e){
				
			}
			boolean flag = RM.verify_PageTitle(driver, "Vehicle Lookup Screen");		
			try {
				Assert.assertEquals(flag, true);
			} catch (AssertionError e) {
				e.printStackTrace();
				System.out.println("Failed to Navigate to Vehicle Lookup Screen");
			}
			Thread.sleep(2000);
			v.CommercialUse.sendKeys("Private Passenger Vehicle");		
			v.CommercialUse.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			v.Year.sendKeys(Parameters.PPV_Year.split("#")[ppv]);
			Thread.sleep(1000);
			v.Year.sendKeys(Keys.TAB);
			Thread.sleep(1000);
			v.Make.sendKeys(Parameters.PPV_Make.split("#")[ppv]);
			Thread.sleep(1000);
			v.Make.sendKeys(Keys.TAB);
			Thread.sleep(1000);
			v.Model.sendKeys(Parameters.PPV_Model.split("#")[ppv]);	
			Thread.sleep(1000);
			v.Model.sendKeys(Keys.TAB);
			Thread.sleep(1000);
			v.search_Vehicle.click();
			Thread.sleep(3000);
			try {
				driver.switchTo().frame(0);
				driver.findElements(By.className("g-btn-text")).get(0).click();				
				try {
					driver.switchTo().window(" ");
					driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
				} catch (Exception e) {
					driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
				}
				Thread.sleep(3000);
				js.executeScript("window.scrollBy(0,1500)");
			} catch (Exception e) {
				v.Add.click();
				Thread.sleep(3000);
			}
			Thread.sleep(2000);
			v.HouseHold.sendKeys(Parameters.HouseHold.split("#")[ppv]);
			Thread.sleep(2000);
			v.HouseHold.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date date = new Date();
			String date1 = dateFormat.format(date);
			if(Parameters.OwnerShipType.split("#")[ppv].equalsIgnoreCase("Leased")){
				v.OwnershipType.clear();
				v.OwnershipType.sendKeys(Parameters.OwnerShipType.split("#")[ppv]);
				Thread.sleep(1000);
				v.OwnershipType.sendKeys(Keys.TAB);
				Thread.sleep(3000);						
				try {
					v.LeasedDate.sendKeys(date1);
					v.LeasedDate.sendKeys(Keys.TAB);
					Thread.sleep(1000);
				} catch (Exception e) {
				}
		
			}else{					
				v.OwnershipType.clear();
				Thread.sleep(1000);	
				v.OwnershipType.sendKeys(Parameters.OwnerShipType.split("#")[ppv]);
				Thread.sleep(1000);
				v.OwnershipType.sendKeys(Keys.TAB);
				Thread.sleep(1000);
				try {
					if(v.PurchaseDate.isDisplayed()){
						v.PurchaseDate.sendKeys(Parameters.PurchaseDate.split("#")[ppv]);
					}
				} catch (Exception e) {				
				}
			}
			
			try{												
				if(Parameters.LocationOfUse.split("#")[ppv].split("_")[0].toUpperCase().contains("OTHER")){
					driver.findElement(By.xpath("//*[@fieldref='RiskVehicleInput.LocationOfUse']")).sendKeys(Parameters.LocationOfUse.split("#")[ppv].split("_")[0]);
					Thread.sleep(1000);
					driver.findElement(By.xpath("//*[@fieldref='RiskVehicleInput.LocationOfUse']")).sendKeys(Keys.TAB);
					Thread.sleep(1000);					
					driver.findElement(By.xpath("//*[@fieldref='RiskCommercialAutoInput.LocationSearch']")).sendKeys(Parameters.LocationOfUse.split("#")[ppv].split("_")[1]);
					Thread.sleep(3000);
					try {
						driver.findElement(By.xpath("//img[@class='g-btn-img-loneIcon']")).click();							
						Thread.sleep(4000);
						try {
							driver.switchTo().frame(0);
							driver.findElements(By.className("g-btn-text")).get(0).click();
							Thread.sleep(2000);
							
							try {
								driver.switchTo().window(" ");
								driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
								} catch (Exception es) {
								driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
								}																			
							} catch (Exception e2) {

						}
					} catch (Exception e1) {
					}															
				}else{														
				}				
			}catch(Exception e){
				System.out.println("Failed to add location use details");
			}
			
			Thread.sleep(1000);	
			v.AnnualKilometers.clear();
			Thread.sleep(1000);	
			v.AnnualKilometers.sendKeys(Parameters.AnnualKilometers.split("#")[ppv]);	
			Thread.sleep(1000);
			v.AnnualKilometers.sendKeys(Keys.TAB);
			Thread.sleep(1000);	
			v.DrivingBusinessUse_Percentage.clear();
			Thread.sleep(1000);
			v.DrivingBusinessUse_Percentage.sendKeys(Parameters.DrivingBusinessUse_Percentage.split("#")[ppv]);
			Thread.sleep(1000);		
			
			v.DrivingBusinessUse_Percentage.sendKeys(Keys.TAB);
			Thread.sleep(1000);	
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", v.RiskPPVInput_WinterTire_No);
			if(Parameters.WinterTires.split("#")[ppv].trim().equalsIgnoreCase("YES")){
				v.RiskPPVInput_WinterTire_Yes.click();
			}else{
				v.RiskPPVInput_WinterTire_No.click();
			}
			
			try{
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", v.RateGroups);
			}catch(Exception E){
				
			}
			
			try {
				if(!v.RateGroups.isDisplayed()){
					if(Parameters.PPV_RateByValue.split("#")[ppv].equalsIgnoreCase("YES")){
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", v.RateByValue);
						v.RateByValue.click();
						Thread.sleep(2000);
						v.VehicleValue.sendKeys(Parameters.PPV_VehicleValue.split("#")[ppv]);			
					}
				}
			} catch (Exception e) {
				if(Parameters.PPV_RateByValue.split("#")[ppv].equalsIgnoreCase("YES")){
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", v.RateByValue);
					v.RateByValue.click();
					Thread.sleep(2000);
					v.VehicleValue.sendKeys(Parameters.PPV_VehicleValue.split("#")[ppv]);			
				}
			}
			
			v.DailyKMOneWay.clear();
			Thread.sleep(1000);
			v.DailyKMOneWay.sendKeys(Parameters.DailyKMOneWay.split("#")[ppv]);
			Thread.sleep(1000);
			v.DailyKMOneWay.sendKeys(Keys.TAB);			
			Thread.sleep(1000);
			
			//updated
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", v.Additional_Information);			
			if(!Parameters.MonthsInUS.isEmpty()||!Parameters.RightHandDrive.isEmpty()){
				v.Additional_Information.click();	
				Thread.sleep(1000);
				v.RiskPPVInput_MonthsInUS.clear();
				v.RiskPPVInput_MonthsInUS.sendKeys(Parameters.MonthsInUS.split("#")[ppv]);
				v.RiskPPVInput_MonthsInUS.sendKeys(Keys.TAB);				
				if(Parameters.RightHandDrive.equalsIgnoreCase("Yes")){
					v.RiskPPVInput_RightHandDrive_Yes.click();
				}
			}									
			RM.captureScreenShot(docx,run,out);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", v.Save);
			v.Save.click();
			Thread.sleep(3000);
			boolean flag2 = RM.verify_PageTitle(driver, "Vehicle");
			try {
				Assert.assertEquals(flag2, true);
			} catch (AssertionError g) {
				g.printStackTrace();
				System.out.println("Failed to Navigate to Vehicle Screen");
			}
		} catch (Exception e) {
			System.out.println("Failed to add_Private_Passenger_Vehicle");
			e.printStackTrace();
		}
	}
	
	public void add_NonOwned_Vehicle(int i, XWPFDocument docx,XWPFRun run,FileOutputStream out) throws InterruptedException{
		
		int j=i;
		
		try {
			Thread.sleep(4000);
			v.AddVehicle.click();			
			Thread.sleep(2000);
			try{
				driver.switchTo().frame(0);
			}catch(Exception e){				
			}
			
			boolean flag = RM.verify_PageTitle(driver, "Vehicle Lookup Screen");		
			try {
				Assert.assertEquals(flag, true);
			} catch (AssertionError e) {
				e.printStackTrace();
				System.out.println("Failed to Navigate to Vehicle Lookup Screen");
			}
			
			v.LookupType_NonOwned.click();
			Thread.sleep(1000);		
			v.NonOwnedInput_Type.sendKeys(Parameters.NonOwnedInput_Type.split("#")[j]);
			v.NonOwnedInput_Type.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			
			if(Parameters.SameUseClassAs.equalsIgnoreCase("other")){
				v.SameUseClassAs.sendKeys("Other");
				Thread.sleep(1000);
				v.SameUseClassAs.sendKeys(Keys.TAB);
				Thread.sleep(1000);
				v.ExposureDays.sendKeys(Parameters.ExposureDays.split("#")[j]);
				v.ExposureDays.sendKeys(Keys.TAB);
				Thread.sleep(1000);
				v.VehicleType.sendKeys(Parameters.Non_VehicleType.split("#")[j]);
				v.VehicleType.sendKeys(Keys.TAB);
				Thread.sleep(1000);												
				v.Limit.sendKeys(Parameters.Limit.split("#")[j]);
				v.Limit.sendKeys(Keys.TAB);
				Thread.sleep(1000);
				v.Add.click();
				Thread.sleep(3000);		
				
				//Add Non-Owned Light Commercial Vehicle Details
				boolean flag1 = RM.verify_PageTitle(driver, "Commercial Vehicle Details");
				try {
					Assert.assertEquals(flag1, true);
				} catch (AssertionError f) {
					System.out.println("Failed to Navigate to Commercial Vehicle Details Screen");					
				}
				
				
				try{
					if(driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).isDisplayed()){
					driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).sendKeys(Parameters.CV_Trailer_PulledBy);
					driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).sendKeys(Keys.TAB);
					if(Parameters.Non_Trailer_PulledBy.toUpperCase().contains("OTHER")){
						driver.findElement(By.xpath("//*[@fieldref='RiskCommercialAutoInput.LocationSearch']")).sendKeys(Parameters.Non_Trailer_LocationOfUse);					
						try {
							driver.findElement(By.xpath("//img[@class='g-btn-img-loneIcon']")).click();							
							Thread.sleep(4000);
						} catch (Exception e1) {
						}
						try {
							driver.switchTo().frame(0);
							driver.findElements(By.className("g-btn-text")).get(0).click();
							Thread.sleep(2000);
							
							try {
								driver.switchTo().window(" ");
								driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
								} catch (Exception es) {
								driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
								}																			
							} catch (Exception e2) {

						}
						v.TypeOfCommercialUse.clear();
						v.TypeOfCommercialUse.sendKeys(Parameters.Non_TypeOfCommercialUse.split("#")[j]);
						v.TypeOfCommercialUse.sendKeys(Keys.TAB);
						Thread.sleep(2000);
						v.CommoditiesCarried.sendKeys(Parameters.Non_CommoditiesCarried.split("#")[j]);
						v.CommoditiesCarried.sendKeys(Keys.TAB);
						Thread.sleep(2000);
						v.RadiusOfOperation.sendKeys(Parameters.Non_RadiusOfOperation.split("#")[j]);
						Thread.sleep(2000);
						RM.captureScreenShot(docx,run,out);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", v.Save);
						v.Save.click();
					}else{					
						driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).sendKeys(Parameters.CV_Trailer_PulledBy);
						driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).sendKeys(Keys.TAB);					
						RM.captureScreenShot(docx,run,out);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", v.Save);
						v.Save.click();
					}
					
					}
				}catch(Exception a){
					
				}				

				try {
					if (driver.findElement(By.xpath("//*[@fieldref='RiskCommercialVehicleInput.VehicleWeight']"))
							.isDisplayed()) {
						driver.findElement(By.xpath("//*[@fieldref='RiskCommercialVehicleInput.VehicleWeight']"))
								.sendKeys(Parameters.Non_VehicleWeight);
						driver.findElement(By.xpath("//*[@fieldref='RiskCommercialVehicleInput.VehicleWeight']"))
								.sendKeys(Keys.TAB);
						driver.findElement(By.xpath("//*[@fieldref='RiskCommercialAutoInput.LocationSearch']"))
								.sendKeys(Parameters.Non_Trailer_LocationOfUse);
						try {
							driver.findElement(By.xpath("//img[@class='g-btn-img-loneIcon']")).click();
							Thread.sleep(4000);
						} catch (Exception e1) {
						}
						try {
							driver.switchTo().frame(0);
							((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid red'", driver.findElements(By.className("g-btn-text")).get(0));
							driver.findElements(By.className("g-btn-text")).get(0).click();
							Thread.sleep(2000);

							try {
								driver.switchTo().window(" ");
								driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
							} catch (Exception es) {
								driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
							}
							
							v.TypeOfCommercialUse.clear();
							v.TypeOfCommercialUse.sendKeys(Parameters.Non_TypeOfCommercialUse.split("#")[j]);
							v.TypeOfCommercialUse.sendKeys(Keys.TAB);
							Thread.sleep(2000);
							v.CommoditiesCarried.sendKeys(Parameters.Non_CommoditiesCarried.split("#")[j]);
							v.CommoditiesCarried.sendKeys(Keys.TAB);
							Thread.sleep(2000);
							v.RadiusOfOperation.sendKeys(Parameters.Non_RadiusOfOperation.split("#")[j]);
							RM.captureScreenShot(docx,run,out);
							Thread.sleep(2000);
							((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", v.Save);
							v.Save.click();

						} catch (Exception e2) {

						}
					}
				} catch (Exception a) {

				}								

				Thread.sleep(3000);
				boolean flag2 = RM.verify_PageTitle(driver, "Vehicle");
				try {
					Assert.assertEquals(flag2, true);
				} catch (AssertionError g) {
					System.out.println("Failed to Navigate to Vehicle Screen");
				}				
			}else{
				v.NonOwnedInput_Type.sendKeys(Parameters.NonOwnedInput_Type);
				v.NonOwnedInput_Type.sendKeys(Keys.TAB);
				v.SameUseClassAs.sendKeys(Parameters.SameUseClassAs);
				v.SameUseClassAs.sendKeys(Keys.TAB);
				v.ExposureDays.sendKeys(Parameters.ExposureDays);
				v.Limit.sendKeys(Parameters.Limit);
				v.Add.click();
			}
		} catch (Exception e) {
		System.out.println("Failed to add Non Owned Vehicle");
			e.printStackTrace();
		}
		
	}
	
	
	public String retrive_ValueName(){
		String vehicle="";		
		List <WebElement> ele_Vehicles = driver.findElements(By.xpath("//div[@class='x-panel-body x-panel-body-noheader']//table/tbody/tr/td[1]/div"));
		vehicle = ele_Vehicles.get(ele_Vehicles.size()-1).getText();
		System.out.println("Vehicel Add: "+vehicle);
		return vehicle;
	}
	
}

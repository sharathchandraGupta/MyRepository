package modules;

import java.io.FileOutputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;

import utils.DataManager;
import utils.Parameters;
import utils.Reusable_Methods;



public class VehicleClass_Verification {

	WebDriver driver;
	pages.VehicleClass_Verification vc;
	String str="";
	String V_Cls = null;
	ExtentTest test;
	Reusable_Methods RM; 
	String path_ResultSheet = "\\\\NBFC.COM\\departments\\QA\\Northbridge_QA\\IRCA_Rate_Testing_VechicleClass\\RateTesting\\TestData\\ResultSheet.xlsx";
			

	public VehicleClass_Verification(WebDriver webdriver, ExtentTest test1) {
		driver = webdriver;
		vc = new pages.VehicleClass_Verification(driver);
		test = test1;
		RM = new Reusable_Methods(driver);
	}
	
	public void verify(int row, String path,XWPFDocument docx,XWPFRun run,FileOutputStream out)throws InterruptedException{
	
		
		try{		
			vc.Vehicle_Button.click();
			Thread.sleep(2000);
		
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(vc.AddVehicle));
			Thread.sleep(2000);
			
			for(int i=0;i<vc.Vehicles_EditButtons.size();i++){
				wait.until(ExpectedConditions.visibilityOf(vc.Vehicles_EditButtons.get(i)));
				Thread.sleep(1000);
				vc.Vehicles_EditButtons.get(i).click();								
				try {
					driver.switchTo().frame(0);
				} catch (Exception e){
				}
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", vc.SaveButton);
				Thread.sleep(1000);
				V_Cls = vc.VehicleClass.getText();								
				System.out.println(V_Cls);
				
				DataManager.writeData(path,row, 2, V_Cls);
				
				try {
					System.out.println(Parameters.Expected_Class.trim().contentEquals(V_Cls));
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				if(Parameters.Expected_Class.trim().matches(V_Cls.trim())){
					test.pass("Verify Vehicle Class"+":"+" Expected Vehicle Class:"+Parameters.Expected_Class+" Actual Vehicle Class:"+V_Cls);
					DataManager.writeData(path,row, 4, "Pass");
				}else{
					test.fail("Verify Vehicle Class"+":"+" Expected Vehicle Class:"+Parameters.Expected_Class+" Actual Vehicle Class:"+V_Cls);
					DataManager.writeData(path,row, 4, "Fail");
				}
				RM.captureScreenShot(docx,run,out);
				vc.SaveButton.click();
				Thread.sleep(4000);
			}
			
		}catch(Exception e){
			System.out.println("Failed to verify vehicle");
		}
	}

	
	
}
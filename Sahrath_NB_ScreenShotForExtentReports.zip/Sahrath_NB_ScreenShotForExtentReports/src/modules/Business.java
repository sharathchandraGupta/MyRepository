package modules;

import java.io.FileOutputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import utils.Parameters;
import utils.Reusable_Methods;

public class Business {
	WebDriver driver;
	pages.Business b;
	Reusable_Methods RM;

	public Business(WebDriver webdriver) {
		driver = webdriver;
		b = new pages.Business(driver);


		RM = new Reusable_Methods(driver);

	}

	public void business(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws InterruptedException {
		try {
			b.propertyLiabilityClaims.sendKeys(Parameters.propertyLiabilityClaims);
			Thread.sleep(2000);
			b.propertyLiabilityClaims.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			b.PowerUnits.sendKeys(Parameters.PowerUnits);
			b.PowerUnits.sendKeys(Keys.TAB);
			if (Parameters.MultiLinePolicy.equalsIgnoreCase("NO"))
				driver.findElement(By.xpath("//*[@fieldref='PolicyInput.MultiLinePolicyIndicator'][@value='0']")).click();
			RM.captureScreenShot(docx,run,out);
						
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,1500)");	
			driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
			Thread.sleep(6000);
		} catch (Exception e) {
			System.out.println("Failed to Enter Details of Business");
			e.printStackTrace();
		}
	}

}

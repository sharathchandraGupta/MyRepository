package modules;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import utils.Parameters;

public class Billing {
	
	Parameters parameter = new Parameters();
	WebDriver driver;
	pages.Billing B;
	ExtentReports extent;
	ExtentTest test;
	
	public Billing(WebDriver webdriver) {
		driver=webdriver;
		B=new pages.Billing(driver);
	}
	
	
	public void Billing() throws InterruptedException
	{	
		B.Next_Button.click();
		
	}
}



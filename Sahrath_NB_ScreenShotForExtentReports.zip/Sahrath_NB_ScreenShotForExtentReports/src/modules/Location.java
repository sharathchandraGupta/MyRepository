package modules;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.Parameters;

public class Location {
	WebDriver driver;
	pages.Location l;

	public Location(WebDriver webdriver) {
		driver = webdriver;
		l = new pages.Location(driver);

	}

	public void location() throws InterruptedException {
		// l.getTownGrade.click();
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Get Town Grade')]")).click();
		Thread.sleep(8000);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1500)");
		
		l.typeOfConstruction.sendKeys(Parameters.typeOfConstruction);
		l.typeOfConstruction.sendKeys(Keys.TAB);

		Thread.sleep(2000);
		l.noOfStoreys.sendKeys(Integer.toString(Parameters.noOfStoreys));

		l.yearBuilt.sendKeys(Integer.toString(Parameters.yearBuilt));

		l.area.sendKeys(Integer.toString(Parameters.area));
		Thread.sleep(2000);
		if(Parameters.BuildingLimit!=0){
			if(!l.BuildingIndicatorCheckbox.isSelected()){
				l.BuildingIndicatorCheckbox.click();
				Thread.sleep(2000);
				l.CovBuildingLimitInput.sendKeys(Integer.toString(Parameters.BuildingLimit));
				l.CovBuildingLimitInput.sendKeys(Keys.TAB);
				Thread.sleep(2000);
			}
		}
		
		if(Parameters.BusinessPersonalProperty!=0){
			l.BusinessPersonalProperty.clear();			
			Thread.sleep(1000);	
			l.BusinessPersonalProperty.sendKeys(Integer.toString(Parameters.BusinessPersonalProperty));
			l.BusinessPersonalProperty.sendKeys(Keys.TAB);
			Thread.sleep(2000);
		}
		
		
		
		
//		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1500)");
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
		Thread.sleep(7000);
	}

}

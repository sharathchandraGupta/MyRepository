import java.util.Iterator;
import java.util.LinkedList;

import org.testng.Assert;
import org.testng.annotations.Test;

@Test
public class E {
 
	public void name() {
		System.out.println("AM in E");
		Assert.assertEquals("Sharath", "Sharath");
	
		
	
	}
	
	
	
	
 	
}

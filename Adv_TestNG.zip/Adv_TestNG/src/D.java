import org.testng.Assert;
import org.testng.annotations.Test;

@Test//(retryAnalyzer = RetryAnalyzer.class)
public class D {
 
	public void name() {
		System.out.println("Am in D");
		Assert.assertEquals("Sharath", "Bharath");
	
	}
	
}

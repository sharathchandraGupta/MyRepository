import org.testng.Assert;
import org.testng.annotations.Test;

@Test//(retryAnalyzer = RetryAnalyzer.class)
public class C {
 
	public void name() {
		System.out.println("Am in C");
		Assert.assertEquals("Sharath", "Sharath");
	
	}
	
}

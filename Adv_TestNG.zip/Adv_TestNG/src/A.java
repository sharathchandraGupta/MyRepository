import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
@Test
public class A {
 
	public void name() {
		System.out.println("Am in A");
		Assert.assertEquals("Sharath", "Sharath");
	
		File file = null ;
		File file2 = null ;
		
		try {
			FileUtils.copyFile(file, file2);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}

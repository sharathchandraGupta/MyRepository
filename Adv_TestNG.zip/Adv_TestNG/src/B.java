import org.testng.Assert;
import org.testng.annotations.Test;

@Test//(retryAnalyzer = RetryAnalyzer.class)
public class B {
 
	public void name() {
		System.out.println("Am in B");
		Assert.assertEquals("Sharath", "Sharath");
	
	}
	
}
